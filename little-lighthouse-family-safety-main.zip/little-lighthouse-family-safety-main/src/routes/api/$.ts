import { createFileRoute } from "@tanstack/react-router";
import { handleApiRequest, type DBState } from "@/server/safekids-api";

async function getAdmin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

async function load(): Promise<DBState | null> {
  const admin = await getAdmin();
  const { data, error } = await admin.from("app_state").select("data").eq("id", 1).maybeSingle();
  if (error) throw error;
  return (data?.data as unknown as DBState) ?? null;
}

async function save(state: DBState): Promise<void> {
  const admin = await getAdmin();
  const { error } = await admin
    .from("app_state")
    .upsert({ id: 1, data: state as never, updated_at: new Date().toISOString() });
  if (error) throw error;
}

const handle = async ({ request }: { request: Request }) => {
  try {
    return await handleApiRequest(request, load, save);
  } catch (err) {
    console.error("SafeKids API error", err);
    return Response.json({ success: false, error: "Server error" }, { status: 500 });
  }
};

export const Route = createFileRoute("/api/$")({
  server: { handlers: { GET: handle, POST: handle } },
});
