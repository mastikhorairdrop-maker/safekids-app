# Little Lighthouse Family Safety

इसमें जो process हैं, वो सब चाहिए और एकदम अच्छा बनाओ जिसमें कोई error ना है।

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://little-lighthouse-family-safety.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/7ada5c70-6ed0-47b2-82ff-e7f56927409c).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
