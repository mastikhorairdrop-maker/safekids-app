package com.safekids.parentalcontrol.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class SafeKidsAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val packageName = event.packageName?.toString() ?: return
        if (packageName == applicationContext.packageName) return

        // Anti-Uninstall Guard: Block settings tampering and package uninstaller
        if (packageName == "com.android.settings" || packageName.contains("packageinstaller")) {
            val textContent = event.text.joinToString(" ").lowercase()
            if (textContent.contains("safekids") && (textContent.contains("uninstall") || textContent.contains("force stop") || textContent.contains("deactivate"))) {
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
        }
    }

    override fun onInterrupt() {}
}