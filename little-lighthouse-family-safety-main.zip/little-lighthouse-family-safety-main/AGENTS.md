<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- SafeKids state lives in one JSON row (`public.app_state`, id=1) read/written only server-side by `src/routes/api/$.ts` via `src/server/safekids-api.ts`; why: faithful port of the original single-file Express/JSON-DB backend so the frontend `/api/*` calls stay unchanged.

- First launch gates the app: role choice (parent/child), then parent Master PIN login or child pairing + app-lock PIN; role and pairing persist in localStorage. Why: one app binary serves both parent and child devices.
