# SafeKids — 100% Free Parental Control App (SafeKids पैरेंटल कंट्रोल)

SafeKids ek 100% free, open-source parental control application hai jo Android first design ki gayi hai. Isme koi paid subscription ya paywall nahi hai.

## 🚀 Features (मुख्य विशेषताएं):
1. **Live GPS & Safe Zones (लाइव लोकेशन व सेफ जोन)**: OpenStreetMap par live GPS tracking aur Home, School, Park jaise safe zones enter/exit notification.
2. **Emergency SOS Siren (आपातकालीन एसओएस)**: Bachha ek tap se SOS siren baja sakta hai aur parents ko instant alert & GPS coordinates bheje jaate hain.
3. **Screen Time & Bedtime Limits (स्क्रीन टाइम और सोने का समय)**: Daily screen-time limits, raat ko bedtime lock aur bachhe dwara "Ask for +30m" request flow.
4. **App Blocker (ऐप लॉकर)**: YouTube, TikTok, Roblox ya games ko ek click me block/unlock karein.
5. **Web Filter & SafeSearch (वेबसाइट फिल्टर)**: Adult, gambling, violence websites block aur curated educational bookmarks (Wikipedia, NASA, PBS Kids).
6. **Remote Live Look-In & Screen Share (कैमरा व स्क्रीन शेयर)**: Child consent-based transparent check-in (Google Play Policies compliant, no spyware).
7. **Two-Way Intercom (मैसेजिंग)**: Parents aur bachhe ke beech instant check-in messages.
8. **Native Android Source Code (एंड्रॉइड नेटिव कोड)**: Kotlin AccessibilityService, DeviceAdminReceiver, LocationForegroundService, MediaProjection aur AndroidManifest.xml included!

---

## 💻 How to Run (चलाने का तरीका):

### 1. Requirements:
- Node.js 18 ya higher (https://nodejs.org)
- Terminal / Command Prompt

### 2. Steps:
```bash
# 1. Project folder me jayein
cd safekids-parental-control

# 2. Dependencies install karein
npm install

# 3. Development server start karein
npm run dev
```

Ab apne browser me **http://localhost:3000** open karein!

---

## 📱 Android App Build (Android APK / AAB):
`android/` folder me sabhi Kotlin source files aur AndroidManifest.xml available hain:
- Android Studio me project open karein.
- `./gradlew assembleDebug` run karke debug APK banayein.
- `./gradlew bundleRelease` se Google Play Store AAB banayein.

Default Parent Master PIN: **1234**
