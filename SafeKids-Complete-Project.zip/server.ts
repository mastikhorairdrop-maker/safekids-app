const express = __vite__cjsImport0_express;const JSZip = __vite__cjsImport5_jszip;const fileURLToPath = __vite__cjsImport4_url["fileURLToPath"];import __vite__cjsImport0_express from "/node_modules/.vite/deps/express.js?v=d3d47fa4";
import { createServer as createViteServer } from "/node_modules/.vite/deps/vite.js?v=d3d47fa4";
import fs from "/@id/__vite-browser-external:fs";
import path from "/@id/__vite-browser-external:path";
import __vite__cjsImport4_url from "/@id/__vite-browser-external:url";
import __vite__cjsImport5_jszip from "/node_modules/.vite/deps/jszip.js?v=d3d47fa4";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.join(__dirname, "data");
const DB_FILE = path.join(DATA_DIR, "safekids-db.json");
// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
	fs.mkdirSync(DATA_DIR, { recursive: true });
}
const DEFAULT_STATE = {
	parentPin: "1234",
	parentEmail: "parent@safekids.local",
	children: [{
		id: "child-leo",
		name: "Leo",
		age: 10,
		avatar: "👦",
		deviceModel: "Pixel 8a (Android 14)",
		osVersion: "Android 14 (API 34)",
		batteryLevel: 78,
		isCharging: false,
		isOnline: true,
		lastSeen: new Date().toISOString(),
		location: {
			latitude: 37.7749,
			longitude: -122.4194,
			accuracy: 12,
			speed: 1.2,
			timestamp: new Date().toISOString(),
			address: "Market St & 4th, San Francisco, CA"
		},
		locationHistory: [
			{
				latitude: 37.7749,
				longitude: -122.4194,
				timestamp: new Date(Date.now() - 5 * 6e4).toISOString(),
				address: "Market St & 4th, San Francisco, CA"
			},
			{
				latitude: 37.7758,
				longitude: -122.4182,
				timestamp: new Date(Date.now() - 25 * 6e4).toISOString(),
				address: "Mission St & 3rd, San Francisco, CA"
			},
			{
				latitude: 37.7765,
				longitude: -122.417,
				timestamp: new Date(Date.now() - 55 * 6e4).toISOString(),
				address: "Howard St & 3rd, San Francisco, CA"
			}
		],
		screenTime: {
			todayUsageMinutes: 85,
			dailyLimitMinutes: 120,
			bedtimeStart: "20:30",
			bedtimeEnd: "07:00",
			bedtimeEnforced: true,
			appRules: [
				{
					packageName: "com.google.android.youtube",
					appName: "YouTube",
					category: "video",
					status: "limited",
					dailyLimitMinutes: 45,
					usedTodayMinutes: 30,
					iconName: "Youtube"
				},
				{
					packageName: "com.roblox.client",
					appName: "Roblox",
					category: "games",
					status: "locked",
					dailyLimitMinutes: 30,
					usedTodayMinutes: 20,
					iconName: "Gamepad2"
				},
				{
					packageName: "com.zhiliaoapp.musically",
					appName: "TikTok",
					category: "social",
					status: "locked",
					dailyLimitMinutes: 0,
					usedTodayMinutes: 0,
					iconName: "Share2"
				},
				{
					packageName: "com.duolingo",
					appName: "Duolingo",
					category: "education",
					status: "allowed",
					dailyLimitMinutes: 60,
					usedTodayMinutes: 15,
					iconName: "BookOpen"
				},
				{
					packageName: "org.khanacademy.android",
					appName: "Khan Academy",
					category: "education",
					status: "allowed",
					dailyLimitMinutes: 120,
					usedTodayMinutes: 20,
					iconName: "GraduationCap"
				},
				{
					packageName: "com.android.chrome",
					appName: "Safe Chrome",
					category: "browsing",
					status: "allowed",
					dailyLimitMinutes: 60,
					usedTodayMinutes: 0,
					iconName: "Compass"
				}
			]
		},
		webFilter: {
			safeSearchEnabled: true,
			blockedCategories: [
				"adult",
				"gambling",
				"violence",
				"weapons",
				"dating"
			],
			blockedDomains: [
				"tiktok.com",
				"omegle.com",
				"discord.com",
				"chatroulette.com"
			],
			allowedDomains: [
				"wikipedia.org",
				"khanacademy.org",
				"nationalgeographic.com",
				"scratch.mit.edu",
				"nasa.gov"
			]
		},
		antiUninstall: {
			deviceAdminEnabled: true,
			accessibilityLockEnabled: true,
			preventSettingsTamper: true,
			uninstallAttemptsCount: 0
		},
		safeZones: [
			{
				id: "zone-home",
				name: "Home",
				latitude: 37.7749,
				longitude: -122.4194,
				radiusMeters: 200,
				icon: "Home",
				enabled: true
			},
			{
				id: "zone-school",
				name: "Lincoln Middle School",
				latitude: 37.778,
				longitude: -122.415,
				radiusMeters: 300,
				icon: "School",
				enabled: true
			},
			{
				id: "zone-park",
				name: "Yerba Buena Park",
				latitude: 37.785,
				longitude: -122.402,
				radiusMeters: 250,
				icon: "Trees",
				enabled: true
			}
		],
		activeSessions: {}
	}, {
		id: "child-maya",
		name: "Maya",
		age: 7,
		avatar: "👧",
		deviceModel: "Samsung Galaxy Tab A9",
		osVersion: "Android 13 (One UI 5.1)",
		batteryLevel: 42,
		isCharging: true,
		isOnline: true,
		lastSeen: new Date().toISOString(),
		location: {
			latitude: 37.7749,
			longitude: -122.4194,
			accuracy: 8,
			speed: 0,
			timestamp: new Date().toISOString(),
			address: "Home (Safe Zone)"
		},
		locationHistory: [{
			latitude: 37.7749,
			longitude: -122.4194,
			timestamp: new Date(Date.now() - 10 * 6e4).toISOString(),
			address: "Home (Safe Zone)"
		}],
		screenTime: {
			todayUsageMinutes: 45,
			dailyLimitMinutes: 60,
			bedtimeStart: "19:45",
			bedtimeEnd: "07:30",
			bedtimeEnforced: true,
			appRules: [
				{
					packageName: "com.google.android.apps.youtube.kids",
					appName: "YouTube Kids",
					category: "video",
					status: "limited",
					dailyLimitMinutes: 30,
					usedTodayMinutes: 25,
					iconName: "Youtube"
				},
				{
					packageName: "com.tocaboca.tocalifeworld",
					appName: "Toca Life World",
					category: "games",
					status: "allowed",
					dailyLimitMinutes: 30,
					usedTodayMinutes: 15,
					iconName: "Gamepad2"
				},
				{
					packageName: "com.duolingo.kids",
					appName: "Duolingo ABC",
					category: "education",
					status: "allowed",
					dailyLimitMinutes: 60,
					usedTodayMinutes: 5,
					iconName: "BookOpen"
				}
			]
		},
		webFilter: {
			safeSearchEnabled: true,
			blockedCategories: [
				"adult",
				"gambling",
				"violence",
				"social",
				"gaming"
			],
			blockedDomains: ["youtube.com", "roblox.com"],
			allowedDomains: [
				"pbskids.org",
				"starfall.com",
				"natgeokids.com"
			]
		},
		antiUninstall: {
			deviceAdminEnabled: true,
			accessibilityLockEnabled: true,
			preventSettingsTamper: true,
			uninstallAttemptsCount: 0
		},
		safeZones: [{
			id: "zone-home",
			name: "Home",
			latitude: 37.7749,
			longitude: -122.4194,
			radiusMeters: 200,
			icon: "Home",
			enabled: true
		}],
		activeSessions: {}
	}],
	alerts: [{
		id: "alert-1",
		childId: "child-leo",
		childName: "Leo",
		type: "geofence_enter",
		title: "Entered Safe Zone: Home",
		message: "Leo arrived safely inside Home safe zone.",
		timestamp: new Date(Date.now() - 40 * 6e4).toISOString(),
		severity: "info",
		read: true,
		coordinates: {
			latitude: 37.7749,
			longitude: -122.4194
		}
	}, {
		id: "alert-2",
		childId: "child-leo",
		childName: "Leo",
		type: "blocked_site",
		title: "Blocked Website Attempt",
		message: "Leo attempted to open discord.com, blocked by Web Filter.",
		timestamp: new Date(Date.now() - 15 * 6e4).toISOString(),
		severity: "warning",
		read: false
	}],
	messages: [{
		id: "msg-1",
		childId: "child-leo",
		sender: "parent",
		text: "Remember soccer practice at 4:30 PM today!",
		timestamp: new Date(Date.now() - 60 * 6e4).toISOString()
	}, {
		id: "msg-2",
		childId: "child-leo",
		sender: "child",
		text: "Got it Dad! Have my cleats packed.",
		timestamp: new Date(Date.now() - 50 * 6e4).toISOString()
	}],
	pairingCodes: []
};
// Database helper functions
function loadDB() {
	try {
		if (fs.existsSync(DB_FILE)) {
			const data = fs.readFileSync(DB_FILE, "utf-8");
			const parsed = JSON.parse(data);
			parsed.children.forEach((c) => {
				if (!c.antiUninstall) {
					c.antiUninstall = {
						deviceAdminEnabled: true,
						accessibilityLockEnabled: true,
						preventSettingsTamper: true,
						uninstallAttemptsCount: 0
					};
				}
			});
			return parsed;
		}
	} catch (err) {
		console.error("Error loading DB file, initializing default:", err);
	}
	saveDB(DEFAULT_STATE);
	return DEFAULT_STATE;
}
function saveDB(state) {
	try {
		fs.writeFileSync(DB_FILE, JSON.stringify(state, null, 2), "utf-8");
	} catch (err) {
		console.error("Error writing DB file:", err);
	}
}
let db = loadDB();
async function startServer() {
	const app = express();
	app.use(express.json());
	// API Endpoints
	// 1. Get full state
	app.get("/api/state", (req, res) => {
		res.json(db);
	});
	// Download entire project as a ZIP archive
	app.get("/api/download-zip", async (req, res) => {
		try {
			const zip = new JSZip();
			const addDirectoryToZip = (dirPath, zipFolder) => {
				const items = fs.readdirSync(dirPath);
				for (const item of items) {
					if (item === "node_modules" || item === ".git" || item === "dist" || item === ".cache" || item === ".aistudio") {
						continue;
					}
					const fullPath = path.join(dirPath, item);
					const stat = fs.statSync(fullPath);
					if (stat.isDirectory()) {
						const nextFolder = zipFolder.folder(item);
						if (nextFolder) addDirectoryToZip(fullPath, nextFolder);
					} else {
						const fileContent = fs.readFileSync(fullPath);
						zipFolder.file(item, fileContent);
					}
				}
			};
			addDirectoryToZip(__dirname, zip);
			const buffer = await zip.generateAsync({
				type: "nodebuffer",
				compression: "DEFLATE"
			});
			res.setHeader("Content-Type", "application/zip");
			res.setHeader("Content-Disposition", "attachment; filename=\"SafeKids-Complete-Project.zip\"");
			res.setHeader("Content-Length", buffer.length);
			return res.send(buffer);
		} catch (err) {
			console.error("Error generating zip:", err);
			return res.status(500).json({ error: "Failed to generate zip file" });
		}
	});
	// 2. Verify or update Parent PIN
	app.post("/api/auth/verify-pin", (req, res) => {
		const { pin } = req.body;
		if (pin === db.parentPin) {
			return res.json({ success: true });
		}
		return res.status(401).json({
			success: false,
			error: "Incorrect PIN"
		});
	});
	app.post("/api/auth/update-pin", (req, res) => {
		const { currentPin, newPin } = req.body;
		if (currentPin !== db.parentPin) {
			return res.status(401).json({
				success: false,
				error: "Current PIN is invalid"
			});
		}
		if (!newPin || newPin.length < 4) {
			return res.status(400).json({
				success: false,
				error: "New PIN must be at least 4 digits"
			});
		}
		db.parentPin = newPin;
		saveDB(db);
		res.json({
			success: true,
			message: "PIN updated successfully"
		});
	});
	// 3. Child Pairing Endpoints
	app.post("/api/pair/generate", (req, res) => {
		const { childName, age, deviceModel } = req.body;
		const code = Math.floor(1e5 + Math.random() * 9e5).toString();
		const expiresAt = Date.now() + 15 * 60 * 1e3;
		// create or find child
		let childId = `child-${Date.now().toString(36)}`;
		const newChild = {
			id: childId,
			name: childName || "New Child",
			age: age || 8,
			avatar: "🧒",
			deviceModel: deviceModel || "Android Phone",
			osVersion: "Android 14 (API 34)",
			batteryLevel: 90,
			isCharging: false,
			isOnline: false,
			lastSeen: new Date().toISOString(),
			location: {
				latitude: 37.7749,
				longitude: -122.4194,
				accuracy: 10,
				speed: 0,
				timestamp: new Date().toISOString(),
				address: "Standby / Waiting for GPS"
			},
			locationHistory: [],
			screenTime: {
				todayUsageMinutes: 0,
				dailyLimitMinutes: 120,
				bedtimeStart: "21:00",
				bedtimeEnd: "07:00",
				bedtimeEnforced: true,
				appRules: [
					{
						packageName: "com.google.android.youtube",
						appName: "YouTube",
						category: "video",
						status: "limited",
						dailyLimitMinutes: 45,
						usedTodayMinutes: 0,
						iconName: "Youtube"
					},
					{
						packageName: "com.roblox.client",
						appName: "Roblox",
						category: "games",
						status: "locked",
						dailyLimitMinutes: 30,
						usedTodayMinutes: 0,
						iconName: "Gamepad2"
					},
					{
						packageName: "com.duolingo",
						appName: "Duolingo",
						category: "education",
						status: "allowed",
						dailyLimitMinutes: 60,
						usedTodayMinutes: 0,
						iconName: "BookOpen"
					}
				]
			},
			webFilter: {
				safeSearchEnabled: true,
				blockedCategories: [
					"adult",
					"gambling",
					"violence"
				],
				blockedDomains: [],
				allowedDomains: []
			},
			antiUninstall: {
				deviceAdminEnabled: true,
				accessibilityLockEnabled: true,
				preventSettingsTamper: true,
				uninstallAttemptsCount: 0
			},
			safeZones: [{
				id: "zone-home",
				name: "Home",
				latitude: 37.7749,
				longitude: -122.4194,
				radiusMeters: 200,
				icon: "Home",
				enabled: true
			}],
			activeSessions: {}
		};
		db.children.push(newChild);
		db.pairingCodes.push({
			code,
			childId,
			expiresAt
		});
		saveDB(db);
		res.json({
			code,
			childId,
			expiresAt
		});
	});
	app.post("/api/pair/claim", (req, res) => {
		const { code, deviceModel, osVersion } = req.body;
		const now = Date.now();
		const entryIndex = db.pairingCodes.findIndex((p) => p.code === code && p.expiresAt > now);
		if (entryIndex === -1) {
			return res.status(400).json({
				success: false,
				error: "Invalid or expired pairing code"
			});
		}
		const { childId } = db.pairingCodes[entryIndex];
		const child = db.children.find((c) => c.id === childId);
		if (!child) {
			return res.status(404).json({
				success: false,
				error: "Child record not found"
			});
		}
		child.isOnline = true;
		child.lastSeen = new Date().toISOString();
		if (deviceModel) child.deviceModel = deviceModel;
		if (osVersion) child.osVersion = osVersion;
		// remove claimed code
		db.pairingCodes.splice(entryIndex, 1);
		saveDB(db);
		res.json({
			success: true,
			childId,
			childName: child.name
		});
	});
	// 4. Update child device status & GPS location
	app.post("/api/child/:id/heartbeat", (req, res) => {
		const { id } = req.params;
		const { batteryLevel, isCharging, location, screenTimeDeltaMinutes } = req.body;
		const child = db.children.find((c) => c.id === id);
		if (!child) {
			return res.status(404).json({ error: "Child not found" });
		}
		child.isOnline = true;
		child.lastSeen = new Date().toISOString();
		if (batteryLevel !== undefined) child.batteryLevel = batteryLevel;
		if (isCharging !== undefined) child.isCharging = isCharging;
		if (screenTimeDeltaMinutes) {
			child.screenTime.todayUsageMinutes += screenTimeDeltaMinutes;
		}
		if (location && location.latitude && location.longitude) {
			child.location = {
				latitude: location.latitude,
				longitude: location.longitude,
				accuracy: location.accuracy || 10,
				speed: location.speed ?? null,
				timestamp: new Date().toISOString(),
				address: location.address || `${location.latitude.toFixed(4)}, ${location.longitude.toFixed(4)}`
			};
			// Add to location history (keep last 50)
			child.locationHistory.unshift({
				latitude: location.latitude,
				longitude: location.longitude,
				timestamp: child.location.timestamp,
				address: child.location.address
			});
			if (child.locationHistory.length > 50) {
				child.locationHistory.pop();
			}
			// Check geofence status
			child.safeZones.forEach((zone) => {
				if (!zone.enabled) return;
				const dist = haversineDistance(location.latitude, location.longitude, zone.latitude, zone.longitude);
				const isInside = dist <= zone.radiusMeters;
				// In full flow we check transitions, here we can log if enter/exit
			});
		}
		// Low battery alert check
		if (child.batteryLevel <= 15 && !child.isCharging) {
			const recentBatteryAlert = db.alerts.find((a) => a.childId === child.id && a.type === "low_battery" && Date.now() - new Date(a.timestamp).getTime() < 30 * 6e4);
			if (!recentBatteryAlert) {
				db.alerts.unshift({
					id: `alert-${Date.now()}`,
					childId: child.id,
					childName: child.name,
					type: "low_battery",
					title: `Low Battery: ${child.name}'s Device (${child.batteryLevel}%)`,
					message: `${child.name}'s device is at ${child.batteryLevel}%. Please prompt them to charge their device.`,
					timestamp: new Date().toISOString(),
					severity: "warning",
					read: false
				});
			}
		}
		saveDB(db);
		res.json({
			success: true,
			child,
			commands: {
				activeCameraSession: child.activeSessions.cameraRequest,
				activeScreenSession: child.activeSessions.screenRequest,
				timeExtension: child.timeExtensionRequest,
				appRules: child.screenTime.appRules,
				dailyLimitMinutes: child.screenTime.dailyLimitMinutes,
				bedtimeStart: child.screenTime.bedtimeStart,
				bedtimeEnd: child.screenTime.bedtimeEnd,
				bedtimeEnforced: child.screenTime.bedtimeEnforced,
				webFilter: child.webFilter
			}
		});
	});
	// 5. Trigger SOS from child
	app.post("/api/child/:id/sos", (req, res) => {
		const { id } = req.params;
		const { latitude, longitude, audioSnippet } = req.body;
		const child = db.children.find((c) => c.id === id);
		const childName = child ? child.name : "Child";
		const alert = {
			id: `sos-${Date.now()}`,
			childId: id,
			childName,
			type: "sos",
			title: `🚨 EMERGENCY SOS ACTIVATED BY ${childName.toUpperCase()}`,
			message: `${childName} pressed the emergency SOS button! Immediate attention required.`,
			timestamp: new Date().toISOString(),
			severity: "critical",
			read: false,
			coordinates: latitude && longitude ? {
				latitude,
				longitude
			} : child?.location
		};
		db.alerts.unshift(alert);
		saveDB(db);
		res.json({
			success: true,
			alert
		});
	});
	// 6. Camera Request Endpoints (Consent-based)
	app.post("/api/child/:id/camera-request", (req, res) => {
		const { id } = req.params;
		const { facingMode, reason } = req.body;
		const child = db.children.find((c) => c.id === id);
		if (!child) return res.status(404).json({ error: "Child not found" });
		child.activeSessions.cameraRequest = {
			id: `cam-${Date.now()}`,
			requestedAt: new Date().toISOString(),
			status: "pending",
			facingMode: facingMode || "user",
			reason: reason || "Parent check-in"
		};
		saveDB(db);
		res.json({
			success: true,
			session: child.activeSessions.cameraRequest
		});
	});
	app.post("/api/child/:id/camera-respond", (req, res) => {
		const { id } = req.params;
		const { status } = req.body;
		const child = db.children.find((c) => c.id === id);
		if (!child || !child.activeSessions.cameraRequest) {
			return res.status(404).json({ error: "Session not found" });
		}
		child.activeSessions.cameraRequest.status = status;
		if (status === "ended") {
			delete child.activeSessions.cameraRequest;
		}
		saveDB(db);
		res.json({ success: true });
	});
	// 7. Screen Sharing Request Endpoints (Consent-based)
	app.post("/api/child/:id/screen-request", (req, res) => {
		const { id } = req.params;
		const { reason } = req.body;
		const child = db.children.find((c) => c.id === id);
		if (!child) return res.status(404).json({ error: "Child not found" });
		child.activeSessions.screenRequest = {
			id: `screen-${Date.now()}`,
			requestedAt: new Date().toISOString(),
			status: "pending",
			reason: reason || "Parent live screen review"
		};
		saveDB(db);
		res.json({
			success: true,
			session: child.activeSessions.screenRequest
		});
	});
	app.post("/api/child/:id/screen-respond", (req, res) => {
		const { id } = req.params;
		const { status } = req.body;
		const child = db.children.find((c) => c.id === id);
		if (!child || !child.activeSessions.screenRequest) {
			return res.status(404).json({ error: "Session not found" });
		}
		child.activeSessions.screenRequest.status = status;
		if (status === "ended") {
			delete child.activeSessions.screenRequest;
		}
		saveDB(db);
		res.json({ success: true });
	});
	// 8. Time extension request
	app.post("/api/child/:id/time-request", (req, res) => {
		const { id } = req.params;
		const { minutes, reason } = req.body;
		const child = db.children.find((c) => c.id === id);
		if (!child) return res.status(404).json({ error: "Child not found" });
		child.timeExtensionRequest = {
			id: `req-${Date.now()}`,
			minutes: minutes || 30,
			reason: reason || "Homework / Finishing project",
			requestedAt: new Date().toISOString(),
			status: "pending"
		};
		db.alerts.unshift({
			id: `alert-time-${Date.now()}`,
			childId: child.id,
			childName: child.name,
			type: "time_request",
			title: `Screen Time Extension Request: ${child.name}`,
			message: `${child.name} is requesting ${minutes || 30} extra minutes. Reason: "${reason || "Schoolwork"}"`,
			timestamp: new Date().toISOString(),
			severity: "info",
			read: false
		});
		saveDB(db);
		res.json({
			success: true,
			request: child.timeExtensionRequest
		});
	});
	app.post("/api/child/:id/time-respond", (req, res) => {
		const { id } = req.params;
		const { status, grantedMinutes } = req.body;
		const child = db.children.find((c) => c.id === id);
		if (!child) return res.status(404).json({ error: "Child not found" });
		if (child.timeExtensionRequest) {
			child.timeExtensionRequest.status = status;
			if (status === "approved" && grantedMinutes) {
				child.screenTime.dailyLimitMinutes += grantedMinutes;
			}
		}
		saveDB(db);
		res.json({
			success: true,
			dailyLimitMinutes: child.screenTime.dailyLimitMinutes
		});
	});
	// 9. Update Screen Time Limits & Bedtime
	app.post("/api/child/:id/screen-limits", (req, res) => {
		const { id } = req.params;
		const { dailyLimitMinutes, bedtimeStart, bedtimeEnd, bedtimeEnforced } = req.body;
		const child = db.children.find((c) => c.id === id);
		if (!child) return res.status(404).json({ error: "Child not found" });
		if (dailyLimitMinutes !== undefined) child.screenTime.dailyLimitMinutes = dailyLimitMinutes;
		if (bedtimeStart !== undefined) child.screenTime.bedtimeStart = bedtimeStart;
		if (bedtimeEnd !== undefined) child.screenTime.bedtimeEnd = bedtimeEnd;
		if (bedtimeEnforced !== undefined) child.screenTime.bedtimeEnforced = bedtimeEnforced;
		saveDB(db);
		res.json({
			success: true,
			screenTime: child.screenTime
		});
	});
	// 10. Update App Rule
	app.post("/api/child/:id/app-rule", (req, res) => {
		const { id } = req.params;
		const { packageName, status, dailyLimitMinutes } = req.body;
		const child = db.children.find((c) => c.id === id);
		if (!child) return res.status(404).json({ error: "Child not found" });
		const rule = child.screenTime.appRules.find((r) => r.packageName === packageName);
		if (rule) {
			if (status) rule.status = status;
			if (dailyLimitMinutes !== undefined) rule.dailyLimitMinutes = dailyLimitMinutes;
		}
		saveDB(db);
		res.json({
			success: true,
			appRules: child.screenTime.appRules
		});
	});
	// 11. Update Web Filter Settings
	app.post("/api/child/:id/web-filter", (req, res) => {
		const { id } = req.params;
		const { safeSearchEnabled, blockedCategories, blockedDomains, allowedDomains } = req.body;
		const child = db.children.find((c) => c.id === id);
		if (!child) return res.status(404).json({ error: "Child not found" });
		if (safeSearchEnabled !== undefined) child.webFilter.safeSearchEnabled = safeSearchEnabled;
		if (blockedCategories) child.webFilter.blockedCategories = blockedCategories;
		if (blockedDomains) child.webFilter.blockedDomains = blockedDomains;
		if (allowedDomains) child.webFilter.allowedDomains = allowedDomains;
		saveDB(db);
		res.json({
			success: true,
			webFilter: child.webFilter
		});
	});
	// 12. Safe Zones Management
	app.post("/api/child/:id/safe-zones", (req, res) => {
		const { id } = req.params;
		const { safeZones } = req.body;
		const child = db.children.find((c) => c.id === id);
		if (!child) return res.status(404).json({ error: "Child not found" });
		child.safeZones = safeZones;
		saveDB(db);
		res.json({
			success: true,
			safeZones: child.safeZones
		});
	});
	// 12b. Anti-Uninstall and Device Admin Settings
	app.post("/api/child/:id/anti-uninstall", (req, res) => {
		const { id } = req.params;
		const { deviceAdminEnabled, accessibilityLockEnabled, preventSettingsTamper } = req.body;
		const child = db.children.find((c) => c.id === id);
		if (!child) return res.status(404).json({ error: "Child not found" });
		if (!child.antiUninstall) {
			child.antiUninstall = {
				deviceAdminEnabled: true,
				accessibilityLockEnabled: true,
				preventSettingsTamper: true,
				uninstallAttemptsCount: 0
			};
		}
		if (deviceAdminEnabled !== undefined) child.antiUninstall.deviceAdminEnabled = deviceAdminEnabled;
		if (accessibilityLockEnabled !== undefined) child.antiUninstall.accessibilityLockEnabled = accessibilityLockEnabled;
		if (preventSettingsTamper !== undefined) child.antiUninstall.preventSettingsTamper = preventSettingsTamper;
		saveDB(db);
		res.json({
			success: true,
			antiUninstall: child.antiUninstall
		});
	});
	// 12c. Report Tamper / Uninstall Attempt from Child Device
	app.post("/api/child/:id/report-tamper", (req, res) => {
		const { id } = req.params;
		const { attemptedAction, component } = req.body;
		const child = db.children.find((c) => c.id === id);
		if (!child) return res.status(404).json({ error: "Child not found" });
		if (!child.antiUninstall) {
			child.antiUninstall = {
				deviceAdminEnabled: true,
				accessibilityLockEnabled: true,
				preventSettingsTamper: true,
				uninstallAttemptsCount: 0
			};
		}
		child.antiUninstall.uninstallAttemptsCount += 1;
		child.antiUninstall.lastTamperAttempt = new Date().toISOString();
		const alert = {
			id: `tamper-${Date.now()}`,
			childId: child.id,
			childName: child.name,
			type: "tamper_attempt",
			title: `🚨 ANTI-UNINSTALL LOCK TRIGGERED: ${child.name}'s Device`,
			message: `An unauthorized attempt to ${attemptedAction || "uninstall SafeKids or revoke Device Admin"} was intercepted on ${child.deviceModel}. System was protected with Parent PIN lock.`,
			timestamp: new Date().toISOString(),
			severity: "critical",
			read: false
		};
		db.alerts.unshift(alert);
		saveDB(db);
		res.json({
			success: true,
			alert,
			uninstallAttemptsCount: child.antiUninstall.uninstallAttemptsCount
		});
	});
	// 13. Messages
	app.post("/api/messages", (req, res) => {
		const { childId, sender, text } = req.body;
		if (!childId || !text) return res.status(400).json({ error: "Missing parameters" });
		const msg = {
			id: `msg-${Date.now()}`,
			childId,
			sender,
			text,
			timestamp: new Date().toISOString()
		};
		db.messages.push(msg);
		saveDB(db);
		res.json({
			success: true,
			message: msg
		});
	});
	// 14. Mark alerts as read
	app.post("/api/alerts/mark-read", (req, res) => {
		const { id, all } = req.body;
		if (all) {
			db.alerts.forEach((a) => a.read = true);
		} else if (id) {
			const alert = db.alerts.find((a) => a.id === id);
			if (alert) alert.read = true;
		}
		saveDB(db);
		res.json({ success: true });
	});
	// 15. Create new child profile
	app.post("/api/children", (req, res) => {
		const { name, age, avatar, deviceModel } = req.body;
		const newChild = {
			id: `child-${Date.now()}`,
			name: name || "Child",
			age: age || 8,
			avatar: avatar || "🧒",
			deviceModel: deviceModel || "Android Phone",
			osVersion: "Android 14",
			batteryLevel: 100,
			isCharging: false,
			isOnline: true,
			lastSeen: new Date().toISOString(),
			location: {
				latitude: 37.7749,
				longitude: -122.4194,
				accuracy: 10,
				speed: 0,
				timestamp: new Date().toISOString(),
				address: "San Francisco, CA"
			},
			locationHistory: [],
			screenTime: {
				todayUsageMinutes: 0,
				dailyLimitMinutes: 120,
				bedtimeStart: "21:00",
				bedtimeEnd: "07:00",
				bedtimeEnforced: true,
				appRules: [
					{
						packageName: "com.google.android.youtube",
						appName: "YouTube",
						category: "video",
						status: "limited",
						dailyLimitMinutes: 45,
						usedTodayMinutes: 0,
						iconName: "Youtube"
					},
					{
						packageName: "com.roblox.client",
						appName: "Roblox",
						category: "games",
						status: "locked",
						dailyLimitMinutes: 30,
						usedTodayMinutes: 0,
						iconName: "Gamepad2"
					},
					{
						packageName: "com.duolingo",
						appName: "Duolingo",
						category: "education",
						status: "allowed",
						dailyLimitMinutes: 60,
						usedTodayMinutes: 0,
						iconName: "BookOpen"
					}
				]
			},
			webFilter: {
				safeSearchEnabled: true,
				blockedCategories: [
					"adult",
					"gambling",
					"violence"
				],
				blockedDomains: [],
				allowedDomains: []
			},
			antiUninstall: {
				deviceAdminEnabled: true,
				accessibilityLockEnabled: true,
				preventSettingsTamper: true,
				uninstallAttemptsCount: 0
			},
			safeZones: [{
				id: "zone-home",
				name: "Home",
				latitude: 37.7749,
				longitude: -122.4194,
				radiusMeters: 200,
				icon: "Home",
				enabled: true
			}],
			activeSessions: {}
		};
		db.children.push(newChild);
		saveDB(db);
		res.json({
			success: true,
			child: newChild
		});
	});
	// Haversine distance formula helper
	function haversineDistance(lat1, lon1, lat2, lon2) {
		const R = 6371e3;
		const dLat = (lat2 - lat1) * Math.PI / 180;
		const dLon = (lon2 - lon1) * Math.PI / 180;
		const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
		const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		return R * c;
	}
	// Mount Vite middleware in development
	const isProduction = "development" === "production";
	const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3e3;
	if (!isProduction) {
		const vite = await createViteServer({
			server: {
				middlewareMode: true,
				hmr: process.env.DISABLE_HMR !== "true"
			},
			appType: "spa"
		});
		app.use(vite.middlewares);
	} else {
		app.use(express.static(path.join(__dirname, "dist")));
		app.get("*", (req, res) => {
			res.sendFile(path.join(__dirname, "dist", "index.html"));
		});
	}
	app.listen(port, "0.0.0.0", () => {
		console.log(`SafeKids Server running on http://0.0.0.0:${port}`);
	});
}
startServer();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxhQUFhO0FBQ3BCLFNBQVMsZ0JBQWdCLHdCQUF3QjtBQUNqRCxPQUFPLFFBQVE7QUFDZixPQUFPLFVBQVU7QUFDakIsU0FBUyxxQkFBcUI7QUFDOUIsT0FBTyxXQUFXO0FBRWxCLE1BQU0sYUFBYSxjQUFjLFlBQVksR0FBRztBQUNoRCxNQUFNLFlBQVksS0FBSyxRQUFRLFVBQVU7QUFFekMsTUFBTSxXQUFXLEtBQUssS0FBSyxXQUFXLE1BQU07QUFDNUMsTUFBTSxVQUFVLEtBQUssS0FBSyxVQUFVLGtCQUFrQjs7QUFHdEQsSUFBSSxDQUFDLEdBQUcsV0FBVyxRQUFRLEdBQUc7Q0FDNUIsR0FBRyxVQUFVLFVBQVUsRUFBRSxXQUFXLEtBQUssQ0FBQztBQUM1QztBQWlJQSxNQUFNLGdCQUF5QjtDQUM3QixXQUFXO0NBQ1gsYUFBYTtDQUNiLFVBQVUsQ0FDUjtFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sS0FBSztFQUNMLFFBQVE7RUFDUixhQUFhO0VBQ2IsV0FBVztFQUNYLGNBQWM7RUFDZCxZQUFZO0VBQ1osVUFBVTtFQUNWLFVBQVUsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ2pDLFVBQVU7R0FDUixVQUFVO0dBQ1YsV0FBVyxDQUFDO0dBQ1osVUFBVTtHQUNWLE9BQU87R0FDUCxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUNsQyxTQUFTO0VBQ1g7RUFDQSxpQkFBaUI7R0FDZjtJQUFFLFVBQVU7SUFBUyxXQUFXLENBQUM7SUFBVSxXQUFXLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJLEdBQUssQ0FBQyxDQUFDLFlBQVk7SUFBRyxTQUFTO0dBQXFDO0dBQ3BKO0lBQUUsVUFBVTtJQUFTLFdBQVcsQ0FBQztJQUFVLFdBQVcsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssR0FBSyxDQUFDLENBQUMsWUFBWTtJQUFHLFNBQVM7R0FBc0M7R0FDdEo7SUFBRSxVQUFVO0lBQVMsV0FBVyxDQUFDO0lBQVUsV0FBVyxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksS0FBSyxHQUFLLENBQUMsQ0FBQyxZQUFZO0lBQUcsU0FBUztHQUFxQztFQUN2SjtFQUNBLFlBQVk7R0FDVixtQkFBbUI7R0FDbkIsbUJBQW1CO0dBQ25CLGNBQWM7R0FDZCxZQUFZO0dBQ1osaUJBQWlCO0dBQ2pCLFVBQVU7SUFDUjtLQUFFLGFBQWE7S0FBOEIsU0FBUztLQUFXLFVBQVU7S0FBUyxRQUFRO0tBQVcsbUJBQW1CO0tBQUksa0JBQWtCO0tBQUksVUFBVTtJQUFVO0lBQ3hLO0tBQUUsYUFBYTtLQUFxQixTQUFTO0tBQVUsVUFBVTtLQUFTLFFBQVE7S0FBVSxtQkFBbUI7S0FBSSxrQkFBa0I7S0FBSSxVQUFVO0lBQVc7SUFDOUo7S0FBRSxhQUFhO0tBQTRCLFNBQVM7S0FBVSxVQUFVO0tBQVUsUUFBUTtLQUFVLG1CQUFtQjtLQUFHLGtCQUFrQjtLQUFHLFVBQVU7SUFBUztJQUNsSztLQUFFLGFBQWE7S0FBZ0IsU0FBUztLQUFZLFVBQVU7S0FBYSxRQUFRO0tBQVcsbUJBQW1CO0tBQUksa0JBQWtCO0tBQUksVUFBVTtJQUFXO0lBQ2hLO0tBQUUsYUFBYTtLQUEyQixTQUFTO0tBQWdCLFVBQVU7S0FBYSxRQUFRO0tBQVcsbUJBQW1CO0tBQUssa0JBQWtCO0tBQUksVUFBVTtJQUFnQjtJQUNyTDtLQUFFLGFBQWE7S0FBc0IsU0FBUztLQUFlLFVBQVU7S0FBWSxRQUFRO0tBQVcsbUJBQW1CO0tBQUksa0JBQWtCO0tBQUcsVUFBVTtJQUFVO0dBQ3hLO0VBQ0Y7RUFDQSxXQUFXO0dBQ1QsbUJBQW1CO0dBQ25CLG1CQUFtQjtJQUFDO0lBQVM7SUFBWTtJQUFZO0lBQVc7R0FBUTtHQUN4RSxnQkFBZ0I7SUFBQztJQUFjO0lBQWM7SUFBZTtHQUFrQjtHQUM5RSxnQkFBZ0I7SUFBQztJQUFpQjtJQUFtQjtJQUEwQjtJQUFtQjtHQUFVO0VBQzlHO0VBQ0EsZUFBZTtHQUNiLG9CQUFvQjtHQUNwQiwwQkFBMEI7R0FDMUIsdUJBQXVCO0dBQ3ZCLHdCQUF3QjtFQUMxQjtFQUNBLFdBQVc7R0FDVDtJQUFFLElBQUk7SUFBYSxNQUFNO0lBQVEsVUFBVTtJQUFTLFdBQVcsQ0FBQztJQUFVLGNBQWM7SUFBSyxNQUFNO0lBQVEsU0FBUztHQUFLO0dBQ3pIO0lBQUUsSUFBSTtJQUFlLE1BQU07SUFBeUIsVUFBVTtJQUFTLFdBQVcsQ0FBQztJQUFVLGNBQWM7SUFBSyxNQUFNO0lBQVUsU0FBUztHQUFLO0dBQzlJO0lBQUUsSUFBSTtJQUFhLE1BQU07SUFBb0IsVUFBVTtJQUFTLFdBQVcsQ0FBQztJQUFVLGNBQWM7SUFBSyxNQUFNO0lBQVMsU0FBUztHQUFLO0VBQ3hJO0VBQ0EsZ0JBQWdCLENBQUM7Q0FDbkIsR0FDQTtFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sS0FBSztFQUNMLFFBQVE7RUFDUixhQUFhO0VBQ2IsV0FBVztFQUNYLGNBQWM7RUFDZCxZQUFZO0VBQ1osVUFBVTtFQUNWLFVBQVUsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ2pDLFVBQVU7R0FDUixVQUFVO0dBQ1YsV0FBVyxDQUFDO0dBQ1osVUFBVTtHQUNWLE9BQU87R0FDUCxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUNsQyxTQUFTO0VBQ1g7RUFDQSxpQkFBaUIsQ0FDZjtHQUFFLFVBQVU7R0FBUyxXQUFXLENBQUM7R0FBVSxXQUFXLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLEdBQUssQ0FBQyxDQUFDLFlBQVk7R0FBRyxTQUFTO0VBQW1CLENBQ3JJO0VBQ0EsWUFBWTtHQUNWLG1CQUFtQjtHQUNuQixtQkFBbUI7R0FDbkIsY0FBYztHQUNkLFlBQVk7R0FDWixpQkFBaUI7R0FDakIsVUFBVTtJQUNSO0tBQUUsYUFBYTtLQUF3QyxTQUFTO0tBQWdCLFVBQVU7S0FBUyxRQUFRO0tBQVcsbUJBQW1CO0tBQUksa0JBQWtCO0tBQUksVUFBVTtJQUFVO0lBQ3ZMO0tBQUUsYUFBYTtLQUE4QixTQUFTO0tBQW1CLFVBQVU7S0FBUyxRQUFRO0tBQVcsbUJBQW1CO0tBQUksa0JBQWtCO0tBQUksVUFBVTtJQUFXO0lBQ2pMO0tBQUUsYUFBYTtLQUFxQixTQUFTO0tBQWdCLFVBQVU7S0FBYSxRQUFRO0tBQVcsbUJBQW1CO0tBQUksa0JBQWtCO0tBQUcsVUFBVTtJQUFXO0dBQzFLO0VBQ0Y7RUFDQSxXQUFXO0dBQ1QsbUJBQW1CO0dBQ25CLG1CQUFtQjtJQUFDO0lBQVM7SUFBWTtJQUFZO0lBQVU7R0FBUTtHQUN2RSxnQkFBZ0IsQ0FBQyxlQUFlLFlBQVk7R0FDNUMsZ0JBQWdCO0lBQUM7SUFBZTtJQUFnQjtHQUFnQjtFQUNsRTtFQUNBLGVBQWU7R0FDYixvQkFBb0I7R0FDcEIsMEJBQTBCO0dBQzFCLHVCQUF1QjtHQUN2Qix3QkFBd0I7RUFDMUI7RUFDQSxXQUFXLENBQ1Q7R0FBRSxJQUFJO0dBQWEsTUFBTTtHQUFRLFVBQVU7R0FBUyxXQUFXLENBQUM7R0FBVSxjQUFjO0dBQUssTUFBTTtHQUFRLFNBQVM7RUFBSyxDQUMzSDtFQUNBLGdCQUFnQixDQUFDO0NBQ25CLENBQ0Y7Q0FDQSxRQUFRLENBQ047RUFDRSxJQUFJO0VBQ0osU0FBUztFQUNULFdBQVc7RUFDWCxNQUFNO0VBQ04sT0FBTztFQUNQLFNBQVM7RUFDVCxXQUFXLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLEdBQUssQ0FBQyxDQUFDLFlBQVk7RUFDekQsVUFBVTtFQUNWLE1BQU07RUFDTixhQUFhO0dBQUUsVUFBVTtHQUFTLFdBQVcsQ0FBQztFQUFTO0NBQ3pELEdBQ0E7RUFDRSxJQUFJO0VBQ0osU0FBUztFQUNULFdBQVc7RUFDWCxNQUFNO0VBQ04sT0FBTztFQUNQLFNBQVM7RUFDVCxXQUFXLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLEdBQUssQ0FBQyxDQUFDLFlBQVk7RUFDekQsVUFBVTtFQUNWLE1BQU07Q0FDUixDQUNGO0NBQ0EsVUFBVSxDQUNSO0VBQ0UsSUFBSTtFQUNKLFNBQVM7RUFDVCxRQUFRO0VBQ1IsTUFBTTtFQUNOLFdBQVcsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssR0FBSyxDQUFDLENBQUMsWUFBWTtDQUMzRCxHQUNBO0VBQ0UsSUFBSTtFQUNKLFNBQVM7RUFDVCxRQUFRO0VBQ1IsTUFBTTtFQUNOLFdBQVcsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssR0FBSyxDQUFDLENBQUMsWUFBWTtDQUMzRCxDQUNGO0NBQ0EsY0FBYyxDQUFDO0FBQ2pCOztBQUdBLFNBQVMsU0FBa0I7Q0FDekIsSUFBSTtFQUNGLElBQUksR0FBRyxXQUFXLE9BQU8sR0FBRztHQUMxQixNQUFNLE9BQU8sR0FBRyxhQUFhLFNBQVMsT0FBTztHQUM3QyxNQUFNLFNBQWtCLEtBQUssTUFBTSxJQUFJO0dBQ3ZDLE9BQU8sU0FBUyxTQUFTLE1BQU07SUFDN0IsSUFBSSxDQUFDLEVBQUUsZUFBZTtLQUNwQixFQUFFLGdCQUFnQjtNQUNoQixvQkFBb0I7TUFDcEIsMEJBQTBCO01BQzFCLHVCQUF1QjtNQUN2Qix3QkFBd0I7S0FDMUI7SUFDRjtHQUNGLENBQUM7R0FDRCxPQUFPO0VBQ1Q7Q0FDRixTQUFTLEtBQUs7RUFDWixRQUFRLE1BQU0sZ0RBQWdELEdBQUc7Q0FDbkU7Q0FDQSxPQUFPLGFBQWE7Q0FDcEIsT0FBTztBQUNUO0FBRUEsU0FBUyxPQUFPLE9BQWdCO0NBQzlCLElBQUk7RUFDRixHQUFHLGNBQWMsU0FBUyxLQUFLLFVBQVUsT0FBTyxNQUFNLENBQUMsR0FBRyxPQUFPO0NBQ25FLFNBQVMsS0FBSztFQUNaLFFBQVEsTUFBTSwwQkFBMEIsR0FBRztDQUM3QztBQUNGO0FBRUEsSUFBSSxLQUFLLE9BQU87QUFFaEIsZUFBZSxjQUFjO0NBQzNCLE1BQU0sTUFBTSxRQUFRO0NBQ3BCLElBQUksSUFBSSxRQUFRLEtBQUssQ0FBQzs7O0NBSXRCLElBQUksSUFBSSxlQUFlLEtBQUssUUFBUTtFQUNsQyxJQUFJLEtBQUssRUFBRTtDQUNiLENBQUM7O0NBR0QsSUFBSSxJQUFJLHFCQUFxQixPQUFPLEtBQUssUUFBUTtFQUMvQyxJQUFJO0dBQ0YsTUFBTSxNQUFNLElBQUksTUFBTTtHQUN0QixNQUFNLHFCQUFxQixTQUFpQixjQUFxQjtJQUMvRCxNQUFNLFFBQVEsR0FBRyxZQUFZLE9BQU87SUFDcEMsS0FBSyxNQUFNLFFBQVEsT0FBTztLQUN4QixJQUNFLFNBQVMsa0JBQ1QsU0FBUyxVQUNULFNBQVMsVUFDVCxTQUFTLFlBQ1QsU0FBUyxhQUNUO01BQ0E7S0FDRjtLQUNBLE1BQU0sV0FBVyxLQUFLLEtBQUssU0FBUyxJQUFJO0tBQ3hDLE1BQU0sT0FBTyxHQUFHLFNBQVMsUUFBUTtLQUNqQyxJQUFJLEtBQUssWUFBWSxHQUFHO01BQ3RCLE1BQU0sYUFBYSxVQUFVLE9BQU8sSUFBSTtNQUN4QyxJQUFJLFlBQVksa0JBQWtCLFVBQVUsVUFBVTtLQUN4RCxPQUFPO01BQ0wsTUFBTSxjQUFjLEdBQUcsYUFBYSxRQUFRO01BQzVDLFVBQVUsS0FBSyxNQUFNLFdBQVc7S0FDbEM7SUFDRjtHQUNGO0dBRUEsa0JBQWtCLFdBQVcsR0FBRztHQUVoQyxNQUFNLFNBQVMsTUFBTSxJQUFJLGNBQWM7SUFBRSxNQUFNO0lBQWMsYUFBYTtHQUFVLENBQUM7R0FDckYsSUFBSSxVQUFVLGdCQUFnQixpQkFBaUI7R0FDL0MsSUFBSSxVQUFVLHVCQUF1Qix3REFBc0Q7R0FDM0YsSUFBSSxVQUFVLGtCQUFrQixPQUFPLE1BQU07R0FDN0MsT0FBTyxJQUFJLEtBQUssTUFBTTtFQUN4QixTQUFTLEtBQVU7R0FDakIsUUFBUSxNQUFNLHlCQUF5QixHQUFHO0dBQzFDLE9BQU8sSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxPQUFPLDhCQUE4QixDQUFDO0VBQ3RFO0NBQ0YsQ0FBQzs7Q0FHRCxJQUFJLEtBQUsseUJBQXlCLEtBQUssUUFBUTtFQUM3QyxNQUFNLEVBQUUsUUFBUSxJQUFJO0VBQ3BCLElBQUksUUFBUSxHQUFHLFdBQVc7R0FDeEIsT0FBTyxJQUFJLEtBQUssRUFBRSxTQUFTLEtBQUssQ0FBQztFQUNuQztFQUNBLE9BQU8sSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEtBQUs7R0FBRSxTQUFTO0dBQU8sT0FBTztFQUFnQixDQUFDO0NBQ3hFLENBQUM7Q0FFRCxJQUFJLEtBQUsseUJBQXlCLEtBQUssUUFBUTtFQUM3QyxNQUFNLEVBQUUsWUFBWSxXQUFXLElBQUk7RUFDbkMsSUFBSSxlQUFlLEdBQUcsV0FBVztHQUMvQixPQUFPLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxLQUFLO0lBQUUsU0FBUztJQUFPLE9BQU87R0FBeUIsQ0FBQztFQUNqRjtFQUNBLElBQUksQ0FBQyxVQUFVLE9BQU8sU0FBUyxHQUFHO0dBQ2hDLE9BQU8sSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEtBQUs7SUFBRSxTQUFTO0lBQU8sT0FBTztHQUFvQyxDQUFDO0VBQzVGO0VBQ0EsR0FBRyxZQUFZO0VBQ2YsT0FBTyxFQUFFO0VBQ1QsSUFBSSxLQUFLO0dBQUUsU0FBUztHQUFNLFNBQVM7RUFBMkIsQ0FBQztDQUNqRSxDQUFDOztDQUdELElBQUksS0FBSyx1QkFBdUIsS0FBSyxRQUFRO0VBQzNDLE1BQU0sRUFBRSxXQUFXLEtBQUssZ0JBQWdCLElBQUk7RUFDNUMsTUFBTSxPQUFPLEtBQUssTUFBTSxNQUFTLEtBQUssT0FBTyxJQUFJLEdBQU0sQ0FBQyxDQUFDLFNBQVM7RUFDbEUsTUFBTSxZQUFZLEtBQUssSUFBSSxJQUFJLEtBQUssS0FBSzs7RUFHekMsSUFBSSxVQUFVLFNBQVMsS0FBSyxJQUFJLENBQUMsQ0FBQyxTQUFTLEVBQUU7RUFDN0MsTUFBTSxXQUF3QjtHQUM1QixJQUFJO0dBQ0osTUFBTSxhQUFhO0dBQ25CLEtBQUssT0FBTztHQUNaLFFBQVE7R0FDUixhQUFhLGVBQWU7R0FDNUIsV0FBVztHQUNYLGNBQWM7R0FDZCxZQUFZO0dBQ1osVUFBVTtHQUNWLFVBQVUsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0dBQ2pDLFVBQVU7SUFDUixVQUFVO0lBQ1YsV0FBVyxDQUFDO0lBQ1osVUFBVTtJQUNWLE9BQU87SUFDUCxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtJQUNsQyxTQUFTO0dBQ1g7R0FDQSxpQkFBaUIsQ0FBQztHQUNsQixZQUFZO0lBQ1YsbUJBQW1CO0lBQ25CLG1CQUFtQjtJQUNuQixjQUFjO0lBQ2QsWUFBWTtJQUNaLGlCQUFpQjtJQUNqQixVQUFVO0tBQ1I7TUFBRSxhQUFhO01BQThCLFNBQVM7TUFBVyxVQUFVO01BQVMsUUFBUTtNQUFXLG1CQUFtQjtNQUFJLGtCQUFrQjtNQUFHLFVBQVU7S0FBVTtLQUN2SztNQUFFLGFBQWE7TUFBcUIsU0FBUztNQUFVLFVBQVU7TUFBUyxRQUFRO01BQVUsbUJBQW1CO01BQUksa0JBQWtCO01BQUcsVUFBVTtLQUFXO0tBQzdKO01BQUUsYUFBYTtNQUFnQixTQUFTO01BQVksVUFBVTtNQUFhLFFBQVE7TUFBVyxtQkFBbUI7TUFBSSxrQkFBa0I7TUFBRyxVQUFVO0tBQVc7SUFDaks7R0FDRjtHQUNBLFdBQVc7SUFDVCxtQkFBbUI7SUFDbkIsbUJBQW1CO0tBQUM7S0FBUztLQUFZO0lBQVU7SUFDbkQsZ0JBQWdCLENBQUM7SUFDakIsZ0JBQWdCLENBQUM7R0FDbkI7R0FDQSxlQUFlO0lBQ2Isb0JBQW9CO0lBQ3BCLDBCQUEwQjtJQUMxQix1QkFBdUI7SUFDdkIsd0JBQXdCO0dBQzFCO0dBQ0EsV0FBVyxDQUNUO0lBQUUsSUFBSTtJQUFhLE1BQU07SUFBUSxVQUFVO0lBQVMsV0FBVyxDQUFDO0lBQVUsY0FBYztJQUFLLE1BQU07SUFBUSxTQUFTO0dBQUssQ0FDM0g7R0FDQSxnQkFBZ0IsQ0FBQztFQUNuQjtFQUVBLEdBQUcsU0FBUyxLQUFLLFFBQVE7RUFDekIsR0FBRyxhQUFhLEtBQUs7R0FBRTtHQUFNO0dBQVM7RUFBVSxDQUFDO0VBQ2pELE9BQU8sRUFBRTtFQUVULElBQUksS0FBSztHQUFFO0dBQU07R0FBUztFQUFVLENBQUM7Q0FDdkMsQ0FBQztDQUVELElBQUksS0FBSyxvQkFBb0IsS0FBSyxRQUFRO0VBQ3hDLE1BQU0sRUFBRSxNQUFNLGFBQWEsY0FBYyxJQUFJO0VBQzdDLE1BQU0sTUFBTSxLQUFLLElBQUk7RUFDckIsTUFBTSxhQUFhLEdBQUcsYUFBYSxXQUFXLE1BQU0sRUFBRSxTQUFTLFFBQVEsRUFBRSxZQUFZLEdBQUc7RUFFeEYsSUFBSSxlQUFlLENBQUMsR0FBRztHQUNyQixPQUFPLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxLQUFLO0lBQUUsU0FBUztJQUFPLE9BQU87R0FBa0MsQ0FBQztFQUMxRjtFQUVBLE1BQU0sRUFBRSxZQUFZLEdBQUcsYUFBYTtFQUNwQyxNQUFNLFFBQVEsR0FBRyxTQUFTLE1BQU0sTUFBTSxFQUFFLE9BQU8sT0FBTztFQUV0RCxJQUFJLENBQUMsT0FBTztHQUNWLE9BQU8sSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEtBQUs7SUFBRSxTQUFTO0lBQU8sT0FBTztHQUF5QixDQUFDO0VBQ2pGO0VBRUEsTUFBTSxXQUFXO0VBQ2pCLE1BQU0sV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDeEMsSUFBSSxhQUFhLE1BQU0sY0FBYztFQUNyQyxJQUFJLFdBQVcsTUFBTSxZQUFZOztFQUdqQyxHQUFHLGFBQWEsT0FBTyxZQUFZLENBQUM7RUFDcEMsT0FBTyxFQUFFO0VBRVQsSUFBSSxLQUFLO0dBQUUsU0FBUztHQUFNO0dBQVMsV0FBVyxNQUFNO0VBQUssQ0FBQztDQUM1RCxDQUFDOztDQUdELElBQUksS0FBSyw2QkFBNkIsS0FBSyxRQUFRO0VBQ2pELE1BQU0sRUFBRSxPQUFPLElBQUk7RUFDbkIsTUFBTSxFQUFFLGNBQWMsWUFBWSxVQUFVLDJCQUEyQixJQUFJO0VBRTNFLE1BQU0sUUFBUSxHQUFHLFNBQVMsTUFBTSxNQUFNLEVBQUUsT0FBTyxFQUFFO0VBQ2pELElBQUksQ0FBQyxPQUFPO0dBQ1YsT0FBTyxJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLE9BQU8sa0JBQWtCLENBQUM7RUFDMUQ7RUFFQSxNQUFNLFdBQVc7RUFDakIsTUFBTSxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtFQUN4QyxJQUFJLGlCQUFpQixXQUFXLE1BQU0sZUFBZTtFQUNyRCxJQUFJLGVBQWUsV0FBVyxNQUFNLGFBQWE7RUFFakQsSUFBSSx3QkFBd0I7R0FDMUIsTUFBTSxXQUFXLHFCQUFxQjtFQUN4QztFQUVBLElBQUksWUFBWSxTQUFTLFlBQVksU0FBUyxXQUFXO0dBQ3ZELE1BQU0sV0FBVztJQUNmLFVBQVUsU0FBUztJQUNuQixXQUFXLFNBQVM7SUFDcEIsVUFBVSxTQUFTLFlBQVk7SUFDL0IsT0FBTyxTQUFTLFNBQVM7SUFDekIsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7SUFDbEMsU0FBUyxTQUFTLFdBQVcsR0FBRyxTQUFTLFNBQVMsUUFBUSxDQUFDLEVBQUUsSUFBSSxTQUFTLFVBQVUsUUFBUSxDQUFDO0dBQy9GOztHQUdBLE1BQU0sZ0JBQWdCLFFBQVE7SUFDNUIsVUFBVSxTQUFTO0lBQ25CLFdBQVcsU0FBUztJQUNwQixXQUFXLE1BQU0sU0FBUztJQUMxQixTQUFTLE1BQU0sU0FBUztHQUMxQixDQUFDO0dBQ0QsSUFBSSxNQUFNLGdCQUFnQixTQUFTLElBQUk7SUFDckMsTUFBTSxnQkFBZ0IsSUFBSTtHQUM1Qjs7R0FHQSxNQUFNLFVBQVUsU0FBUyxTQUFTO0lBQ2hDLElBQUksQ0FBQyxLQUFLLFNBQVM7SUFDbkIsTUFBTSxPQUFPLGtCQUNYLFNBQVMsVUFDVCxTQUFTLFdBQ1QsS0FBSyxVQUNMLEtBQUssU0FDUDtJQUNBLE1BQU0sV0FBVyxRQUFRLEtBQUs7O0dBRWhDLENBQUM7RUFDSDs7RUFHQSxJQUFJLE1BQU0sZ0JBQWdCLE1BQU0sQ0FBQyxNQUFNLFlBQVk7R0FDakQsTUFBTSxxQkFBcUIsR0FBRyxPQUFPLE1BQ2xDLE1BQU0sRUFBRSxZQUFZLE1BQU0sTUFBTSxFQUFFLFNBQVMsaUJBQWtCLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDLFFBQVEsSUFBSSxLQUFLLEdBQ3BIO0dBQ0EsSUFBSSxDQUFDLG9CQUFvQjtJQUN2QixHQUFHLE9BQU8sUUFBUTtLQUNoQixJQUFJLFNBQVMsS0FBSyxJQUFJO0tBQ3RCLFNBQVMsTUFBTTtLQUNmLFdBQVcsTUFBTTtLQUNqQixNQUFNO0tBQ04sT0FBTyxnQkFBZ0IsTUFBTSxLQUFLLGFBQWEsTUFBTSxhQUFhO0tBQ2xFLFNBQVMsR0FBRyxNQUFNLEtBQUssa0JBQWtCLE1BQU0sYUFBYTtLQUM1RCxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtLQUNsQyxVQUFVO0tBQ1YsTUFBTTtJQUNSLENBQUM7R0FDSDtFQUNGO0VBRUEsT0FBTyxFQUFFO0VBQ1QsSUFBSSxLQUFLO0dBQ1AsU0FBUztHQUNUO0dBQ0EsVUFBVTtJQUNSLHFCQUFxQixNQUFNLGVBQWU7SUFDMUMscUJBQXFCLE1BQU0sZUFBZTtJQUMxQyxlQUFlLE1BQU07SUFDckIsVUFBVSxNQUFNLFdBQVc7SUFDM0IsbUJBQW1CLE1BQU0sV0FBVztJQUNwQyxjQUFjLE1BQU0sV0FBVztJQUMvQixZQUFZLE1BQU0sV0FBVztJQUM3QixpQkFBaUIsTUFBTSxXQUFXO0lBQ2xDLFdBQVcsTUFBTTtHQUNuQjtFQUNGLENBQUM7Q0FDSCxDQUFDOztDQUdELElBQUksS0FBSyx1QkFBdUIsS0FBSyxRQUFRO0VBQzNDLE1BQU0sRUFBRSxPQUFPLElBQUk7RUFDbkIsTUFBTSxFQUFFLFVBQVUsV0FBVyxpQkFBaUIsSUFBSTtFQUNsRCxNQUFNLFFBQVEsR0FBRyxTQUFTLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRTtFQUVqRCxNQUFNLFlBQVksUUFBUSxNQUFNLE9BQU87RUFDdkMsTUFBTSxRQUFtQjtHQUN2QixJQUFJLE9BQU8sS0FBSyxJQUFJO0dBQ3BCLFNBQVM7R0FDVDtHQUNBLE1BQU07R0FDTixPQUFPLGlDQUFpQyxVQUFVLFlBQVk7R0FDOUQsU0FBUyxHQUFHLFVBQVU7R0FDdEIsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDbEMsVUFBVTtHQUNWLE1BQU07R0FDTixhQUFhLFlBQVksWUFBWTtJQUFFO0lBQVU7R0FBVSxJQUFJLE9BQU87RUFDeEU7RUFFQSxHQUFHLE9BQU8sUUFBUSxLQUFLO0VBQ3ZCLE9BQU8sRUFBRTtFQUVULElBQUksS0FBSztHQUFFLFNBQVM7R0FBTTtFQUFNLENBQUM7Q0FDbkMsQ0FBQzs7Q0FHRCxJQUFJLEtBQUssa0NBQWtDLEtBQUssUUFBUTtFQUN0RCxNQUFNLEVBQUUsT0FBTyxJQUFJO0VBQ25CLE1BQU0sRUFBRSxZQUFZLFdBQVcsSUFBSTtFQUNuQyxNQUFNLFFBQVEsR0FBRyxTQUFTLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRTtFQUNqRCxJQUFJLENBQUMsT0FBTyxPQUFPLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxrQkFBa0IsQ0FBQztFQUVwRSxNQUFNLGVBQWUsZ0JBQWdCO0dBQ25DLElBQUksT0FBTyxLQUFLLElBQUk7R0FDcEIsYUFBYSxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDcEMsUUFBUTtHQUNSLFlBQVksY0FBYztHQUMxQixRQUFRLFVBQVU7RUFDcEI7RUFFQSxPQUFPLEVBQUU7RUFDVCxJQUFJLEtBQUs7R0FBRSxTQUFTO0dBQU0sU0FBUyxNQUFNLGVBQWU7RUFBYyxDQUFDO0NBQ3pFLENBQUM7Q0FFRCxJQUFJLEtBQUssa0NBQWtDLEtBQUssUUFBUTtFQUN0RCxNQUFNLEVBQUUsT0FBTyxJQUFJO0VBQ25CLE1BQU0sRUFBRSxXQUFXLElBQUk7RUFDdkIsTUFBTSxRQUFRLEdBQUcsU0FBUyxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUU7RUFDakQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLGVBQWUsZUFBZTtHQUNqRCxPQUFPLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxvQkFBb0IsQ0FBQztFQUM1RDtFQUVBLE1BQU0sZUFBZSxjQUFjLFNBQVM7RUFDNUMsSUFBSSxXQUFXLFNBQVM7R0FDdEIsT0FBTyxNQUFNLGVBQWU7RUFDOUI7RUFFQSxPQUFPLEVBQUU7RUFDVCxJQUFJLEtBQUssRUFBRSxTQUFTLEtBQUssQ0FBQztDQUM1QixDQUFDOztDQUdELElBQUksS0FBSyxrQ0FBa0MsS0FBSyxRQUFRO0VBQ3RELE1BQU0sRUFBRSxPQUFPLElBQUk7RUFDbkIsTUFBTSxFQUFFLFdBQVcsSUFBSTtFQUN2QixNQUFNLFFBQVEsR0FBRyxTQUFTLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRTtFQUNqRCxJQUFJLENBQUMsT0FBTyxPQUFPLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxrQkFBa0IsQ0FBQztFQUVwRSxNQUFNLGVBQWUsZ0JBQWdCO0dBQ25DLElBQUksVUFBVSxLQUFLLElBQUk7R0FDdkIsYUFBYSxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDcEMsUUFBUTtHQUNSLFFBQVEsVUFBVTtFQUNwQjtFQUVBLE9BQU8sRUFBRTtFQUNULElBQUksS0FBSztHQUFFLFNBQVM7R0FBTSxTQUFTLE1BQU0sZUFBZTtFQUFjLENBQUM7Q0FDekUsQ0FBQztDQUVELElBQUksS0FBSyxrQ0FBa0MsS0FBSyxRQUFRO0VBQ3RELE1BQU0sRUFBRSxPQUFPLElBQUk7RUFDbkIsTUFBTSxFQUFFLFdBQVcsSUFBSTtFQUN2QixNQUFNLFFBQVEsR0FBRyxTQUFTLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRTtFQUNqRCxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sZUFBZSxlQUFlO0dBQ2pELE9BQU8sSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxPQUFPLG9CQUFvQixDQUFDO0VBQzVEO0VBRUEsTUFBTSxlQUFlLGNBQWMsU0FBUztFQUM1QyxJQUFJLFdBQVcsU0FBUztHQUN0QixPQUFPLE1BQU0sZUFBZTtFQUM5QjtFQUVBLE9BQU8sRUFBRTtFQUNULElBQUksS0FBSyxFQUFFLFNBQVMsS0FBSyxDQUFDO0NBQzVCLENBQUM7O0NBR0QsSUFBSSxLQUFLLGdDQUFnQyxLQUFLLFFBQVE7RUFDcEQsTUFBTSxFQUFFLE9BQU8sSUFBSTtFQUNuQixNQUFNLEVBQUUsU0FBUyxXQUFXLElBQUk7RUFDaEMsTUFBTSxRQUFRLEdBQUcsU0FBUyxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUU7RUFDakQsSUFBSSxDQUFDLE9BQU8sT0FBTyxJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLE9BQU8sa0JBQWtCLENBQUM7RUFFcEUsTUFBTSx1QkFBdUI7R0FDM0IsSUFBSSxPQUFPLEtBQUssSUFBSTtHQUNwQixTQUFTLFdBQVc7R0FDcEIsUUFBUSxVQUFVO0dBQ2xCLGFBQWEsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0dBQ3BDLFFBQVE7RUFDVjtFQUVBLEdBQUcsT0FBTyxRQUFRO0dBQ2hCLElBQUksY0FBYyxLQUFLLElBQUk7R0FDM0IsU0FBUyxNQUFNO0dBQ2YsV0FBVyxNQUFNO0dBQ2pCLE1BQU07R0FDTixPQUFPLGtDQUFrQyxNQUFNO0dBQy9DLFNBQVMsR0FBRyxNQUFNLEtBQUssaUJBQWlCLFdBQVcsR0FBRywyQkFBMkIsVUFBVSxhQUFhO0dBQ3hHLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0dBQ2xDLFVBQVU7R0FDVixNQUFNO0VBQ1IsQ0FBQztFQUVELE9BQU8sRUFBRTtFQUNULElBQUksS0FBSztHQUFFLFNBQVM7R0FBTSxTQUFTLE1BQU07RUFBcUIsQ0FBQztDQUNqRSxDQUFDO0NBRUQsSUFBSSxLQUFLLGdDQUFnQyxLQUFLLFFBQVE7RUFDcEQsTUFBTSxFQUFFLE9BQU8sSUFBSTtFQUNuQixNQUFNLEVBQUUsUUFBUSxtQkFBbUIsSUFBSTtFQUN2QyxNQUFNLFFBQVEsR0FBRyxTQUFTLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRTtFQUNqRCxJQUFJLENBQUMsT0FBTyxPQUFPLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxrQkFBa0IsQ0FBQztFQUVwRSxJQUFJLE1BQU0sc0JBQXNCO0dBQzlCLE1BQU0scUJBQXFCLFNBQVM7R0FDcEMsSUFBSSxXQUFXLGNBQWMsZ0JBQWdCO0lBQzNDLE1BQU0sV0FBVyxxQkFBcUI7R0FDeEM7RUFDRjtFQUVBLE9BQU8sRUFBRTtFQUNULElBQUksS0FBSztHQUFFLFNBQVM7R0FBTSxtQkFBbUIsTUFBTSxXQUFXO0VBQWtCLENBQUM7Q0FDbkYsQ0FBQzs7Q0FHRCxJQUFJLEtBQUssaUNBQWlDLEtBQUssUUFBUTtFQUNyRCxNQUFNLEVBQUUsT0FBTyxJQUFJO0VBQ25CLE1BQU0sRUFBRSxtQkFBbUIsY0FBYyxZQUFZLG9CQUFvQixJQUFJO0VBQzdFLE1BQU0sUUFBUSxHQUFHLFNBQVMsTUFBTSxNQUFNLEVBQUUsT0FBTyxFQUFFO0VBQ2pELElBQUksQ0FBQyxPQUFPLE9BQU8sSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxPQUFPLGtCQUFrQixDQUFDO0VBRXBFLElBQUksc0JBQXNCLFdBQVcsTUFBTSxXQUFXLG9CQUFvQjtFQUMxRSxJQUFJLGlCQUFpQixXQUFXLE1BQU0sV0FBVyxlQUFlO0VBQ2hFLElBQUksZUFBZSxXQUFXLE1BQU0sV0FBVyxhQUFhO0VBQzVELElBQUksb0JBQW9CLFdBQVcsTUFBTSxXQUFXLGtCQUFrQjtFQUV0RSxPQUFPLEVBQUU7RUFDVCxJQUFJLEtBQUs7R0FBRSxTQUFTO0dBQU0sWUFBWSxNQUFNO0VBQVcsQ0FBQztDQUMxRCxDQUFDOztDQUdELElBQUksS0FBSyw0QkFBNEIsS0FBSyxRQUFRO0VBQ2hELE1BQU0sRUFBRSxPQUFPLElBQUk7RUFDbkIsTUFBTSxFQUFFLGFBQWEsUUFBUSxzQkFBc0IsSUFBSTtFQUN2RCxNQUFNLFFBQVEsR0FBRyxTQUFTLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRTtFQUNqRCxJQUFJLENBQUMsT0FBTyxPQUFPLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxrQkFBa0IsQ0FBQztFQUVwRSxNQUFNLE9BQU8sTUFBTSxXQUFXLFNBQVMsTUFBTSxNQUFNLEVBQUUsZ0JBQWdCLFdBQVc7RUFDaEYsSUFBSSxNQUFNO0dBQ1IsSUFBSSxRQUFRLEtBQUssU0FBUztHQUMxQixJQUFJLHNCQUFzQixXQUFXLEtBQUssb0JBQW9CO0VBQ2hFO0VBRUEsT0FBTyxFQUFFO0VBQ1QsSUFBSSxLQUFLO0dBQUUsU0FBUztHQUFNLFVBQVUsTUFBTSxXQUFXO0VBQVMsQ0FBQztDQUNqRSxDQUFDOztDQUdELElBQUksS0FBSyw4QkFBOEIsS0FBSyxRQUFRO0VBQ2xELE1BQU0sRUFBRSxPQUFPLElBQUk7RUFDbkIsTUFBTSxFQUFFLG1CQUFtQixtQkFBbUIsZ0JBQWdCLG1CQUFtQixJQUFJO0VBQ3JGLE1BQU0sUUFBUSxHQUFHLFNBQVMsTUFBTSxNQUFNLEVBQUUsT0FBTyxFQUFFO0VBQ2pELElBQUksQ0FBQyxPQUFPLE9BQU8sSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxPQUFPLGtCQUFrQixDQUFDO0VBRXBFLElBQUksc0JBQXNCLFdBQVcsTUFBTSxVQUFVLG9CQUFvQjtFQUN6RSxJQUFJLG1CQUFtQixNQUFNLFVBQVUsb0JBQW9CO0VBQzNELElBQUksZ0JBQWdCLE1BQU0sVUFBVSxpQkFBaUI7RUFDckQsSUFBSSxnQkFBZ0IsTUFBTSxVQUFVLGlCQUFpQjtFQUVyRCxPQUFPLEVBQUU7RUFDVCxJQUFJLEtBQUs7R0FBRSxTQUFTO0dBQU0sV0FBVyxNQUFNO0VBQVUsQ0FBQztDQUN4RCxDQUFDOztDQUdELElBQUksS0FBSyw4QkFBOEIsS0FBSyxRQUFRO0VBQ2xELE1BQU0sRUFBRSxPQUFPLElBQUk7RUFDbkIsTUFBTSxFQUFFLGNBQWMsSUFBSTtFQUMxQixNQUFNLFFBQVEsR0FBRyxTQUFTLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRTtFQUNqRCxJQUFJLENBQUMsT0FBTyxPQUFPLElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsT0FBTyxrQkFBa0IsQ0FBQztFQUVwRSxNQUFNLFlBQVk7RUFDbEIsT0FBTyxFQUFFO0VBQ1QsSUFBSSxLQUFLO0dBQUUsU0FBUztHQUFNLFdBQVcsTUFBTTtFQUFVLENBQUM7Q0FDeEQsQ0FBQzs7Q0FHRCxJQUFJLEtBQUssa0NBQWtDLEtBQUssUUFBUTtFQUN0RCxNQUFNLEVBQUUsT0FBTyxJQUFJO0VBQ25CLE1BQU0sRUFBRSxvQkFBb0IsMEJBQTBCLDBCQUEwQixJQUFJO0VBQ3BGLE1BQU0sUUFBUSxHQUFHLFNBQVMsTUFBTSxNQUFNLEVBQUUsT0FBTyxFQUFFO0VBQ2pELElBQUksQ0FBQyxPQUFPLE9BQU8sSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxPQUFPLGtCQUFrQixDQUFDO0VBRXBFLElBQUksQ0FBQyxNQUFNLGVBQWU7R0FDeEIsTUFBTSxnQkFBZ0I7SUFDcEIsb0JBQW9CO0lBQ3BCLDBCQUEwQjtJQUMxQix1QkFBdUI7SUFDdkIsd0JBQXdCO0dBQzFCO0VBQ0Y7RUFFQSxJQUFJLHVCQUF1QixXQUFXLE1BQU0sY0FBYyxxQkFBcUI7RUFDL0UsSUFBSSw2QkFBNkIsV0FBVyxNQUFNLGNBQWMsMkJBQTJCO0VBQzNGLElBQUksMEJBQTBCLFdBQVcsTUFBTSxjQUFjLHdCQUF3QjtFQUVyRixPQUFPLEVBQUU7RUFDVCxJQUFJLEtBQUs7R0FBRSxTQUFTO0dBQU0sZUFBZSxNQUFNO0VBQWMsQ0FBQztDQUNoRSxDQUFDOztDQUdELElBQUksS0FBSyxpQ0FBaUMsS0FBSyxRQUFRO0VBQ3JELE1BQU0sRUFBRSxPQUFPLElBQUk7RUFDbkIsTUFBTSxFQUFFLGlCQUFpQixjQUFjLElBQUk7RUFDM0MsTUFBTSxRQUFRLEdBQUcsU0FBUyxNQUFNLE1BQU0sRUFBRSxPQUFPLEVBQUU7RUFDakQsSUFBSSxDQUFDLE9BQU8sT0FBTyxJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLE9BQU8sa0JBQWtCLENBQUM7RUFFcEUsSUFBSSxDQUFDLE1BQU0sZUFBZTtHQUN4QixNQUFNLGdCQUFnQjtJQUNwQixvQkFBb0I7SUFDcEIsMEJBQTBCO0lBQzFCLHVCQUF1QjtJQUN2Qix3QkFBd0I7R0FDMUI7RUFDRjtFQUVBLE1BQU0sY0FBYywwQkFBMEI7RUFDOUMsTUFBTSxjQUFjLG9CQUFvQixJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFFL0QsTUFBTSxRQUFtQjtHQUN2QixJQUFJLFVBQVUsS0FBSyxJQUFJO0dBQ3ZCLFNBQVMsTUFBTTtHQUNmLFdBQVcsTUFBTTtHQUNqQixNQUFNO0dBQ04sT0FBTyxxQ0FBcUMsTUFBTSxLQUFLO0dBQ3ZELFNBQVMsOEJBQThCLG1CQUFtQiw0Q0FBNEMsc0JBQXNCLE1BQU0sWUFBWTtHQUM5SSxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUNsQyxVQUFVO0dBQ1YsTUFBTTtFQUNSO0VBRUEsR0FBRyxPQUFPLFFBQVEsS0FBSztFQUN2QixPQUFPLEVBQUU7RUFDVCxJQUFJLEtBQUs7R0FBRSxTQUFTO0dBQU07R0FBTyx3QkFBd0IsTUFBTSxjQUFjO0VBQXVCLENBQUM7Q0FDdkcsQ0FBQzs7Q0FHRCxJQUFJLEtBQUssa0JBQWtCLEtBQUssUUFBUTtFQUN0QyxNQUFNLEVBQUUsU0FBUyxRQUFRLFNBQVMsSUFBSTtFQUN0QyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sT0FBTyxJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLE9BQU8scUJBQXFCLENBQUM7RUFFbEYsTUFBTSxNQUFtQjtHQUN2QixJQUFJLE9BQU8sS0FBSyxJQUFJO0dBQ3BCO0dBQ0E7R0FDQTtHQUNBLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ3BDO0VBRUEsR0FBRyxTQUFTLEtBQUssR0FBRztFQUNwQixPQUFPLEVBQUU7RUFDVCxJQUFJLEtBQUs7R0FBRSxTQUFTO0dBQU0sU0FBUztFQUFJLENBQUM7Q0FDMUMsQ0FBQzs7Q0FHRCxJQUFJLEtBQUssMEJBQTBCLEtBQUssUUFBUTtFQUM5QyxNQUFNLEVBQUUsSUFBSSxRQUFRLElBQUk7RUFDeEIsSUFBSSxLQUFLO0dBQ1AsR0FBRyxPQUFPLFNBQVMsTUFBTyxFQUFFLE9BQU8sSUFBSztFQUMxQyxPQUFPLElBQUksSUFBSTtHQUNiLE1BQU0sUUFBUSxHQUFHLE9BQU8sTUFBTSxNQUFNLEVBQUUsT0FBTyxFQUFFO0dBQy9DLElBQUksT0FBTyxNQUFNLE9BQU87RUFDMUI7RUFDQSxPQUFPLEVBQUU7RUFDVCxJQUFJLEtBQUssRUFBRSxTQUFTLEtBQUssQ0FBQztDQUM1QixDQUFDOztDQUdELElBQUksS0FBSyxrQkFBa0IsS0FBSyxRQUFRO0VBQ3RDLE1BQU0sRUFBRSxNQUFNLEtBQUssUUFBUSxnQkFBZ0IsSUFBSTtFQUMvQyxNQUFNLFdBQXdCO0dBQzVCLElBQUksU0FBUyxLQUFLLElBQUk7R0FDdEIsTUFBTSxRQUFRO0dBQ2QsS0FBSyxPQUFPO0dBQ1osUUFBUSxVQUFVO0dBQ2xCLGFBQWEsZUFBZTtHQUM1QixXQUFXO0dBQ1gsY0FBYztHQUNkLFlBQVk7R0FDWixVQUFVO0dBQ1YsVUFBVSxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDakMsVUFBVTtJQUNSLFVBQVU7SUFDVixXQUFXLENBQUM7SUFDWixVQUFVO0lBQ1YsT0FBTztJQUNQLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0lBQ2xDLFNBQVM7R0FDWDtHQUNBLGlCQUFpQixDQUFDO0dBQ2xCLFlBQVk7SUFDVixtQkFBbUI7SUFDbkIsbUJBQW1CO0lBQ25CLGNBQWM7SUFDZCxZQUFZO0lBQ1osaUJBQWlCO0lBQ2pCLFVBQVU7S0FDUjtNQUFFLGFBQWE7TUFBOEIsU0FBUztNQUFXLFVBQVU7TUFBUyxRQUFRO01BQVcsbUJBQW1CO01BQUksa0JBQWtCO01BQUcsVUFBVTtLQUFVO0tBQ3ZLO01BQUUsYUFBYTtNQUFxQixTQUFTO01BQVUsVUFBVTtNQUFTLFFBQVE7TUFBVSxtQkFBbUI7TUFBSSxrQkFBa0I7TUFBRyxVQUFVO0tBQVc7S0FDN0o7TUFBRSxhQUFhO01BQWdCLFNBQVM7TUFBWSxVQUFVO01BQWEsUUFBUTtNQUFXLG1CQUFtQjtNQUFJLGtCQUFrQjtNQUFHLFVBQVU7S0FBVztJQUNqSztHQUNGO0dBQ0EsV0FBVztJQUNULG1CQUFtQjtJQUNuQixtQkFBbUI7S0FBQztLQUFTO0tBQVk7SUFBVTtJQUNuRCxnQkFBZ0IsQ0FBQztJQUNqQixnQkFBZ0IsQ0FBQztHQUNuQjtHQUNBLGVBQWU7SUFDYixvQkFBb0I7SUFDcEIsMEJBQTBCO0lBQzFCLHVCQUF1QjtJQUN2Qix3QkFBd0I7R0FDMUI7R0FDQSxXQUFXLENBQ1Q7SUFBRSxJQUFJO0lBQWEsTUFBTTtJQUFRLFVBQVU7SUFBUyxXQUFXLENBQUM7SUFBVSxjQUFjO0lBQUssTUFBTTtJQUFRLFNBQVM7R0FBSyxDQUMzSDtHQUNBLGdCQUFnQixDQUFDO0VBQ25CO0VBRUEsR0FBRyxTQUFTLEtBQUssUUFBUTtFQUN6QixPQUFPLEVBQUU7RUFDVCxJQUFJLEtBQUs7R0FBRSxTQUFTO0dBQU0sT0FBTztFQUFTLENBQUM7Q0FDN0MsQ0FBQzs7Q0FHRCxTQUFTLGtCQUFrQixNQUFjLE1BQWMsTUFBYyxNQUFzQjtFQUN6RixNQUFNLElBQUk7RUFDVixNQUFNLFFBQVMsT0FBTyxRQUFRLEtBQUssS0FBTTtFQUN6QyxNQUFNLFFBQVMsT0FBTyxRQUFRLEtBQUssS0FBTTtFQUN6QyxNQUFNLElBQ0osS0FBSyxJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssSUFBSSxPQUFPLENBQUMsSUFDdEMsS0FBSyxJQUFLLE9BQU8sS0FBSyxLQUFNLEdBQUcsSUFDN0IsS0FBSyxJQUFLLE9BQU8sS0FBSyxLQUFNLEdBQUcsSUFDL0IsS0FBSyxJQUFJLE9BQU8sQ0FBQyxJQUNqQixLQUFLLElBQUksT0FBTyxDQUFDO0VBQ3JCLE1BQU0sSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLEtBQUssQ0FBQyxHQUFHLEtBQUssS0FBSyxJQUFJLENBQUMsQ0FBQztFQUN2RCxPQUFPLElBQUk7Q0FDYjs7Q0FHQSxNQUFNLGlDQUF3QztDQUM5QyxNQUFNLE9BQU8sUUFBUSxJQUFJLE9BQU8sU0FBUyxRQUFRLElBQUksTUFBTSxFQUFFLElBQUk7Q0FFakUsSUFBSSxDQUFDLGNBQWM7RUFDakIsTUFBTSxPQUFPLE1BQU0saUJBQWlCO0dBQ2xDLFFBQVE7SUFBRSxnQkFBZ0I7SUFBTSxLQUFLLFFBQVEsSUFBSSxnQkFBZ0I7R0FBTztHQUN4RSxTQUFTO0VBQ1gsQ0FBQztFQUNELElBQUksSUFBSSxLQUFLLFdBQVc7Q0FDMUIsT0FBTztFQUNMLElBQUksSUFBSSxRQUFRLE9BQU8sS0FBSyxLQUFLLFdBQVcsTUFBTSxDQUFDLENBQUM7RUFDcEQsSUFBSSxJQUFJLE1BQU0sS0FBSyxRQUFRO0dBQ3pCLElBQUksU0FBUyxLQUFLLEtBQUssV0FBVyxRQUFRLFlBQVksQ0FBQztFQUN6RCxDQUFDO0NBQ0g7Q0FFQSxJQUFJLE9BQU8sTUFBTSxpQkFBaUI7RUFDaEMsUUFBUSxJQUFJLDZDQUE2QyxNQUFNO0NBQ2pFLENBQUM7QUFDSDtBQUVBLFlBQVkiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInNlcnZlci50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgZXhwcmVzcyBmcm9tICdleHByZXNzJztcbmltcG9ydCB7IGNyZWF0ZVNlcnZlciBhcyBjcmVhdGVWaXRlU2VydmVyIH0gZnJvbSAndml0ZSc7XG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCc7XG5pbXBvcnQgeyBmaWxlVVJMVG9QYXRoIH0gZnJvbSAndXJsJztcbmltcG9ydCBKU1ppcCBmcm9tICdqc3ppcCc7XG5cbmNvbnN0IF9fZmlsZW5hbWUgPSBmaWxlVVJMVG9QYXRoKGltcG9ydC5tZXRhLnVybCk7XG5jb25zdCBfX2Rpcm5hbWUgPSBwYXRoLmRpcm5hbWUoX19maWxlbmFtZSk7XG5cbmNvbnN0IERBVEFfRElSID0gcGF0aC5qb2luKF9fZGlybmFtZSwgJ2RhdGEnKTtcbmNvbnN0IERCX0ZJTEUgPSBwYXRoLmpvaW4oREFUQV9ESVIsICdzYWZla2lkcy1kYi5qc29uJyk7XG5cbi8vIEVuc3VyZSBkYXRhIGRpcmVjdG9yeSBleGlzdHNcbmlmICghZnMuZXhpc3RzU3luYyhEQVRBX0RJUikpIHtcbiAgZnMubWtkaXJTeW5jKERBVEFfRElSLCB7IHJlY3Vyc2l2ZTogdHJ1ZSB9KTtcbn1cblxuaW50ZXJmYWNlIFNhZmVab25lIHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBsYXRpdHVkZTogbnVtYmVyO1xuICBsb25naXR1ZGU6IG51bWJlcjtcbiAgcmFkaXVzTWV0ZXJzOiBudW1iZXI7XG4gIGljb246IHN0cmluZztcbiAgZW5hYmxlZDogYm9vbGVhbjtcbn1cblxuaW50ZXJmYWNlIEFwcFJ1bGUge1xuICBwYWNrYWdlTmFtZTogc3RyaW5nO1xuICBhcHBOYW1lOiBzdHJpbmc7XG4gIGNhdGVnb3J5OiAnc29jaWFsJyB8ICdnYW1lcycgfCAndmlkZW8nIHwgJ2Jyb3dzaW5nJyB8ICdlZHVjYXRpb24nIHwgJ290aGVyJztcbiAgc3RhdHVzOiAnYWxsb3dlZCcgfCAnbG9ja2VkJyB8ICdsaW1pdGVkJztcbiAgZGFpbHlMaW1pdE1pbnV0ZXM/OiBudW1iZXI7XG4gIHVzZWRUb2RheU1pbnV0ZXM6IG51bWJlcjtcbiAgaWNvbk5hbWU6IHN0cmluZztcbn1cblxuaW50ZXJmYWNlIENoaWxkRGV2aWNlIHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBhZ2U6IG51bWJlcjtcbiAgYXZhdGFyOiBzdHJpbmc7XG4gIGRldmljZU1vZGVsOiBzdHJpbmc7XG4gIG9zVmVyc2lvbjogc3RyaW5nO1xuICBiYXR0ZXJ5TGV2ZWw6IG51bWJlcjtcbiAgaXNDaGFyZ2luZzogYm9vbGVhbjtcbiAgaXNPbmxpbmU6IGJvb2xlYW47XG4gIGxhc3RTZWVuOiBzdHJpbmc7XG4gIGxvY2F0aW9uOiB7XG4gICAgbGF0aXR1ZGU6IG51bWJlcjtcbiAgICBsb25naXR1ZGU6IG51bWJlcjtcbiAgICBhY2N1cmFjeTogbnVtYmVyO1xuICAgIHNwZWVkOiBudW1iZXIgfCBudWxsO1xuICAgIHRpbWVzdGFtcDogc3RyaW5nO1xuICAgIGFkZHJlc3M6IHN0cmluZztcbiAgfTtcbiAgbG9jYXRpb25IaXN0b3J5OiBBcnJheTx7XG4gICAgbGF0aXR1ZGU6IG51bWJlcjtcbiAgICBsb25naXR1ZGU6IG51bWJlcjtcbiAgICB0aW1lc3RhbXA6IHN0cmluZztcbiAgICBhZGRyZXNzOiBzdHJpbmc7XG4gIH0+O1xuICBzY3JlZW5UaW1lOiB7XG4gICAgdG9kYXlVc2FnZU1pbnV0ZXM6IG51bWJlcjtcbiAgICBkYWlseUxpbWl0TWludXRlczogbnVtYmVyO1xuICAgIGJlZHRpbWVTdGFydDogc3RyaW5nOyAvLyBlLmcuIFwiMjE6MDBcIlxuICAgIGJlZHRpbWVFbmQ6IHN0cmluZzsgICAvLyBlLmcuIFwiMDc6MDBcIlxuICAgIGJlZHRpbWVFbmZvcmNlZDogYm9vbGVhbjtcbiAgICBhcHBSdWxlczogQXBwUnVsZVtdO1xuICB9O1xuICB3ZWJGaWx0ZXI6IHtcbiAgICBzYWZlU2VhcmNoRW5hYmxlZDogYm9vbGVhbjtcbiAgICBibG9ja2VkQ2F0ZWdvcmllczogc3RyaW5nW107XG4gICAgYmxvY2tlZERvbWFpbnM6IHN0cmluZ1tdO1xuICAgIGFsbG93ZWREb21haW5zOiBzdHJpbmdbXTtcbiAgfTtcbiAgYW50aVVuaW5zdGFsbDoge1xuICAgIGRldmljZUFkbWluRW5hYmxlZDogYm9vbGVhbjtcbiAgICBhY2Nlc3NpYmlsaXR5TG9ja0VuYWJsZWQ6IGJvb2xlYW47XG4gICAgcHJldmVudFNldHRpbmdzVGFtcGVyOiBib29sZWFuO1xuICAgIHVuaW5zdGFsbEF0dGVtcHRzQ291bnQ6IG51bWJlcjtcbiAgICBsYXN0VGFtcGVyQXR0ZW1wdD86IHN0cmluZztcbiAgfTtcbiAgc2FmZVpvbmVzOiBTYWZlWm9uZVtdO1xuICBhY3RpdmVTZXNzaW9uczoge1xuICAgIGNhbWVyYVJlcXVlc3Q/OiB7XG4gICAgICBpZDogc3RyaW5nO1xuICAgICAgcmVxdWVzdGVkQXQ6IHN0cmluZztcbiAgICAgIHN0YXR1czogJ3BlbmRpbmcnIHwgJ2FjY2VwdGVkJyB8ICdkZW5pZWQnIHwgJ2VuZGVkJztcbiAgICAgIGZhY2luZ01vZGU6ICd1c2VyJyB8ICdlbnZpcm9ubWVudCc7XG4gICAgICByZWFzb24/OiBzdHJpbmc7XG4gICAgfTtcbiAgICBzY3JlZW5SZXF1ZXN0Pzoge1xuICAgICAgaWQ6IHN0cmluZztcbiAgICAgIHJlcXVlc3RlZEF0OiBzdHJpbmc7XG4gICAgICBzdGF0dXM6ICdwZW5kaW5nJyB8ICdhY2NlcHRlZCcgfCAnZGVuaWVkJyB8ICdlbmRlZCc7XG4gICAgICByZWFzb24/OiBzdHJpbmc7XG4gICAgfTtcbiAgfTtcbiAgdGltZUV4dGVuc2lvblJlcXVlc3Q/OiB7XG4gICAgaWQ6IHN0cmluZztcbiAgICBtaW51dGVzOiBudW1iZXI7XG4gICAgcmVhc29uOiBzdHJpbmc7XG4gICAgcmVxdWVzdGVkQXQ6IHN0cmluZztcbiAgICBzdGF0dXM6ICdwZW5kaW5nJyB8ICdhcHByb3ZlZCcgfCAnZGVuaWVkJztcbiAgfTtcbn1cblxuaW50ZXJmYWNlIEFsZXJ0SXRlbSB7XG4gIGlkOiBzdHJpbmc7XG4gIGNoaWxkSWQ6IHN0cmluZztcbiAgY2hpbGROYW1lOiBzdHJpbmc7XG4gIHR5cGU6ICdzb3MnIHwgJ2dlb2ZlbmNlX2VudGVyJyB8ICdnZW9mZW5jZV9leGl0JyB8ICdsb3dfYmF0dGVyeScgfCAnc2NyZWVuX2xpbWl0JyB8ICdibG9ja2VkX3NpdGUnIHwgJ3RpbWVfcmVxdWVzdCcgfCAndGFtcGVyX2F0dGVtcHQnO1xuICB0aXRsZTogc3RyaW5nO1xuICBtZXNzYWdlOiBzdHJpbmc7XG4gIHRpbWVzdGFtcDogc3RyaW5nO1xuICBzZXZlcml0eTogJ2NyaXRpY2FsJyB8ICd3YXJuaW5nJyB8ICdpbmZvJztcbiAgcmVhZDogYm9vbGVhbjtcbiAgY29vcmRpbmF0ZXM/OiB7IGxhdGl0dWRlOiBudW1iZXI7IGxvbmdpdHVkZTogbnVtYmVyIH07XG59XG5cbmludGVyZmFjZSBNZXNzYWdlSXRlbSB7XG4gIGlkOiBzdHJpbmc7XG4gIGNoaWxkSWQ6IHN0cmluZztcbiAgc2VuZGVyOiAncGFyZW50JyB8ICdjaGlsZCc7XG4gIHRleHQ6IHN0cmluZztcbiAgdGltZXN0YW1wOiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBQYWlyaW5nQ29kZSB7XG4gIGNvZGU6IHN0cmluZztcbiAgY2hpbGRJZDogc3RyaW5nO1xuICBleHBpcmVzQXQ6IG51bWJlcjtcbn1cblxuaW50ZXJmYWNlIERCU3RhdGUge1xuICBwYXJlbnRQaW46IHN0cmluZztcbiAgcGFyZW50RW1haWw6IHN0cmluZztcbiAgY2hpbGRyZW46IENoaWxkRGV2aWNlW107XG4gIGFsZXJ0czogQWxlcnRJdGVtW107XG4gIG1lc3NhZ2VzOiBNZXNzYWdlSXRlbVtdO1xuICBwYWlyaW5nQ29kZXM6IFBhaXJpbmdDb2RlW107XG59XG5cbmNvbnN0IERFRkFVTFRfU1RBVEU6IERCU3RhdGUgPSB7XG4gIHBhcmVudFBpbjogJzEyMzQnLFxuICBwYXJlbnRFbWFpbDogJ3BhcmVudEBzYWZla2lkcy5sb2NhbCcsXG4gIGNoaWxkcmVuOiBbXG4gICAge1xuICAgICAgaWQ6ICdjaGlsZC1sZW8nLFxuICAgICAgbmFtZTogJ0xlbycsXG4gICAgICBhZ2U6IDEwLFxuICAgICAgYXZhdGFyOiAn8J+RpicsXG4gICAgICBkZXZpY2VNb2RlbDogJ1BpeGVsIDhhIChBbmRyb2lkIDE0KScsXG4gICAgICBvc1ZlcnNpb246ICdBbmRyb2lkIDE0IChBUEkgMzQpJyxcbiAgICAgIGJhdHRlcnlMZXZlbDogNzgsXG4gICAgICBpc0NoYXJnaW5nOiBmYWxzZSxcbiAgICAgIGlzT25saW5lOiB0cnVlLFxuICAgICAgbGFzdFNlZW46IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGxvY2F0aW9uOiB7XG4gICAgICAgIGxhdGl0dWRlOiAzNy43NzQ5LFxuICAgICAgICBsb25naXR1ZGU6IC0xMjIuNDE5NCxcbiAgICAgICAgYWNjdXJhY3k6IDEyLFxuICAgICAgICBzcGVlZDogMS4yLFxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgYWRkcmVzczogJ01hcmtldCBTdCAmIDR0aCwgU2FuIEZyYW5jaXNjbywgQ0EnLFxuICAgICAgfSxcbiAgICAgIGxvY2F0aW9uSGlzdG9yeTogW1xuICAgICAgICB7IGxhdGl0dWRlOiAzNy43NzQ5LCBsb25naXR1ZGU6IC0xMjIuNDE5NCwgdGltZXN0YW1wOiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gNSAqIDYwMDAwKS50b0lTT1N0cmluZygpLCBhZGRyZXNzOiAnTWFya2V0IFN0ICYgNHRoLCBTYW4gRnJhbmNpc2NvLCBDQScgfSxcbiAgICAgICAgeyBsYXRpdHVkZTogMzcuNzc1OCwgbG9uZ2l0dWRlOiAtMTIyLjQxODIsIHRpbWVzdGFtcDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDI1ICogNjAwMDApLnRvSVNPU3RyaW5nKCksIGFkZHJlc3M6ICdNaXNzaW9uIFN0ICYgM3JkLCBTYW4gRnJhbmNpc2NvLCBDQScgfSxcbiAgICAgICAgeyBsYXRpdHVkZTogMzcuNzc2NSwgbG9uZ2l0dWRlOiAtMTIyLjQxNzAsIHRpbWVzdGFtcDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDU1ICogNjAwMDApLnRvSVNPU3RyaW5nKCksIGFkZHJlc3M6ICdIb3dhcmQgU3QgJiAzcmQsIFNhbiBGcmFuY2lzY28sIENBJyB9LFxuICAgICAgXSxcbiAgICAgIHNjcmVlblRpbWU6IHtcbiAgICAgICAgdG9kYXlVc2FnZU1pbnV0ZXM6IDg1LFxuICAgICAgICBkYWlseUxpbWl0TWludXRlczogMTIwLFxuICAgICAgICBiZWR0aW1lU3RhcnQ6ICcyMDozMCcsXG4gICAgICAgIGJlZHRpbWVFbmQ6ICcwNzowMCcsXG4gICAgICAgIGJlZHRpbWVFbmZvcmNlZDogdHJ1ZSxcbiAgICAgICAgYXBwUnVsZXM6IFtcbiAgICAgICAgICB7IHBhY2thZ2VOYW1lOiAnY29tLmdvb2dsZS5hbmRyb2lkLnlvdXR1YmUnLCBhcHBOYW1lOiAnWW91VHViZScsIGNhdGVnb3J5OiAndmlkZW8nLCBzdGF0dXM6ICdsaW1pdGVkJywgZGFpbHlMaW1pdE1pbnV0ZXM6IDQ1LCB1c2VkVG9kYXlNaW51dGVzOiAzMCwgaWNvbk5hbWU6ICdZb3V0dWJlJyB9LFxuICAgICAgICAgIHsgcGFja2FnZU5hbWU6ICdjb20ucm9ibG94LmNsaWVudCcsIGFwcE5hbWU6ICdSb2Jsb3gnLCBjYXRlZ29yeTogJ2dhbWVzJywgc3RhdHVzOiAnbG9ja2VkJywgZGFpbHlMaW1pdE1pbnV0ZXM6IDMwLCB1c2VkVG9kYXlNaW51dGVzOiAyMCwgaWNvbk5hbWU6ICdHYW1lcGFkMicgfSxcbiAgICAgICAgICB7IHBhY2thZ2VOYW1lOiAnY29tLnpoaWxpYW9hcHAubXVzaWNhbGx5JywgYXBwTmFtZTogJ1Rpa1RvaycsIGNhdGVnb3J5OiAnc29jaWFsJywgc3RhdHVzOiAnbG9ja2VkJywgZGFpbHlMaW1pdE1pbnV0ZXM6IDAsIHVzZWRUb2RheU1pbnV0ZXM6IDAsIGljb25OYW1lOiAnU2hhcmUyJyB9LFxuICAgICAgICAgIHsgcGFja2FnZU5hbWU6ICdjb20uZHVvbGluZ28nLCBhcHBOYW1lOiAnRHVvbGluZ28nLCBjYXRlZ29yeTogJ2VkdWNhdGlvbicsIHN0YXR1czogJ2FsbG93ZWQnLCBkYWlseUxpbWl0TWludXRlczogNjAsIHVzZWRUb2RheU1pbnV0ZXM6IDE1LCBpY29uTmFtZTogJ0Jvb2tPcGVuJyB9LFxuICAgICAgICAgIHsgcGFja2FnZU5hbWU6ICdvcmcua2hhbmFjYWRlbXkuYW5kcm9pZCcsIGFwcE5hbWU6ICdLaGFuIEFjYWRlbXknLCBjYXRlZ29yeTogJ2VkdWNhdGlvbicsIHN0YXR1czogJ2FsbG93ZWQnLCBkYWlseUxpbWl0TWludXRlczogMTIwLCB1c2VkVG9kYXlNaW51dGVzOiAyMCwgaWNvbk5hbWU6ICdHcmFkdWF0aW9uQ2FwJyB9LFxuICAgICAgICAgIHsgcGFja2FnZU5hbWU6ICdjb20uYW5kcm9pZC5jaHJvbWUnLCBhcHBOYW1lOiAnU2FmZSBDaHJvbWUnLCBjYXRlZ29yeTogJ2Jyb3dzaW5nJywgc3RhdHVzOiAnYWxsb3dlZCcsIGRhaWx5TGltaXRNaW51dGVzOiA2MCwgdXNlZFRvZGF5TWludXRlczogMCwgaWNvbk5hbWU6ICdDb21wYXNzJyB9LFxuICAgICAgICBdLFxuICAgICAgfSxcbiAgICAgIHdlYkZpbHRlcjoge1xuICAgICAgICBzYWZlU2VhcmNoRW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgYmxvY2tlZENhdGVnb3JpZXM6IFsnYWR1bHQnLCAnZ2FtYmxpbmcnLCAndmlvbGVuY2UnLCAnd2VhcG9ucycsICdkYXRpbmcnXSxcbiAgICAgICAgYmxvY2tlZERvbWFpbnM6IFsndGlrdG9rLmNvbScsICdvbWVnbGUuY29tJywgJ2Rpc2NvcmQuY29tJywgJ2NoYXRyb3VsZXR0ZS5jb20nXSxcbiAgICAgICAgYWxsb3dlZERvbWFpbnM6IFsnd2lraXBlZGlhLm9yZycsICdraGFuYWNhZGVteS5vcmcnLCAnbmF0aW9uYWxnZW9ncmFwaGljLmNvbScsICdzY3JhdGNoLm1pdC5lZHUnLCAnbmFzYS5nb3YnXSxcbiAgICAgIH0sXG4gICAgICBhbnRpVW5pbnN0YWxsOiB7XG4gICAgICAgIGRldmljZUFkbWluRW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgYWNjZXNzaWJpbGl0eUxvY2tFbmFibGVkOiB0cnVlLFxuICAgICAgICBwcmV2ZW50U2V0dGluZ3NUYW1wZXI6IHRydWUsXG4gICAgICAgIHVuaW5zdGFsbEF0dGVtcHRzQ291bnQ6IDAsXG4gICAgICB9LFxuICAgICAgc2FmZVpvbmVzOiBbXG4gICAgICAgIHsgaWQ6ICd6b25lLWhvbWUnLCBuYW1lOiAnSG9tZScsIGxhdGl0dWRlOiAzNy43NzQ5LCBsb25naXR1ZGU6IC0xMjIuNDE5NCwgcmFkaXVzTWV0ZXJzOiAyMDAsIGljb246ICdIb21lJywgZW5hYmxlZDogdHJ1ZSB9LFxuICAgICAgICB7IGlkOiAnem9uZS1zY2hvb2wnLCBuYW1lOiAnTGluY29sbiBNaWRkbGUgU2Nob29sJywgbGF0aXR1ZGU6IDM3Ljc3ODAsIGxvbmdpdHVkZTogLTEyMi40MTUwLCByYWRpdXNNZXRlcnM6IDMwMCwgaWNvbjogJ1NjaG9vbCcsIGVuYWJsZWQ6IHRydWUgfSxcbiAgICAgICAgeyBpZDogJ3pvbmUtcGFyaycsIG5hbWU6ICdZZXJiYSBCdWVuYSBQYXJrJywgbGF0aXR1ZGU6IDM3Ljc4NTAsIGxvbmdpdHVkZTogLTEyMi40MDIwLCByYWRpdXNNZXRlcnM6IDI1MCwgaWNvbjogJ1RyZWVzJywgZW5hYmxlZDogdHJ1ZSB9LFxuICAgICAgXSxcbiAgICAgIGFjdGl2ZVNlc3Npb25zOiB7fSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAnY2hpbGQtbWF5YScsXG4gICAgICBuYW1lOiAnTWF5YScsXG4gICAgICBhZ2U6IDcsXG4gICAgICBhdmF0YXI6ICfwn5GnJyxcbiAgICAgIGRldmljZU1vZGVsOiAnU2Ftc3VuZyBHYWxheHkgVGFiIEE5JyxcbiAgICAgIG9zVmVyc2lvbjogJ0FuZHJvaWQgMTMgKE9uZSBVSSA1LjEpJyxcbiAgICAgIGJhdHRlcnlMZXZlbDogNDIsXG4gICAgICBpc0NoYXJnaW5nOiB0cnVlLFxuICAgICAgaXNPbmxpbmU6IHRydWUsXG4gICAgICBsYXN0U2VlbjogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgbG9jYXRpb246IHtcbiAgICAgICAgbGF0aXR1ZGU6IDM3Ljc3NDksXG4gICAgICAgIGxvbmdpdHVkZTogLTEyMi40MTk0LFxuICAgICAgICBhY2N1cmFjeTogOCxcbiAgICAgICAgc3BlZWQ6IDAsXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICBhZGRyZXNzOiAnSG9tZSAoU2FmZSBab25lKScsXG4gICAgICB9LFxuICAgICAgbG9jYXRpb25IaXN0b3J5OiBbXG4gICAgICAgIHsgbGF0aXR1ZGU6IDM3Ljc3NDksIGxvbmdpdHVkZTogLTEyMi40MTk0LCB0aW1lc3RhbXA6IG5ldyBEYXRlKERhdGUubm93KCkgLSAxMCAqIDYwMDAwKS50b0lTT1N0cmluZygpLCBhZGRyZXNzOiAnSG9tZSAoU2FmZSBab25lKScgfSxcbiAgICAgIF0sXG4gICAgICBzY3JlZW5UaW1lOiB7XG4gICAgICAgIHRvZGF5VXNhZ2VNaW51dGVzOiA0NSxcbiAgICAgICAgZGFpbHlMaW1pdE1pbnV0ZXM6IDYwLFxuICAgICAgICBiZWR0aW1lU3RhcnQ6ICcxOTo0NScsXG4gICAgICAgIGJlZHRpbWVFbmQ6ICcwNzozMCcsXG4gICAgICAgIGJlZHRpbWVFbmZvcmNlZDogdHJ1ZSxcbiAgICAgICAgYXBwUnVsZXM6IFtcbiAgICAgICAgICB7IHBhY2thZ2VOYW1lOiAnY29tLmdvb2dsZS5hbmRyb2lkLmFwcHMueW91dHViZS5raWRzJywgYXBwTmFtZTogJ1lvdVR1YmUgS2lkcycsIGNhdGVnb3J5OiAndmlkZW8nLCBzdGF0dXM6ICdsaW1pdGVkJywgZGFpbHlMaW1pdE1pbnV0ZXM6IDMwLCB1c2VkVG9kYXlNaW51dGVzOiAyNSwgaWNvbk5hbWU6ICdZb3V0dWJlJyB9LFxuICAgICAgICAgIHsgcGFja2FnZU5hbWU6ICdjb20udG9jYWJvY2EudG9jYWxpZmV3b3JsZCcsIGFwcE5hbWU6ICdUb2NhIExpZmUgV29ybGQnLCBjYXRlZ29yeTogJ2dhbWVzJywgc3RhdHVzOiAnYWxsb3dlZCcsIGRhaWx5TGltaXRNaW51dGVzOiAzMCwgdXNlZFRvZGF5TWludXRlczogMTUsIGljb25OYW1lOiAnR2FtZXBhZDInIH0sXG4gICAgICAgICAgeyBwYWNrYWdlTmFtZTogJ2NvbS5kdW9saW5nby5raWRzJywgYXBwTmFtZTogJ0R1b2xpbmdvIEFCQycsIGNhdGVnb3J5OiAnZWR1Y2F0aW9uJywgc3RhdHVzOiAnYWxsb3dlZCcsIGRhaWx5TGltaXRNaW51dGVzOiA2MCwgdXNlZFRvZGF5TWludXRlczogNSwgaWNvbk5hbWU6ICdCb29rT3BlbicgfSxcbiAgICAgICAgXSxcbiAgICAgIH0sXG4gICAgICB3ZWJGaWx0ZXI6IHtcbiAgICAgICAgc2FmZVNlYXJjaEVuYWJsZWQ6IHRydWUsXG4gICAgICAgIGJsb2NrZWRDYXRlZ29yaWVzOiBbJ2FkdWx0JywgJ2dhbWJsaW5nJywgJ3Zpb2xlbmNlJywgJ3NvY2lhbCcsICdnYW1pbmcnXSxcbiAgICAgICAgYmxvY2tlZERvbWFpbnM6IFsneW91dHViZS5jb20nLCAncm9ibG94LmNvbSddLFxuICAgICAgICBhbGxvd2VkRG9tYWluczogWydwYnNraWRzLm9yZycsICdzdGFyZmFsbC5jb20nLCAnbmF0Z2Vva2lkcy5jb20nXSxcbiAgICAgIH0sXG4gICAgICBhbnRpVW5pbnN0YWxsOiB7XG4gICAgICAgIGRldmljZUFkbWluRW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgYWNjZXNzaWJpbGl0eUxvY2tFbmFibGVkOiB0cnVlLFxuICAgICAgICBwcmV2ZW50U2V0dGluZ3NUYW1wZXI6IHRydWUsXG4gICAgICAgIHVuaW5zdGFsbEF0dGVtcHRzQ291bnQ6IDAsXG4gICAgICB9LFxuICAgICAgc2FmZVpvbmVzOiBbXG4gICAgICAgIHsgaWQ6ICd6b25lLWhvbWUnLCBuYW1lOiAnSG9tZScsIGxhdGl0dWRlOiAzNy43NzQ5LCBsb25naXR1ZGU6IC0xMjIuNDE5NCwgcmFkaXVzTWV0ZXJzOiAyMDAsIGljb246ICdIb21lJywgZW5hYmxlZDogdHJ1ZSB9LFxuICAgICAgXSxcbiAgICAgIGFjdGl2ZVNlc3Npb25zOiB7fSxcbiAgICB9LFxuICBdLFxuICBhbGVydHM6IFtcbiAgICB7XG4gICAgICBpZDogJ2FsZXJ0LTEnLFxuICAgICAgY2hpbGRJZDogJ2NoaWxkLWxlbycsXG4gICAgICBjaGlsZE5hbWU6ICdMZW8nLFxuICAgICAgdHlwZTogJ2dlb2ZlbmNlX2VudGVyJyxcbiAgICAgIHRpdGxlOiAnRW50ZXJlZCBTYWZlIFpvbmU6IEhvbWUnLFxuICAgICAgbWVzc2FnZTogJ0xlbyBhcnJpdmVkIHNhZmVseSBpbnNpZGUgSG9tZSBzYWZlIHpvbmUuJyxcbiAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDQwICogNjAwMDApLnRvSVNPU3RyaW5nKCksXG4gICAgICBzZXZlcml0eTogJ2luZm8nLFxuICAgICAgcmVhZDogdHJ1ZSxcbiAgICAgIGNvb3JkaW5hdGVzOiB7IGxhdGl0dWRlOiAzNy43NzQ5LCBsb25naXR1ZGU6IC0xMjIuNDE5NCB9LFxuICAgIH0sXG4gICAge1xuICAgICAgaWQ6ICdhbGVydC0yJyxcbiAgICAgIGNoaWxkSWQ6ICdjaGlsZC1sZW8nLFxuICAgICAgY2hpbGROYW1lOiAnTGVvJyxcbiAgICAgIHR5cGU6ICdibG9ja2VkX3NpdGUnLFxuICAgICAgdGl0bGU6ICdCbG9ja2VkIFdlYnNpdGUgQXR0ZW1wdCcsXG4gICAgICBtZXNzYWdlOiAnTGVvIGF0dGVtcHRlZCB0byBvcGVuIGRpc2NvcmQuY29tLCBibG9ja2VkIGJ5IFdlYiBGaWx0ZXIuJyxcbiAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDE1ICogNjAwMDApLnRvSVNPU3RyaW5nKCksXG4gICAgICBzZXZlcml0eTogJ3dhcm5pbmcnLFxuICAgICAgcmVhZDogZmFsc2UsXG4gICAgfSxcbiAgXSxcbiAgbWVzc2FnZXM6IFtcbiAgICB7XG4gICAgICBpZDogJ21zZy0xJyxcbiAgICAgIGNoaWxkSWQ6ICdjaGlsZC1sZW8nLFxuICAgICAgc2VuZGVyOiAncGFyZW50JyxcbiAgICAgIHRleHQ6ICdSZW1lbWJlciBzb2NjZXIgcHJhY3RpY2UgYXQgNDozMCBQTSB0b2RheSEnLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gNjAgKiA2MDAwMCkudG9JU09TdHJpbmcoKSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAnbXNnLTInLFxuICAgICAgY2hpbGRJZDogJ2NoaWxkLWxlbycsXG4gICAgICBzZW5kZXI6ICdjaGlsZCcsXG4gICAgICB0ZXh0OiAnR290IGl0IERhZCEgSGF2ZSBteSBjbGVhdHMgcGFja2VkLicsXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKERhdGUubm93KCkgLSA1MCAqIDYwMDAwKS50b0lTT1N0cmluZygpLFxuICAgIH0sXG4gIF0sXG4gIHBhaXJpbmdDb2RlczogW10sXG59O1xuXG4vLyBEYXRhYmFzZSBoZWxwZXIgZnVuY3Rpb25zXG5mdW5jdGlvbiBsb2FkREIoKTogREJTdGF0ZSB7XG4gIHRyeSB7XG4gICAgaWYgKGZzLmV4aXN0c1N5bmMoREJfRklMRSkpIHtcbiAgICAgIGNvbnN0IGRhdGEgPSBmcy5yZWFkRmlsZVN5bmMoREJfRklMRSwgJ3V0Zi04Jyk7XG4gICAgICBjb25zdCBwYXJzZWQ6IERCU3RhdGUgPSBKU09OLnBhcnNlKGRhdGEpO1xuICAgICAgcGFyc2VkLmNoaWxkcmVuLmZvckVhY2goKGMpID0+IHtcbiAgICAgICAgaWYgKCFjLmFudGlVbmluc3RhbGwpIHtcbiAgICAgICAgICBjLmFudGlVbmluc3RhbGwgPSB7XG4gICAgICAgICAgICBkZXZpY2VBZG1pbkVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICBhY2Nlc3NpYmlsaXR5TG9ja0VuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICBwcmV2ZW50U2V0dGluZ3NUYW1wZXI6IHRydWUsXG4gICAgICAgICAgICB1bmluc3RhbGxBdHRlbXB0c0NvdW50OiAwLFxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHBhcnNlZDtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGxvYWRpbmcgREIgZmlsZSwgaW5pdGlhbGl6aW5nIGRlZmF1bHQ6JywgZXJyKTtcbiAgfVxuICBzYXZlREIoREVGQVVMVF9TVEFURSk7XG4gIHJldHVybiBERUZBVUxUX1NUQVRFO1xufVxuXG5mdW5jdGlvbiBzYXZlREIoc3RhdGU6IERCU3RhdGUpIHtcbiAgdHJ5IHtcbiAgICBmcy53cml0ZUZpbGVTeW5jKERCX0ZJTEUsIEpTT04uc3RyaW5naWZ5KHN0YXRlLCBudWxsLCAyKSwgJ3V0Zi04Jyk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHdyaXRpbmcgREIgZmlsZTonLCBlcnIpO1xuICB9XG59XG5cbmxldCBkYiA9IGxvYWREQigpO1xuXG5hc3luYyBmdW5jdGlvbiBzdGFydFNlcnZlcigpIHtcbiAgY29uc3QgYXBwID0gZXhwcmVzcygpO1xuICBhcHAudXNlKGV4cHJlc3MuanNvbigpKTtcblxuICAvLyBBUEkgRW5kcG9pbnRzXG4gIC8vIDEuIEdldCBmdWxsIHN0YXRlXG4gIGFwcC5nZXQoJy9hcGkvc3RhdGUnLCAocmVxLCByZXMpID0+IHtcbiAgICByZXMuanNvbihkYik7XG4gIH0pO1xuXG4gIC8vIERvd25sb2FkIGVudGlyZSBwcm9qZWN0IGFzIGEgWklQIGFyY2hpdmVcbiAgYXBwLmdldCgnL2FwaS9kb3dubG9hZC16aXAnLCBhc3luYyAocmVxLCByZXMpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgemlwID0gbmV3IEpTWmlwKCk7XG4gICAgICBjb25zdCBhZGREaXJlY3RvcnlUb1ppcCA9IChkaXJQYXRoOiBzdHJpbmcsIHppcEZvbGRlcjogSlNaaXApID0+IHtcbiAgICAgICAgY29uc3QgaXRlbXMgPSBmcy5yZWFkZGlyU3luYyhkaXJQYXRoKTtcbiAgICAgICAgZm9yIChjb25zdCBpdGVtIG9mIGl0ZW1zKSB7XG4gICAgICAgICAgaWYgKFxuICAgICAgICAgICAgaXRlbSA9PT0gJ25vZGVfbW9kdWxlcycgfHxcbiAgICAgICAgICAgIGl0ZW0gPT09ICcuZ2l0JyB8fFxuICAgICAgICAgICAgaXRlbSA9PT0gJ2Rpc3QnIHx8XG4gICAgICAgICAgICBpdGVtID09PSAnLmNhY2hlJyB8fFxuICAgICAgICAgICAgaXRlbSA9PT0gJy5haXN0dWRpbydcbiAgICAgICAgICApIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBmdWxsUGF0aCA9IHBhdGguam9pbihkaXJQYXRoLCBpdGVtKTtcbiAgICAgICAgICBjb25zdCBzdGF0ID0gZnMuc3RhdFN5bmMoZnVsbFBhdGgpO1xuICAgICAgICAgIGlmIChzdGF0LmlzRGlyZWN0b3J5KCkpIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHRGb2xkZXIgPSB6aXBGb2xkZXIuZm9sZGVyKGl0ZW0pO1xuICAgICAgICAgICAgaWYgKG5leHRGb2xkZXIpIGFkZERpcmVjdG9yeVRvWmlwKGZ1bGxQYXRoLCBuZXh0Rm9sZGVyKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgZmlsZUNvbnRlbnQgPSBmcy5yZWFkRmlsZVN5bmMoZnVsbFBhdGgpO1xuICAgICAgICAgICAgemlwRm9sZGVyLmZpbGUoaXRlbSwgZmlsZUNvbnRlbnQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgYWRkRGlyZWN0b3J5VG9aaXAoX19kaXJuYW1lLCB6aXApO1xuXG4gICAgICBjb25zdCBidWZmZXIgPSBhd2FpdCB6aXAuZ2VuZXJhdGVBc3luYyh7IHR5cGU6ICdub2RlYnVmZmVyJywgY29tcHJlc3Npb246ICdERUZMQVRFJyB9KTtcbiAgICAgIHJlcy5zZXRIZWFkZXIoJ0NvbnRlbnQtVHlwZScsICdhcHBsaWNhdGlvbi96aXAnKTtcbiAgICAgIHJlcy5zZXRIZWFkZXIoJ0NvbnRlbnQtRGlzcG9zaXRpb24nLCAnYXR0YWNobWVudDsgZmlsZW5hbWU9XCJTYWZlS2lkcy1Db21wbGV0ZS1Qcm9qZWN0LnppcFwiJyk7XG4gICAgICByZXMuc2V0SGVhZGVyKCdDb250ZW50LUxlbmd0aCcsIGJ1ZmZlci5sZW5ndGgpO1xuICAgICAgcmV0dXJuIHJlcy5zZW5kKGJ1ZmZlcik7XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGdlbmVyYXRpbmcgemlwOicsIGVycik7XG4gICAgICByZXR1cm4gcmVzLnN0YXR1cyg1MDApLmpzb24oeyBlcnJvcjogJ0ZhaWxlZCB0byBnZW5lcmF0ZSB6aXAgZmlsZScgfSk7XG4gICAgfVxuICB9KTtcblxuICAvLyAyLiBWZXJpZnkgb3IgdXBkYXRlIFBhcmVudCBQSU5cbiAgYXBwLnBvc3QoJy9hcGkvYXV0aC92ZXJpZnktcGluJywgKHJlcSwgcmVzKSA9PiB7XG4gICAgY29uc3QgeyBwaW4gfSA9IHJlcS5ib2R5O1xuICAgIGlmIChwaW4gPT09IGRiLnBhcmVudFBpbikge1xuICAgICAgcmV0dXJuIHJlcy5qc29uKHsgc3VjY2VzczogdHJ1ZSB9KTtcbiAgICB9XG4gICAgcmV0dXJuIHJlcy5zdGF0dXMoNDAxKS5qc29uKHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnSW5jb3JyZWN0IFBJTicgfSk7XG4gIH0pO1xuXG4gIGFwcC5wb3N0KCcvYXBpL2F1dGgvdXBkYXRlLXBpbicsIChyZXEsIHJlcykgPT4ge1xuICAgIGNvbnN0IHsgY3VycmVudFBpbiwgbmV3UGluIH0gPSByZXEuYm9keTtcbiAgICBpZiAoY3VycmVudFBpbiAhPT0gZGIucGFyZW50UGluKSB7XG4gICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDEpLmpzb24oeyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdDdXJyZW50IFBJTiBpcyBpbnZhbGlkJyB9KTtcbiAgICB9XG4gICAgaWYgKCFuZXdQaW4gfHwgbmV3UGluLmxlbmd0aCA8IDQpIHtcbiAgICAgIHJldHVybiByZXMuc3RhdHVzKDQwMCkuanNvbih7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ05ldyBQSU4gbXVzdCBiZSBhdCBsZWFzdCA0IGRpZ2l0cycgfSk7XG4gICAgfVxuICAgIGRiLnBhcmVudFBpbiA9IG5ld1BpbjtcbiAgICBzYXZlREIoZGIpO1xuICAgIHJlcy5qc29uKHsgc3VjY2VzczogdHJ1ZSwgbWVzc2FnZTogJ1BJTiB1cGRhdGVkIHN1Y2Nlc3NmdWxseScgfSk7XG4gIH0pO1xuXG4gIC8vIDMuIENoaWxkIFBhaXJpbmcgRW5kcG9pbnRzXG4gIGFwcC5wb3N0KCcvYXBpL3BhaXIvZ2VuZXJhdGUnLCAocmVxLCByZXMpID0+IHtcbiAgICBjb25zdCB7IGNoaWxkTmFtZSwgYWdlLCBkZXZpY2VNb2RlbCB9ID0gcmVxLmJvZHk7XG4gICAgY29uc3QgY29kZSA9IE1hdGguZmxvb3IoMTAwMDAwICsgTWF0aC5yYW5kb20oKSAqIDkwMDAwMCkudG9TdHJpbmcoKTtcbiAgICBjb25zdCBleHBpcmVzQXQgPSBEYXRlLm5vdygpICsgMTUgKiA2MCAqIDEwMDA7IC8vIDE1IG1pbnNcblxuICAgIC8vIGNyZWF0ZSBvciBmaW5kIGNoaWxkXG4gICAgbGV0IGNoaWxkSWQgPSBgY2hpbGQtJHtEYXRlLm5vdygpLnRvU3RyaW5nKDM2KX1gO1xuICAgIGNvbnN0IG5ld0NoaWxkOiBDaGlsZERldmljZSA9IHtcbiAgICAgIGlkOiBjaGlsZElkLFxuICAgICAgbmFtZTogY2hpbGROYW1lIHx8ICdOZXcgQ2hpbGQnLFxuICAgICAgYWdlOiBhZ2UgfHwgOCxcbiAgICAgIGF2YXRhcjogJ/Cfp5InLFxuICAgICAgZGV2aWNlTW9kZWw6IGRldmljZU1vZGVsIHx8ICdBbmRyb2lkIFBob25lJyxcbiAgICAgIG9zVmVyc2lvbjogJ0FuZHJvaWQgMTQgKEFQSSAzNCknLFxuICAgICAgYmF0dGVyeUxldmVsOiA5MCxcbiAgICAgIGlzQ2hhcmdpbmc6IGZhbHNlLFxuICAgICAgaXNPbmxpbmU6IGZhbHNlLFxuICAgICAgbGFzdFNlZW46IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGxvY2F0aW9uOiB7XG4gICAgICAgIGxhdGl0dWRlOiAzNy43NzQ5LFxuICAgICAgICBsb25naXR1ZGU6IC0xMjIuNDE5NCxcbiAgICAgICAgYWNjdXJhY3k6IDEwLFxuICAgICAgICBzcGVlZDogMCxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGFkZHJlc3M6ICdTdGFuZGJ5IC8gV2FpdGluZyBmb3IgR1BTJyxcbiAgICAgIH0sXG4gICAgICBsb2NhdGlvbkhpc3Rvcnk6IFtdLFxuICAgICAgc2NyZWVuVGltZToge1xuICAgICAgICB0b2RheVVzYWdlTWludXRlczogMCxcbiAgICAgICAgZGFpbHlMaW1pdE1pbnV0ZXM6IDEyMCxcbiAgICAgICAgYmVkdGltZVN0YXJ0OiAnMjE6MDAnLFxuICAgICAgICBiZWR0aW1lRW5kOiAnMDc6MDAnLFxuICAgICAgICBiZWR0aW1lRW5mb3JjZWQ6IHRydWUsXG4gICAgICAgIGFwcFJ1bGVzOiBbXG4gICAgICAgICAgeyBwYWNrYWdlTmFtZTogJ2NvbS5nb29nbGUuYW5kcm9pZC55b3V0dWJlJywgYXBwTmFtZTogJ1lvdVR1YmUnLCBjYXRlZ29yeTogJ3ZpZGVvJywgc3RhdHVzOiAnbGltaXRlZCcsIGRhaWx5TGltaXRNaW51dGVzOiA0NSwgdXNlZFRvZGF5TWludXRlczogMCwgaWNvbk5hbWU6ICdZb3V0dWJlJyB9LFxuICAgICAgICAgIHsgcGFja2FnZU5hbWU6ICdjb20ucm9ibG94LmNsaWVudCcsIGFwcE5hbWU6ICdSb2Jsb3gnLCBjYXRlZ29yeTogJ2dhbWVzJywgc3RhdHVzOiAnbG9ja2VkJywgZGFpbHlMaW1pdE1pbnV0ZXM6IDMwLCB1c2VkVG9kYXlNaW51dGVzOiAwLCBpY29uTmFtZTogJ0dhbWVwYWQyJyB9LFxuICAgICAgICAgIHsgcGFja2FnZU5hbWU6ICdjb20uZHVvbGluZ28nLCBhcHBOYW1lOiAnRHVvbGluZ28nLCBjYXRlZ29yeTogJ2VkdWNhdGlvbicsIHN0YXR1czogJ2FsbG93ZWQnLCBkYWlseUxpbWl0TWludXRlczogNjAsIHVzZWRUb2RheU1pbnV0ZXM6IDAsIGljb25OYW1lOiAnQm9va09wZW4nIH0sXG4gICAgICAgIF0sXG4gICAgICB9LFxuICAgICAgd2ViRmlsdGVyOiB7XG4gICAgICAgIHNhZmVTZWFyY2hFbmFibGVkOiB0cnVlLFxuICAgICAgICBibG9ja2VkQ2F0ZWdvcmllczogWydhZHVsdCcsICdnYW1ibGluZycsICd2aW9sZW5jZSddLFxuICAgICAgICBibG9ja2VkRG9tYWluczogW10sXG4gICAgICAgIGFsbG93ZWREb21haW5zOiBbXSxcbiAgICAgIH0sXG4gICAgICBhbnRpVW5pbnN0YWxsOiB7XG4gICAgICAgIGRldmljZUFkbWluRW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgYWNjZXNzaWJpbGl0eUxvY2tFbmFibGVkOiB0cnVlLFxuICAgICAgICBwcmV2ZW50U2V0dGluZ3NUYW1wZXI6IHRydWUsXG4gICAgICAgIHVuaW5zdGFsbEF0dGVtcHRzQ291bnQ6IDAsXG4gICAgICB9LFxuICAgICAgc2FmZVpvbmVzOiBbXG4gICAgICAgIHsgaWQ6ICd6b25lLWhvbWUnLCBuYW1lOiAnSG9tZScsIGxhdGl0dWRlOiAzNy43NzQ5LCBsb25naXR1ZGU6IC0xMjIuNDE5NCwgcmFkaXVzTWV0ZXJzOiAyMDAsIGljb246ICdIb21lJywgZW5hYmxlZDogdHJ1ZSB9LFxuICAgICAgXSxcbiAgICAgIGFjdGl2ZVNlc3Npb25zOiB7fSxcbiAgICB9O1xuXG4gICAgZGIuY2hpbGRyZW4ucHVzaChuZXdDaGlsZCk7XG4gICAgZGIucGFpcmluZ0NvZGVzLnB1c2goeyBjb2RlLCBjaGlsZElkLCBleHBpcmVzQXQgfSk7XG4gICAgc2F2ZURCKGRiKTtcblxuICAgIHJlcy5qc29uKHsgY29kZSwgY2hpbGRJZCwgZXhwaXJlc0F0IH0pO1xuICB9KTtcblxuICBhcHAucG9zdCgnL2FwaS9wYWlyL2NsYWltJywgKHJlcSwgcmVzKSA9PiB7XG4gICAgY29uc3QgeyBjb2RlLCBkZXZpY2VNb2RlbCwgb3NWZXJzaW9uIH0gPSByZXEuYm9keTtcbiAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgIGNvbnN0IGVudHJ5SW5kZXggPSBkYi5wYWlyaW5nQ29kZXMuZmluZEluZGV4KChwKSA9PiBwLmNvZGUgPT09IGNvZGUgJiYgcC5leHBpcmVzQXQgPiBub3cpO1xuXG4gICAgaWYgKGVudHJ5SW5kZXggPT09IC0xKSB7XG4gICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDApLmpzb24oeyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdJbnZhbGlkIG9yIGV4cGlyZWQgcGFpcmluZyBjb2RlJyB9KTtcbiAgICB9XG5cbiAgICBjb25zdCB7IGNoaWxkSWQgfSA9IGRiLnBhaXJpbmdDb2Rlc1tlbnRyeUluZGV4XTtcbiAgICBjb25zdCBjaGlsZCA9IGRiLmNoaWxkcmVuLmZpbmQoKGMpID0+IGMuaWQgPT09IGNoaWxkSWQpO1xuXG4gICAgaWYgKCFjaGlsZCkge1xuICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoNDA0KS5qc29uKHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnQ2hpbGQgcmVjb3JkIG5vdCBmb3VuZCcgfSk7XG4gICAgfVxuXG4gICAgY2hpbGQuaXNPbmxpbmUgPSB0cnVlO1xuICAgIGNoaWxkLmxhc3RTZWVuID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGlmIChkZXZpY2VNb2RlbCkgY2hpbGQuZGV2aWNlTW9kZWwgPSBkZXZpY2VNb2RlbDtcbiAgICBpZiAob3NWZXJzaW9uKSBjaGlsZC5vc1ZlcnNpb24gPSBvc1ZlcnNpb247XG5cbiAgICAvLyByZW1vdmUgY2xhaW1lZCBjb2RlXG4gICAgZGIucGFpcmluZ0NvZGVzLnNwbGljZShlbnRyeUluZGV4LCAxKTtcbiAgICBzYXZlREIoZGIpO1xuXG4gICAgcmVzLmpzb24oeyBzdWNjZXNzOiB0cnVlLCBjaGlsZElkLCBjaGlsZE5hbWU6IGNoaWxkLm5hbWUgfSk7XG4gIH0pO1xuXG4gIC8vIDQuIFVwZGF0ZSBjaGlsZCBkZXZpY2Ugc3RhdHVzICYgR1BTIGxvY2F0aW9uXG4gIGFwcC5wb3N0KCcvYXBpL2NoaWxkLzppZC9oZWFydGJlYXQnLCAocmVxLCByZXMpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSByZXEucGFyYW1zO1xuICAgIGNvbnN0IHsgYmF0dGVyeUxldmVsLCBpc0NoYXJnaW5nLCBsb2NhdGlvbiwgc2NyZWVuVGltZURlbHRhTWludXRlcyB9ID0gcmVxLmJvZHk7XG5cbiAgICBjb25zdCBjaGlsZCA9IGRiLmNoaWxkcmVuLmZpbmQoKGMpID0+IGMuaWQgPT09IGlkKTtcbiAgICBpZiAoIWNoaWxkKSB7XG4gICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDQpLmpzb24oeyBlcnJvcjogJ0NoaWxkIG5vdCBmb3VuZCcgfSk7XG4gICAgfVxuXG4gICAgY2hpbGQuaXNPbmxpbmUgPSB0cnVlO1xuICAgIGNoaWxkLmxhc3RTZWVuID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGlmIChiYXR0ZXJ5TGV2ZWwgIT09IHVuZGVmaW5lZCkgY2hpbGQuYmF0dGVyeUxldmVsID0gYmF0dGVyeUxldmVsO1xuICAgIGlmIChpc0NoYXJnaW5nICE9PSB1bmRlZmluZWQpIGNoaWxkLmlzQ2hhcmdpbmcgPSBpc0NoYXJnaW5nO1xuXG4gICAgaWYgKHNjcmVlblRpbWVEZWx0YU1pbnV0ZXMpIHtcbiAgICAgIGNoaWxkLnNjcmVlblRpbWUudG9kYXlVc2FnZU1pbnV0ZXMgKz0gc2NyZWVuVGltZURlbHRhTWludXRlcztcbiAgICB9XG5cbiAgICBpZiAobG9jYXRpb24gJiYgbG9jYXRpb24ubGF0aXR1ZGUgJiYgbG9jYXRpb24ubG9uZ2l0dWRlKSB7XG4gICAgICBjaGlsZC5sb2NhdGlvbiA9IHtcbiAgICAgICAgbGF0aXR1ZGU6IGxvY2F0aW9uLmxhdGl0dWRlLFxuICAgICAgICBsb25naXR1ZGU6IGxvY2F0aW9uLmxvbmdpdHVkZSxcbiAgICAgICAgYWNjdXJhY3k6IGxvY2F0aW9uLmFjY3VyYWN5IHx8IDEwLFxuICAgICAgICBzcGVlZDogbG9jYXRpb24uc3BlZWQgPz8gbnVsbCxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGFkZHJlc3M6IGxvY2F0aW9uLmFkZHJlc3MgfHwgYCR7bG9jYXRpb24ubGF0aXR1ZGUudG9GaXhlZCg0KX0sICR7bG9jYXRpb24ubG9uZ2l0dWRlLnRvRml4ZWQoNCl9YCxcbiAgICAgIH07XG5cbiAgICAgIC8vIEFkZCB0byBsb2NhdGlvbiBoaXN0b3J5IChrZWVwIGxhc3QgNTApXG4gICAgICBjaGlsZC5sb2NhdGlvbkhpc3RvcnkudW5zaGlmdCh7XG4gICAgICAgIGxhdGl0dWRlOiBsb2NhdGlvbi5sYXRpdHVkZSxcbiAgICAgICAgbG9uZ2l0dWRlOiBsb2NhdGlvbi5sb25naXR1ZGUsXG4gICAgICAgIHRpbWVzdGFtcDogY2hpbGQubG9jYXRpb24udGltZXN0YW1wLFxuICAgICAgICBhZGRyZXNzOiBjaGlsZC5sb2NhdGlvbi5hZGRyZXNzLFxuICAgICAgfSk7XG4gICAgICBpZiAoY2hpbGQubG9jYXRpb25IaXN0b3J5Lmxlbmd0aCA+IDUwKSB7XG4gICAgICAgIGNoaWxkLmxvY2F0aW9uSGlzdG9yeS5wb3AoKTtcbiAgICAgIH1cblxuICAgICAgLy8gQ2hlY2sgZ2VvZmVuY2Ugc3RhdHVzXG4gICAgICBjaGlsZC5zYWZlWm9uZXMuZm9yRWFjaCgoem9uZSkgPT4ge1xuICAgICAgICBpZiAoIXpvbmUuZW5hYmxlZCkgcmV0dXJuO1xuICAgICAgICBjb25zdCBkaXN0ID0gaGF2ZXJzaW5lRGlzdGFuY2UoXG4gICAgICAgICAgbG9jYXRpb24ubGF0aXR1ZGUsXG4gICAgICAgICAgbG9jYXRpb24ubG9uZ2l0dWRlLFxuICAgICAgICAgIHpvbmUubGF0aXR1ZGUsXG4gICAgICAgICAgem9uZS5sb25naXR1ZGVcbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgaXNJbnNpZGUgPSBkaXN0IDw9IHpvbmUucmFkaXVzTWV0ZXJzO1xuICAgICAgICAvLyBJbiBmdWxsIGZsb3cgd2UgY2hlY2sgdHJhbnNpdGlvbnMsIGhlcmUgd2UgY2FuIGxvZyBpZiBlbnRlci9leGl0XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBMb3cgYmF0dGVyeSBhbGVydCBjaGVja1xuICAgIGlmIChjaGlsZC5iYXR0ZXJ5TGV2ZWwgPD0gMTUgJiYgIWNoaWxkLmlzQ2hhcmdpbmcpIHtcbiAgICAgIGNvbnN0IHJlY2VudEJhdHRlcnlBbGVydCA9IGRiLmFsZXJ0cy5maW5kKFxuICAgICAgICAoYSkgPT4gYS5jaGlsZElkID09PSBjaGlsZC5pZCAmJiBhLnR5cGUgPT09ICdsb3dfYmF0dGVyeScgJiYgKERhdGUubm93KCkgLSBuZXcgRGF0ZShhLnRpbWVzdGFtcCkuZ2V0VGltZSgpIDwgMzAgKiA2MDAwMClcbiAgICAgICk7XG4gICAgICBpZiAoIXJlY2VudEJhdHRlcnlBbGVydCkge1xuICAgICAgICBkYi5hbGVydHMudW5zaGlmdCh7XG4gICAgICAgICAgaWQ6IGBhbGVydC0ke0RhdGUubm93KCl9YCxcbiAgICAgICAgICBjaGlsZElkOiBjaGlsZC5pZCxcbiAgICAgICAgICBjaGlsZE5hbWU6IGNoaWxkLm5hbWUsXG4gICAgICAgICAgdHlwZTogJ2xvd19iYXR0ZXJ5JyxcbiAgICAgICAgICB0aXRsZTogYExvdyBCYXR0ZXJ5OiAke2NoaWxkLm5hbWV9J3MgRGV2aWNlICgke2NoaWxkLmJhdHRlcnlMZXZlbH0lKWAsXG4gICAgICAgICAgbWVzc2FnZTogYCR7Y2hpbGQubmFtZX0ncyBkZXZpY2UgaXMgYXQgJHtjaGlsZC5iYXR0ZXJ5TGV2ZWx9JS4gUGxlYXNlIHByb21wdCB0aGVtIHRvIGNoYXJnZSB0aGVpciBkZXZpY2UuYCxcbiAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICBzZXZlcml0eTogJ3dhcm5pbmcnLFxuICAgICAgICAgIHJlYWQ6IGZhbHNlLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBzYXZlREIoZGIpO1xuICAgIHJlcy5qc29uKHtcbiAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICBjaGlsZCxcbiAgICAgIGNvbW1hbmRzOiB7XG4gICAgICAgIGFjdGl2ZUNhbWVyYVNlc3Npb246IGNoaWxkLmFjdGl2ZVNlc3Npb25zLmNhbWVyYVJlcXVlc3QsXG4gICAgICAgIGFjdGl2ZVNjcmVlblNlc3Npb246IGNoaWxkLmFjdGl2ZVNlc3Npb25zLnNjcmVlblJlcXVlc3QsXG4gICAgICAgIHRpbWVFeHRlbnNpb246IGNoaWxkLnRpbWVFeHRlbnNpb25SZXF1ZXN0LFxuICAgICAgICBhcHBSdWxlczogY2hpbGQuc2NyZWVuVGltZS5hcHBSdWxlcyxcbiAgICAgICAgZGFpbHlMaW1pdE1pbnV0ZXM6IGNoaWxkLnNjcmVlblRpbWUuZGFpbHlMaW1pdE1pbnV0ZXMsXG4gICAgICAgIGJlZHRpbWVTdGFydDogY2hpbGQuc2NyZWVuVGltZS5iZWR0aW1lU3RhcnQsXG4gICAgICAgIGJlZHRpbWVFbmQ6IGNoaWxkLnNjcmVlblRpbWUuYmVkdGltZUVuZCxcbiAgICAgICAgYmVkdGltZUVuZm9yY2VkOiBjaGlsZC5zY3JlZW5UaW1lLmJlZHRpbWVFbmZvcmNlZCxcbiAgICAgICAgd2ViRmlsdGVyOiBjaGlsZC53ZWJGaWx0ZXIsXG4gICAgICB9LFxuICAgIH0pO1xuICB9KTtcblxuICAvLyA1LiBUcmlnZ2VyIFNPUyBmcm9tIGNoaWxkXG4gIGFwcC5wb3N0KCcvYXBpL2NoaWxkLzppZC9zb3MnLCAocmVxLCByZXMpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSByZXEucGFyYW1zO1xuICAgIGNvbnN0IHsgbGF0aXR1ZGUsIGxvbmdpdHVkZSwgYXVkaW9TbmlwcGV0IH0gPSByZXEuYm9keTtcbiAgICBjb25zdCBjaGlsZCA9IGRiLmNoaWxkcmVuLmZpbmQoKGMpID0+IGMuaWQgPT09IGlkKTtcblxuICAgIGNvbnN0IGNoaWxkTmFtZSA9IGNoaWxkID8gY2hpbGQubmFtZSA6ICdDaGlsZCc7XG4gICAgY29uc3QgYWxlcnQ6IEFsZXJ0SXRlbSA9IHtcbiAgICAgIGlkOiBgc29zLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgY2hpbGRJZDogaWQsXG4gICAgICBjaGlsZE5hbWUsXG4gICAgICB0eXBlOiAnc29zJyxcbiAgICAgIHRpdGxlOiBg8J+aqCBFTUVSR0VOQ1kgU09TIEFDVElWQVRFRCBCWSAke2NoaWxkTmFtZS50b1VwcGVyQ2FzZSgpfWAsXG4gICAgICBtZXNzYWdlOiBgJHtjaGlsZE5hbWV9IHByZXNzZWQgdGhlIGVtZXJnZW5jeSBTT1MgYnV0dG9uISBJbW1lZGlhdGUgYXR0ZW50aW9uIHJlcXVpcmVkLmAsXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIHNldmVyaXR5OiAnY3JpdGljYWwnLFxuICAgICAgcmVhZDogZmFsc2UsXG4gICAgICBjb29yZGluYXRlczogbGF0aXR1ZGUgJiYgbG9uZ2l0dWRlID8geyBsYXRpdHVkZSwgbG9uZ2l0dWRlIH0gOiBjaGlsZD8ubG9jYXRpb24sXG4gICAgfTtcblxuICAgIGRiLmFsZXJ0cy51bnNoaWZ0KGFsZXJ0KTtcbiAgICBzYXZlREIoZGIpO1xuXG4gICAgcmVzLmpzb24oeyBzdWNjZXNzOiB0cnVlLCBhbGVydCB9KTtcbiAgfSk7XG5cbiAgLy8gNi4gQ2FtZXJhIFJlcXVlc3QgRW5kcG9pbnRzIChDb25zZW50LWJhc2VkKVxuICBhcHAucG9zdCgnL2FwaS9jaGlsZC86aWQvY2FtZXJhLXJlcXVlc3QnLCAocmVxLCByZXMpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSByZXEucGFyYW1zO1xuICAgIGNvbnN0IHsgZmFjaW5nTW9kZSwgcmVhc29uIH0gPSByZXEuYm9keTtcbiAgICBjb25zdCBjaGlsZCA9IGRiLmNoaWxkcmVuLmZpbmQoKGMpID0+IGMuaWQgPT09IGlkKTtcbiAgICBpZiAoIWNoaWxkKSByZXR1cm4gcmVzLnN0YXR1cyg0MDQpLmpzb24oeyBlcnJvcjogJ0NoaWxkIG5vdCBmb3VuZCcgfSk7XG5cbiAgICBjaGlsZC5hY3RpdmVTZXNzaW9ucy5jYW1lcmFSZXF1ZXN0ID0ge1xuICAgICAgaWQ6IGBjYW0tJHtEYXRlLm5vdygpfWAsXG4gICAgICByZXF1ZXN0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgc3RhdHVzOiAncGVuZGluZycsXG4gICAgICBmYWNpbmdNb2RlOiBmYWNpbmdNb2RlIHx8ICd1c2VyJyxcbiAgICAgIHJlYXNvbjogcmVhc29uIHx8ICdQYXJlbnQgY2hlY2staW4nLFxuICAgIH07XG5cbiAgICBzYXZlREIoZGIpO1xuICAgIHJlcy5qc29uKHsgc3VjY2VzczogdHJ1ZSwgc2Vzc2lvbjogY2hpbGQuYWN0aXZlU2Vzc2lvbnMuY2FtZXJhUmVxdWVzdCB9KTtcbiAgfSk7XG5cbiAgYXBwLnBvc3QoJy9hcGkvY2hpbGQvOmlkL2NhbWVyYS1yZXNwb25kJywgKHJlcSwgcmVzKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICBjb25zdCB7IHN0YXR1cyB9ID0gcmVxLmJvZHk7IC8vICdhY2NlcHRlZCcgfCAnZGVuaWVkJyB8ICdlbmRlZCdcbiAgICBjb25zdCBjaGlsZCA9IGRiLmNoaWxkcmVuLmZpbmQoKGMpID0+IGMuaWQgPT09IGlkKTtcbiAgICBpZiAoIWNoaWxkIHx8ICFjaGlsZC5hY3RpdmVTZXNzaW9ucy5jYW1lcmFSZXF1ZXN0KSB7XG4gICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDQpLmpzb24oeyBlcnJvcjogJ1Nlc3Npb24gbm90IGZvdW5kJyB9KTtcbiAgICB9XG5cbiAgICBjaGlsZC5hY3RpdmVTZXNzaW9ucy5jYW1lcmFSZXF1ZXN0LnN0YXR1cyA9IHN0YXR1cztcbiAgICBpZiAoc3RhdHVzID09PSAnZW5kZWQnKSB7XG4gICAgICBkZWxldGUgY2hpbGQuYWN0aXZlU2Vzc2lvbnMuY2FtZXJhUmVxdWVzdDtcbiAgICB9XG5cbiAgICBzYXZlREIoZGIpO1xuICAgIHJlcy5qc29uKHsgc3VjY2VzczogdHJ1ZSB9KTtcbiAgfSk7XG5cbiAgLy8gNy4gU2NyZWVuIFNoYXJpbmcgUmVxdWVzdCBFbmRwb2ludHMgKENvbnNlbnQtYmFzZWQpXG4gIGFwcC5wb3N0KCcvYXBpL2NoaWxkLzppZC9zY3JlZW4tcmVxdWVzdCcsIChyZXEsIHJlcykgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgY29uc3QgeyByZWFzb24gfSA9IHJlcS5ib2R5O1xuICAgIGNvbnN0IGNoaWxkID0gZGIuY2hpbGRyZW4uZmluZCgoYykgPT4gYy5pZCA9PT0gaWQpO1xuICAgIGlmICghY2hpbGQpIHJldHVybiByZXMuc3RhdHVzKDQwNCkuanNvbih7IGVycm9yOiAnQ2hpbGQgbm90IGZvdW5kJyB9KTtcblxuICAgIGNoaWxkLmFjdGl2ZVNlc3Npb25zLnNjcmVlblJlcXVlc3QgPSB7XG4gICAgICBpZDogYHNjcmVlbi0ke0RhdGUubm93KCl9YCxcbiAgICAgIHJlcXVlc3RlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBzdGF0dXM6ICdwZW5kaW5nJyxcbiAgICAgIHJlYXNvbjogcmVhc29uIHx8ICdQYXJlbnQgbGl2ZSBzY3JlZW4gcmV2aWV3JyxcbiAgICB9O1xuXG4gICAgc2F2ZURCKGRiKTtcbiAgICByZXMuanNvbih7IHN1Y2Nlc3M6IHRydWUsIHNlc3Npb246IGNoaWxkLmFjdGl2ZVNlc3Npb25zLnNjcmVlblJlcXVlc3QgfSk7XG4gIH0pO1xuXG4gIGFwcC5wb3N0KCcvYXBpL2NoaWxkLzppZC9zY3JlZW4tcmVzcG9uZCcsIChyZXEsIHJlcykgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgY29uc3QgeyBzdGF0dXMgfSA9IHJlcS5ib2R5OyAvLyAnYWNjZXB0ZWQnIHwgJ2RlbmllZCcgfCAnZW5kZWQnXG4gICAgY29uc3QgY2hpbGQgPSBkYi5jaGlsZHJlbi5maW5kKChjKSA9PiBjLmlkID09PSBpZCk7XG4gICAgaWYgKCFjaGlsZCB8fCAhY2hpbGQuYWN0aXZlU2Vzc2lvbnMuc2NyZWVuUmVxdWVzdCkge1xuICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoNDA0KS5qc29uKHsgZXJyb3I6ICdTZXNzaW9uIG5vdCBmb3VuZCcgfSk7XG4gICAgfVxuXG4gICAgY2hpbGQuYWN0aXZlU2Vzc2lvbnMuc2NyZWVuUmVxdWVzdC5zdGF0dXMgPSBzdGF0dXM7XG4gICAgaWYgKHN0YXR1cyA9PT0gJ2VuZGVkJykge1xuICAgICAgZGVsZXRlIGNoaWxkLmFjdGl2ZVNlc3Npb25zLnNjcmVlblJlcXVlc3Q7XG4gICAgfVxuXG4gICAgc2F2ZURCKGRiKTtcbiAgICByZXMuanNvbih7IHN1Y2Nlc3M6IHRydWUgfSk7XG4gIH0pO1xuXG4gIC8vIDguIFRpbWUgZXh0ZW5zaW9uIHJlcXVlc3RcbiAgYXBwLnBvc3QoJy9hcGkvY2hpbGQvOmlkL3RpbWUtcmVxdWVzdCcsIChyZXEsIHJlcykgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgY29uc3QgeyBtaW51dGVzLCByZWFzb24gfSA9IHJlcS5ib2R5O1xuICAgIGNvbnN0IGNoaWxkID0gZGIuY2hpbGRyZW4uZmluZCgoYykgPT4gYy5pZCA9PT0gaWQpO1xuICAgIGlmICghY2hpbGQpIHJldHVybiByZXMuc3RhdHVzKDQwNCkuanNvbih7IGVycm9yOiAnQ2hpbGQgbm90IGZvdW5kJyB9KTtcblxuICAgIGNoaWxkLnRpbWVFeHRlbnNpb25SZXF1ZXN0ID0ge1xuICAgICAgaWQ6IGByZXEtJHtEYXRlLm5vdygpfWAsXG4gICAgICBtaW51dGVzOiBtaW51dGVzIHx8IDMwLFxuICAgICAgcmVhc29uOiByZWFzb24gfHwgJ0hvbWV3b3JrIC8gRmluaXNoaW5nIHByb2plY3QnLFxuICAgICAgcmVxdWVzdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIHN0YXR1czogJ3BlbmRpbmcnLFxuICAgIH07XG5cbiAgICBkYi5hbGVydHMudW5zaGlmdCh7XG4gICAgICBpZDogYGFsZXJ0LXRpbWUtJHtEYXRlLm5vdygpfWAsXG4gICAgICBjaGlsZElkOiBjaGlsZC5pZCxcbiAgICAgIGNoaWxkTmFtZTogY2hpbGQubmFtZSxcbiAgICAgIHR5cGU6ICd0aW1lX3JlcXVlc3QnLFxuICAgICAgdGl0bGU6IGBTY3JlZW4gVGltZSBFeHRlbnNpb24gUmVxdWVzdDogJHtjaGlsZC5uYW1lfWAsXG4gICAgICBtZXNzYWdlOiBgJHtjaGlsZC5uYW1lfSBpcyByZXF1ZXN0aW5nICR7bWludXRlcyB8fCAzMH0gZXh0cmEgbWludXRlcy4gUmVhc29uOiBcIiR7cmVhc29uIHx8ICdTY2hvb2x3b3JrJ31cImAsXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIHNldmVyaXR5OiAnaW5mbycsXG4gICAgICByZWFkOiBmYWxzZSxcbiAgICB9KTtcblxuICAgIHNhdmVEQihkYik7XG4gICAgcmVzLmpzb24oeyBzdWNjZXNzOiB0cnVlLCByZXF1ZXN0OiBjaGlsZC50aW1lRXh0ZW5zaW9uUmVxdWVzdCB9KTtcbiAgfSk7XG5cbiAgYXBwLnBvc3QoJy9hcGkvY2hpbGQvOmlkL3RpbWUtcmVzcG9uZCcsIChyZXEsIHJlcykgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgY29uc3QgeyBzdGF0dXMsIGdyYW50ZWRNaW51dGVzIH0gPSByZXEuYm9keTsgLy8gJ2FwcHJvdmVkJyB8ICdkZW5pZWQnXG4gICAgY29uc3QgY2hpbGQgPSBkYi5jaGlsZHJlbi5maW5kKChjKSA9PiBjLmlkID09PSBpZCk7XG4gICAgaWYgKCFjaGlsZCkgcmV0dXJuIHJlcy5zdGF0dXMoNDA0KS5qc29uKHsgZXJyb3I6ICdDaGlsZCBub3QgZm91bmQnIH0pO1xuXG4gICAgaWYgKGNoaWxkLnRpbWVFeHRlbnNpb25SZXF1ZXN0KSB7XG4gICAgICBjaGlsZC50aW1lRXh0ZW5zaW9uUmVxdWVzdC5zdGF0dXMgPSBzdGF0dXM7XG4gICAgICBpZiAoc3RhdHVzID09PSAnYXBwcm92ZWQnICYmIGdyYW50ZWRNaW51dGVzKSB7XG4gICAgICAgIGNoaWxkLnNjcmVlblRpbWUuZGFpbHlMaW1pdE1pbnV0ZXMgKz0gZ3JhbnRlZE1pbnV0ZXM7XG4gICAgICB9XG4gICAgfVxuXG4gICAgc2F2ZURCKGRiKTtcbiAgICByZXMuanNvbih7IHN1Y2Nlc3M6IHRydWUsIGRhaWx5TGltaXRNaW51dGVzOiBjaGlsZC5zY3JlZW5UaW1lLmRhaWx5TGltaXRNaW51dGVzIH0pO1xuICB9KTtcblxuICAvLyA5LiBVcGRhdGUgU2NyZWVuIFRpbWUgTGltaXRzICYgQmVkdGltZVxuICBhcHAucG9zdCgnL2FwaS9jaGlsZC86aWQvc2NyZWVuLWxpbWl0cycsIChyZXEsIHJlcykgPT4ge1xuICAgIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gICAgY29uc3QgeyBkYWlseUxpbWl0TWludXRlcywgYmVkdGltZVN0YXJ0LCBiZWR0aW1lRW5kLCBiZWR0aW1lRW5mb3JjZWQgfSA9IHJlcS5ib2R5O1xuICAgIGNvbnN0IGNoaWxkID0gZGIuY2hpbGRyZW4uZmluZCgoYykgPT4gYy5pZCA9PT0gaWQpO1xuICAgIGlmICghY2hpbGQpIHJldHVybiByZXMuc3RhdHVzKDQwNCkuanNvbih7IGVycm9yOiAnQ2hpbGQgbm90IGZvdW5kJyB9KTtcblxuICAgIGlmIChkYWlseUxpbWl0TWludXRlcyAhPT0gdW5kZWZpbmVkKSBjaGlsZC5zY3JlZW5UaW1lLmRhaWx5TGltaXRNaW51dGVzID0gZGFpbHlMaW1pdE1pbnV0ZXM7XG4gICAgaWYgKGJlZHRpbWVTdGFydCAhPT0gdW5kZWZpbmVkKSBjaGlsZC5zY3JlZW5UaW1lLmJlZHRpbWVTdGFydCA9IGJlZHRpbWVTdGFydDtcbiAgICBpZiAoYmVkdGltZUVuZCAhPT0gdW5kZWZpbmVkKSBjaGlsZC5zY3JlZW5UaW1lLmJlZHRpbWVFbmQgPSBiZWR0aW1lRW5kO1xuICAgIGlmIChiZWR0aW1lRW5mb3JjZWQgIT09IHVuZGVmaW5lZCkgY2hpbGQuc2NyZWVuVGltZS5iZWR0aW1lRW5mb3JjZWQgPSBiZWR0aW1lRW5mb3JjZWQ7XG5cbiAgICBzYXZlREIoZGIpO1xuICAgIHJlcy5qc29uKHsgc3VjY2VzczogdHJ1ZSwgc2NyZWVuVGltZTogY2hpbGQuc2NyZWVuVGltZSB9KTtcbiAgfSk7XG5cbiAgLy8gMTAuIFVwZGF0ZSBBcHAgUnVsZVxuICBhcHAucG9zdCgnL2FwaS9jaGlsZC86aWQvYXBwLXJ1bGUnLCAocmVxLCByZXMpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSByZXEucGFyYW1zO1xuICAgIGNvbnN0IHsgcGFja2FnZU5hbWUsIHN0YXR1cywgZGFpbHlMaW1pdE1pbnV0ZXMgfSA9IHJlcS5ib2R5O1xuICAgIGNvbnN0IGNoaWxkID0gZGIuY2hpbGRyZW4uZmluZCgoYykgPT4gYy5pZCA9PT0gaWQpO1xuICAgIGlmICghY2hpbGQpIHJldHVybiByZXMuc3RhdHVzKDQwNCkuanNvbih7IGVycm9yOiAnQ2hpbGQgbm90IGZvdW5kJyB9KTtcblxuICAgIGNvbnN0IHJ1bGUgPSBjaGlsZC5zY3JlZW5UaW1lLmFwcFJ1bGVzLmZpbmQoKHIpID0+IHIucGFja2FnZU5hbWUgPT09IHBhY2thZ2VOYW1lKTtcbiAgICBpZiAocnVsZSkge1xuICAgICAgaWYgKHN0YXR1cykgcnVsZS5zdGF0dXMgPSBzdGF0dXM7XG4gICAgICBpZiAoZGFpbHlMaW1pdE1pbnV0ZXMgIT09IHVuZGVmaW5lZCkgcnVsZS5kYWlseUxpbWl0TWludXRlcyA9IGRhaWx5TGltaXRNaW51dGVzO1xuICAgIH1cblxuICAgIHNhdmVEQihkYik7XG4gICAgcmVzLmpzb24oeyBzdWNjZXNzOiB0cnVlLCBhcHBSdWxlczogY2hpbGQuc2NyZWVuVGltZS5hcHBSdWxlcyB9KTtcbiAgfSk7XG5cbiAgLy8gMTEuIFVwZGF0ZSBXZWIgRmlsdGVyIFNldHRpbmdzXG4gIGFwcC5wb3N0KCcvYXBpL2NoaWxkLzppZC93ZWItZmlsdGVyJywgKHJlcSwgcmVzKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICBjb25zdCB7IHNhZmVTZWFyY2hFbmFibGVkLCBibG9ja2VkQ2F0ZWdvcmllcywgYmxvY2tlZERvbWFpbnMsIGFsbG93ZWREb21haW5zIH0gPSByZXEuYm9keTtcbiAgICBjb25zdCBjaGlsZCA9IGRiLmNoaWxkcmVuLmZpbmQoKGMpID0+IGMuaWQgPT09IGlkKTtcbiAgICBpZiAoIWNoaWxkKSByZXR1cm4gcmVzLnN0YXR1cyg0MDQpLmpzb24oeyBlcnJvcjogJ0NoaWxkIG5vdCBmb3VuZCcgfSk7XG5cbiAgICBpZiAoc2FmZVNlYXJjaEVuYWJsZWQgIT09IHVuZGVmaW5lZCkgY2hpbGQud2ViRmlsdGVyLnNhZmVTZWFyY2hFbmFibGVkID0gc2FmZVNlYXJjaEVuYWJsZWQ7XG4gICAgaWYgKGJsb2NrZWRDYXRlZ29yaWVzKSBjaGlsZC53ZWJGaWx0ZXIuYmxvY2tlZENhdGVnb3JpZXMgPSBibG9ja2VkQ2F0ZWdvcmllcztcbiAgICBpZiAoYmxvY2tlZERvbWFpbnMpIGNoaWxkLndlYkZpbHRlci5ibG9ja2VkRG9tYWlucyA9IGJsb2NrZWREb21haW5zO1xuICAgIGlmIChhbGxvd2VkRG9tYWlucykgY2hpbGQud2ViRmlsdGVyLmFsbG93ZWREb21haW5zID0gYWxsb3dlZERvbWFpbnM7XG5cbiAgICBzYXZlREIoZGIpO1xuICAgIHJlcy5qc29uKHsgc3VjY2VzczogdHJ1ZSwgd2ViRmlsdGVyOiBjaGlsZC53ZWJGaWx0ZXIgfSk7XG4gIH0pO1xuXG4gIC8vIDEyLiBTYWZlIFpvbmVzIE1hbmFnZW1lbnRcbiAgYXBwLnBvc3QoJy9hcGkvY2hpbGQvOmlkL3NhZmUtem9uZXMnLCAocmVxLCByZXMpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSByZXEucGFyYW1zO1xuICAgIGNvbnN0IHsgc2FmZVpvbmVzIH0gPSByZXEuYm9keTtcbiAgICBjb25zdCBjaGlsZCA9IGRiLmNoaWxkcmVuLmZpbmQoKGMpID0+IGMuaWQgPT09IGlkKTtcbiAgICBpZiAoIWNoaWxkKSByZXR1cm4gcmVzLnN0YXR1cyg0MDQpLmpzb24oeyBlcnJvcjogJ0NoaWxkIG5vdCBmb3VuZCcgfSk7XG5cbiAgICBjaGlsZC5zYWZlWm9uZXMgPSBzYWZlWm9uZXM7XG4gICAgc2F2ZURCKGRiKTtcbiAgICByZXMuanNvbih7IHN1Y2Nlc3M6IHRydWUsIHNhZmVab25lczogY2hpbGQuc2FmZVpvbmVzIH0pO1xuICB9KTtcblxuICAvLyAxMmIuIEFudGktVW5pbnN0YWxsIGFuZCBEZXZpY2UgQWRtaW4gU2V0dGluZ3NcbiAgYXBwLnBvc3QoJy9hcGkvY2hpbGQvOmlkL2FudGktdW5pbnN0YWxsJywgKHJlcSwgcmVzKSA9PiB7XG4gICAgY29uc3QgeyBpZCB9ID0gcmVxLnBhcmFtcztcbiAgICBjb25zdCB7IGRldmljZUFkbWluRW5hYmxlZCwgYWNjZXNzaWJpbGl0eUxvY2tFbmFibGVkLCBwcmV2ZW50U2V0dGluZ3NUYW1wZXIgfSA9IHJlcS5ib2R5O1xuICAgIGNvbnN0IGNoaWxkID0gZGIuY2hpbGRyZW4uZmluZCgoYykgPT4gYy5pZCA9PT0gaWQpO1xuICAgIGlmICghY2hpbGQpIHJldHVybiByZXMuc3RhdHVzKDQwNCkuanNvbih7IGVycm9yOiAnQ2hpbGQgbm90IGZvdW5kJyB9KTtcblxuICAgIGlmICghY2hpbGQuYW50aVVuaW5zdGFsbCkge1xuICAgICAgY2hpbGQuYW50aVVuaW5zdGFsbCA9IHtcbiAgICAgICAgZGV2aWNlQWRtaW5FbmFibGVkOiB0cnVlLFxuICAgICAgICBhY2Nlc3NpYmlsaXR5TG9ja0VuYWJsZWQ6IHRydWUsXG4gICAgICAgIHByZXZlbnRTZXR0aW5nc1RhbXBlcjogdHJ1ZSxcbiAgICAgICAgdW5pbnN0YWxsQXR0ZW1wdHNDb3VudDogMCxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgaWYgKGRldmljZUFkbWluRW5hYmxlZCAhPT0gdW5kZWZpbmVkKSBjaGlsZC5hbnRpVW5pbnN0YWxsLmRldmljZUFkbWluRW5hYmxlZCA9IGRldmljZUFkbWluRW5hYmxlZDtcbiAgICBpZiAoYWNjZXNzaWJpbGl0eUxvY2tFbmFibGVkICE9PSB1bmRlZmluZWQpIGNoaWxkLmFudGlVbmluc3RhbGwuYWNjZXNzaWJpbGl0eUxvY2tFbmFibGVkID0gYWNjZXNzaWJpbGl0eUxvY2tFbmFibGVkO1xuICAgIGlmIChwcmV2ZW50U2V0dGluZ3NUYW1wZXIgIT09IHVuZGVmaW5lZCkgY2hpbGQuYW50aVVuaW5zdGFsbC5wcmV2ZW50U2V0dGluZ3NUYW1wZXIgPSBwcmV2ZW50U2V0dGluZ3NUYW1wZXI7XG5cbiAgICBzYXZlREIoZGIpO1xuICAgIHJlcy5qc29uKHsgc3VjY2VzczogdHJ1ZSwgYW50aVVuaW5zdGFsbDogY2hpbGQuYW50aVVuaW5zdGFsbCB9KTtcbiAgfSk7XG5cbiAgLy8gMTJjLiBSZXBvcnQgVGFtcGVyIC8gVW5pbnN0YWxsIEF0dGVtcHQgZnJvbSBDaGlsZCBEZXZpY2VcbiAgYXBwLnBvc3QoJy9hcGkvY2hpbGQvOmlkL3JlcG9ydC10YW1wZXInLCAocmVxLCByZXMpID0+IHtcbiAgICBjb25zdCB7IGlkIH0gPSByZXEucGFyYW1zO1xuICAgIGNvbnN0IHsgYXR0ZW1wdGVkQWN0aW9uLCBjb21wb25lbnQgfSA9IHJlcS5ib2R5O1xuICAgIGNvbnN0IGNoaWxkID0gZGIuY2hpbGRyZW4uZmluZCgoYykgPT4gYy5pZCA9PT0gaWQpO1xuICAgIGlmICghY2hpbGQpIHJldHVybiByZXMuc3RhdHVzKDQwNCkuanNvbih7IGVycm9yOiAnQ2hpbGQgbm90IGZvdW5kJyB9KTtcblxuICAgIGlmICghY2hpbGQuYW50aVVuaW5zdGFsbCkge1xuICAgICAgY2hpbGQuYW50aVVuaW5zdGFsbCA9IHtcbiAgICAgICAgZGV2aWNlQWRtaW5FbmFibGVkOiB0cnVlLFxuICAgICAgICBhY2Nlc3NpYmlsaXR5TG9ja0VuYWJsZWQ6IHRydWUsXG4gICAgICAgIHByZXZlbnRTZXR0aW5nc1RhbXBlcjogdHJ1ZSxcbiAgICAgICAgdW5pbnN0YWxsQXR0ZW1wdHNDb3VudDogMCxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgY2hpbGQuYW50aVVuaW5zdGFsbC51bmluc3RhbGxBdHRlbXB0c0NvdW50ICs9IDE7XG4gICAgY2hpbGQuYW50aVVuaW5zdGFsbC5sYXN0VGFtcGVyQXR0ZW1wdCA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcblxuICAgIGNvbnN0IGFsZXJ0OiBBbGVydEl0ZW0gPSB7XG4gICAgICBpZDogYHRhbXBlci0ke0RhdGUubm93KCl9YCxcbiAgICAgIGNoaWxkSWQ6IGNoaWxkLmlkLFxuICAgICAgY2hpbGROYW1lOiBjaGlsZC5uYW1lLFxuICAgICAgdHlwZTogJ3RhbXBlcl9hdHRlbXB0JyxcbiAgICAgIHRpdGxlOiBg8J+aqCBBTlRJLVVOSU5TVEFMTCBMT0NLIFRSSUdHRVJFRDogJHtjaGlsZC5uYW1lfSdzIERldmljZWAsXG4gICAgICBtZXNzYWdlOiBgQW4gdW5hdXRob3JpemVkIGF0dGVtcHQgdG8gJHthdHRlbXB0ZWRBY3Rpb24gfHwgJ3VuaW5zdGFsbCBTYWZlS2lkcyBvciByZXZva2UgRGV2aWNlIEFkbWluJ30gd2FzIGludGVyY2VwdGVkIG9uICR7Y2hpbGQuZGV2aWNlTW9kZWx9LiBTeXN0ZW0gd2FzIHByb3RlY3RlZCB3aXRoIFBhcmVudCBQSU4gbG9jay5gLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBzZXZlcml0eTogJ2NyaXRpY2FsJyxcbiAgICAgIHJlYWQ6IGZhbHNlLFxuICAgIH07XG5cbiAgICBkYi5hbGVydHMudW5zaGlmdChhbGVydCk7XG4gICAgc2F2ZURCKGRiKTtcbiAgICByZXMuanNvbih7IHN1Y2Nlc3M6IHRydWUsIGFsZXJ0LCB1bmluc3RhbGxBdHRlbXB0c0NvdW50OiBjaGlsZC5hbnRpVW5pbnN0YWxsLnVuaW5zdGFsbEF0dGVtcHRzQ291bnQgfSk7XG4gIH0pO1xuXG4gIC8vIDEzLiBNZXNzYWdlc1xuICBhcHAucG9zdCgnL2FwaS9tZXNzYWdlcycsIChyZXEsIHJlcykgPT4ge1xuICAgIGNvbnN0IHsgY2hpbGRJZCwgc2VuZGVyLCB0ZXh0IH0gPSByZXEuYm9keTtcbiAgICBpZiAoIWNoaWxkSWQgfHwgIXRleHQpIHJldHVybiByZXMuc3RhdHVzKDQwMCkuanNvbih7IGVycm9yOiAnTWlzc2luZyBwYXJhbWV0ZXJzJyB9KTtcblxuICAgIGNvbnN0IG1zZzogTWVzc2FnZUl0ZW0gPSB7XG4gICAgICBpZDogYG1zZy0ke0RhdGUubm93KCl9YCxcbiAgICAgIGNoaWxkSWQsXG4gICAgICBzZW5kZXIsXG4gICAgICB0ZXh0LFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfTtcblxuICAgIGRiLm1lc3NhZ2VzLnB1c2gobXNnKTtcbiAgICBzYXZlREIoZGIpO1xuICAgIHJlcy5qc29uKHsgc3VjY2VzczogdHJ1ZSwgbWVzc2FnZTogbXNnIH0pO1xuICB9KTtcblxuICAvLyAxNC4gTWFyayBhbGVydHMgYXMgcmVhZFxuICBhcHAucG9zdCgnL2FwaS9hbGVydHMvbWFyay1yZWFkJywgKHJlcSwgcmVzKSA9PiB7XG4gICAgY29uc3QgeyBpZCwgYWxsIH0gPSByZXEuYm9keTtcbiAgICBpZiAoYWxsKSB7XG4gICAgICBkYi5hbGVydHMuZm9yRWFjaCgoYSkgPT4gKGEucmVhZCA9IHRydWUpKTtcbiAgICB9IGVsc2UgaWYgKGlkKSB7XG4gICAgICBjb25zdCBhbGVydCA9IGRiLmFsZXJ0cy5maW5kKChhKSA9PiBhLmlkID09PSBpZCk7XG4gICAgICBpZiAoYWxlcnQpIGFsZXJ0LnJlYWQgPSB0cnVlO1xuICAgIH1cbiAgICBzYXZlREIoZGIpO1xuICAgIHJlcy5qc29uKHsgc3VjY2VzczogdHJ1ZSB9KTtcbiAgfSk7XG5cbiAgLy8gMTUuIENyZWF0ZSBuZXcgY2hpbGQgcHJvZmlsZVxuICBhcHAucG9zdCgnL2FwaS9jaGlsZHJlbicsIChyZXEsIHJlcykgPT4ge1xuICAgIGNvbnN0IHsgbmFtZSwgYWdlLCBhdmF0YXIsIGRldmljZU1vZGVsIH0gPSByZXEuYm9keTtcbiAgICBjb25zdCBuZXdDaGlsZDogQ2hpbGREZXZpY2UgPSB7XG4gICAgICBpZDogYGNoaWxkLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgbmFtZTogbmFtZSB8fCAnQ2hpbGQnLFxuICAgICAgYWdlOiBhZ2UgfHwgOCxcbiAgICAgIGF2YXRhcjogYXZhdGFyIHx8ICfwn6eSJyxcbiAgICAgIGRldmljZU1vZGVsOiBkZXZpY2VNb2RlbCB8fCAnQW5kcm9pZCBQaG9uZScsXG4gICAgICBvc1ZlcnNpb246ICdBbmRyb2lkIDE0JyxcbiAgICAgIGJhdHRlcnlMZXZlbDogMTAwLFxuICAgICAgaXNDaGFyZ2luZzogZmFsc2UsXG4gICAgICBpc09ubGluZTogdHJ1ZSxcbiAgICAgIGxhc3RTZWVuOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBsb2NhdGlvbjoge1xuICAgICAgICBsYXRpdHVkZTogMzcuNzc0OSxcbiAgICAgICAgbG9uZ2l0dWRlOiAtMTIyLjQxOTQsXG4gICAgICAgIGFjY3VyYWN5OiAxMCxcbiAgICAgICAgc3BlZWQ6IDAsXG4gICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICBhZGRyZXNzOiAnU2FuIEZyYW5jaXNjbywgQ0EnLFxuICAgICAgfSxcbiAgICAgIGxvY2F0aW9uSGlzdG9yeTogW10sXG4gICAgICBzY3JlZW5UaW1lOiB7XG4gICAgICAgIHRvZGF5VXNhZ2VNaW51dGVzOiAwLFxuICAgICAgICBkYWlseUxpbWl0TWludXRlczogMTIwLFxuICAgICAgICBiZWR0aW1lU3RhcnQ6ICcyMTowMCcsXG4gICAgICAgIGJlZHRpbWVFbmQ6ICcwNzowMCcsXG4gICAgICAgIGJlZHRpbWVFbmZvcmNlZDogdHJ1ZSxcbiAgICAgICAgYXBwUnVsZXM6IFtcbiAgICAgICAgICB7IHBhY2thZ2VOYW1lOiAnY29tLmdvb2dsZS5hbmRyb2lkLnlvdXR1YmUnLCBhcHBOYW1lOiAnWW91VHViZScsIGNhdGVnb3J5OiAndmlkZW8nLCBzdGF0dXM6ICdsaW1pdGVkJywgZGFpbHlMaW1pdE1pbnV0ZXM6IDQ1LCB1c2VkVG9kYXlNaW51dGVzOiAwLCBpY29uTmFtZTogJ1lvdXR1YmUnIH0sXG4gICAgICAgICAgeyBwYWNrYWdlTmFtZTogJ2NvbS5yb2Jsb3guY2xpZW50JywgYXBwTmFtZTogJ1JvYmxveCcsIGNhdGVnb3J5OiAnZ2FtZXMnLCBzdGF0dXM6ICdsb2NrZWQnLCBkYWlseUxpbWl0TWludXRlczogMzAsIHVzZWRUb2RheU1pbnV0ZXM6IDAsIGljb25OYW1lOiAnR2FtZXBhZDInIH0sXG4gICAgICAgICAgeyBwYWNrYWdlTmFtZTogJ2NvbS5kdW9saW5nbycsIGFwcE5hbWU6ICdEdW9saW5nbycsIGNhdGVnb3J5OiAnZWR1Y2F0aW9uJywgc3RhdHVzOiAnYWxsb3dlZCcsIGRhaWx5TGltaXRNaW51dGVzOiA2MCwgdXNlZFRvZGF5TWludXRlczogMCwgaWNvbk5hbWU6ICdCb29rT3BlbicgfSxcbiAgICAgICAgXSxcbiAgICAgIH0sXG4gICAgICB3ZWJGaWx0ZXI6IHtcbiAgICAgICAgc2FmZVNlYXJjaEVuYWJsZWQ6IHRydWUsXG4gICAgICAgIGJsb2NrZWRDYXRlZ29yaWVzOiBbJ2FkdWx0JywgJ2dhbWJsaW5nJywgJ3Zpb2xlbmNlJ10sXG4gICAgICAgIGJsb2NrZWREb21haW5zOiBbXSxcbiAgICAgICAgYWxsb3dlZERvbWFpbnM6IFtdLFxuICAgICAgfSxcbiAgICAgIGFudGlVbmluc3RhbGw6IHtcbiAgICAgICAgZGV2aWNlQWRtaW5FbmFibGVkOiB0cnVlLFxuICAgICAgICBhY2Nlc3NpYmlsaXR5TG9ja0VuYWJsZWQ6IHRydWUsXG4gICAgICAgIHByZXZlbnRTZXR0aW5nc1RhbXBlcjogdHJ1ZSxcbiAgICAgICAgdW5pbnN0YWxsQXR0ZW1wdHNDb3VudDogMCxcbiAgICAgIH0sXG4gICAgICBzYWZlWm9uZXM6IFtcbiAgICAgICAgeyBpZDogJ3pvbmUtaG9tZScsIG5hbWU6ICdIb21lJywgbGF0aXR1ZGU6IDM3Ljc3NDksIGxvbmdpdHVkZTogLTEyMi40MTk0LCByYWRpdXNNZXRlcnM6IDIwMCwgaWNvbjogJ0hvbWUnLCBlbmFibGVkOiB0cnVlIH0sXG4gICAgICBdLFxuICAgICAgYWN0aXZlU2Vzc2lvbnM6IHt9LFxuICAgIH07XG5cbiAgICBkYi5jaGlsZHJlbi5wdXNoKG5ld0NoaWxkKTtcbiAgICBzYXZlREIoZGIpO1xuICAgIHJlcy5qc29uKHsgc3VjY2VzczogdHJ1ZSwgY2hpbGQ6IG5ld0NoaWxkIH0pO1xuICB9KTtcblxuICAvLyBIYXZlcnNpbmUgZGlzdGFuY2UgZm9ybXVsYSBoZWxwZXJcbiAgZnVuY3Rpb24gaGF2ZXJzaW5lRGlzdGFuY2UobGF0MTogbnVtYmVyLCBsb24xOiBudW1iZXIsIGxhdDI6IG51bWJlciwgbG9uMjogbnVtYmVyKTogbnVtYmVyIHtcbiAgICBjb25zdCBSID0gNjM3MTAwMDsgLy8gbWV0ZXJzXG4gICAgY29uc3QgZExhdCA9ICgobGF0MiAtIGxhdDEpICogTWF0aC5QSSkgLyAxODA7XG4gICAgY29uc3QgZExvbiA9ICgobG9uMiAtIGxvbjEpICogTWF0aC5QSSkgLyAxODA7XG4gICAgY29uc3QgYSA9XG4gICAgICBNYXRoLnNpbihkTGF0IC8gMikgKiBNYXRoLnNpbihkTGF0IC8gMikgK1xuICAgICAgTWF0aC5jb3MoKGxhdDEgKiBNYXRoLlBJKSAvIDE4MCkgKlxuICAgICAgICBNYXRoLmNvcygobGF0MiAqIE1hdGguUEkpIC8gMTgwKSAqXG4gICAgICAgIE1hdGguc2luKGRMb24gLyAyKSAqXG4gICAgICAgIE1hdGguc2luKGRMb24gLyAyKTtcbiAgICBjb25zdCBjID0gMiAqIE1hdGguYXRhbjIoTWF0aC5zcXJ0KGEpLCBNYXRoLnNxcnQoMSAtIGEpKTtcbiAgICByZXR1cm4gUiAqIGM7XG4gIH1cblxuICAvLyBNb3VudCBWaXRlIG1pZGRsZXdhcmUgaW4gZGV2ZWxvcG1lbnRcbiAgY29uc3QgaXNQcm9kdWN0aW9uID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdwcm9kdWN0aW9uJztcbiAgY29uc3QgcG9ydCA9IHByb2Nlc3MuZW52LlBPUlQgPyBwYXJzZUludChwcm9jZXNzLmVudi5QT1JULCAxMCkgOiAzMDAwO1xuXG4gIGlmICghaXNQcm9kdWN0aW9uKSB7XG4gICAgY29uc3Qgdml0ZSA9IGF3YWl0IGNyZWF0ZVZpdGVTZXJ2ZXIoe1xuICAgICAgc2VydmVyOiB7IG1pZGRsZXdhcmVNb2RlOiB0cnVlLCBobXI6IHByb2Nlc3MuZW52LkRJU0FCTEVfSE1SICE9PSAndHJ1ZScgfSxcbiAgICAgIGFwcFR5cGU6ICdzcGEnLFxuICAgIH0pO1xuICAgIGFwcC51c2Uodml0ZS5taWRkbGV3YXJlcyk7XG4gIH0gZWxzZSB7XG4gICAgYXBwLnVzZShleHByZXNzLnN0YXRpYyhwYXRoLmpvaW4oX19kaXJuYW1lLCAnZGlzdCcpKSk7XG4gICAgYXBwLmdldCgnKicsIChyZXEsIHJlcykgPT4ge1xuICAgICAgcmVzLnNlbmRGaWxlKHBhdGguam9pbihfX2Rpcm5hbWUsICdkaXN0JywgJ2luZGV4Lmh0bWwnKSk7XG4gICAgfSk7XG4gIH1cblxuICBhcHAubGlzdGVuKHBvcnQsICcwLjAuMC4wJywgKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKGBTYWZlS2lkcyBTZXJ2ZXIgcnVubmluZyBvbiBodHRwOi8vMC4wLjAuMDoke3BvcnR9YCk7XG4gIH0pO1xufVxuXG5zdGFydFNlcnZlcigpO1xuIl0sImZpbGUiOiIvYXBwL2FwcGxldC9zZXJ2ZXIudHMifQ==