export const INITIAL_DEFAULT_STATE = {
	parentPin: "1234",
	parentEmail: "parent@safekids.local",
	children: [{
		id: "child-leo",
		name: "Leo",
		age: 10,
		avatar: "👦",
		deviceModel: "Pixel 8a (Android 14)",
		osVersion: "Android 14 (API 34)",
		batteryLevel: 78,
		isCharging: false,
		isOnline: true,
		lastSeen: new Date().toISOString(),
		location: {
			latitude: 37.7749,
			longitude: -122.4194,
			accuracy: 12,
			speed: 1.2,
			timestamp: new Date().toISOString(),
			address: "Market St & 4th, San Francisco, CA"
		},
		locationHistory: [
			{
				latitude: 37.7749,
				longitude: -122.4194,
				timestamp: new Date(Date.now() - 5 * 6e4).toISOString(),
				address: "Market St & 4th, San Francisco, CA"
			},
			{
				latitude: 37.7758,
				longitude: -122.4182,
				timestamp: new Date(Date.now() - 25 * 6e4).toISOString(),
				address: "Mission St & 3rd, San Francisco, CA"
			},
			{
				latitude: 37.7765,
				longitude: -122.417,
				timestamp: new Date(Date.now() - 55 * 6e4).toISOString(),
				address: "Howard St & 3rd, San Francisco, CA"
			}
		],
		screenTime: {
			todayUsageMinutes: 85,
			dailyLimitMinutes: 120,
			bedtimeStart: "20:30",
			bedtimeEnd: "07:00",
			bedtimeEnforced: true,
			appRules: [
				{
					packageName: "com.google.android.youtube",
					appName: "YouTube",
					category: "video",
					status: "limited",
					dailyLimitMinutes: 45,
					usedTodayMinutes: 30,
					iconName: "Youtube"
				},
				{
					packageName: "com.roblox.client",
					appName: "Roblox",
					category: "games",
					status: "locked",
					dailyLimitMinutes: 30,
					usedTodayMinutes: 20,
					iconName: "Gamepad2"
				},
				{
					packageName: "com.zhiliaoapp.musically",
					appName: "TikTok",
					category: "social",
					status: "locked",
					dailyLimitMinutes: 0,
					usedTodayMinutes: 0,
					iconName: "Share2"
				},
				{
					packageName: "com.duolingo",
					appName: "Duolingo",
					category: "education",
					status: "allowed",
					dailyLimitMinutes: 60,
					usedTodayMinutes: 15,
					iconName: "BookOpen"
				},
				{
					packageName: "org.khanacademy.android",
					appName: "Khan Academy",
					category: "education",
					status: "allowed",
					dailyLimitMinutes: 120,
					usedTodayMinutes: 20,
					iconName: "GraduationCap"
				},
				{
					packageName: "com.android.chrome",
					appName: "Safe Chrome",
					category: "browsing",
					status: "allowed",
					dailyLimitMinutes: 60,
					usedTodayMinutes: 0,
					iconName: "Compass"
				}
			]
		},
		webFilter: {
			safeSearchEnabled: true,
			blockedCategories: [
				"adult",
				"gambling",
				"violence",
				"weapons",
				"dating"
			],
			blockedDomains: [
				"tiktok.com",
				"omegle.com",
				"discord.com",
				"chatroulette.com"
			],
			allowedDomains: [
				"wikipedia.org",
				"khanacademy.org",
				"nationalgeographic.com",
				"scratch.mit.edu",
				"nasa.gov"
			]
		},
		antiUninstall: {
			deviceAdminEnabled: true,
			accessibilityLockEnabled: true,
			preventSettingsTamper: true,
			uninstallAttemptsCount: 0
		},
		safeZones: [
			{
				id: "zone-home",
				name: "Home",
				latitude: 37.7749,
				longitude: -122.4194,
				radiusMeters: 200,
				icon: "Home",
				enabled: true
			},
			{
				id: "zone-school",
				name: "Lincoln Middle School",
				latitude: 37.778,
				longitude: -122.415,
				radiusMeters: 300,
				icon: "School",
				enabled: true
			},
			{
				id: "zone-park",
				name: "Yerba Buena Park",
				latitude: 37.785,
				longitude: -122.402,
				radiusMeters: 250,
				icon: "Trees",
				enabled: true
			}
		],
		activeSessions: {}
	}, {
		id: "child-maya",
		name: "Maya",
		age: 7,
		avatar: "👧",
		deviceModel: "Samsung Galaxy Tab A9",
		osVersion: "Android 13 (One UI 5.1)",
		batteryLevel: 42,
		isCharging: true,
		isOnline: true,
		lastSeen: new Date().toISOString(),
		location: {
			latitude: 37.7749,
			longitude: -122.4194,
			accuracy: 8,
			speed: 0,
			timestamp: new Date().toISOString(),
			address: "Home (Safe Zone)"
		},
		locationHistory: [{
			latitude: 37.7749,
			longitude: -122.4194,
			timestamp: new Date(Date.now() - 10 * 6e4).toISOString(),
			address: "Home (Safe Zone)"
		}],
		screenTime: {
			todayUsageMinutes: 45,
			dailyLimitMinutes: 60,
			bedtimeStart: "19:45",
			bedtimeEnd: "07:30",
			bedtimeEnforced: true,
			appRules: [
				{
					packageName: "com.google.android.apps.youtube.kids",
					appName: "YouTube Kids",
					category: "video",
					status: "limited",
					dailyLimitMinutes: 30,
					usedTodayMinutes: 25,
					iconName: "Youtube"
				},
				{
					packageName: "com.tocaboca.tocalifeworld",
					appName: "Toca Life World",
					category: "games",
					status: "allowed",
					dailyLimitMinutes: 30,
					usedTodayMinutes: 15,
					iconName: "Gamepad2"
				},
				{
					packageName: "com.duolingo.kids",
					appName: "Duolingo ABC",
					category: "education",
					status: "allowed",
					dailyLimitMinutes: 60,
					usedTodayMinutes: 5,
					iconName: "BookOpen"
				}
			]
		},
		webFilter: {
			safeSearchEnabled: true,
			blockedCategories: [
				"adult",
				"gambling",
				"violence",
				"social",
				"gaming"
			],
			blockedDomains: ["youtube.com", "roblox.com"],
			allowedDomains: [
				"pbskids.org",
				"starfall.com",
				"natgeokids.com"
			]
		},
		antiUninstall: {
			deviceAdminEnabled: true,
			accessibilityLockEnabled: true,
			preventSettingsTamper: true,
			uninstallAttemptsCount: 0
		},
		safeZones: [{
			id: "zone-home",
			name: "Home",
			latitude: 37.7749,
			longitude: -122.4194,
			radiusMeters: 200,
			icon: "Home",
			enabled: true
		}],
		activeSessions: {}
	}],
	alerts: [{
		id: "alert-1",
		childId: "child-leo",
		childName: "Leo",
		type: "geofence_enter",
		title: "Entered Safe Zone: Home",
		message: "Leo arrived safely inside Home safe zone.",
		timestamp: new Date(Date.now() - 40 * 6e4).toISOString(),
		severity: "info",
		read: true,
		coordinates: {
			latitude: 37.7749,
			longitude: -122.4194
		}
	}, {
		id: "alert-2",
		childId: "child-leo",
		childName: "Leo",
		type: "blocked_site",
		title: "Blocked Website Attempt",
		message: "Leo attempted to open discord.com, blocked by Web Filter.",
		timestamp: new Date(Date.now() - 15 * 6e4).toISOString(),
		severity: "warning",
		read: false
	}],
	messages: [{
		id: "msg-1",
		childId: "child-leo",
		sender: "parent",
		text: "Remember soccer practice at 4:30 PM today!",
		timestamp: new Date(Date.now() - 60 * 6e4).toISOString()
	}, {
		id: "msg-2",
		childId: "child-leo",
		sender: "child",
		text: "Got it Dad! Have my cleats packed.",
		timestamp: new Date(Date.now() - 50 * 6e4).toISOString()
	}],
	pairingCodes: []
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsT0FBTyxNQUFNLHdCQUFpQztDQUM1QyxXQUFXO0NBQ1gsYUFBYTtDQUNiLFVBQVUsQ0FDUjtFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sS0FBSztFQUNMLFFBQVE7RUFDUixhQUFhO0VBQ2IsV0FBVztFQUNYLGNBQWM7RUFDZCxZQUFZO0VBQ1osVUFBVTtFQUNWLFVBQVUsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ2pDLFVBQVU7R0FDUixVQUFVO0dBQ1YsV0FBVyxDQUFDO0dBQ1osVUFBVTtHQUNWLE9BQU87R0FDUCxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUNsQyxTQUFTO0VBQ1g7RUFDQSxpQkFBaUI7R0FDZjtJQUFFLFVBQVU7SUFBUyxXQUFXLENBQUM7SUFBVSxXQUFXLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJLEdBQUssQ0FBQyxDQUFDLFlBQVk7SUFBRyxTQUFTO0dBQXFDO0dBQ3BKO0lBQUUsVUFBVTtJQUFTLFdBQVcsQ0FBQztJQUFVLFdBQVcsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssR0FBSyxDQUFDLENBQUMsWUFBWTtJQUFHLFNBQVM7R0FBc0M7R0FDdEo7SUFBRSxVQUFVO0lBQVMsV0FBVyxDQUFDO0lBQVUsV0FBVyxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksS0FBSyxHQUFLLENBQUMsQ0FBQyxZQUFZO0lBQUcsU0FBUztHQUFxQztFQUN2SjtFQUNBLFlBQVk7R0FDVixtQkFBbUI7R0FDbkIsbUJBQW1CO0dBQ25CLGNBQWM7R0FDZCxZQUFZO0dBQ1osaUJBQWlCO0dBQ2pCLFVBQVU7SUFDUjtLQUFFLGFBQWE7S0FBOEIsU0FBUztLQUFXLFVBQVU7S0FBUyxRQUFRO0tBQVcsbUJBQW1CO0tBQUksa0JBQWtCO0tBQUksVUFBVTtJQUFVO0lBQ3hLO0tBQUUsYUFBYTtLQUFxQixTQUFTO0tBQVUsVUFBVTtLQUFTLFFBQVE7S0FBVSxtQkFBbUI7S0FBSSxrQkFBa0I7S0FBSSxVQUFVO0lBQVc7SUFDOUo7S0FBRSxhQUFhO0tBQTRCLFNBQVM7S0FBVSxVQUFVO0tBQVUsUUFBUTtLQUFVLG1CQUFtQjtLQUFHLGtCQUFrQjtLQUFHLFVBQVU7SUFBUztJQUNsSztLQUFFLGFBQWE7S0FBZ0IsU0FBUztLQUFZLFVBQVU7S0FBYSxRQUFRO0tBQVcsbUJBQW1CO0tBQUksa0JBQWtCO0tBQUksVUFBVTtJQUFXO0lBQ2hLO0tBQUUsYUFBYTtLQUEyQixTQUFTO0tBQWdCLFVBQVU7S0FBYSxRQUFRO0tBQVcsbUJBQW1CO0tBQUssa0JBQWtCO0tBQUksVUFBVTtJQUFnQjtJQUNyTDtLQUFFLGFBQWE7S0FBc0IsU0FBUztLQUFlLFVBQVU7S0FBWSxRQUFRO0tBQVcsbUJBQW1CO0tBQUksa0JBQWtCO0tBQUcsVUFBVTtJQUFVO0dBQ3hLO0VBQ0Y7RUFDQSxXQUFXO0dBQ1QsbUJBQW1CO0dBQ25CLG1CQUFtQjtJQUFDO0lBQVM7SUFBWTtJQUFZO0lBQVc7R0FBUTtHQUN4RSxnQkFBZ0I7SUFBQztJQUFjO0lBQWM7SUFBZTtHQUFrQjtHQUM5RSxnQkFBZ0I7SUFBQztJQUFpQjtJQUFtQjtJQUEwQjtJQUFtQjtHQUFVO0VBQzlHO0VBQ0EsZUFBZTtHQUNiLG9CQUFvQjtHQUNwQiwwQkFBMEI7R0FDMUIsdUJBQXVCO0dBQ3ZCLHdCQUF3QjtFQUMxQjtFQUNBLFdBQVc7R0FDVDtJQUFFLElBQUk7SUFBYSxNQUFNO0lBQVEsVUFBVTtJQUFTLFdBQVcsQ0FBQztJQUFVLGNBQWM7SUFBSyxNQUFNO0lBQVEsU0FBUztHQUFLO0dBQ3pIO0lBQUUsSUFBSTtJQUFlLE1BQU07SUFBeUIsVUFBVTtJQUFTLFdBQVcsQ0FBQztJQUFVLGNBQWM7SUFBSyxNQUFNO0lBQVUsU0FBUztHQUFLO0dBQzlJO0lBQUUsSUFBSTtJQUFhLE1BQU07SUFBb0IsVUFBVTtJQUFTLFdBQVcsQ0FBQztJQUFVLGNBQWM7SUFBSyxNQUFNO0lBQVMsU0FBUztHQUFLO0VBQ3hJO0VBQ0EsZ0JBQWdCLENBQUM7Q0FDbkIsR0FDQTtFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sS0FBSztFQUNMLFFBQVE7RUFDUixhQUFhO0VBQ2IsV0FBVztFQUNYLGNBQWM7RUFDZCxZQUFZO0VBQ1osVUFBVTtFQUNWLFVBQVUsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ2pDLFVBQVU7R0FDUixVQUFVO0dBQ1YsV0FBVyxDQUFDO0dBQ1osVUFBVTtHQUNWLE9BQU87R0FDUCxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUNsQyxTQUFTO0VBQ1g7RUFDQSxpQkFBaUIsQ0FDZjtHQUFFLFVBQVU7R0FBUyxXQUFXLENBQUM7R0FBVSxXQUFXLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLEdBQUssQ0FBQyxDQUFDLFlBQVk7R0FBRyxTQUFTO0VBQW1CLENBQ3JJO0VBQ0EsWUFBWTtHQUNWLG1CQUFtQjtHQUNuQixtQkFBbUI7R0FDbkIsY0FBYztHQUNkLFlBQVk7R0FDWixpQkFBaUI7R0FDakIsVUFBVTtJQUNSO0tBQUUsYUFBYTtLQUF3QyxTQUFTO0tBQWdCLFVBQVU7S0FBUyxRQUFRO0tBQVcsbUJBQW1CO0tBQUksa0JBQWtCO0tBQUksVUFBVTtJQUFVO0lBQ3ZMO0tBQUUsYUFBYTtLQUE4QixTQUFTO0tBQW1CLFVBQVU7S0FBUyxRQUFRO0tBQVcsbUJBQW1CO0tBQUksa0JBQWtCO0tBQUksVUFBVTtJQUFXO0lBQ2pMO0tBQUUsYUFBYTtLQUFxQixTQUFTO0tBQWdCLFVBQVU7S0FBYSxRQUFRO0tBQVcsbUJBQW1CO0tBQUksa0JBQWtCO0tBQUcsVUFBVTtJQUFXO0dBQzFLO0VBQ0Y7RUFDQSxXQUFXO0dBQ1QsbUJBQW1CO0dBQ25CLG1CQUFtQjtJQUFDO0lBQVM7SUFBWTtJQUFZO0lBQVU7R0FBUTtHQUN2RSxnQkFBZ0IsQ0FBQyxlQUFlLFlBQVk7R0FDNUMsZ0JBQWdCO0lBQUM7SUFBZTtJQUFnQjtHQUFnQjtFQUNsRTtFQUNBLGVBQWU7R0FDYixvQkFBb0I7R0FDcEIsMEJBQTBCO0dBQzFCLHVCQUF1QjtHQUN2Qix3QkFBd0I7RUFDMUI7RUFDQSxXQUFXLENBQ1Q7R0FBRSxJQUFJO0dBQWEsTUFBTTtHQUFRLFVBQVU7R0FBUyxXQUFXLENBQUM7R0FBVSxjQUFjO0dBQUssTUFBTTtHQUFRLFNBQVM7RUFBSyxDQUMzSDtFQUNBLGdCQUFnQixDQUFDO0NBQ25CLENBQ0Y7Q0FDQSxRQUFRLENBQ047RUFDRSxJQUFJO0VBQ0osU0FBUztFQUNULFdBQVc7RUFDWCxNQUFNO0VBQ04sT0FBTztFQUNQLFNBQVM7RUFDVCxXQUFXLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLEdBQUssQ0FBQyxDQUFDLFlBQVk7RUFDekQsVUFBVTtFQUNWLE1BQU07RUFDTixhQUFhO0dBQUUsVUFBVTtHQUFTLFdBQVcsQ0FBQztFQUFTO0NBQ3pELEdBQ0E7RUFDRSxJQUFJO0VBQ0osU0FBUztFQUNULFdBQVc7RUFDWCxNQUFNO0VBQ04sT0FBTztFQUNQLFNBQVM7RUFDVCxXQUFXLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLEdBQUssQ0FBQyxDQUFDLFlBQVk7RUFDekQsVUFBVTtFQUNWLE1BQU07Q0FDUixDQUNGO0NBQ0EsVUFBVSxDQUNSO0VBQ0UsSUFBSTtFQUNKLFNBQVM7RUFDVCxRQUFRO0VBQ1IsTUFBTTtFQUNOLFdBQVcsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssR0FBSyxDQUFDLENBQUMsWUFBWTtDQUMzRCxHQUNBO0VBQ0UsSUFBSTtFQUNKLFNBQVM7RUFDVCxRQUFRO0VBQ1IsTUFBTTtFQUNOLFdBQVcsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLEtBQUssR0FBSyxDQUFDLENBQUMsWUFBWTtDQUMzRCxDQUNGO0NBQ0EsY0FBYyxDQUFDO0FBQ2pCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImluaXRpYWxTdGF0ZS50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEQlN0YXRlIH0gZnJvbSAnLi4vdHlwZXMvc2FmZWtpZHMnO1xuXG5leHBvcnQgY29uc3QgSU5JVElBTF9ERUZBVUxUX1NUQVRFOiBEQlN0YXRlID0ge1xuICBwYXJlbnRQaW46ICcxMjM0JyxcbiAgcGFyZW50RW1haWw6ICdwYXJlbnRAc2FmZWtpZHMubG9jYWwnLFxuICBjaGlsZHJlbjogW1xuICAgIHtcbiAgICAgIGlkOiAnY2hpbGQtbGVvJyxcbiAgICAgIG5hbWU6ICdMZW8nLFxuICAgICAgYWdlOiAxMCxcbiAgICAgIGF2YXRhcjogJ/CfkaYnLFxuICAgICAgZGV2aWNlTW9kZWw6ICdQaXhlbCA4YSAoQW5kcm9pZCAxNCknLFxuICAgICAgb3NWZXJzaW9uOiAnQW5kcm9pZCAxNCAoQVBJIDM0KScsXG4gICAgICBiYXR0ZXJ5TGV2ZWw6IDc4LFxuICAgICAgaXNDaGFyZ2luZzogZmFsc2UsXG4gICAgICBpc09ubGluZTogdHJ1ZSxcbiAgICAgIGxhc3RTZWVuOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBsb2NhdGlvbjoge1xuICAgICAgICBsYXRpdHVkZTogMzcuNzc0OSxcbiAgICAgICAgbG9uZ2l0dWRlOiAtMTIyLjQxOTQsXG4gICAgICAgIGFjY3VyYWN5OiAxMixcbiAgICAgICAgc3BlZWQ6IDEuMixcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGFkZHJlc3M6ICdNYXJrZXQgU3QgJiA0dGgsIFNhbiBGcmFuY2lzY28sIENBJyxcbiAgICAgIH0sXG4gICAgICBsb2NhdGlvbkhpc3Rvcnk6IFtcbiAgICAgICAgeyBsYXRpdHVkZTogMzcuNzc0OSwgbG9uZ2l0dWRlOiAtMTIyLjQxOTQsIHRpbWVzdGFtcDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDUgKiA2MDAwMCkudG9JU09TdHJpbmcoKSwgYWRkcmVzczogJ01hcmtldCBTdCAmIDR0aCwgU2FuIEZyYW5jaXNjbywgQ0EnIH0sXG4gICAgICAgIHsgbGF0aXR1ZGU6IDM3Ljc3NTgsIGxvbmdpdHVkZTogLTEyMi40MTgyLCB0aW1lc3RhbXA6IG5ldyBEYXRlKERhdGUubm93KCkgLSAyNSAqIDYwMDAwKS50b0lTT1N0cmluZygpLCBhZGRyZXNzOiAnTWlzc2lvbiBTdCAmIDNyZCwgU2FuIEZyYW5jaXNjbywgQ0EnIH0sXG4gICAgICAgIHsgbGF0aXR1ZGU6IDM3Ljc3NjUsIGxvbmdpdHVkZTogLTEyMi40MTcwLCB0aW1lc3RhbXA6IG5ldyBEYXRlKERhdGUubm93KCkgLSA1NSAqIDYwMDAwKS50b0lTT1N0cmluZygpLCBhZGRyZXNzOiAnSG93YXJkIFN0ICYgM3JkLCBTYW4gRnJhbmNpc2NvLCBDQScgfSxcbiAgICAgIF0sXG4gICAgICBzY3JlZW5UaW1lOiB7XG4gICAgICAgIHRvZGF5VXNhZ2VNaW51dGVzOiA4NSxcbiAgICAgICAgZGFpbHlMaW1pdE1pbnV0ZXM6IDEyMCxcbiAgICAgICAgYmVkdGltZVN0YXJ0OiAnMjA6MzAnLFxuICAgICAgICBiZWR0aW1lRW5kOiAnMDc6MDAnLFxuICAgICAgICBiZWR0aW1lRW5mb3JjZWQ6IHRydWUsXG4gICAgICAgIGFwcFJ1bGVzOiBbXG4gICAgICAgICAgeyBwYWNrYWdlTmFtZTogJ2NvbS5nb29nbGUuYW5kcm9pZC55b3V0dWJlJywgYXBwTmFtZTogJ1lvdVR1YmUnLCBjYXRlZ29yeTogJ3ZpZGVvJywgc3RhdHVzOiAnbGltaXRlZCcsIGRhaWx5TGltaXRNaW51dGVzOiA0NSwgdXNlZFRvZGF5TWludXRlczogMzAsIGljb25OYW1lOiAnWW91dHViZScgfSxcbiAgICAgICAgICB7IHBhY2thZ2VOYW1lOiAnY29tLnJvYmxveC5jbGllbnQnLCBhcHBOYW1lOiAnUm9ibG94JywgY2F0ZWdvcnk6ICdnYW1lcycsIHN0YXR1czogJ2xvY2tlZCcsIGRhaWx5TGltaXRNaW51dGVzOiAzMCwgdXNlZFRvZGF5TWludXRlczogMjAsIGljb25OYW1lOiAnR2FtZXBhZDInIH0sXG4gICAgICAgICAgeyBwYWNrYWdlTmFtZTogJ2NvbS56aGlsaWFvYXBwLm11c2ljYWxseScsIGFwcE5hbWU6ICdUaWtUb2snLCBjYXRlZ29yeTogJ3NvY2lhbCcsIHN0YXR1czogJ2xvY2tlZCcsIGRhaWx5TGltaXRNaW51dGVzOiAwLCB1c2VkVG9kYXlNaW51dGVzOiAwLCBpY29uTmFtZTogJ1NoYXJlMicgfSxcbiAgICAgICAgICB7IHBhY2thZ2VOYW1lOiAnY29tLmR1b2xpbmdvJywgYXBwTmFtZTogJ0R1b2xpbmdvJywgY2F0ZWdvcnk6ICdlZHVjYXRpb24nLCBzdGF0dXM6ICdhbGxvd2VkJywgZGFpbHlMaW1pdE1pbnV0ZXM6IDYwLCB1c2VkVG9kYXlNaW51dGVzOiAxNSwgaWNvbk5hbWU6ICdCb29rT3BlbicgfSxcbiAgICAgICAgICB7IHBhY2thZ2VOYW1lOiAnb3JnLmtoYW5hY2FkZW15LmFuZHJvaWQnLCBhcHBOYW1lOiAnS2hhbiBBY2FkZW15JywgY2F0ZWdvcnk6ICdlZHVjYXRpb24nLCBzdGF0dXM6ICdhbGxvd2VkJywgZGFpbHlMaW1pdE1pbnV0ZXM6IDEyMCwgdXNlZFRvZGF5TWludXRlczogMjAsIGljb25OYW1lOiAnR3JhZHVhdGlvbkNhcCcgfSxcbiAgICAgICAgICB7IHBhY2thZ2VOYW1lOiAnY29tLmFuZHJvaWQuY2hyb21lJywgYXBwTmFtZTogJ1NhZmUgQ2hyb21lJywgY2F0ZWdvcnk6ICdicm93c2luZycsIHN0YXR1czogJ2FsbG93ZWQnLCBkYWlseUxpbWl0TWludXRlczogNjAsIHVzZWRUb2RheU1pbnV0ZXM6IDAsIGljb25OYW1lOiAnQ29tcGFzcycgfSxcbiAgICAgICAgXSxcbiAgICAgIH0sXG4gICAgICB3ZWJGaWx0ZXI6IHtcbiAgICAgICAgc2FmZVNlYXJjaEVuYWJsZWQ6IHRydWUsXG4gICAgICAgIGJsb2NrZWRDYXRlZ29yaWVzOiBbJ2FkdWx0JywgJ2dhbWJsaW5nJywgJ3Zpb2xlbmNlJywgJ3dlYXBvbnMnLCAnZGF0aW5nJ10sXG4gICAgICAgIGJsb2NrZWREb21haW5zOiBbJ3Rpa3Rvay5jb20nLCAnb21lZ2xlLmNvbScsICdkaXNjb3JkLmNvbScsICdjaGF0cm91bGV0dGUuY29tJ10sXG4gICAgICAgIGFsbG93ZWREb21haW5zOiBbJ3dpa2lwZWRpYS5vcmcnLCAna2hhbmFjYWRlbXkub3JnJywgJ25hdGlvbmFsZ2VvZ3JhcGhpYy5jb20nLCAnc2NyYXRjaC5taXQuZWR1JywgJ25hc2EuZ292J10sXG4gICAgICB9LFxuICAgICAgYW50aVVuaW5zdGFsbDoge1xuICAgICAgICBkZXZpY2VBZG1pbkVuYWJsZWQ6IHRydWUsXG4gICAgICAgIGFjY2Vzc2liaWxpdHlMb2NrRW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgcHJldmVudFNldHRpbmdzVGFtcGVyOiB0cnVlLFxuICAgICAgICB1bmluc3RhbGxBdHRlbXB0c0NvdW50OiAwLFxuICAgICAgfSxcbiAgICAgIHNhZmVab25lczogW1xuICAgICAgICB7IGlkOiAnem9uZS1ob21lJywgbmFtZTogJ0hvbWUnLCBsYXRpdHVkZTogMzcuNzc0OSwgbG9uZ2l0dWRlOiAtMTIyLjQxOTQsIHJhZGl1c01ldGVyczogMjAwLCBpY29uOiAnSG9tZScsIGVuYWJsZWQ6IHRydWUgfSxcbiAgICAgICAgeyBpZDogJ3pvbmUtc2Nob29sJywgbmFtZTogJ0xpbmNvbG4gTWlkZGxlIFNjaG9vbCcsIGxhdGl0dWRlOiAzNy43NzgwLCBsb25naXR1ZGU6IC0xMjIuNDE1MCwgcmFkaXVzTWV0ZXJzOiAzMDAsIGljb246ICdTY2hvb2wnLCBlbmFibGVkOiB0cnVlIH0sXG4gICAgICAgIHsgaWQ6ICd6b25lLXBhcmsnLCBuYW1lOiAnWWVyYmEgQnVlbmEgUGFyaycsIGxhdGl0dWRlOiAzNy43ODUwLCBsb25naXR1ZGU6IC0xMjIuNDAyMCwgcmFkaXVzTWV0ZXJzOiAyNTAsIGljb246ICdUcmVlcycsIGVuYWJsZWQ6IHRydWUgfSxcbiAgICAgIF0sXG4gICAgICBhY3RpdmVTZXNzaW9uczoge30sXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ2NoaWxkLW1heWEnLFxuICAgICAgbmFtZTogJ01heWEnLFxuICAgICAgYWdlOiA3LFxuICAgICAgYXZhdGFyOiAn8J+RpycsXG4gICAgICBkZXZpY2VNb2RlbDogJ1NhbXN1bmcgR2FsYXh5IFRhYiBBOScsXG4gICAgICBvc1ZlcnNpb246ICdBbmRyb2lkIDEzIChPbmUgVUkgNS4xKScsXG4gICAgICBiYXR0ZXJ5TGV2ZWw6IDQyLFxuICAgICAgaXNDaGFyZ2luZzogdHJ1ZSxcbiAgICAgIGlzT25saW5lOiB0cnVlLFxuICAgICAgbGFzdFNlZW46IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGxvY2F0aW9uOiB7XG4gICAgICAgIGxhdGl0dWRlOiAzNy43NzQ5LFxuICAgICAgICBsb25naXR1ZGU6IC0xMjIuNDE5NCxcbiAgICAgICAgYWNjdXJhY3k6IDgsXG4gICAgICAgIHNwZWVkOiAwLFxuICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgYWRkcmVzczogJ0hvbWUgKFNhZmUgWm9uZSknLFxuICAgICAgfSxcbiAgICAgIGxvY2F0aW9uSGlzdG9yeTogW1xuICAgICAgICB7IGxhdGl0dWRlOiAzNy43NzQ5LCBsb25naXR1ZGU6IC0xMjIuNDE5NCwgdGltZXN0YW1wOiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gMTAgKiA2MDAwMCkudG9JU09TdHJpbmcoKSwgYWRkcmVzczogJ0hvbWUgKFNhZmUgWm9uZSknIH0sXG4gICAgICBdLFxuICAgICAgc2NyZWVuVGltZToge1xuICAgICAgICB0b2RheVVzYWdlTWludXRlczogNDUsXG4gICAgICAgIGRhaWx5TGltaXRNaW51dGVzOiA2MCxcbiAgICAgICAgYmVkdGltZVN0YXJ0OiAnMTk6NDUnLFxuICAgICAgICBiZWR0aW1lRW5kOiAnMDc6MzAnLFxuICAgICAgICBiZWR0aW1lRW5mb3JjZWQ6IHRydWUsXG4gICAgICAgIGFwcFJ1bGVzOiBbXG4gICAgICAgICAgeyBwYWNrYWdlTmFtZTogJ2NvbS5nb29nbGUuYW5kcm9pZC5hcHBzLnlvdXR1YmUua2lkcycsIGFwcE5hbWU6ICdZb3VUdWJlIEtpZHMnLCBjYXRlZ29yeTogJ3ZpZGVvJywgc3RhdHVzOiAnbGltaXRlZCcsIGRhaWx5TGltaXRNaW51dGVzOiAzMCwgdXNlZFRvZGF5TWludXRlczogMjUsIGljb25OYW1lOiAnWW91dHViZScgfSxcbiAgICAgICAgICB7IHBhY2thZ2VOYW1lOiAnY29tLnRvY2Fib2NhLnRvY2FsaWZld29ybGQnLCBhcHBOYW1lOiAnVG9jYSBMaWZlIFdvcmxkJywgY2F0ZWdvcnk6ICdnYW1lcycsIHN0YXR1czogJ2FsbG93ZWQnLCBkYWlseUxpbWl0TWludXRlczogMzAsIHVzZWRUb2RheU1pbnV0ZXM6IDE1LCBpY29uTmFtZTogJ0dhbWVwYWQyJyB9LFxuICAgICAgICAgIHsgcGFja2FnZU5hbWU6ICdjb20uZHVvbGluZ28ua2lkcycsIGFwcE5hbWU6ICdEdW9saW5nbyBBQkMnLCBjYXRlZ29yeTogJ2VkdWNhdGlvbicsIHN0YXR1czogJ2FsbG93ZWQnLCBkYWlseUxpbWl0TWludXRlczogNjAsIHVzZWRUb2RheU1pbnV0ZXM6IDUsIGljb25OYW1lOiAnQm9va09wZW4nIH0sXG4gICAgICAgIF0sXG4gICAgICB9LFxuICAgICAgd2ViRmlsdGVyOiB7XG4gICAgICAgIHNhZmVTZWFyY2hFbmFibGVkOiB0cnVlLFxuICAgICAgICBibG9ja2VkQ2F0ZWdvcmllczogWydhZHVsdCcsICdnYW1ibGluZycsICd2aW9sZW5jZScsICdzb2NpYWwnLCAnZ2FtaW5nJ10sXG4gICAgICAgIGJsb2NrZWREb21haW5zOiBbJ3lvdXR1YmUuY29tJywgJ3JvYmxveC5jb20nXSxcbiAgICAgICAgYWxsb3dlZERvbWFpbnM6IFsncGJza2lkcy5vcmcnLCAnc3RhcmZhbGwuY29tJywgJ25hdGdlb2tpZHMuY29tJ10sXG4gICAgICB9LFxuICAgICAgYW50aVVuaW5zdGFsbDoge1xuICAgICAgICBkZXZpY2VBZG1pbkVuYWJsZWQ6IHRydWUsXG4gICAgICAgIGFjY2Vzc2liaWxpdHlMb2NrRW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgcHJldmVudFNldHRpbmdzVGFtcGVyOiB0cnVlLFxuICAgICAgICB1bmluc3RhbGxBdHRlbXB0c0NvdW50OiAwLFxuICAgICAgfSxcbiAgICAgIHNhZmVab25lczogW1xuICAgICAgICB7IGlkOiAnem9uZS1ob21lJywgbmFtZTogJ0hvbWUnLCBsYXRpdHVkZTogMzcuNzc0OSwgbG9uZ2l0dWRlOiAtMTIyLjQxOTQsIHJhZGl1c01ldGVyczogMjAwLCBpY29uOiAnSG9tZScsIGVuYWJsZWQ6IHRydWUgfSxcbiAgICAgIF0sXG4gICAgICBhY3RpdmVTZXNzaW9uczoge30sXG4gICAgfSxcbiAgXSxcbiAgYWxlcnRzOiBbXG4gICAge1xuICAgICAgaWQ6ICdhbGVydC0xJyxcbiAgICAgIGNoaWxkSWQ6ICdjaGlsZC1sZW8nLFxuICAgICAgY2hpbGROYW1lOiAnTGVvJyxcbiAgICAgIHR5cGU6ICdnZW9mZW5jZV9lbnRlcicsXG4gICAgICB0aXRsZTogJ0VudGVyZWQgU2FmZSBab25lOiBIb21lJyxcbiAgICAgIG1lc3NhZ2U6ICdMZW8gYXJyaXZlZCBzYWZlbHkgaW5zaWRlIEhvbWUgc2FmZSB6b25lLicsXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKERhdGUubm93KCkgLSA0MCAqIDYwMDAwKS50b0lTT1N0cmluZygpLFxuICAgICAgc2V2ZXJpdHk6ICdpbmZvJyxcbiAgICAgIHJlYWQ6IHRydWUsXG4gICAgICBjb29yZGluYXRlczogeyBsYXRpdHVkZTogMzcuNzc0OSwgbG9uZ2l0dWRlOiAtMTIyLjQxOTQgfSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAnYWxlcnQtMicsXG4gICAgICBjaGlsZElkOiAnY2hpbGQtbGVvJyxcbiAgICAgIGNoaWxkTmFtZTogJ0xlbycsXG4gICAgICB0eXBlOiAnYmxvY2tlZF9zaXRlJyxcbiAgICAgIHRpdGxlOiAnQmxvY2tlZCBXZWJzaXRlIEF0dGVtcHQnLFxuICAgICAgbWVzc2FnZTogJ0xlbyBhdHRlbXB0ZWQgdG8gb3BlbiBkaXNjb3JkLmNvbSwgYmxvY2tlZCBieSBXZWIgRmlsdGVyLicsXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKERhdGUubm93KCkgLSAxNSAqIDYwMDAwKS50b0lTT1N0cmluZygpLFxuICAgICAgc2V2ZXJpdHk6ICd3YXJuaW5nJyxcbiAgICAgIHJlYWQ6IGZhbHNlLFxuICAgIH0sXG4gIF0sXG4gIG1lc3NhZ2VzOiBbXG4gICAge1xuICAgICAgaWQ6ICdtc2ctMScsXG4gICAgICBjaGlsZElkOiAnY2hpbGQtbGVvJyxcbiAgICAgIHNlbmRlcjogJ3BhcmVudCcsXG4gICAgICB0ZXh0OiAnUmVtZW1iZXIgc29jY2VyIHByYWN0aWNlIGF0IDQ6MzAgUE0gdG9kYXkhJyxcbiAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoRGF0ZS5ub3coKSAtIDYwICogNjAwMDApLnRvSVNPU3RyaW5nKCksXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ21zZy0yJyxcbiAgICAgIGNoaWxkSWQ6ICdjaGlsZC1sZW8nLFxuICAgICAgc2VuZGVyOiAnY2hpbGQnLFxuICAgICAgdGV4dDogJ0dvdCBpdCBEYWQhIEhhdmUgbXkgY2xlYXRzIHBhY2tlZC4nLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZShEYXRlLm5vdygpIC0gNTAgKiA2MDAwMCkudG9JU09TdHJpbmcoKSxcbiAgICB9LFxuICBdLFxuICBwYWlyaW5nQ29kZXM6IFtdLFxufTtcbiJdfQ==