export const FILTER_CATEGORIES = [
	{
		id: "adult",
		name: "Adult & Explicit Content",
		description: "Pornography, mature themes, and age-restricted sites",
		severity: "high",
		icon: "ShieldAlert"
	},
	{
		id: "gambling",
		name: "Gambling & Betting",
		description: "Casinos, sports betting, lottery, and loot boxes",
		severity: "high",
		icon: "Coins"
	},
	{
		id: "violence",
		name: "Violence & Weapons",
		description: "Guns, gore, hate speech, and dangerous weapons",
		severity: "high",
		icon: "Sword"
	},
	{
		id: "social",
		name: "Social Media & Feeds",
		description: "TikTok, Instagram, Snapchat, Facebook, Reddit",
		severity: "medium",
		icon: "Users"
	},
	{
		id: "gaming",
		name: "Online Gaming Portals",
		description: "Roblox, Discord, Steam, browser flash games",
		severity: "medium",
		icon: "Gamepad"
	},
	{
		id: "dating",
		name: "Dating & Meetups",
		description: "Tinder, Bumble, chat roulette, meetups",
		severity: "high",
		icon: "Heart"
	},
	{
		id: "unmoderated_chat",
		name: "Unmoderated Chat & P2P",
		description: "Omegle, random chatrooms, torrents",
		severity: "high",
		icon: "MessageSquareWarning"
	}
];
export const CURATED_SAFE_SITES = [
	{
		name: "NASA Kids’ Club",
		url: "https://www.nasa.gov/learning-resources/nasa-kids-club/",
		category: "Science & Space",
		icon: "🚀"
	},
	{
		name: "Khan Academy Kids",
		url: "https://www.khanacademy.org/",
		category: "Math & Learning",
		icon: "🎓"
	},
	{
		name: "PBS KIDS",
		url: "https://pbskids.org/",
		category: "Games & Shows",
		icon: "🐾"
	},
	{
		name: "National Geographic Kids",
		url: "https://kids.nationalgeographic.com/",
		category: "Nature & Animals",
		icon: "🦁"
	},
	{
		name: "Scratch Coding",
		url: "https://scratch.mit.edu/",
		category: "Creative Coding",
		icon: "🐱"
	},
	{
		name: "Smithsonian for Kids",
		url: "https://www.si.edu/kids",
		category: "History & Culture",
		icon: "🏛️"
	},
	{
		name: "Duolingo",
		url: "https://www.duolingo.com/",
		category: "Languages",
		icon: "🦉"
	},
	{
		name: "Wikipedia (Safe)",
		url: "https://en.wikipedia.org/wiki/Main_Page",
		category: "Encyclopedia",
		icon: "📚"
	}
];
const CATEGORY_DOMAIN_PATTERNS = {
	adult: [
		"pornhub",
		"xvideos",
		"onlyfans",
		"redtube",
		"chaturbate",
		"adult",
		"xxx",
		"hentai",
		"cam4",
		"playboy",
		"brazzers",
		"sex"
	],
	gambling: [
		"bet365",
		"draftkings",
		"fanduel",
		"poker",
		"casino",
		"stake.com",
		"bovada",
		"slots",
		"betting",
		"lottery"
	],
	violence: [
		"bestgore",
		"rotten.com",
		"gunbroker",
		"weapons",
		"knifebuy",
		"darknet"
	],
	social: [
		"tiktok.com",
		"instagram.com",
		"snapchat.com",
		"facebook.com",
		"twitter.com",
		"x.com",
		"reddit.com",
		"tumblr.com"
	],
	gaming: [
		"roblox.com",
		"discord.com",
		"twitch.tv",
		"steamcommunity.com",
		"miniclip.com",
		"crazygames.com",
		"poki.com"
	],
	dating: [
		"tinder.com",
		"bumble.com",
		"hinge.co",
		"match.com",
		"badoo.com",
		"okcupid.com",
		"grindr.com"
	],
	unmoderated_chat: [
		"omegle.com",
		"chatroulette.com",
		"tinychat.com",
		"emeraldchat.com",
		"monkey.app"
	]
};
/**
* Evaluates whether a given URL is allowed according to filter rules
*/
export function checkUrlAllowed(urlInput, blockedCategories, blockedDomains, allowedDomains) {
	let hostname = urlInput.trim().toLowerCase();
	try {
		if (!hostname.startsWith("http://") && !hostname.startsWith("https://")) {
			hostname = "https://" + hostname;
		}
		const parsed = new URL(hostname);
		hostname = parsed.hostname;
	} catch {}
	// Strip 'www.'
	hostname = hostname.replace(/^www\./, "");
	// 1. Check explicit whitelist first
	const isExplicitlyAllowed = allowedDomains.some((allowed) => {
		const cleanAllowed = allowed.toLowerCase().replace(/^www\./, "");
		return hostname === cleanAllowed || hostname.endsWith("." + cleanAllowed);
	});
	if (isExplicitlyAllowed) {
		return { allowed: true };
	}
	// 2. Check explicit blacklist
	const isExplicitlyBlocked = blockedDomains.some((blocked) => {
		const cleanBlocked = blocked.toLowerCase().replace(/^www\./, "");
		return hostname === cleanBlocked || hostname.endsWith("." + cleanBlocked);
	});
	if (isExplicitlyBlocked) {
		return {
			allowed: false,
			blockedReason: `The domain "${hostname}" is explicitly blocked by parental rule.`,
			matchedRule: "custom_blacklist"
		};
	}
	// 3. Check categories
	for (const categoryId of blockedCategories) {
		const patterns = CATEGORY_DOMAIN_PATTERNS[categoryId] || [];
		for (const pattern of patterns) {
			if (hostname.includes(pattern)) {
				const catObj = FILTER_CATEGORIES.find((c) => c.id === categoryId);
				return {
					allowed: false,
					blockedReason: `Blocked under category: ${catObj?.name || categoryId}`,
					matchedCategory: categoryId,
					matchedRule: "category_rule"
				};
			}
		}
	}
	return { allowed: true };
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBUUEsT0FBTyxNQUFNLG9CQUEwQztDQUNyRDtFQUFFLElBQUk7RUFBUyxNQUFNO0VBQTRCLGFBQWE7RUFBd0QsVUFBVTtFQUFRLE1BQU07Q0FBYztDQUM1SjtFQUFFLElBQUk7RUFBWSxNQUFNO0VBQXNCLGFBQWE7RUFBb0QsVUFBVTtFQUFRLE1BQU07Q0FBUTtDQUMvSTtFQUFFLElBQUk7RUFBWSxNQUFNO0VBQXNCLGFBQWE7RUFBa0QsVUFBVTtFQUFRLE1BQU07Q0FBUTtDQUM3STtFQUFFLElBQUk7RUFBVSxNQUFNO0VBQXdCLGFBQWE7RUFBaUQsVUFBVTtFQUFVLE1BQU07Q0FBUTtDQUM5STtFQUFFLElBQUk7RUFBVSxNQUFNO0VBQXlCLGFBQWE7RUFBK0MsVUFBVTtFQUFVLE1BQU07Q0FBVTtDQUMvSTtFQUFFLElBQUk7RUFBVSxNQUFNO0VBQW9CLGFBQWE7RUFBMEMsVUFBVTtFQUFRLE1BQU07Q0FBUTtDQUNqSTtFQUFFLElBQUk7RUFBb0IsTUFBTTtFQUEwQixhQUFhO0VBQXNDLFVBQVU7RUFBUSxNQUFNO0NBQXVCO0FBQzlKO0FBRUEsT0FBTyxNQUFNLHFCQUFxQjtDQUNoQztFQUFFLE1BQU07RUFBbUIsS0FBSztFQUEyRCxVQUFVO0VBQW1CLE1BQU07Q0FBSztDQUNuSTtFQUFFLE1BQU07RUFBcUIsS0FBSztFQUFnQyxVQUFVO0VBQW1CLE1BQU07Q0FBSztDQUMxRztFQUFFLE1BQU07RUFBWSxLQUFLO0VBQXdCLFVBQVU7RUFBaUIsTUFBTTtDQUFLO0NBQ3ZGO0VBQUUsTUFBTTtFQUE0QixLQUFLO0VBQXdDLFVBQVU7RUFBb0IsTUFBTTtDQUFLO0NBQzFIO0VBQUUsTUFBTTtFQUFrQixLQUFLO0VBQTRCLFVBQVU7RUFBbUIsTUFBTTtDQUFLO0NBQ25HO0VBQUUsTUFBTTtFQUF3QixLQUFLO0VBQTJCLFVBQVU7RUFBcUIsTUFBTTtDQUFNO0NBQzNHO0VBQUUsTUFBTTtFQUFZLEtBQUs7RUFBNkIsVUFBVTtFQUFhLE1BQU07Q0FBSztDQUN4RjtFQUFFLE1BQU07RUFBb0IsS0FBSztFQUEyQyxVQUFVO0VBQWdCLE1BQU07Q0FBSztBQUNuSDtBQUVBLE1BQU0sMkJBQXFEO0NBQ3pELE9BQU87RUFBQztFQUFXO0VBQVc7RUFBWTtFQUFXO0VBQWM7RUFBUztFQUFPO0VBQVU7RUFBUTtFQUFXO0VBQVk7Q0FBSztDQUNqSSxVQUFVO0VBQUM7RUFBVTtFQUFjO0VBQVc7RUFBUztFQUFVO0VBQWE7RUFBVTtFQUFTO0VBQVc7Q0FBUztDQUNySCxVQUFVO0VBQUM7RUFBWTtFQUFjO0VBQWE7RUFBVztFQUFZO0NBQVM7Q0FDbEYsUUFBUTtFQUFDO0VBQWM7RUFBaUI7RUFBZ0I7RUFBZ0I7RUFBZTtFQUFTO0VBQWM7Q0FBWTtDQUMxSCxRQUFRO0VBQUM7RUFBYztFQUFlO0VBQWE7RUFBc0I7RUFBZ0I7RUFBa0I7Q0FBVTtDQUNySCxRQUFRO0VBQUM7RUFBYztFQUFjO0VBQVk7RUFBYTtFQUFhO0VBQWU7Q0FBWTtDQUN0RyxrQkFBa0I7RUFBQztFQUFjO0VBQW9CO0VBQWdCO0VBQW1CO0NBQVk7QUFDdEc7Ozs7QUFZQSxPQUFPLFNBQVMsZ0JBQ2QsVUFDQSxtQkFDQSxnQkFDQSxnQkFDaUI7Q0FDakIsSUFBSSxXQUFXLFNBQVMsS0FBSyxDQUFDLENBQUMsWUFBWTtDQUMzQyxJQUFJO0VBQ0YsSUFBSSxDQUFDLFNBQVMsV0FBVyxTQUFTLEtBQUssQ0FBQyxTQUFTLFdBQVcsVUFBVSxHQUFHO0dBQ3ZFLFdBQVcsYUFBYTtFQUMxQjtFQUNBLE1BQU0sU0FBUyxJQUFJLElBQUksUUFBUTtFQUMvQixXQUFXLE9BQU87Q0FDcEIsUUFBUSxDQUVSOztDQUdBLFdBQVcsU0FBUyxRQUFRLFVBQVUsRUFBRTs7Q0FHeEMsTUFBTSxzQkFBc0IsZUFBZSxNQUFNLFlBQVk7RUFDM0QsTUFBTSxlQUFlLFFBQVEsWUFBWSxDQUFDLENBQUMsUUFBUSxVQUFVLEVBQUU7RUFDL0QsT0FBTyxhQUFhLGdCQUFnQixTQUFTLFNBQVMsTUFBTSxZQUFZO0NBQzFFLENBQUM7Q0FFRCxJQUFJLHFCQUFxQjtFQUN2QixPQUFPLEVBQUUsU0FBUyxLQUFLO0NBQ3pCOztDQUdBLE1BQU0sc0JBQXNCLGVBQWUsTUFBTSxZQUFZO0VBQzNELE1BQU0sZUFBZSxRQUFRLFlBQVksQ0FBQyxDQUFDLFFBQVEsVUFBVSxFQUFFO0VBQy9ELE9BQU8sYUFBYSxnQkFBZ0IsU0FBUyxTQUFTLE1BQU0sWUFBWTtDQUMxRSxDQUFDO0NBRUQsSUFBSSxxQkFBcUI7RUFDdkIsT0FBTztHQUNMLFNBQVM7R0FDVCxlQUFlLGVBQWUsU0FBUztHQUN2QyxhQUFhO0VBQ2Y7Q0FDRjs7Q0FHQSxLQUFLLE1BQU0sY0FBYyxtQkFBbUI7RUFDMUMsTUFBTSxXQUFXLHlCQUF5QixlQUFlLENBQUM7RUFDMUQsS0FBSyxNQUFNLFdBQVcsVUFBVTtHQUM5QixJQUFJLFNBQVMsU0FBUyxPQUFPLEdBQUc7SUFDOUIsTUFBTSxTQUFTLGtCQUFrQixNQUFNLE1BQU0sRUFBRSxPQUFPLFVBQVU7SUFDaEUsT0FBTztLQUNMLFNBQVM7S0FDVCxlQUFlLDJCQUEyQixRQUFRLFFBQVE7S0FDMUQsaUJBQWlCO0tBQ2pCLGFBQWE7SUFDZjtHQUNGO0VBQ0Y7Q0FDRjtDQUVBLE9BQU8sRUFBRSxTQUFTLEtBQUs7QUFDekIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsid2ViZmlsdGVyLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBpbnRlcmZhY2UgQ2F0ZWdvcnlEZWZpbml0aW9uIHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xuICBzZXZlcml0eTogJ2hpZ2gnIHwgJ21lZGl1bScgfCAnbG93JztcbiAgaWNvbjogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgRklMVEVSX0NBVEVHT1JJRVM6IENhdGVnb3J5RGVmaW5pdGlvbltdID0gW1xuICB7IGlkOiAnYWR1bHQnLCBuYW1lOiAnQWR1bHQgJiBFeHBsaWNpdCBDb250ZW50JywgZGVzY3JpcHRpb246ICdQb3Jub2dyYXBoeSwgbWF0dXJlIHRoZW1lcywgYW5kIGFnZS1yZXN0cmljdGVkIHNpdGVzJywgc2V2ZXJpdHk6ICdoaWdoJywgaWNvbjogJ1NoaWVsZEFsZXJ0JyB9LFxuICB7IGlkOiAnZ2FtYmxpbmcnLCBuYW1lOiAnR2FtYmxpbmcgJiBCZXR0aW5nJywgZGVzY3JpcHRpb246ICdDYXNpbm9zLCBzcG9ydHMgYmV0dGluZywgbG90dGVyeSwgYW5kIGxvb3QgYm94ZXMnLCBzZXZlcml0eTogJ2hpZ2gnLCBpY29uOiAnQ29pbnMnIH0sXG4gIHsgaWQ6ICd2aW9sZW5jZScsIG5hbWU6ICdWaW9sZW5jZSAmIFdlYXBvbnMnLCBkZXNjcmlwdGlvbjogJ0d1bnMsIGdvcmUsIGhhdGUgc3BlZWNoLCBhbmQgZGFuZ2Vyb3VzIHdlYXBvbnMnLCBzZXZlcml0eTogJ2hpZ2gnLCBpY29uOiAnU3dvcmQnIH0sXG4gIHsgaWQ6ICdzb2NpYWwnLCBuYW1lOiAnU29jaWFsIE1lZGlhICYgRmVlZHMnLCBkZXNjcmlwdGlvbjogJ1Rpa1RvaywgSW5zdGFncmFtLCBTbmFwY2hhdCwgRmFjZWJvb2ssIFJlZGRpdCcsIHNldmVyaXR5OiAnbWVkaXVtJywgaWNvbjogJ1VzZXJzJyB9LFxuICB7IGlkOiAnZ2FtaW5nJywgbmFtZTogJ09ubGluZSBHYW1pbmcgUG9ydGFscycsIGRlc2NyaXB0aW9uOiAnUm9ibG94LCBEaXNjb3JkLCBTdGVhbSwgYnJvd3NlciBmbGFzaCBnYW1lcycsIHNldmVyaXR5OiAnbWVkaXVtJywgaWNvbjogJ0dhbWVwYWQnIH0sXG4gIHsgaWQ6ICdkYXRpbmcnLCBuYW1lOiAnRGF0aW5nICYgTWVldHVwcycsIGRlc2NyaXB0aW9uOiAnVGluZGVyLCBCdW1ibGUsIGNoYXQgcm91bGV0dGUsIG1lZXR1cHMnLCBzZXZlcml0eTogJ2hpZ2gnLCBpY29uOiAnSGVhcnQnIH0sXG4gIHsgaWQ6ICd1bm1vZGVyYXRlZF9jaGF0JywgbmFtZTogJ1VubW9kZXJhdGVkIENoYXQgJiBQMlAnLCBkZXNjcmlwdGlvbjogJ09tZWdsZSwgcmFuZG9tIGNoYXRyb29tcywgdG9ycmVudHMnLCBzZXZlcml0eTogJ2hpZ2gnLCBpY29uOiAnTWVzc2FnZVNxdWFyZVdhcm5pbmcnIH0sXG5dO1xuXG5leHBvcnQgY29uc3QgQ1VSQVRFRF9TQUZFX1NJVEVTID0gW1xuICB7IG5hbWU6ICdOQVNBIEtpZHPigJkgQ2x1YicsIHVybDogJ2h0dHBzOi8vd3d3Lm5hc2EuZ292L2xlYXJuaW5nLXJlc291cmNlcy9uYXNhLWtpZHMtY2x1Yi8nLCBjYXRlZ29yeTogJ1NjaWVuY2UgJiBTcGFjZScsIGljb246ICfwn5qAJyB9LFxuICB7IG5hbWU6ICdLaGFuIEFjYWRlbXkgS2lkcycsIHVybDogJ2h0dHBzOi8vd3d3LmtoYW5hY2FkZW15Lm9yZy8nLCBjYXRlZ29yeTogJ01hdGggJiBMZWFybmluZycsIGljb246ICfwn46TJyB9LFxuICB7IG5hbWU6ICdQQlMgS0lEUycsIHVybDogJ2h0dHBzOi8vcGJza2lkcy5vcmcvJywgY2F0ZWdvcnk6ICdHYW1lcyAmIFNob3dzJywgaWNvbjogJ/CfkL4nIH0sXG4gIHsgbmFtZTogJ05hdGlvbmFsIEdlb2dyYXBoaWMgS2lkcycsIHVybDogJ2h0dHBzOi8va2lkcy5uYXRpb25hbGdlb2dyYXBoaWMuY29tLycsIGNhdGVnb3J5OiAnTmF0dXJlICYgQW5pbWFscycsIGljb246ICfwn6aBJyB9LFxuICB7IG5hbWU6ICdTY3JhdGNoIENvZGluZycsIHVybDogJ2h0dHBzOi8vc2NyYXRjaC5taXQuZWR1LycsIGNhdGVnb3J5OiAnQ3JlYXRpdmUgQ29kaW5nJywgaWNvbjogJ/CfkLEnIH0sXG4gIHsgbmFtZTogJ1NtaXRoc29uaWFuIGZvciBLaWRzJywgdXJsOiAnaHR0cHM6Ly93d3cuc2kuZWR1L2tpZHMnLCBjYXRlZ29yeTogJ0hpc3RvcnkgJiBDdWx0dXJlJywgaWNvbjogJ/Cfj5vvuI8nIH0sXG4gIHsgbmFtZTogJ0R1b2xpbmdvJywgdXJsOiAnaHR0cHM6Ly93d3cuZHVvbGluZ28uY29tLycsIGNhdGVnb3J5OiAnTGFuZ3VhZ2VzJywgaWNvbjogJ/CfpoknIH0sXG4gIHsgbmFtZTogJ1dpa2lwZWRpYSAoU2FmZSknLCB1cmw6ICdodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9NYWluX1BhZ2UnLCBjYXRlZ29yeTogJ0VuY3ljbG9wZWRpYScsIGljb246ICfwn5OaJyB9LFxuXTtcblxuY29uc3QgQ0FURUdPUllfRE9NQUlOX1BBVFRFUk5TOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4gPSB7XG4gIGFkdWx0OiBbJ3Bvcm5odWInLCAneHZpZGVvcycsICdvbmx5ZmFucycsICdyZWR0dWJlJywgJ2NoYXR1cmJhdGUnLCAnYWR1bHQnLCAneHh4JywgJ2hlbnRhaScsICdjYW00JywgJ3BsYXlib3knLCAnYnJhenplcnMnLCAnc2V4J10sXG4gIGdhbWJsaW5nOiBbJ2JldDM2NScsICdkcmFmdGtpbmdzJywgJ2ZhbmR1ZWwnLCAncG9rZXInLCAnY2FzaW5vJywgJ3N0YWtlLmNvbScsICdib3ZhZGEnLCAnc2xvdHMnLCAnYmV0dGluZycsICdsb3R0ZXJ5J10sXG4gIHZpb2xlbmNlOiBbJ2Jlc3Rnb3JlJywgJ3JvdHRlbi5jb20nLCAnZ3VuYnJva2VyJywgJ3dlYXBvbnMnLCAna25pZmVidXknLCAnZGFya25ldCddLFxuICBzb2NpYWw6IFsndGlrdG9rLmNvbScsICdpbnN0YWdyYW0uY29tJywgJ3NuYXBjaGF0LmNvbScsICdmYWNlYm9vay5jb20nLCAndHdpdHRlci5jb20nLCAneC5jb20nLCAncmVkZGl0LmNvbScsICd0dW1ibHIuY29tJ10sXG4gIGdhbWluZzogWydyb2Jsb3guY29tJywgJ2Rpc2NvcmQuY29tJywgJ3R3aXRjaC50dicsICdzdGVhbWNvbW11bml0eS5jb20nLCAnbWluaWNsaXAuY29tJywgJ2NyYXp5Z2FtZXMuY29tJywgJ3Bva2kuY29tJ10sXG4gIGRhdGluZzogWyd0aW5kZXIuY29tJywgJ2J1bWJsZS5jb20nLCAnaGluZ2UuY28nLCAnbWF0Y2guY29tJywgJ2JhZG9vLmNvbScsICdva2N1cGlkLmNvbScsICdncmluZHIuY29tJ10sXG4gIHVubW9kZXJhdGVkX2NoYXQ6IFsnb21lZ2xlLmNvbScsICdjaGF0cm91bGV0dGUuY29tJywgJ3RpbnljaGF0LmNvbScsICdlbWVyYWxkY2hhdC5jb20nLCAnbW9ua2V5LmFwcCddLFxufTtcblxuZXhwb3J0IGludGVyZmFjZSBXZWJGaWx0ZXJSZXN1bHQge1xuICBhbGxvd2VkOiBib29sZWFuO1xuICBibG9ja2VkUmVhc29uPzogc3RyaW5nO1xuICBtYXRjaGVkQ2F0ZWdvcnk/OiBzdHJpbmc7XG4gIG1hdGNoZWRSdWxlPzogc3RyaW5nO1xufVxuXG4vKipcbiAqIEV2YWx1YXRlcyB3aGV0aGVyIGEgZ2l2ZW4gVVJMIGlzIGFsbG93ZWQgYWNjb3JkaW5nIHRvIGZpbHRlciBydWxlc1xuICovXG5leHBvcnQgZnVuY3Rpb24gY2hlY2tVcmxBbGxvd2VkKFxuICB1cmxJbnB1dDogc3RyaW5nLFxuICBibG9ja2VkQ2F0ZWdvcmllczogc3RyaW5nW10sXG4gIGJsb2NrZWREb21haW5zOiBzdHJpbmdbXSxcbiAgYWxsb3dlZERvbWFpbnM6IHN0cmluZ1tdXG4pOiBXZWJGaWx0ZXJSZXN1bHQge1xuICBsZXQgaG9zdG5hbWUgPSB1cmxJbnB1dC50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgdHJ5IHtcbiAgICBpZiAoIWhvc3RuYW1lLnN0YXJ0c1dpdGgoJ2h0dHA6Ly8nKSAmJiAhaG9zdG5hbWUuc3RhcnRzV2l0aCgnaHR0cHM6Ly8nKSkge1xuICAgICAgaG9zdG5hbWUgPSAnaHR0cHM6Ly8nICsgaG9zdG5hbWU7XG4gICAgfVxuICAgIGNvbnN0IHBhcnNlZCA9IG5ldyBVUkwoaG9zdG5hbWUpO1xuICAgIGhvc3RuYW1lID0gcGFyc2VkLmhvc3RuYW1lO1xuICB9IGNhdGNoIHtcbiAgICAvLyByYXcgaG9zdG5hbWVcbiAgfVxuXG4gIC8vIFN0cmlwICd3d3cuJ1xuICBob3N0bmFtZSA9IGhvc3RuYW1lLnJlcGxhY2UoL153d3dcXC4vLCAnJyk7XG5cbiAgLy8gMS4gQ2hlY2sgZXhwbGljaXQgd2hpdGVsaXN0IGZpcnN0XG4gIGNvbnN0IGlzRXhwbGljaXRseUFsbG93ZWQgPSBhbGxvd2VkRG9tYWlucy5zb21lKChhbGxvd2VkKSA9PiB7XG4gICAgY29uc3QgY2xlYW5BbGxvd2VkID0gYWxsb3dlZC50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL153d3dcXC4vLCAnJyk7XG4gICAgcmV0dXJuIGhvc3RuYW1lID09PSBjbGVhbkFsbG93ZWQgfHwgaG9zdG5hbWUuZW5kc1dpdGgoJy4nICsgY2xlYW5BbGxvd2VkKTtcbiAgfSk7XG5cbiAgaWYgKGlzRXhwbGljaXRseUFsbG93ZWQpIHtcbiAgICByZXR1cm4geyBhbGxvd2VkOiB0cnVlIH07XG4gIH1cblxuICAvLyAyLiBDaGVjayBleHBsaWNpdCBibGFja2xpc3RcbiAgY29uc3QgaXNFeHBsaWNpdGx5QmxvY2tlZCA9IGJsb2NrZWREb21haW5zLnNvbWUoKGJsb2NrZWQpID0+IHtcbiAgICBjb25zdCBjbGVhbkJsb2NrZWQgPSBibG9ja2VkLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvXnd3d1xcLi8sICcnKTtcbiAgICByZXR1cm4gaG9zdG5hbWUgPT09IGNsZWFuQmxvY2tlZCB8fCBob3N0bmFtZS5lbmRzV2l0aCgnLicgKyBjbGVhbkJsb2NrZWQpO1xuICB9KTtcblxuICBpZiAoaXNFeHBsaWNpdGx5QmxvY2tlZCkge1xuICAgIHJldHVybiB7XG4gICAgICBhbGxvd2VkOiBmYWxzZSxcbiAgICAgIGJsb2NrZWRSZWFzb246IGBUaGUgZG9tYWluIFwiJHtob3N0bmFtZX1cIiBpcyBleHBsaWNpdGx5IGJsb2NrZWQgYnkgcGFyZW50YWwgcnVsZS5gLFxuICAgICAgbWF0Y2hlZFJ1bGU6ICdjdXN0b21fYmxhY2tsaXN0JyxcbiAgICB9O1xuICB9XG5cbiAgLy8gMy4gQ2hlY2sgY2F0ZWdvcmllc1xuICBmb3IgKGNvbnN0IGNhdGVnb3J5SWQgb2YgYmxvY2tlZENhdGVnb3JpZXMpIHtcbiAgICBjb25zdCBwYXR0ZXJucyA9IENBVEVHT1JZX0RPTUFJTl9QQVRURVJOU1tjYXRlZ29yeUlkXSB8fCBbXTtcbiAgICBmb3IgKGNvbnN0IHBhdHRlcm4gb2YgcGF0dGVybnMpIHtcbiAgICAgIGlmIChob3N0bmFtZS5pbmNsdWRlcyhwYXR0ZXJuKSkge1xuICAgICAgICBjb25zdCBjYXRPYmogPSBGSUxURVJfQ0FURUdPUklFUy5maW5kKChjKSA9PiBjLmlkID09PSBjYXRlZ29yeUlkKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBhbGxvd2VkOiBmYWxzZSxcbiAgICAgICAgICBibG9ja2VkUmVhc29uOiBgQmxvY2tlZCB1bmRlciBjYXRlZ29yeTogJHtjYXRPYmo/Lm5hbWUgfHwgY2F0ZWdvcnlJZH1gLFxuICAgICAgICAgIG1hdGNoZWRDYXRlZ29yeTogY2F0ZWdvcnlJZCxcbiAgICAgICAgICBtYXRjaGVkUnVsZTogJ2NhdGVnb3J5X3J1bGUnLFxuICAgICAgICB9O1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiB7IGFsbG93ZWQ6IHRydWUgfTtcbn1cbiJdfQ==