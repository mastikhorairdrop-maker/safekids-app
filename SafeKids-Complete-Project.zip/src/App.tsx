const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=d3d47fa4";
import { fetchState, updateParentPin } from "/src/services/api.ts";
import { ParentDashboard } from "/src/components/ParentDashboard.tsx";
import { ChildModeView } from "/src/components/ChildModeView.tsx";
import { PinProtectionModal } from "/src/components/PinProtectionModal.tsx";
import { playNotificationChime, playSOSSiren } from "/src/utils/audio.ts";
import { INITIAL_DEFAULT_STATE } from "/src/utils/initialState.ts";
var _jsxFileName = "/app/applet/src/App.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d3d47fa4";
export default function App() {
	const [state, setState] = useState(INITIAL_DEFAULT_STATE);
	const [currentMode, setCurrentMode] = useState("parent");
	const [activeChildIdForChildMode, setActiveChildIdForChildMode] = useState("");
	const [darkMode, setDarkMode] = useState(() => {
		const saved = localStorage.getItem("safekids_theme");
		return saved ? saved === "dark" : false;
	});
	// PIN modal
	const [showPinModal, setShowPinModal] = useState(false);
	const [pinAction, setPinAction] = useState("exit_child");
	const [showChangePinForm, setShowChangePinForm] = useState(false);
	const [newPinValue, setNewPinValue] = useState("");
	const [pinChangeMsg, setPinChangeMsg] = useState("");
	// Audio alert tracking
	const previousAlertCountRef = useRef(0);
	// Sync state function
	const refreshData = async () => {
		const data = await fetchState();
		if (data) {
			// Check if new alert appeared
			if (data.alerts.length > previousAlertCountRef.current && previousAlertCountRef.current > 0) {
				const latest = data.alerts[0];
				if (latest.type === "sos") {
					playSOSSiren(4);
				} else {
					playNotificationChime();
				}
			}
			previousAlertCountRef.current = data.alerts.length;
			setState(data);
		}
	};
	useEffect(() => {
		refreshData();
		const interval = setInterval(refreshData, 6e3);
		return () => clearInterval(interval);
	}, []);
	useEffect(() => {
		if (darkMode) {
			document.documentElement.classList.add("dark");
			localStorage.setItem("safekids_theme", "dark");
		} else {
			document.documentElement.classList.remove("dark");
			localStorage.setItem("safekids_theme", "light");
		}
	}, [darkMode]);
	const handleToggleDarkMode = () => {
		setDarkMode(!darkMode);
	};
	const handleSwitchToChildMode = (childId) => {
		setActiveChildIdForChildMode(childId);
		setCurrentMode("child");
	};
	const handleExitChildModeRequest = () => {
		setPinAction("exit_child");
		setShowPinModal(true);
	};
	const handlePinSuccess = () => {
		setShowPinModal(false);
		if (pinAction === "exit_child") {
			setCurrentMode("parent");
		} else if (pinAction === "change_pin") {
			setShowChangePinForm(true);
		}
	};
	const handleSaveNewPin = async (e) => {
		e.preventDefault();
		if (!state || newPinValue.length < 4) return;
		const res = await updateParentPin(state.parentPin, newPinValue);
		if (res.success) {
			setPinChangeMsg("Master PIN updated successfully!");
			setTimeout(() => {
				setShowChangePinForm(false);
				setPinChangeMsg("");
				setNewPinValue("");
			}, 1500);
			refreshData();
		} else {
			setPinChangeMsg(res.error || "Failed to update PIN");
		}
	};
	if (!state) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 text-white",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "w-12 h-12 rounded-2xl bg-blue-600 animate-pulse flex items-center justify-center mb-4",
					children: "🛡️"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 106,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-lg font-bold",
					children: "Initializing SafeKids..."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-1",
					children: "Connecting free parental security engine"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 105,
			columnNumber: 7
		}, this);
	}
	const childForChildMode = state.children.find((c) => c.id === activeChildIdForChildMode) || state.children[0];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors",
		children: [
			currentMode === "parent" ? /* @__PURE__ */ _jsxDEV(ParentDashboard, {
				state,
				onRefresh: refreshData,
				onSwitchToChildMode: handleSwitchToChildMode,
				darkMode,
				onToggleDarkMode: handleToggleDarkMode,
				onChangePinRequested: () => {
					setPinAction("change_pin");
					setShowPinModal(true);
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 121,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV(ChildModeView, {
				child: childForChildMode,
				onExitChildMode: handleExitChildModeRequest,
				onRefresh: refreshData
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 133,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(PinProtectionModal, {
				isOpen: showPinModal,
				title: pinAction === "exit_child" ? "Parent PIN Required to Exit Child Mode" : "Enter Current PIN to Modify Security Settings",
				subtitle: "Default Parent PIN is 1234",
				onSuccess: handlePinSuccess,
				onCancel: () => setShowPinModal(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 141,
				columnNumber: 7
			}, this),
			showChangePinForm && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-xs w-full p-6 space-y-4 shadow-2xl",
					children: [
						/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-bold text-base text-slate-900 dark:text-slate-100 text-center",
							children: "Set New Master Parent PIN"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 157,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 text-center",
							children: "Used to exit child mode, change limits, and pair devices."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 160,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("form", {
							onSubmit: handleSaveNewPin,
							className: "space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("input", {
									type: "password",
									inputMode: "numeric",
									maxLength: 6,
									value: newPinValue,
									onChange: (e) => setNewPinValue(e.target.value.replace(/\D/g, "")),
									placeholder: "Enter 4-6 digits",
									className: "w-full text-center tracking-widest text-lg font-mono px-3 py-2 border rounded-xl border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 165,
									columnNumber: 15
								}, this),
								pinChangeMsg && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-center font-semibold text-emerald-600 dark:text-emerald-400",
									children: pinChangeMsg
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 176,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setShowChangePinForm(false),
										className: "py-2 px-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold",
										children: "Cancel"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 182,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "submit",
										disabled: newPinValue.length < 4,
										className: "py-2 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold disabled:opacity-50",
										children: "Save PIN"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 189,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 181,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "border-t border-slate-100 dark:border-slate-800 pt-2.5 text-center",
									children: /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 block",
										children: ["SafeKids Settings • Developed by ", /* @__PURE__ */ _jsxDEV("strong", {
											className: "text-slate-700 dark:text-slate-300",
											children: "Rajan Vishwakarma"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 201,
											columnNumber: 52
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 200,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 199,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 164,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 156,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 155,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 119,
		columnNumber: 5
	}, this);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsV0FBVyxjQUFjO0FBRW5ELFNBQVMsWUFBWSx1QkFBdUI7QUFDNUMsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyx1QkFBdUIsb0JBQW9CO0FBQ3BELFNBQVMsNkJBQTZCOzs7QUFFdEMsZUFBZSxTQUFTLE1BQU07Q0FDNUIsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFrQixxQkFBcUI7Q0FDakUsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQTZCLFFBQVE7Q0FDM0UsTUFBTSxDQUFDLDJCQUEyQixnQ0FBZ0MsU0FBaUIsRUFBRTtDQUNyRixNQUFNLENBQUMsVUFBVSxlQUFlLGVBQXdCO0VBQ3RELE1BQU0sUUFBUSxhQUFhLFFBQVEsZ0JBQWdCO0VBQ25ELE9BQU8sUUFBUSxVQUFVLFNBQVM7Q0FDcEMsQ0FBQzs7Q0FHRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFzQyxZQUFZO0NBQ3BGLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQVMsS0FBSztDQUNoRSxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEVBQUU7O0NBR25ELE1BQU0sd0JBQXdCLE9BQU8sQ0FBQzs7Q0FHdEMsTUFBTSxjQUFjLFlBQVk7RUFDOUIsTUFBTSxPQUFPLE1BQU0sV0FBVztFQUM5QixJQUFJLE1BQU07O0dBRVIsSUFBSSxLQUFLLE9BQU8sU0FBUyxzQkFBc0IsV0FBVyxzQkFBc0IsVUFBVSxHQUFHO0lBQzNGLE1BQU0sU0FBUyxLQUFLLE9BQU87SUFDM0IsSUFBSSxPQUFPLFNBQVMsT0FBTztLQUN6QixhQUFhLENBQUM7SUFDaEIsT0FBTztLQUNMLHNCQUFzQjtJQUN4QjtHQUNGO0dBQ0Esc0JBQXNCLFVBQVUsS0FBSyxPQUFPO0dBQzVDLFNBQVMsSUFBSTtFQUNmO0NBQ0Y7Q0FFQSxnQkFBZ0I7RUFDZCxZQUFZO0VBQ1osTUFBTSxXQUFXLFlBQVksYUFBYSxHQUFJO0VBQzlDLGFBQWEsY0FBYyxRQUFRO0NBQ3JDLEdBQUcsQ0FBQyxDQUFDO0NBRUwsZ0JBQWdCO0VBQ2QsSUFBSSxVQUFVO0dBQ1osU0FBUyxnQkFBZ0IsVUFBVSxJQUFJLE1BQU07R0FDN0MsYUFBYSxRQUFRLGtCQUFrQixNQUFNO0VBQy9DLE9BQU87R0FDTCxTQUFTLGdCQUFnQixVQUFVLE9BQU8sTUFBTTtHQUNoRCxhQUFhLFFBQVEsa0JBQWtCLE9BQU87RUFDaEQ7Q0FDRixHQUFHLENBQUMsUUFBUSxDQUFDO0NBRWIsTUFBTSw2QkFBNkI7RUFDakMsWUFBWSxDQUFDLFFBQVE7Q0FDdkI7Q0FFQSxNQUFNLDJCQUEyQixZQUFvQjtFQUNuRCw2QkFBNkIsT0FBTztFQUNwQyxlQUFlLE9BQU87Q0FDeEI7Q0FFQSxNQUFNLG1DQUFtQztFQUN2QyxhQUFhLFlBQVk7RUFDekIsZ0JBQWdCLElBQUk7Q0FDdEI7Q0FFQSxNQUFNLHlCQUF5QjtFQUM3QixnQkFBZ0IsS0FBSztFQUNyQixJQUFJLGNBQWMsY0FBYztHQUM5QixlQUFlLFFBQVE7RUFDekIsT0FBTyxJQUFJLGNBQWMsY0FBYztHQUNyQyxxQkFBcUIsSUFBSTtFQUMzQjtDQUNGO0NBRUEsTUFBTSxtQkFBbUIsT0FBTyxNQUF1QjtFQUNyRCxFQUFFLGVBQWU7RUFDakIsSUFBSSxDQUFDLFNBQVMsWUFBWSxTQUFTLEdBQUc7RUFDdEMsTUFBTSxNQUFNLE1BQU0sZ0JBQWdCLE1BQU0sV0FBVyxXQUFXO0VBQzlELElBQUksSUFBSSxTQUFTO0dBQ2YsZ0JBQWdCLGtDQUFrQztHQUNsRCxpQkFBaUI7SUFDZixxQkFBcUIsS0FBSztJQUMxQixnQkFBZ0IsRUFBRTtJQUNsQixlQUFlLEVBQUU7R0FDbkIsR0FBRyxJQUFJO0dBQ1AsWUFBWTtFQUNkLE9BQU87R0FDTCxnQkFBZ0IsSUFBSSxTQUFTLHNCQUFzQjtFQUNyRDtDQUNGO0NBRUEsSUFBSSxDQUFDLE9BQU87RUFDVixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUF3RjtJQUVsRzs7Ozs7SUFDTCx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFvQjtJQUE0Qjs7Ozs7SUFDOUQsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBOEI7SUFBMkM7Ozs7O0dBQ25GOzs7Ozs7Q0FFVDtDQUVBLE1BQU0sb0JBQ0osTUFBTSxTQUFTLE1BQU0sTUFBTSxFQUFFLE9BQU8seUJBQXlCLEtBQUssTUFBTSxTQUFTO0NBRW5GLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNHLGdCQUFnQixXQUNmLHdCQUFDLGlCQUFEO0lBQ1M7SUFDUCxXQUFXO0lBQ1gscUJBQXFCO0lBQ1g7SUFDVixrQkFBa0I7SUFDbEIsNEJBQTRCO0tBQzFCLGFBQWEsWUFBWTtLQUN6QixnQkFBZ0IsSUFBSTtJQUN0QjtHQUNEOzs7O2NBRUQsd0JBQUMsZUFBRDtJQUNFLE9BQU87SUFDUCxpQkFBaUI7SUFDakIsV0FBVztHQUNaOzs7OztHQUlILHdCQUFDLG9CQUFEO0lBQ0UsUUFBUTtJQUNSLE9BQ0UsY0FBYyxlQUNWLDJDQUNBO0lBRU4sVUFBUztJQUNULFdBQVc7SUFDWCxnQkFBZ0IsZ0JBQWdCLEtBQUs7R0FDdEM7Ozs7O0dBR0EscUJBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQXFFO01BRS9FOzs7OztNQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFxQztNQUUvQzs7Ozs7TUFFSCx3QkFBQyxRQUFEO09BQU0sVUFBVTtPQUFrQixXQUFVO2lCQUE1QztRQUNFLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsV0FBVTtTQUNWLFdBQVc7U0FDWCxPQUFPO1NBQ1AsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLE1BQU0sUUFBUSxPQUFPLEVBQUUsQ0FBQztTQUNqRSxhQUFZO1NBQ1osV0FBVTtRQUNYOzs7OztRQUVBLGdCQUNDLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUNWO1FBQ0E7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLGVBQWUscUJBQXFCLEtBQUs7VUFDekMsV0FBVTtvQkFDWDtTQUVPOzs7O21CQUNSLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsVUFBVSxZQUFZLFNBQVM7VUFDL0IsV0FBVTtvQkFDWDtTQUVPOzs7O2lCQUNMOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FBbUQscUNBQ2hCLHdCQUFDLFVBQUQ7V0FBUSxXQUFVO3FCQUFxQztVQUF5Qjs7OztrQkFDN0c7Ozs7OztRQUNIOzs7OztPQUNEOzs7Ozs7S0FDSDs7Ozs7O0dBQ0Y7Ozs7O0VBRUo7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IERCU3RhdGUsIENoaWxkRGV2aWNlIH0gZnJvbSAnLi90eXBlcy9zYWZla2lkcyc7XG5pbXBvcnQgeyBmZXRjaFN0YXRlLCB1cGRhdGVQYXJlbnRQaW4gfSBmcm9tICcuL3NlcnZpY2VzL2FwaSc7XG5pbXBvcnQgeyBQYXJlbnREYXNoYm9hcmQgfSBmcm9tICcuL2NvbXBvbmVudHMvUGFyZW50RGFzaGJvYXJkJztcbmltcG9ydCB7IENoaWxkTW9kZVZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvQ2hpbGRNb2RlVmlldyc7XG5pbXBvcnQgeyBQaW5Qcm90ZWN0aW9uTW9kYWwgfSBmcm9tICcuL2NvbXBvbmVudHMvUGluUHJvdGVjdGlvbk1vZGFsJztcbmltcG9ydCB7IHBsYXlOb3RpZmljYXRpb25DaGltZSwgcGxheVNPU1NpcmVuIH0gZnJvbSAnLi91dGlscy9hdWRpbyc7XG5pbXBvcnQgeyBJTklUSUFMX0RFRkFVTFRfU1RBVEUgfSBmcm9tICcuL3V0aWxzL2luaXRpYWxTdGF0ZSc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgY29uc3QgW3N0YXRlLCBzZXRTdGF0ZV0gPSB1c2VTdGF0ZTxEQlN0YXRlPihJTklUSUFMX0RFRkFVTFRfU1RBVEUpO1xuICBjb25zdCBbY3VycmVudE1vZGUsIHNldEN1cnJlbnRNb2RlXSA9IHVzZVN0YXRlPCdwYXJlbnQnIHwgJ2NoaWxkJz4oJ3BhcmVudCcpO1xuICBjb25zdCBbYWN0aXZlQ2hpbGRJZEZvckNoaWxkTW9kZSwgc2V0QWN0aXZlQ2hpbGRJZEZvckNoaWxkTW9kZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgY29uc3QgW2RhcmtNb2RlLCBzZXREYXJrTW9kZV0gPSB1c2VTdGF0ZTxib29sZWFuPigoKSA9PiB7XG4gICAgY29uc3Qgc2F2ZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnc2FmZWtpZHNfdGhlbWUnKTtcbiAgICByZXR1cm4gc2F2ZWQgPyBzYXZlZCA9PT0gJ2RhcmsnIDogZmFsc2U7XG4gIH0pO1xuXG4gIC8vIFBJTiBtb2RhbFxuICBjb25zdCBbc2hvd1Bpbk1vZGFsLCBzZXRTaG93UGluTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbcGluQWN0aW9uLCBzZXRQaW5BY3Rpb25dID0gdXNlU3RhdGU8J2V4aXRfY2hpbGQnIHwgJ2NoYW5nZV9waW4nPignZXhpdF9jaGlsZCcpO1xuICBjb25zdCBbc2hvd0NoYW5nZVBpbkZvcm0sIHNldFNob3dDaGFuZ2VQaW5Gb3JtXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW25ld1BpblZhbHVlLCBzZXROZXdQaW5WYWx1ZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtwaW5DaGFuZ2VNc2csIHNldFBpbkNoYW5nZU1zZ10gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgLy8gQXVkaW8gYWxlcnQgdHJhY2tpbmdcbiAgY29uc3QgcHJldmlvdXNBbGVydENvdW50UmVmID0gdXNlUmVmKDApO1xuXG4gIC8vIFN5bmMgc3RhdGUgZnVuY3Rpb25cbiAgY29uc3QgcmVmcmVzaERhdGEgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IGZldGNoU3RhdGUoKTtcbiAgICBpZiAoZGF0YSkge1xuICAgICAgLy8gQ2hlY2sgaWYgbmV3IGFsZXJ0IGFwcGVhcmVkXG4gICAgICBpZiAoZGF0YS5hbGVydHMubGVuZ3RoID4gcHJldmlvdXNBbGVydENvdW50UmVmLmN1cnJlbnQgJiYgcHJldmlvdXNBbGVydENvdW50UmVmLmN1cnJlbnQgPiAwKSB7XG4gICAgICAgIGNvbnN0IGxhdGVzdCA9IGRhdGEuYWxlcnRzWzBdO1xuICAgICAgICBpZiAobGF0ZXN0LnR5cGUgPT09ICdzb3MnKSB7XG4gICAgICAgICAgcGxheVNPU1NpcmVuKDQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHBsYXlOb3RpZmljYXRpb25DaGltZSgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBwcmV2aW91c0FsZXJ0Q291bnRSZWYuY3VycmVudCA9IGRhdGEuYWxlcnRzLmxlbmd0aDtcbiAgICAgIHNldFN0YXRlKGRhdGEpO1xuICAgIH1cbiAgfTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJlZnJlc2hEYXRhKCk7XG4gICAgY29uc3QgaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbChyZWZyZXNoRGF0YSwgNjAwMCk7XG4gICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWwpO1xuICB9LCBbXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZGFya01vZGUpIHtcbiAgICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGFzc0xpc3QuYWRkKCdkYXJrJyk7XG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnc2FmZWtpZHNfdGhlbWUnLCAnZGFyaycpO1xuICAgIH0gZWxzZSB7XG4gICAgICBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnZGFyaycpO1xuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3NhZmVraWRzX3RoZW1lJywgJ2xpZ2h0Jyk7XG4gICAgfVxuICB9LCBbZGFya01vZGVdKTtcblxuICBjb25zdCBoYW5kbGVUb2dnbGVEYXJrTW9kZSA9ICgpID0+IHtcbiAgICBzZXREYXJrTW9kZSghZGFya01vZGUpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVN3aXRjaFRvQ2hpbGRNb2RlID0gKGNoaWxkSWQ6IHN0cmluZykgPT4ge1xuICAgIHNldEFjdGl2ZUNoaWxkSWRGb3JDaGlsZE1vZGUoY2hpbGRJZCk7XG4gICAgc2V0Q3VycmVudE1vZGUoJ2NoaWxkJyk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRXhpdENoaWxkTW9kZVJlcXVlc3QgPSAoKSA9PiB7XG4gICAgc2V0UGluQWN0aW9uKCdleGl0X2NoaWxkJyk7XG4gICAgc2V0U2hvd1Bpbk1vZGFsKHRydWUpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVBpblN1Y2Nlc3MgPSAoKSA9PiB7XG4gICAgc2V0U2hvd1Bpbk1vZGFsKGZhbHNlKTtcbiAgICBpZiAocGluQWN0aW9uID09PSAnZXhpdF9jaGlsZCcpIHtcbiAgICAgIHNldEN1cnJlbnRNb2RlKCdwYXJlbnQnKTtcbiAgICB9IGVsc2UgaWYgKHBpbkFjdGlvbiA9PT0gJ2NoYW5nZV9waW4nKSB7XG4gICAgICBzZXRTaG93Q2hhbmdlUGluRm9ybSh0cnVlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU2F2ZU5ld1BpbiA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFzdGF0ZSB8fCBuZXdQaW5WYWx1ZS5sZW5ndGggPCA0KSByZXR1cm47XG4gICAgY29uc3QgcmVzID0gYXdhaXQgdXBkYXRlUGFyZW50UGluKHN0YXRlLnBhcmVudFBpbiwgbmV3UGluVmFsdWUpO1xuICAgIGlmIChyZXMuc3VjY2Vzcykge1xuICAgICAgc2V0UGluQ2hhbmdlTXNnKCdNYXN0ZXIgUElOIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IScpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldFNob3dDaGFuZ2VQaW5Gb3JtKGZhbHNlKTtcbiAgICAgICAgc2V0UGluQ2hhbmdlTXNnKCcnKTtcbiAgICAgICAgc2V0TmV3UGluVmFsdWUoJycpO1xuICAgICAgfSwgMTUwMCk7XG4gICAgICByZWZyZXNoRGF0YSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRQaW5DaGFuZ2VNc2cocmVzLmVycm9yIHx8ICdGYWlsZWQgdG8gdXBkYXRlIFBJTicpO1xuICAgIH1cbiAgfTtcblxuICBpZiAoIXN0YXRlKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTkwMCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgdGV4dC13aGl0ZVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLTJ4bCBiZy1ibHVlLTYwMCBhbmltYXRlLXB1bHNlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTRcIj5cbiAgICAgICAgICDwn5uh77iPXG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGRcIj5Jbml0aWFsaXppbmcgU2FmZUtpZHMuLi48L2gyPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTFcIj5Db25uZWN0aW5nIGZyZWUgcGFyZW50YWwgc2VjdXJpdHkgZW5naW5lPC9wPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIGNvbnN0IGNoaWxkRm9yQ2hpbGRNb2RlID1cbiAgICBzdGF0ZS5jaGlsZHJlbi5maW5kKChjKSA9PiBjLmlkID09PSBhY3RpdmVDaGlsZElkRm9yQ2hpbGRNb2RlKSB8fCBzdGF0ZS5jaGlsZHJlblswXTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtOTUwIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgIHtjdXJyZW50TW9kZSA9PT0gJ3BhcmVudCcgPyAoXG4gICAgICAgIDxQYXJlbnREYXNoYm9hcmRcbiAgICAgICAgICBzdGF0ZT17c3RhdGV9XG4gICAgICAgICAgb25SZWZyZXNoPXtyZWZyZXNoRGF0YX1cbiAgICAgICAgICBvblN3aXRjaFRvQ2hpbGRNb2RlPXtoYW5kbGVTd2l0Y2hUb0NoaWxkTW9kZX1cbiAgICAgICAgICBkYXJrTW9kZT17ZGFya01vZGV9XG4gICAgICAgICAgb25Ub2dnbGVEYXJrTW9kZT17aGFuZGxlVG9nZ2xlRGFya01vZGV9XG4gICAgICAgICAgb25DaGFuZ2VQaW5SZXF1ZXN0ZWQ9eygpID0+IHtcbiAgICAgICAgICAgIHNldFBpbkFjdGlvbignY2hhbmdlX3BpbicpO1xuICAgICAgICAgICAgc2V0U2hvd1Bpbk1vZGFsKHRydWUpO1xuICAgICAgICAgIH19XG4gICAgICAgIC8+XG4gICAgICApIDogKFxuICAgICAgICA8Q2hpbGRNb2RlVmlld1xuICAgICAgICAgIGNoaWxkPXtjaGlsZEZvckNoaWxkTW9kZX1cbiAgICAgICAgICBvbkV4aXRDaGlsZE1vZGU9e2hhbmRsZUV4aXRDaGlsZE1vZGVSZXF1ZXN0fVxuICAgICAgICAgIG9uUmVmcmVzaD17cmVmcmVzaERhdGF9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7LyogUElOIFZlcmlmaWNhdGlvbiBNb2RhbCAqL31cbiAgICAgIDxQaW5Qcm90ZWN0aW9uTW9kYWxcbiAgICAgICAgaXNPcGVuPXtzaG93UGluTW9kYWx9XG4gICAgICAgIHRpdGxlPXtcbiAgICAgICAgICBwaW5BY3Rpb24gPT09ICdleGl0X2NoaWxkJ1xuICAgICAgICAgICAgPyAnUGFyZW50IFBJTiBSZXF1aXJlZCB0byBFeGl0IENoaWxkIE1vZGUnXG4gICAgICAgICAgICA6ICdFbnRlciBDdXJyZW50IFBJTiB0byBNb2RpZnkgU2VjdXJpdHkgU2V0dGluZ3MnXG4gICAgICAgIH1cbiAgICAgICAgc3VidGl0bGU9XCJEZWZhdWx0IFBhcmVudCBQSU4gaXMgMTIzNFwiXG4gICAgICAgIG9uU3VjY2Vzcz17aGFuZGxlUGluU3VjY2Vzc31cbiAgICAgICAgb25DYW5jZWw9eygpID0+IHNldFNob3dQaW5Nb2RhbChmYWxzZSl9XG4gICAgICAvPlxuXG4gICAgICB7LyogQ2hhbmdlIFBJTiBEaWFsb2cgKi99XG4gICAgICB7c2hvd0NoYW5nZVBpbkZvcm0gJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svODAgYmFja2Ryb3AtYmx1ci1zbSB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIG1heC13LXhzIHctZnVsbCBwLTYgc3BhY2UteS00IHNoYWRvdy0yeGxcIj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1iYXNlIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgU2V0IE5ldyBNYXN0ZXIgUGFyZW50IFBJTlxuICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgVXNlZCB0byBleGl0IGNoaWxkIG1vZGUsIGNoYW5nZSBsaW1pdHMsIGFuZCBwYWlyIGRldmljZXMuXG4gICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTYXZlTmV3UGlufSBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJudW1lcmljXCJcbiAgICAgICAgICAgICAgICBtYXhMZW5ndGg9ezZ9XG4gICAgICAgICAgICAgICAgdmFsdWU9e25ld1BpblZhbHVlfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3UGluVmFsdWUoZS50YXJnZXQudmFsdWUucmVwbGFjZSgvXFxEL2csICcnKSl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciA0LTYgZGlnaXRzXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgdHJhY2tpbmctd2lkZXN0IHRleHQtbGcgZm9udC1tb25vIHB4LTMgcHktMiBib3JkZXIgcm91bmRlZC14bCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMFwiXG4gICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAge3BpbkNoYW5nZU1zZyAmJiAoXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWNlbnRlciBmb250LXNlbWlib2xkIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICB7cGluQ2hhbmdlTXNnfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dDaGFuZ2VQaW5Gb3JtKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB5LTIgcHgtMyBiZy1zbGF0ZS0xMDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e25ld1BpblZhbHVlLmxlbmd0aCA8IDR9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweS0yIHB4LTMgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIFNhdmUgUElOXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBEZXZlbG9wZXIgQXR0cmlidXRpb24gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcHQtMi41IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgYmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgIFNhZmVLaWRzIFNldHRpbmdzIOKAoiBEZXZlbG9wZWQgYnkgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+UmFqYW4gVmlzaHdha2FybWE8L3N0cm9uZz5cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXX0=