const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=d3d47fa4";
import { Shield, AlertTriangle, Battery, BatteryCharging, Clock, Lock, Compass, PhoneCall, Send, Camera, Monitor, CheckCircle2, X, ExternalLink, MessageSquare, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=d3d47fa4";
import { triggerSOS, requestTimeExtension, respondCameraRequest, respondScreenRequest, sendChildHeartbeat, sendMessage } from "/src/services/api.ts";
import { playSOSSiren, playRequestIncomingBell } from "/src/utils/audio.ts";
import { checkUrlAllowed, CURATED_SAFE_SITES } from "/src/utils/webfilter.ts";
import { reverseGeocode } from "/src/utils/geofence.ts";
var _jsxFileName = "/app/applet/src/components/ChildModeView.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d3d47fa4";
export const ChildModeView = ({ child, onExitChildMode, onRefresh }) => {
	// SOS State
	const [sosActive, setSosActive] = useState(false);
	const [sosCountdown, setSosCountdown] = useState(null);
	const sirenStopFnRef = useRef(null);
	// Time Request Modal
	const [showTimeRequestModal, setShowTimeRequestModal] = useState(false);
	const [requestMinutes, setRequestMinutes] = useState(30);
	const [requestReason, setRequestReason] = useState("Finishing school assignment");
	const [timeRequestSent, setTimeRequestSent] = useState(false);
	// Safe Browser State
	const [browserUrl, setBrowserUrl] = useState("");
	const [currentBrowserPage, setCurrentBrowserPage] = useState(null);
	const [blockedAttempt, setBlockedAttempt] = useState(null);
	// Chat message to parent
	const [quickMsg, setQuickMsg] = useState("");
	const [chatSent, setChatSent] = useState(false);
	// Camera / Screen Sharing Stream
	const [isSharingMedia, setIsSharingMedia] = useState(false);
	const [mediaType, setMediaType] = useState(null);
	const activeMediaStreamRef = useRef(null);
	const childVideoRef = useRef(null);
	// Simulated GPS position
	const [currentCoords, setCurrentCoords] = useState({
		lat: child.location.latitude,
		lng: child.location.longitude
	});
	// Track battery using navigator.getBattery if supported
	const [batteryLevel, setBatteryLevel] = useState(child.batteryLevel);
	const [isCharging, setIsCharging] = useState(child.isCharging);
	useEffect(() => {
		if ("getBattery" in navigator) {
			try {
				navigator.getBattery().then((battery) => {
					if (!battery) return;
					setBatteryLevel(Math.round(battery.level * 100));
					setIsCharging(battery.charging);
					battery.addEventListener("levelchange", () => {
						setBatteryLevel(Math.round(battery.level * 100));
					});
					battery.addEventListener("chargingchange", () => {
						setIsCharging(battery.charging);
					});
				}).catch(() => {
					// battery api restricted in iframe
				});
			} catch {}
		}
		// Try real geolocation
		if (navigator.geolocation) {
			navigator.geolocation.getCurrentPosition(async (pos) => {
				const lat = pos.coords.latitude;
				const lng = pos.coords.longitude;
				setCurrentCoords({
					lat,
					lng
				});
				const address = await reverseGeocode(lat, lng);
				sendChildHeartbeat(child.id, {
					batteryLevel,
					isCharging,
					location: {
						latitude: lat,
						longitude: lng,
						accuracy: pos.coords.accuracy,
						speed: pos.coords.speed,
						address
					}
				});
			}, () => {
				// ignore or keep default
			}, {
				enableHighAccuracy: true,
				timeout: 5e3
			});
		}
	}, [child.id]);
	// Periodic heartbeat sync to server
	useEffect(() => {
		const timer = setInterval(() => {
			sendChildHeartbeat(child.id, {
				batteryLevel,
				isCharging
			});
			onRefresh();
		}, 15e3);
		return () => clearInterval(timer);
	}, [
		child.id,
		batteryLevel,
		isCharging,
		onRefresh
	]);
	// Check incoming camera / screen requests from parent
	const cameraRequest = child.activeSessions?.cameraRequest;
	const screenRequest = child.activeSessions?.screenRequest;
	useEffect(() => {
		if (cameraRequest && cameraRequest.status === "pending") {
			playRequestIncomingBell();
		}
		if (screenRequest && screenRequest.status === "pending") {
			playRequestIncomingBell();
		}
	}, [cameraRequest?.status, screenRequest?.status]);
	// Trigger Emergency SOS
	const handleTriggerSOS = async () => {
		setSosActive(true);
		const stopFn = playSOSSiren(6);
		sirenStopFnRef.current = stopFn;
		// Send to backend
		await triggerSOS(child.id, currentCoords.lat, currentCoords.lng);
		onRefresh();
	};
	const handleCancelSOS = () => {
		if (sirenStopFnRef.current) {
			sirenStopFnRef.current();
			sirenStopFnRef.current = null;
		}
		setSosActive(false);
	};
	// Safe Browser Navigate
	const handleNavigateBrowser = (urlToOpen) => {
		setBlockedAttempt(null);
		let target = urlToOpen.trim();
		if (!target) return;
		if (!target.startsWith("http://") && !target.startsWith("https://")) {
			target = "https://" + target;
		}
		// Filter validation
		const result = checkUrlAllowed(target, child.webFilter.blockedCategories, child.webFilter.blockedDomains, child.webFilter.allowedDomains);
		if (!result.allowed) {
			setBlockedAttempt({
				url: target,
				reason: result.blockedReason
			});
			setCurrentBrowserPage(null);
			// Log blocked attempt to parent
			sendChildHeartbeat(child.id, {});
			return;
		}
		// Allowed
		let title = target;
		try {
			title = new URL(target).hostname;
		} catch {}
		setCurrentBrowserPage({
			url: target,
			title
		});
		setBrowserUrl(target);
	};
	// Handle Parent Camera Request Accept
	const handleAcceptCamera = async () => {
		try {
			const facing = cameraRequest?.facingMode || "user";
			const stream = await navigator.mediaDevices.getUserMedia({
				video: { facingMode: facing },
				audio: false
			});
			activeMediaStreamRef.current = stream;
			setIsSharingMedia(true);
			setMediaType("camera");
			if (childVideoRef.current) {
				childVideoRef.current.srcObject = stream;
			}
			await respondCameraRequest(child.id, "accepted");
			onRefresh();
		} catch (e) {
			alert("Camera permission denied or camera device not found: " + e.message);
			await respondCameraRequest(child.id, "denied");
		}
	};
	const handleDeclineCamera = async () => {
		await respondCameraRequest(child.id, "denied");
		onRefresh();
	};
	// Handle Parent Screen Share Request Accept
	const handleAcceptScreen = async () => {
		try {
			if (!navigator.mediaDevices.getDisplayMedia) {
				alert("Screen sharing is not supported on this device/browser.");
				await respondScreenRequest(child.id, "denied");
				return;
			}
			const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
			stream.getVideoTracks()[0].onended = () => {
				handleStopSharing();
			};
			activeMediaStreamRef.current = stream;
			setIsSharingMedia(true);
			setMediaType("screen");
			if (childVideoRef.current) {
				childVideoRef.current.srcObject = stream;
			}
			await respondScreenRequest(child.id, "accepted");
			onRefresh();
		} catch (e) {
			await respondScreenRequest(child.id, "denied");
		}
	};
	const handleDeclineScreen = async () => {
		await respondScreenRequest(child.id, "denied");
		onRefresh();
	};
	const handleStopSharing = async () => {
		if (activeMediaStreamRef.current) {
			activeMediaStreamRef.current.getTracks().forEach((t) => t.stop());
			activeMediaStreamRef.current = null;
		}
		setIsSharingMedia(false);
		if (mediaType === "camera") {
			await respondCameraRequest(child.id, "ended");
		} else {
			await respondScreenRequest(child.id, "ended");
		}
		setMediaType(null);
		onRefresh();
	};
	// Time Extension Submission
	const handleSubmitTimeRequest = async (e) => {
		e.preventDefault();
		await requestTimeExtension(child.id, requestMinutes, requestReason);
		setTimeRequestSent(true);
		setTimeout(() => {
			setTimeRequestSent(false);
			setShowTimeRequestModal(false);
		}, 2e3);
		onRefresh();
	};
	// Send message to parent
	const handleSendChat = async () => {
		if (!quickMsg.trim()) return;
		await sendMessage(child.id, "child", quickMsg.trim());
		setQuickMsg("");
		setChatSent(true);
		setTimeout(() => setChatSent(false), 2e3);
		onRefresh();
	};
	const remainingMinutes = Math.max(0, child.screenTime.dailyLimitMinutes - child.screenTime.todayUsageMinutes);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-900 text-white flex flex-col justify-between pb-10",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "bg-slate-950/80 backdrop-blur-md px-4 py-3 border-b border-slate-800 sticky top-0 z-30 flex items-center justify-between",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-9 h-9 rounded-full bg-blue-600 text-lg flex items-center justify-center shadow-md",
						children: child.avatar
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 318,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-bold text-sm tracking-tight",
							children: [child.name, "'s Phone"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 323,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-1.5 py-0.5 rounded font-mono",
							children: "SAFE"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 324,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 322,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "text-[11px] text-slate-400 flex items-center gap-2",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: child.deviceModel }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 329,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 330,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "flex items-center gap-1",
								children: [
									isCharging ? /* @__PURE__ */ _jsxDEV(BatteryCharging, { className: "w-3 h-3 text-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 333,
										columnNumber: 19
									}, this) : /* @__PURE__ */ _jsxDEV(Battery, { className: "w-3 h-3 text-slate-300" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 335,
										columnNumber: 19
									}, this),
									batteryLevel,
									"%"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 331,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 328,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 321,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 317,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: onExitChildMode,
					className: "px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-xl font-medium flex items-center gap-1.5 border border-slate-700 transition-colors",
					children: [/* @__PURE__ */ _jsxDEV(Lock, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 348,
						columnNumber: 11
					}, this), " Parent Exit"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 344,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 316,
				columnNumber: 7
			}, this),
			isSharingMedia && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-emerald-600 text-white px-4 py-2 text-xs font-semibold flex items-center justify-between shadow-lg sticky top-[57px] z-40 animate-pulse",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-white" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 356,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
						"LIVE ",
						mediaType === "camera" ? "CAMERA" : "SCREEN",
						" SHARING IS ACTIVE WITH YOUR PARENTS"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 357,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 355,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: handleStopSharing,
					className: "px-2.5 py-1 bg-white text-emerald-800 rounded-lg text-xs font-bold hover:bg-slate-100 transition-colors",
					children: "STOP SHARING"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 361,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 354,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "max-w-xl mx-auto w-full p-4 space-y-5 flex-1",
				children: [
					/* @__PURE__ */ _jsxDEV("section", {
						className: `rounded-3xl p-5 border transition-all text-center ${sosActive ? "bg-rose-950/80 border-rose-500 shadow-2xl shadow-rose-900/50 animate-bounce" : "bg-gradient-to-b from-rose-900/40 to-slate-900 border-rose-900/60"}`,
						children: sosActive ? /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "w-16 h-16 rounded-full bg-rose-600 mx-auto flex items-center justify-center animate-ping",
									children: /* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-8 h-8 text-white" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 381,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 380,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-xl font-black text-rose-300 tracking-wider",
									children: "🚨 SOS ALERT TRANSMITTED!"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 383,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-rose-200",
									children: "Your parents have been notified with your exact GPS coordinates and high-priority siren."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 386,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2 flex justify-center gap-3",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleCancelSOS,
										className: "px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold border border-slate-600",
										children: "I Am Safe (Cancel SOS)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 390,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("a", {
										href: "tel:911",
										className: "px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(PhoneCall, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 400,
											columnNumber: 19
										}, this), " Call Emergency (911)"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 396,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 389,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 379,
							columnNumber: 13
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-center gap-2 text-rose-400 font-bold text-xs uppercase tracking-widest",
									children: [/* @__PURE__ */ _jsxDEV(Shield, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 407,
										columnNumber: 17
									}, this), " Emergency Protection"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 406,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleTriggerSOS,
									className: "w-full py-4 rounded-2xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black text-base shadow-lg shadow-rose-700/40 active:scale-95 transition-all flex items-center justify-center gap-2 tracking-wide",
									children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-5 h-5 text-yellow-300" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 413,
										columnNumber: 17
									}, this), " TAP FOR EMERGENCY SOS"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 409,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-400",
									children: "Instantly alerts your parents, shares your GPS, and sounds an audible emergency siren."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 415,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 405,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 373,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "bg-slate-800/80 rounded-2xl p-4 border border-slate-700/80 shadow-md",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-9 h-9 rounded-xl bg-blue-600/30 text-blue-400 flex items-center justify-center",
									children: /* @__PURE__ */ _jsxDEV(Clock, { className: "w-5 h-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 427,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 426,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-bold text-sm text-slate-100",
									children: "Daily Screen Time"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 430,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400",
									children: remainingMinutes > 0 ? `${remainingMinutes} minutes remaining` : "Daily time limit reached!"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 431,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 429,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 425,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setShowTimeRequestModal(true),
								className: "px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors flex items-center gap-1",
								children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5 text-yellow-300" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 441,
									columnNumber: 15
								}, this), " Ask for Time"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 437,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 424,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-full bg-slate-900 rounded-full h-2.5 overflow-hidden",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: `h-full transition-all duration-500 ${remainingMinutes <= 15 ? "bg-amber-500" : "bg-blue-500"}`,
									style: { width: `${Math.min(100, child.screenTime.todayUsageMinutes / Math.max(1, child.screenTime.dailyLimitMinutes) * 100)}%` }
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 448,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 447,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between text-[11px] text-slate-400 mt-1.5",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: [
									"Used: ",
									child.screenTime.todayUsageMinutes,
									"m"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 458,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
									"Limit: ",
									child.screenTime.dailyLimitMinutes,
									"m"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 459,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 457,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 446,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 423,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "bg-slate-800/80 rounded-2xl p-4 border border-slate-700/80 shadow-md space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "w-8 h-8 rounded-lg bg-emerald-600/30 text-emerald-400 flex items-center justify-center",
										children: /* @__PURE__ */ _jsxDEV(Compass, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 469,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 468,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "font-bold text-sm text-slate-100",
										children: "Safe Web Explorer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 472,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-400",
										children: "SafeSearch & Filter Active"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 473,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 471,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 467,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-medium border border-emerald-500/30",
									children: "Filtered"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 476,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 466,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: browserUrl,
									onChange: (e) => setBrowserUrl(e.target.value),
									onKeyDown: (e) => e.key === "Enter" && handleNavigateBrowser(browserUrl),
									placeholder: "Search or enter website (e.g. wikipedia.org)...",
									className: "flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 483,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleNavigateBrowser(browserUrl),
									className: "px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-colors",
									children: "Go"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 491,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 482,
								columnNumber: 11
							}, this),
							blockedAttempt && /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-rose-950/70 border border-rose-600/70 rounded-xl p-3 text-xs text-rose-200 space-y-2 animate-in fade-in duration-200",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2 font-bold text-rose-300",
										children: [/* @__PURE__ */ _jsxDEV(Lock, { className: "w-4 h-4 text-rose-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 503,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Website Blocked by SafeKids Filter" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 504,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 502,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-rose-300/90 leading-relaxed",
										children: blockedAttempt.reason || "This site is not permitted under family safety rules."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 506,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex gap-2 pt-1",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: async () => {
												await sendMessage(child.id, "child", `Dad/Mom, can you please unblock "${blockedAttempt.url}"? I need it for research.`);
												alert("Request sent to parents!");
												setBlockedAttempt(null);
											},
											className: "px-2.5 py-1 bg-rose-800 hover:bg-rose-700 text-white rounded-lg text-[11px] font-semibold",
											children: "Ask Parent to Unblock"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 510,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setBlockedAttempt(null),
											className: "px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-[11px]",
											children: "Dismiss"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 520,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 509,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 501,
								columnNumber: 13
							}, this),
							currentBrowserPage && !blockedAttempt && /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-900 rounded-xl border border-slate-700 overflow-hidden",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-950 px-3 py-2 text-xs flex items-center justify-between border-b border-slate-800",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono text-[11px] text-emerald-400 truncate max-w-[240px]",
										children: ["🔒 ", currentBrowserPage.url]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 534,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("a", {
											href: currentBrowserPage.url,
											target: "_blank",
											rel: "noopener noreferrer",
											className: "text-blue-400 hover:text-blue-300 text-[11px] flex items-center gap-1",
											children: ["Open ", /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3 h-3" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 544,
												columnNumber: 26
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 538,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCurrentBrowserPage(null),
											className: "text-slate-400 hover:text-slate-200",
											children: /* @__PURE__ */ _jsxDEV(X, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 550,
												columnNumber: 21
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 546,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 537,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 533,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 text-center space-y-2",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-300",
										children: ["Safely navigated to ", /* @__PURE__ */ _jsxDEV("strong", { children: currentBrowserPage.title }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 556,
											columnNumber: 39
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 555,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-500",
										children: "Protected with parental content filter & tracking blocker."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 558,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 554,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 532,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-400 font-semibold block mb-2",
								children: "Verified Kid-Friendly Websites:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 567,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-2",
								children: CURATED_SAFE_SITES.slice(0, 4).map((site) => /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleNavigateBrowser(site.url),
									className: "p-2.5 bg-slate-900/90 hover:bg-slate-900 border border-slate-700/80 rounded-xl text-left transition-all group",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-base block mb-1",
											children: site.icon
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 577,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-medium text-xs text-slate-200 group-hover:text-blue-400 block truncate",
											children: site.name
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 578,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-500 block truncate",
											children: site.category
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 581,
											columnNumber: 19
										}, this)
									]
								}, site.name, true, {
									fileName: _jsxFileName,
									lineNumber: 572,
									columnNumber: 17
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 570,
								columnNumber: 13
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 566,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 465,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "bg-slate-800/80 rounded-2xl p-4 border border-slate-700/80 shadow-md space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "w-8 h-8 rounded-lg bg-indigo-600/30 text-indigo-400 flex items-center justify-center",
										children: /* @__PURE__ */ _jsxDEV(MessageSquare, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 595,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 594,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "font-bold text-sm text-slate-100",
										children: "Parent Intercom"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 598,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-400",
										children: "Direct instant check-in message"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 599,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 597,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 593,
									columnNumber: 13
								}, this), chatSent && /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] text-emerald-400 flex items-center gap-1 font-semibold",
									children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 604,
										columnNumber: 17
									}, this), " Sent!"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 603,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 592,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex gap-1.5 overflow-x-auto pb-1 text-[11px]",
								children: [
									"I am safe at home 👍",
									"Finished homework 📚",
									"Can I have 15m more?",
									"Please call me 📞"
								].map((preset) => /* @__PURE__ */ _jsxDEV("button", {
									onClick: async () => {
										await sendMessage(child.id, "child", preset);
										setChatSent(true);
										setTimeout(() => setChatSent(false), 2e3);
										onRefresh();
									},
									className: "px-2.5 py-1 bg-slate-900 border border-slate-700 hover:border-indigo-500 text-slate-300 rounded-lg whitespace-nowrap transition-colors",
									children: preset
								}, preset, false, {
									fileName: _jsxFileName,
									lineNumber: 612,
									columnNumber: 15
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 610,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: quickMsg,
									onChange: (e) => setQuickMsg(e.target.value),
									onKeyDown: (e) => e.key === "Enter" && handleSendChat(),
									placeholder: "Send message to parents...",
									className: "flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 628,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleSendChat,
									className: "px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors",
									children: /* @__PURE__ */ _jsxDEV(Send, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 640,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 636,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 627,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 591,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("section", {
						className: "bg-slate-950/80 rounded-2xl p-3.5 border border-slate-800 text-center space-y-1.5 shadow-sm",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-center gap-1.5 text-xs font-bold text-slate-300",
							children: [/* @__PURE__ */ _jsxDEV(Lock, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 648,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Anti-Uninstall & Device Admin Protected" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 649,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 647,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-slate-500",
							children: "SafeKids is locked to this device. Deleting or disabling this app requires Parent Master PIN authorization."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 651,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 646,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("footer", {
						className: "text-center py-2 text-xs text-slate-500 space-y-1",
						children: /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px]",
							children: ["SafeKids Child Shield • Developed by ", /* @__PURE__ */ _jsxDEV("strong", {
								className: "text-slate-300 font-bold",
								children: "Rajan Vishwakarma"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 659,
								columnNumber: 50
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 658,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 657,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("video", {
						ref: childVideoRef,
						autoPlay: true,
						playsInline: true,
						muted: true,
						className: "hidden"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 664,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 371,
				columnNumber: 7
			}, this),
			cameraRequest && cameraRequest.status === "pending" && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border-2 border-blue-500 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl animate-in zoom-in-95",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "w-16 h-16 rounded-2xl bg-blue-600/30 text-blue-400 mx-auto flex items-center justify-center animate-bounce",
							children: /* @__PURE__ */ _jsxDEV(Camera, { className: "w-8 h-8" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 672,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 671,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-lg font-bold text-white",
								children: "Parent Video Check-In"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 675,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-300 mt-1",
								children: "Your parent is requesting a 2-minute live camera look-in."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 676,
								columnNumber: 15
							}, this),
							cameraRequest.reason && /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-800 p-2 rounded-xl text-xs text-slate-400 mt-2 italic",
								children: [
									"\"",
									cameraRequest.reason,
									"\""
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 680,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 674,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-blue-950/40 p-3 rounded-xl border border-blue-800 text-[11px] text-blue-200",
							children: "🛡️ SafeKids Notice: You have full control. You can accept or deny. You can stop sharing at any second."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 686,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-3 pt-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: handleDeclineCamera,
								className: "py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700",
								children: "Decline"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 691,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleAcceptCamera,
								className: "py-2.5 px-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-blue-600/30",
								children: "Accept & Share"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 697,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 690,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 670,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 669,
				columnNumber: 9
			}, this),
			screenRequest && screenRequest.status === "pending" && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border-2 border-indigo-500 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl animate-in zoom-in-95",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "w-16 h-16 rounded-2xl bg-indigo-600/30 text-indigo-400 mx-auto flex items-center justify-center animate-bounce",
							children: /* @__PURE__ */ _jsxDEV(Monitor, { className: "w-8 h-8" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 713,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 712,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-lg font-bold text-white",
								children: "Screen Sharing Request"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 716,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-300 mt-1",
								children: "Your parent requested to review your screen via Android MediaProjection."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 717,
								columnNumber: 15
							}, this),
							screenRequest.reason && /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-800 p-2 rounded-xl text-xs text-slate-400 mt-2 italic",
								children: [
									"\"",
									screenRequest.reason,
									"\""
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 721,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 715,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-indigo-950/40 p-3 rounded-xl border border-indigo-800 text-[11px] text-indigo-200",
							children: "🛡️ SafeKids Notice: Android will display an official permission prompt. You can end screen sharing at any time."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 727,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-3 pt-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: handleDeclineScreen,
								className: "py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700",
								children: "Decline"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 732,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleAcceptScreen,
								className: "py-2.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/30",
								children: "Allow Screen Share"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 738,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 731,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 711,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 710,
				columnNumber: 9
			}, this),
			showTimeRequestModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-700 rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-bold text-base text-white flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-5 h-5 text-yellow-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 755,
								columnNumber: 17
							}, this), " Ask for Screen Time"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 754,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowTimeRequestModal(false),
							className: "text-slate-400 hover:text-white",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 761,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 757,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 753,
						columnNumber: 13
					}, this), timeRequestSent ? /* @__PURE__ */ _jsxDEV("div", {
						className: "py-6 text-center space-y-2",
						children: [
							/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-12 h-12 text-emerald-400 mx-auto" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 767,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("h4", {
								className: "font-bold text-white",
								children: "Request Sent to Parents!"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 768,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400",
								children: "They will receive a notification to approve your time."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 769,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 766,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleSubmitTimeRequest,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-xs font-semibold text-slate-300 block mb-2",
								children: "How many minutes do you need?"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 776,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									15,
									30,
									45
								].map((mins) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setRequestMinutes(mins),
									className: `py-2 text-xs rounded-xl font-bold border transition-all ${requestMinutes === mins ? "bg-blue-600 text-white border-blue-500" : "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700"}`,
									children: [
										"+",
										mins,
										" mins"
									]
								}, mins, true, {
									fileName: _jsxFileName,
									lineNumber: 781,
									columnNumber: 23
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 779,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 775,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-xs font-semibold text-slate-300 block mb-1.5",
								children: "What are you working on?"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 798,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: requestReason,
								onChange: (e) => setRequestReason(e.target.value),
								required: true,
								placeholder: "e.g. Science project, Reading, Math...",
								className: "w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 801,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 797,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow-md transition-colors",
								children: "Send Request to Parents"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 811,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 774,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 752,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 751,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 314,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsV0FBVyxjQUFjO0FBQ25ELFNBQ0UsUUFDQSxlQUNBLFNBQ0EsaUJBQ0EsT0FFQSxNQUdBLFNBQ0EsV0FDQSxNQUNBLFFBQ0EsU0FFQSxjQUNBLEdBQ0EsY0FDQSxlQUNBLGdCQUtLO0FBR1AsU0FDRSxZQUNBLHNCQUNBLHNCQUNBLHNCQUNBLG9CQUNBLG1CQUNLO0FBQ1AsU0FBUyxjQUFxQywrQkFBK0I7QUFDN0UsU0FBUyxpQkFBaUIsMEJBQTBCO0FBQ3BELFNBQVMsc0JBQXNCOzs7QUFRL0IsT0FBTyxNQUFNLGlCQUErQyxFQUMxRCxPQUNBLGlCQUNBLGdCQUNJOztDQUVKLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQXdCLElBQUk7Q0FDcEUsTUFBTSxpQkFBaUIsT0FBNEIsSUFBSTs7Q0FHdkQsTUFBTSxDQUFDLHNCQUFzQiwyQkFBMkIsU0FBUyxLQUFLO0NBQ3RFLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsRUFBRTtDQUN2RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyw2QkFBNkI7Q0FDaEYsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLOztDQUc1RCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQWdELElBQUk7Q0FDeEcsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBa0QsSUFBSTs7Q0FHbEcsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEtBQUs7O0NBRzlDLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsS0FBSztDQUMxRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBcUMsSUFBSTtDQUMzRSxNQUFNLHVCQUF1QixPQUEyQixJQUFJO0NBQzVELE1BQU0sZ0JBQWdCLE9BQXlCLElBQUk7O0NBR25ELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTO0VBQ2pELEtBQUssTUFBTSxTQUFTO0VBQ3BCLEtBQUssTUFBTSxTQUFTO0NBQ3RCLENBQUM7O0NBR0QsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsTUFBTSxZQUFZO0NBQ25FLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLE1BQU0sVUFBVTtDQUU3RCxnQkFBZ0I7RUFDZCxJQUFJLGdCQUFnQixXQUFXO0dBQzdCLElBQUk7SUFDRixBQUFDLFVBQWtCLFdBQVcsQ0FBQyxDQUFDLE1BQU0sWUFBaUI7S0FDckQsSUFBSSxDQUFDLFNBQVM7S0FDZCxnQkFBZ0IsS0FBSyxNQUFNLFFBQVEsUUFBUSxHQUFHLENBQUM7S0FDL0MsY0FBYyxRQUFRLFFBQVE7S0FDOUIsUUFBUSxpQkFBaUIscUJBQXFCO01BQzVDLGdCQUFnQixLQUFLLE1BQU0sUUFBUSxRQUFRLEdBQUcsQ0FBQztLQUNqRCxDQUFDO0tBQ0QsUUFBUSxpQkFBaUIsd0JBQXdCO01BQy9DLGNBQWMsUUFBUSxRQUFRO0tBQ2hDLENBQUM7SUFDSCxDQUFDLENBQUMsQ0FBQyxZQUFZOztJQUVmLENBQUM7R0FDSCxRQUFRLENBRVI7RUFDRjs7RUFHQSxJQUFJLFVBQVUsYUFBYTtHQUN6QixVQUFVLFlBQVksbUJBQ3BCLE9BQU8sUUFBUTtJQUNiLE1BQU0sTUFBTSxJQUFJLE9BQU87SUFDdkIsTUFBTSxNQUFNLElBQUksT0FBTztJQUN2QixpQkFBaUI7S0FBRTtLQUFLO0lBQUksQ0FBQztJQUM3QixNQUFNLFVBQVUsTUFBTSxlQUFlLEtBQUssR0FBRztJQUM3QyxtQkFBbUIsTUFBTSxJQUFJO0tBQzNCO0tBQ0E7S0FDQSxVQUFVO01BQ1IsVUFBVTtNQUNWLFdBQVc7TUFDWCxVQUFVLElBQUksT0FBTztNQUNyQixPQUFPLElBQUksT0FBTztNQUNsQjtLQUNGO0lBQ0YsQ0FBQztHQUNILFNBQ007O0dBRU4sR0FDQTtJQUFFLG9CQUFvQjtJQUFNLFNBQVM7R0FBSyxDQUM1QztFQUNGO0NBQ0YsR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDOztDQUdiLGdCQUFnQjtFQUNkLE1BQU0sUUFBUSxrQkFBa0I7R0FDOUIsbUJBQW1CLE1BQU0sSUFBSTtJQUMzQjtJQUNBO0dBQ0YsQ0FBQztHQUNELFVBQVU7RUFDWixHQUFHLElBQUs7RUFDUixhQUFhLGNBQWMsS0FBSztDQUNsQyxHQUFHO0VBQUMsTUFBTTtFQUFJO0VBQWM7RUFBWTtDQUFTLENBQUM7O0NBR2xELE1BQU0sZ0JBQWdCLE1BQU0sZ0JBQWdCO0NBQzVDLE1BQU0sZ0JBQWdCLE1BQU0sZ0JBQWdCO0NBRTVDLGdCQUFnQjtFQUNkLElBQUksaUJBQWlCLGNBQWMsV0FBVyxXQUFXO0dBQ3ZELHdCQUF3QjtFQUMxQjtFQUNBLElBQUksaUJBQWlCLGNBQWMsV0FBVyxXQUFXO0dBQ3ZELHdCQUF3QjtFQUMxQjtDQUNGLEdBQUcsQ0FBQyxlQUFlLFFBQVEsZUFBZSxNQUFNLENBQUM7O0NBR2pELE1BQU0sbUJBQW1CLFlBQVk7RUFDbkMsYUFBYSxJQUFJO0VBQ2pCLE1BQU0sU0FBUyxhQUFhLENBQUM7RUFDN0IsZUFBZSxVQUFVOztFQUd6QixNQUFNLFdBQVcsTUFBTSxJQUFJLGNBQWMsS0FBSyxjQUFjLEdBQUc7RUFDL0QsVUFBVTtDQUNaO0NBRUEsTUFBTSx3QkFBd0I7RUFDNUIsSUFBSSxlQUFlLFNBQVM7R0FDMUIsZUFBZSxRQUFRO0dBQ3ZCLGVBQWUsVUFBVTtFQUMzQjtFQUNBLGFBQWEsS0FBSztDQUNwQjs7Q0FHQSxNQUFNLHlCQUF5QixjQUFzQjtFQUNuRCxrQkFBa0IsSUFBSTtFQUN0QixJQUFJLFNBQVMsVUFBVSxLQUFLO0VBQzVCLElBQUksQ0FBQyxRQUFRO0VBRWIsSUFBSSxDQUFDLE9BQU8sV0FBVyxTQUFTLEtBQUssQ0FBQyxPQUFPLFdBQVcsVUFBVSxHQUFHO0dBQ25FLFNBQVMsYUFBYTtFQUN4Qjs7RUFHQSxNQUFNLFNBQVMsZ0JBQ2IsUUFDQSxNQUFNLFVBQVUsbUJBQ2hCLE1BQU0sVUFBVSxnQkFDaEIsTUFBTSxVQUFVLGNBQ2xCO0VBRUEsSUFBSSxDQUFDLE9BQU8sU0FBUztHQUNuQixrQkFBa0I7SUFBRSxLQUFLO0lBQVEsUUFBUSxPQUFPO0dBQWMsQ0FBQztHQUMvRCxzQkFBc0IsSUFBSTs7R0FFMUIsbUJBQW1CLE1BQU0sSUFBSSxDQUFDLENBQUM7R0FDL0I7RUFDRjs7RUFHQSxJQUFJLFFBQVE7RUFDWixJQUFJO0dBQ0YsUUFBUSxJQUFJLElBQUksTUFBTSxDQUFDLENBQUM7RUFDMUIsUUFBUSxDQUFDO0VBQ1Qsc0JBQXNCO0dBQUUsS0FBSztHQUFRO0VBQU0sQ0FBQztFQUM1QyxjQUFjLE1BQU07Q0FDdEI7O0NBR0EsTUFBTSxxQkFBcUIsWUFBWTtFQUNyQyxJQUFJO0dBQ0YsTUFBTSxTQUFTLGVBQWUsY0FBYztHQUM1QyxNQUFNLFNBQVMsTUFBTSxVQUFVLGFBQWEsYUFBYTtJQUN2RCxPQUFPLEVBQUUsWUFBWSxPQUFPO0lBQzVCLE9BQU87R0FDVCxDQUFDO0dBQ0QscUJBQXFCLFVBQVU7R0FDL0Isa0JBQWtCLElBQUk7R0FDdEIsYUFBYSxRQUFRO0dBQ3JCLElBQUksY0FBYyxTQUFTO0lBQ3pCLGNBQWMsUUFBUSxZQUFZO0dBQ3BDO0dBQ0EsTUFBTSxxQkFBcUIsTUFBTSxJQUFJLFVBQVU7R0FDL0MsVUFBVTtFQUNaLFNBQVMsR0FBUTtHQUNmLE1BQU0sMERBQTBELEVBQUUsT0FBTztHQUN6RSxNQUFNLHFCQUFxQixNQUFNLElBQUksUUFBUTtFQUMvQztDQUNGO0NBRUEsTUFBTSxzQkFBc0IsWUFBWTtFQUN0QyxNQUFNLHFCQUFxQixNQUFNLElBQUksUUFBUTtFQUM3QyxVQUFVO0NBQ1o7O0NBR0EsTUFBTSxxQkFBcUIsWUFBWTtFQUNyQyxJQUFJO0dBQ0YsSUFBSSxDQUFDLFVBQVUsYUFBYSxpQkFBaUI7SUFDM0MsTUFBTSx5REFBeUQ7SUFDL0QsTUFBTSxxQkFBcUIsTUFBTSxJQUFJLFFBQVE7SUFDN0M7R0FDRjtHQUNBLE1BQU0sU0FBUyxNQUFNLFVBQVUsYUFBYSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUssQ0FBQztHQUMzRSxPQUFPLGVBQWUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0I7SUFDekMsa0JBQWtCO0dBQ3BCO0dBQ0EscUJBQXFCLFVBQVU7R0FDL0Isa0JBQWtCLElBQUk7R0FDdEIsYUFBYSxRQUFRO0dBQ3JCLElBQUksY0FBYyxTQUFTO0lBQ3pCLGNBQWMsUUFBUSxZQUFZO0dBQ3BDO0dBQ0EsTUFBTSxxQkFBcUIsTUFBTSxJQUFJLFVBQVU7R0FDL0MsVUFBVTtFQUNaLFNBQVMsR0FBUTtHQUNmLE1BQU0scUJBQXFCLE1BQU0sSUFBSSxRQUFRO0VBQy9DO0NBQ0Y7Q0FFQSxNQUFNLHNCQUFzQixZQUFZO0VBQ3RDLE1BQU0scUJBQXFCLE1BQU0sSUFBSSxRQUFRO0VBQzdDLFVBQVU7Q0FDWjtDQUVBLE1BQU0sb0JBQW9CLFlBQVk7RUFDcEMsSUFBSSxxQkFBcUIsU0FBUztHQUNoQyxxQkFBcUIsUUFBUSxVQUFVLENBQUMsQ0FBQyxTQUFTLE1BQU0sRUFBRSxLQUFLLENBQUM7R0FDaEUscUJBQXFCLFVBQVU7RUFDakM7RUFDQSxrQkFBa0IsS0FBSztFQUN2QixJQUFJLGNBQWMsVUFBVTtHQUMxQixNQUFNLHFCQUFxQixNQUFNLElBQUksT0FBTztFQUM5QyxPQUFPO0dBQ0wsTUFBTSxxQkFBcUIsTUFBTSxJQUFJLE9BQU87RUFDOUM7RUFDQSxhQUFhLElBQUk7RUFDakIsVUFBVTtDQUNaOztDQUdBLE1BQU0sMEJBQTBCLE9BQU8sTUFBdUI7RUFDNUQsRUFBRSxlQUFlO0VBQ2pCLE1BQU0scUJBQXFCLE1BQU0sSUFBSSxnQkFBZ0IsYUFBYTtFQUNsRSxtQkFBbUIsSUFBSTtFQUN2QixpQkFBaUI7R0FDZixtQkFBbUIsS0FBSztHQUN4Qix3QkFBd0IsS0FBSztFQUMvQixHQUFHLEdBQUk7RUFDUCxVQUFVO0NBQ1o7O0NBR0EsTUFBTSxpQkFBaUIsWUFBWTtFQUNqQyxJQUFJLENBQUMsU0FBUyxLQUFLLEdBQUc7RUFDdEIsTUFBTSxZQUFZLE1BQU0sSUFBSSxTQUFTLFNBQVMsS0FBSyxDQUFDO0VBQ3BELFlBQVksRUFBRTtFQUNkLFlBQVksSUFBSTtFQUNoQixpQkFBaUIsWUFBWSxLQUFLLEdBQUcsR0FBSTtFQUN6QyxVQUFVO0NBQ1o7Q0FFQSxNQUFNLG1CQUFtQixLQUFLLElBQUksR0FBRyxNQUFNLFdBQVcsb0JBQW9CLE1BQU0sV0FBVyxpQkFBaUI7Q0FFNUcsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osTUFBTTtLQUNKOzs7O2VBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQW9ELE1BQU0sTUFBSyxVQUFtQjs7Ozs7Z0JBQ2xGLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUE4RztNQUV4SDs7OztjQUNIOzs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRCxZQUFPLE1BQU0sWUFBa0I7Ozs7O09BQy9CLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztPQUNiLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQjtTQUNHLGFBQ0Msd0JBQUMsaUJBQUQsRUFBaUIsV0FBVSwyQkFBNEI7Ozs7b0JBRXZELHdCQUFDLFNBQUQsRUFBUyxXQUFVLHlCQUEwQjs7Ozs7U0FFOUM7U0FBYTtRQUNWOzs7Ozs7TUFDSDs7Ozs7YUFDRjs7OzthQUNGOzs7OztjQUdMLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtlQUZaLENBSUUsd0JBQUMsTUFBRCxFQUFNLFdBQVUsNEJBQTZCOzs7O2VBQUMsY0FDeEM7Ozs7O1lBQ0Y7Ozs7OztHQUdQLGtCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsb0NBQTBDOzs7O2VBQzFELHdCQUFDLFFBQUQ7TUFBTTtNQUNFLGNBQWMsV0FBVyxXQUFXO01BQVM7S0FDL0M7Ozs7YUFDSDs7Ozs7Y0FDTCx3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFdBQVU7ZUFDWDtJQUVPOzs7O1lBQ0w7Ozs7OztHQUlQLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWhCO0tBRUUsd0JBQUMsV0FBRDtNQUFTLFdBQVcscURBQ2xCLFlBQ0ksZ0ZBQ0E7Z0JBRUgsWUFDQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLGVBQUQsRUFBZSxXQUFVLHFCQUFzQjs7Ozs7UUFDNUM7Ozs7O1FBQ0wsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWtEO1FBRTVEOzs7OztRQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF3QjtRQUVsQzs7Ozs7UUFDSCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFVBQUQ7VUFDRSxTQUFTO1VBQ1QsV0FBVTtvQkFDWDtTQUVPOzs7O21CQUNSLHdCQUFDLEtBQUQ7VUFDRSxNQUFLO1VBQ0wsV0FBVTtvQkFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGNBQWU7Ozs7b0JBQUMsdUJBQ3BDOzs7OztpQkFDQTs7Ozs7O09BQ0Y7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7O21CQUFDLHVCQUMzQjs7Ozs7O1FBQ0wsd0JBQUMsVUFBRDtTQUNFLFNBQVM7U0FDVCxXQUFVO21CQUZaLENBSUUsd0JBQUMsZUFBRCxFQUFlLFdBQVUsMEJBQTJCOzs7O21CQUFDLHdCQUMvQzs7Ozs7O1FBQ1Isd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTZCO1FBRXZDOzs7OztPQUNBOzs7Ozs7S0FFQTs7Ozs7S0FHVCx3QkFBQyxXQUFEO01BQVMsV0FBVTtnQkFBbkIsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ2Isd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7Ozs7UUFDekI7Ozs7a0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFtQztRQUFxQjs7OztrQkFDdEUsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1YsbUJBQW1CLElBQUksR0FBRyxpQkFBaUIsc0JBQXNCO1FBQ2pFOzs7O2dCQUNBOzs7O2dCQUNGOzs7OztpQkFFTCx3QkFBQyxVQUFEO1FBQ0UsZUFBZSx3QkFBd0IsSUFBSTtRQUMzQyxXQUFVO2tCQUZaLENBSUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsOEJBQStCOzs7O2tCQUFDLGVBQzlDOzs7OztlQUNMOzs7OztnQkFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLE9BQUQ7U0FDRSxXQUFXLHNDQUNULG9CQUFvQixLQUFLLGlCQUFpQjtTQUU1QyxPQUFPLEVBQ0wsT0FBTyxHQUFHLEtBQUssSUFBSSxLQUFNLE1BQU0sV0FBVyxvQkFBb0IsS0FBSyxJQUFJLEdBQUcsTUFBTSxXQUFXLGlCQUFpQixJQUFLLEdBQUcsRUFBRSxHQUN4SDtRQUNEOzs7OztPQUNFOzs7O2lCQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNO1NBQU8sTUFBTSxXQUFXO1NBQWtCO1FBQU87Ozs7a0JBQ3ZELHdCQUFDLFFBQUQ7U0FBTTtTQUFRLE1BQU0sV0FBVztTQUFrQjtRQUFPOzs7O2dCQUNyRDs7Ozs7ZUFDRjs7Ozs7Y0FDRTs7Ozs7O0tBR1Qsd0JBQUMsV0FBRDtNQUFTLFdBQVU7Z0JBQW5CO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7O1NBQzNCOzs7O21CQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBbUM7U0FBcUI7Ozs7bUJBQ3RFLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUE2QjtTQUE2Qjs7OztpQkFDcEU7Ozs7aUJBQ0Y7Ozs7O2tCQUNMLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUE4RztRQUV4SDs7OztnQkFDSDs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE9BQU87U0FDUCxXQUFXLE1BQU0sY0FBYyxFQUFFLE9BQU8sS0FBSztTQUM3QyxZQUFZLE1BQU0sRUFBRSxRQUFRLFdBQVcsc0JBQXNCLFVBQVU7U0FDdkUsYUFBWTtTQUNaLFdBQVU7UUFDWDs7OztrQkFDRCx3QkFBQyxVQUFEO1NBQ0UsZUFBZSxzQkFBc0IsVUFBVTtTQUMvQyxXQUFVO21CQUNYO1FBRU87Ozs7Z0JBQ0w7Ozs7OztPQUdKLGtCQUNDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSx3QkFBeUI7Ozs7b0JBQ3pDLHdCQUFDLFFBQUQsWUFBTSxxQ0FBd0M7Ozs7a0JBQzNDOzs7Ozs7U0FDTCx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFDVixlQUFlLFVBQVU7U0FDekI7Ozs7O1NBQ0gsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1dBQ0UsU0FBUyxZQUFZO1lBQ25CLE1BQU0sWUFBWSxNQUFNLElBQUksU0FBUyxvQ0FBb0MsZUFBZSxJQUFJLDJCQUEyQjtZQUN2SCxNQUFNLDBCQUEwQjtZQUNoQyxrQkFBa0IsSUFBSTtXQUN4QjtXQUNBLFdBQVU7cUJBQ1g7VUFFTzs7OztvQkFDUix3QkFBQyxVQUFEO1dBQ0UsZUFBZSxrQkFBa0IsSUFBSTtXQUNyQyxXQUFVO3FCQUNYO1VBRU87Ozs7a0JBQ0w7Ozs7OztRQUNGOzs7Ozs7T0FJTixzQkFBc0IsQ0FBQyxrQkFDdEIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUFnRixPQUMxRSxtQkFBbUIsR0FDbkI7Ozs7O21CQUNOLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsS0FBRDtXQUNFLE1BQU0sbUJBQW1CO1dBQ3pCLFFBQU87V0FDUCxLQUFJO1dBQ0osV0FBVTtxQkFKWixDQUtDLFNBQ00sd0JBQUMsY0FBRCxFQUFjLFdBQVUsVUFBVzs7OzttQkFDdkM7Ozs7O29CQUNILHdCQUFDLFVBQUQ7V0FDRSxlQUFlLHNCQUFzQixJQUFJO1dBQ3pDLFdBQVU7cUJBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsY0FBZTs7Ozs7VUFDdEI7Ozs7a0JBQ0w7Ozs7O2lCQUNGOzs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiLENBQXNDLHdCQUNoQix3QkFBQyxVQUFELFlBQVMsbUJBQW1CLE1BQWM7Ozs7a0JBQzdEOzs7OzttQkFDSCx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBNkI7U0FFdkM7Ozs7aUJBQ0E7Ozs7O2dCQUNGOzs7Ozs7T0FJUCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXNEO09BRWhFOzs7O2lCQUNOLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLG1CQUFtQixNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUNuQyx3QkFBQyxVQUFEO1NBRUUsZUFBZSxzQkFBc0IsS0FBSyxHQUFHO1NBQzdDLFdBQVU7bUJBSFo7VUFLRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBd0IsS0FBSztVQUFXOzs7OztVQUN4RCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYixLQUFLO1VBQ0Y7Ozs7O1VBQ04sd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ2IsS0FBSztVQUNGOzs7OztTQUNBO1dBWEQsS0FBSzs7OztlQVdKLENBQ1Q7T0FDRTs7OztlQUNGOzs7OztNQUNFOzs7Ozs7S0FHVCx3QkFBQyxXQUFEO01BQVMsV0FBVTtnQkFBbkI7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsZUFBRCxFQUFlLFdBQVUsVUFBVzs7Ozs7U0FDakM7Ozs7bUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFtQztTQUFtQjs7OzttQkFDcEUsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQTZCO1NBQWtDOzs7O2lCQUN6RTs7OztpQkFDRjs7Ozs7a0JBQ0osWUFDQyx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSxjQUFlOzs7O21CQUFDLFFBQ3BDOzs7OztnQkFFTDs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1o7U0FBQztTQUF3QjtTQUF3QjtTQUF3QjtRQUFtQixDQUFDLENBQUMsS0FBSyxXQUNsRyx3QkFBQyxVQUFEO1NBRUUsU0FBUyxZQUFZO1VBQ25CLE1BQU0sWUFBWSxNQUFNLElBQUksU0FBUyxNQUFNO1VBQzNDLFlBQVksSUFBSTtVQUNoQixpQkFBaUIsWUFBWSxLQUFLLEdBQUcsR0FBSTtVQUN6QyxVQUFVO1NBQ1o7U0FDQSxXQUFVO21CQUVUO1FBQ0ssR0FWRDs7OztlQVVDLENBQ1Q7T0FDRTs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsT0FBTztTQUNQLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxLQUFLO1NBQzNDLFlBQVksTUFBTSxFQUFFLFFBQVEsV0FBVyxlQUFlO1NBQ3RELGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7a0JBQ0Qsd0JBQUMsVUFBRDtTQUNFLFNBQVM7U0FDVCxXQUFVO21CQUVWLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGNBQWU7Ozs7O1FBQ3pCOzs7O2dCQUNMOzs7Ozs7TUFDRTs7Ozs7O0tBR1Qsd0JBQUMsV0FBRDtNQUFTLFdBQVU7Z0JBQW5CLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSw0QkFBNkI7Ozs7aUJBQzdDLHdCQUFDLFFBQUQsWUFBTSwwQ0FBNkM7Ozs7ZUFDaEQ7Ozs7O2dCQUNMLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUE2QjtNQUV2Qzs7OztjQUNJOzs7Ozs7S0FHVCx3QkFBQyxVQUFEO01BQVEsV0FBVTtnQkFDaEIsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWIsQ0FBMkIseUNBQ1ksd0JBQUMsVUFBRDtRQUFRLFdBQVU7a0JBQTJCO09BQXlCOzs7O2VBQzFHOzs7Ozs7S0FDRzs7Ozs7S0FHUix3QkFBQyxTQUFEO01BQU8sS0FBSztNQUFlO01BQVM7TUFBWTtNQUFNLFdBQVU7S0FBVTs7Ozs7SUFDdEU7Ozs7OztHQUdMLGlCQUFpQixjQUFjLFdBQVcsYUFDekMsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7Ozs7TUFDMUI7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUErQjtPQUF5Qjs7Ozs7T0FDdEUsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQThCO09BRXhDOzs7OztPQUNGLGNBQWMsVUFDYix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUFnRjtTQUN2RSxjQUFjO1NBQU87UUFDekI7Ozs7OztNQUVKOzs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFpRjtNQUUzRjs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQ7UUFDRSxTQUFTO1FBQ1QsV0FBVTtrQkFDWDtPQUVPOzs7O2lCQUNSLHdCQUFDLFVBQUQ7UUFDRSxTQUFTO1FBQ1QsV0FBVTtrQkFDWDtPQUVPOzs7O2VBQ0w7Ozs7OztLQUNGOzs7Ozs7R0FDRjs7Ozs7R0FJTixpQkFBaUIsY0FBYyxXQUFXLGFBQ3pDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7O01BQzNCOzs7OztNQUNMLHdCQUFDLE9BQUQ7T0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBK0I7T0FBMEI7Ozs7O09BQ3ZFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE4QjtPQUV4Qzs7Ozs7T0FDRixjQUFjLFVBQ2Isd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FBZ0Y7U0FDdkUsY0FBYztTQUFPO1FBQ3pCOzs7Ozs7TUFFSjs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBdUY7TUFFakc7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFdBQVU7a0JBQ1g7T0FFTzs7OztpQkFDUix3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFdBQVU7a0JBQ1g7T0FFTzs7OztlQUNMOzs7Ozs7S0FDRjs7Ozs7O0dBQ0Y7Ozs7O0dBSU4sd0JBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDBCQUEyQjs7OztpQkFBQyxzQkFDOUM7Ozs7O2dCQUNKLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLHdCQUF3QixLQUFLO09BQzVDLFdBQVU7aUJBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7TUFDbEI7Ozs7Y0FDTDs7Ozs7ZUFFSixrQkFDQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLHFDQUFzQzs7Ozs7T0FDOUQsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXVCO09BQTRCOzs7OztPQUNqRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBeUI7T0FFbkM7Ozs7O01BQ0E7Ozs7O2dCQUVMLHdCQUFDLFFBQUQ7TUFBTSxVQUFVO01BQXlCLFdBQVU7Z0JBQW5EO09BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFrRDtPQUU1RDs7OztpQkFDUCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWjtTQUFDO1NBQUk7U0FBSTtRQUFFLENBQUMsQ0FBQyxLQUFLLFNBQ2pCLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBRUwsZUFBZSxrQkFBa0IsSUFBSTtTQUNyQyxXQUFXLDJEQUNULG1CQUFtQixPQUNmLDJDQUNBO21CQVBSO1VBU0M7VUFDRztVQUFLO1NBQ0Q7V0FURDs7OztlQVNDLENBQ1Q7T0FDRTs7OztlQUNGOzs7OztPQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBb0Q7T0FFOUQ7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztRQUNoRDtRQUNBLGFBQVk7UUFDWixXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7T0FFTCx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLFdBQVU7a0JBQ1g7T0FFTzs7Ozs7TUFDSjs7Ozs7YUFFTDs7Ozs7O0dBQ0Y7Ozs7O0VBRUo7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNoaWxkTW9kZVZpZXcudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgU2hpZWxkLCBcbiAgQWxlcnRUcmlhbmdsZSwgXG4gIEJhdHRlcnksIFxuICBCYXR0ZXJ5Q2hhcmdpbmcsIFxuICBDbG9jaywgXG4gIE1vb24sIFxuICBMb2NrLCBcbiAgVW5sb2NrLCBcbiAgR2xvYmUsIFxuICBDb21wYXNzLCBcbiAgUGhvbmVDYWxsLCBcbiAgU2VuZCwgXG4gIENhbWVyYSwgXG4gIE1vbml0b3IsIFxuICBWb2x1bWUyLCBcbiAgQ2hlY2tDaXJjbGUyLCBcbiAgWCxcbiAgRXh0ZXJuYWxMaW5rLFxuICBNZXNzYWdlU3F1YXJlLFxuICBTcGFya2xlcyxcbiAgQm9va09wZW4sXG4gIEdyYWR1YXRpb25DYXAsXG4gIFlvdXR1YmUsXG4gIEdhbWVwYWQyXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgY29uZmV0dGkgZnJvbSAnY2FudmFzLWNvbmZldHRpJztcbmltcG9ydCB7IENoaWxkRGV2aWNlLCBBbGVydEl0ZW0gfSBmcm9tICcuLi90eXBlcy9zYWZla2lkcyc7XG5pbXBvcnQgeyBcbiAgdHJpZ2dlclNPUywgXG4gIHJlcXVlc3RUaW1lRXh0ZW5zaW9uLCBcbiAgcmVzcG9uZENhbWVyYVJlcXVlc3QsIFxuICByZXNwb25kU2NyZWVuUmVxdWVzdCwgXG4gIHNlbmRDaGlsZEhlYXJ0YmVhdCxcbiAgc2VuZE1lc3NhZ2UgXG59IGZyb20gJy4uL3NlcnZpY2VzL2FwaSc7XG5pbXBvcnQgeyBwbGF5U09TU2lyZW4sIHBsYXlOb3RpZmljYXRpb25DaGltZSwgcGxheVJlcXVlc3RJbmNvbWluZ0JlbGwgfSBmcm9tICcuLi91dGlscy9hdWRpbyc7XG5pbXBvcnQgeyBjaGVja1VybEFsbG93ZWQsIENVUkFURURfU0FGRV9TSVRFUyB9IGZyb20gJy4uL3V0aWxzL3dlYmZpbHRlcic7XG5pbXBvcnQgeyByZXZlcnNlR2VvY29kZSB9IGZyb20gJy4uL3V0aWxzL2dlb2ZlbmNlJztcblxuaW50ZXJmYWNlIENoaWxkTW9kZVZpZXdQcm9wcyB7XG4gIGNoaWxkOiBDaGlsZERldmljZTtcbiAgb25FeGl0Q2hpbGRNb2RlOiAoKSA9PiB2b2lkO1xuICBvblJlZnJlc2g6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBDaGlsZE1vZGVWaWV3OiBSZWFjdC5GQzxDaGlsZE1vZGVWaWV3UHJvcHM+ID0gKHtcbiAgY2hpbGQsXG4gIG9uRXhpdENoaWxkTW9kZSxcbiAgb25SZWZyZXNoLFxufSkgPT4ge1xuICAvLyBTT1MgU3RhdGVcbiAgY29uc3QgW3Nvc0FjdGl2ZSwgc2V0U29zQWN0aXZlXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Nvc0NvdW50ZG93biwgc2V0U29zQ291bnRkb3duXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBzaXJlblN0b3BGblJlZiA9IHVzZVJlZjwoKCkgPT4gdm9pZCkgfCBudWxsPihudWxsKTtcblxuICAvLyBUaW1lIFJlcXVlc3QgTW9kYWxcbiAgY29uc3QgW3Nob3dUaW1lUmVxdWVzdE1vZGFsLCBzZXRTaG93VGltZVJlcXVlc3RNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtyZXF1ZXN0TWludXRlcywgc2V0UmVxdWVzdE1pbnV0ZXNdID0gdXNlU3RhdGUoMzApO1xuICBjb25zdCBbcmVxdWVzdFJlYXNvbiwgc2V0UmVxdWVzdFJlYXNvbl0gPSB1c2VTdGF0ZSgnRmluaXNoaW5nIHNjaG9vbCBhc3NpZ25tZW50Jyk7XG4gIGNvbnN0IFt0aW1lUmVxdWVzdFNlbnQsIHNldFRpbWVSZXF1ZXN0U2VudF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgLy8gU2FmZSBCcm93c2VyIFN0YXRlXG4gIGNvbnN0IFticm93c2VyVXJsLCBzZXRCcm93c2VyVXJsXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2N1cnJlbnRCcm93c2VyUGFnZSwgc2V0Q3VycmVudEJyb3dzZXJQYWdlXSA9IHVzZVN0YXRlPHsgdXJsOiBzdHJpbmc7IHRpdGxlOiBzdHJpbmcgfSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbYmxvY2tlZEF0dGVtcHQsIHNldEJsb2NrZWRBdHRlbXB0XSA9IHVzZVN0YXRlPHsgdXJsOiBzdHJpbmc7IHJlYXNvbj86IHN0cmluZyB9IHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gQ2hhdCBtZXNzYWdlIHRvIHBhcmVudFxuICBjb25zdCBbcXVpY2tNc2csIHNldFF1aWNrTXNnXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2NoYXRTZW50LCBzZXRDaGF0U2VudF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgLy8gQ2FtZXJhIC8gU2NyZWVuIFNoYXJpbmcgU3RyZWFtXG4gIGNvbnN0IFtpc1NoYXJpbmdNZWRpYSwgc2V0SXNTaGFyaW5nTWVkaWFdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbbWVkaWFUeXBlLCBzZXRNZWRpYVR5cGVdID0gdXNlU3RhdGU8J2NhbWVyYScgfCAnc2NyZWVuJyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBhY3RpdmVNZWRpYVN0cmVhbVJlZiA9IHVzZVJlZjxNZWRpYVN0cmVhbSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBjaGlsZFZpZGVvUmVmID0gdXNlUmVmPEhUTUxWaWRlb0VsZW1lbnQ+KG51bGwpO1xuXG4gIC8vIFNpbXVsYXRlZCBHUFMgcG9zaXRpb25cbiAgY29uc3QgW2N1cnJlbnRDb29yZHMsIHNldEN1cnJlbnRDb29yZHNdID0gdXNlU3RhdGUoe1xuICAgIGxhdDogY2hpbGQubG9jYXRpb24ubGF0aXR1ZGUsXG4gICAgbG5nOiBjaGlsZC5sb2NhdGlvbi5sb25naXR1ZGUsXG4gIH0pO1xuXG4gIC8vIFRyYWNrIGJhdHRlcnkgdXNpbmcgbmF2aWdhdG9yLmdldEJhdHRlcnkgaWYgc3VwcG9ydGVkXG4gIGNvbnN0IFtiYXR0ZXJ5TGV2ZWwsIHNldEJhdHRlcnlMZXZlbF0gPSB1c2VTdGF0ZShjaGlsZC5iYXR0ZXJ5TGV2ZWwpO1xuICBjb25zdCBbaXNDaGFyZ2luZywgc2V0SXNDaGFyZ2luZ10gPSB1c2VTdGF0ZShjaGlsZC5pc0NoYXJnaW5nKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICgnZ2V0QmF0dGVyeScgaW4gbmF2aWdhdG9yKSB7XG4gICAgICB0cnkge1xuICAgICAgICAobmF2aWdhdG9yIGFzIGFueSkuZ2V0QmF0dGVyeSgpLnRoZW4oKGJhdHRlcnk6IGFueSkgPT4ge1xuICAgICAgICAgIGlmICghYmF0dGVyeSkgcmV0dXJuO1xuICAgICAgICAgIHNldEJhdHRlcnlMZXZlbChNYXRoLnJvdW5kKGJhdHRlcnkubGV2ZWwgKiAxMDApKTtcbiAgICAgICAgICBzZXRJc0NoYXJnaW5nKGJhdHRlcnkuY2hhcmdpbmcpO1xuICAgICAgICAgIGJhdHRlcnkuYWRkRXZlbnRMaXN0ZW5lcignbGV2ZWxjaGFuZ2UnLCAoKSA9PiB7XG4gICAgICAgICAgICBzZXRCYXR0ZXJ5TGV2ZWwoTWF0aC5yb3VuZChiYXR0ZXJ5LmxldmVsICogMTAwKSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgYmF0dGVyeS5hZGRFdmVudExpc3RlbmVyKCdjaGFyZ2luZ2NoYW5nZScsICgpID0+IHtcbiAgICAgICAgICAgIHNldElzQ2hhcmdpbmcoYmF0dGVyeS5jaGFyZ2luZyk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICAvLyBiYXR0ZXJ5IGFwaSByZXN0cmljdGVkIGluIGlmcmFtZVxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBpZ25vcmVcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBUcnkgcmVhbCBnZW9sb2NhdGlvblxuICAgIGlmIChuYXZpZ2F0b3IuZ2VvbG9jYXRpb24pIHtcbiAgICAgIG5hdmlnYXRvci5nZW9sb2NhdGlvbi5nZXRDdXJyZW50UG9zaXRpb24oXG4gICAgICAgIGFzeW5jIChwb3MpID0+IHtcbiAgICAgICAgICBjb25zdCBsYXQgPSBwb3MuY29vcmRzLmxhdGl0dWRlO1xuICAgICAgICAgIGNvbnN0IGxuZyA9IHBvcy5jb29yZHMubG9uZ2l0dWRlO1xuICAgICAgICAgIHNldEN1cnJlbnRDb29yZHMoeyBsYXQsIGxuZyB9KTtcbiAgICAgICAgICBjb25zdCBhZGRyZXNzID0gYXdhaXQgcmV2ZXJzZUdlb2NvZGUobGF0LCBsbmcpO1xuICAgICAgICAgIHNlbmRDaGlsZEhlYXJ0YmVhdChjaGlsZC5pZCwge1xuICAgICAgICAgICAgYmF0dGVyeUxldmVsLFxuICAgICAgICAgICAgaXNDaGFyZ2luZyxcbiAgICAgICAgICAgIGxvY2F0aW9uOiB7XG4gICAgICAgICAgICAgIGxhdGl0dWRlOiBsYXQsXG4gICAgICAgICAgICAgIGxvbmdpdHVkZTogbG5nLFxuICAgICAgICAgICAgICBhY2N1cmFjeTogcG9zLmNvb3Jkcy5hY2N1cmFjeSxcbiAgICAgICAgICAgICAgc3BlZWQ6IHBvcy5jb29yZHMuc3BlZWQsXG4gICAgICAgICAgICAgIGFkZHJlc3MsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgICAoKSA9PiB7XG4gICAgICAgICAgLy8gaWdub3JlIG9yIGtlZXAgZGVmYXVsdFxuICAgICAgICB9LFxuICAgICAgICB7IGVuYWJsZUhpZ2hBY2N1cmFjeTogdHJ1ZSwgdGltZW91dDogNTAwMCB9XG4gICAgICApO1xuICAgIH1cbiAgfSwgW2NoaWxkLmlkXSk7XG5cbiAgLy8gUGVyaW9kaWMgaGVhcnRiZWF0IHN5bmMgdG8gc2VydmVyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgdGltZXIgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICBzZW5kQ2hpbGRIZWFydGJlYXQoY2hpbGQuaWQsIHtcbiAgICAgICAgYmF0dGVyeUxldmVsLFxuICAgICAgICBpc0NoYXJnaW5nLFxuICAgICAgfSk7XG4gICAgICBvblJlZnJlc2goKTtcbiAgICB9LCAxNTAwMCk7XG4gICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwodGltZXIpO1xuICB9LCBbY2hpbGQuaWQsIGJhdHRlcnlMZXZlbCwgaXNDaGFyZ2luZywgb25SZWZyZXNoXSk7XG5cbiAgLy8gQ2hlY2sgaW5jb21pbmcgY2FtZXJhIC8gc2NyZWVuIHJlcXVlc3RzIGZyb20gcGFyZW50XG4gIGNvbnN0IGNhbWVyYVJlcXVlc3QgPSBjaGlsZC5hY3RpdmVTZXNzaW9ucz8uY2FtZXJhUmVxdWVzdDtcbiAgY29uc3Qgc2NyZWVuUmVxdWVzdCA9IGNoaWxkLmFjdGl2ZVNlc3Npb25zPy5zY3JlZW5SZXF1ZXN0O1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGNhbWVyYVJlcXVlc3QgJiYgY2FtZXJhUmVxdWVzdC5zdGF0dXMgPT09ICdwZW5kaW5nJykge1xuICAgICAgcGxheVJlcXVlc3RJbmNvbWluZ0JlbGwoKTtcbiAgICB9XG4gICAgaWYgKHNjcmVlblJlcXVlc3QgJiYgc2NyZWVuUmVxdWVzdC5zdGF0dXMgPT09ICdwZW5kaW5nJykge1xuICAgICAgcGxheVJlcXVlc3RJbmNvbWluZ0JlbGwoKTtcbiAgICB9XG4gIH0sIFtjYW1lcmFSZXF1ZXN0Py5zdGF0dXMsIHNjcmVlblJlcXVlc3Q/LnN0YXR1c10pO1xuXG4gIC8vIFRyaWdnZXIgRW1lcmdlbmN5IFNPU1xuICBjb25zdCBoYW5kbGVUcmlnZ2VyU09TID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldFNvc0FjdGl2ZSh0cnVlKTtcbiAgICBjb25zdCBzdG9wRm4gPSBwbGF5U09TU2lyZW4oNik7XG4gICAgc2lyZW5TdG9wRm5SZWYuY3VycmVudCA9IHN0b3BGbjtcblxuICAgIC8vIFNlbmQgdG8gYmFja2VuZFxuICAgIGF3YWl0IHRyaWdnZXJTT1MoY2hpbGQuaWQsIGN1cnJlbnRDb29yZHMubGF0LCBjdXJyZW50Q29vcmRzLmxuZyk7XG4gICAgb25SZWZyZXNoKCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2FuY2VsU09TID0gKCkgPT4ge1xuICAgIGlmIChzaXJlblN0b3BGblJlZi5jdXJyZW50KSB7XG4gICAgICBzaXJlblN0b3BGblJlZi5jdXJyZW50KCk7XG4gICAgICBzaXJlblN0b3BGblJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgc2V0U29zQWN0aXZlKGZhbHNlKTtcbiAgfTtcblxuICAvLyBTYWZlIEJyb3dzZXIgTmF2aWdhdGVcbiAgY29uc3QgaGFuZGxlTmF2aWdhdGVCcm93c2VyID0gKHVybFRvT3Blbjogc3RyaW5nKSA9PiB7XG4gICAgc2V0QmxvY2tlZEF0dGVtcHQobnVsbCk7XG4gICAgbGV0IHRhcmdldCA9IHVybFRvT3Blbi50cmltKCk7XG4gICAgaWYgKCF0YXJnZXQpIHJldHVybjtcblxuICAgIGlmICghdGFyZ2V0LnN0YXJ0c1dpdGgoJ2h0dHA6Ly8nKSAmJiAhdGFyZ2V0LnN0YXJ0c1dpdGgoJ2h0dHBzOi8vJykpIHtcbiAgICAgIHRhcmdldCA9ICdodHRwczovLycgKyB0YXJnZXQ7XG4gICAgfVxuXG4gICAgLy8gRmlsdGVyIHZhbGlkYXRpb25cbiAgICBjb25zdCByZXN1bHQgPSBjaGVja1VybEFsbG93ZWQoXG4gICAgICB0YXJnZXQsXG4gICAgICBjaGlsZC53ZWJGaWx0ZXIuYmxvY2tlZENhdGVnb3JpZXMsXG4gICAgICBjaGlsZC53ZWJGaWx0ZXIuYmxvY2tlZERvbWFpbnMsXG4gICAgICBjaGlsZC53ZWJGaWx0ZXIuYWxsb3dlZERvbWFpbnNcbiAgICApO1xuXG4gICAgaWYgKCFyZXN1bHQuYWxsb3dlZCkge1xuICAgICAgc2V0QmxvY2tlZEF0dGVtcHQoeyB1cmw6IHRhcmdldCwgcmVhc29uOiByZXN1bHQuYmxvY2tlZFJlYXNvbiB9KTtcbiAgICAgIHNldEN1cnJlbnRCcm93c2VyUGFnZShudWxsKTtcbiAgICAgIC8vIExvZyBibG9ja2VkIGF0dGVtcHQgdG8gcGFyZW50XG4gICAgICBzZW5kQ2hpbGRIZWFydGJlYXQoY2hpbGQuaWQsIHt9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBBbGxvd2VkXG4gICAgbGV0IHRpdGxlID0gdGFyZ2V0O1xuICAgIHRyeSB7XG4gICAgICB0aXRsZSA9IG5ldyBVUkwodGFyZ2V0KS5ob3N0bmFtZTtcbiAgICB9IGNhdGNoIHt9XG4gICAgc2V0Q3VycmVudEJyb3dzZXJQYWdlKHsgdXJsOiB0YXJnZXQsIHRpdGxlIH0pO1xuICAgIHNldEJyb3dzZXJVcmwodGFyZ2V0KTtcbiAgfTtcblxuICAvLyBIYW5kbGUgUGFyZW50IENhbWVyYSBSZXF1ZXN0IEFjY2VwdFxuICBjb25zdCBoYW5kbGVBY2NlcHRDYW1lcmEgPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGZhY2luZyA9IGNhbWVyYVJlcXVlc3Q/LmZhY2luZ01vZGUgfHwgJ3VzZXInO1xuICAgICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgbmF2aWdhdG9yLm1lZGlhRGV2aWNlcy5nZXRVc2VyTWVkaWEoe1xuICAgICAgICB2aWRlbzogeyBmYWNpbmdNb2RlOiBmYWNpbmcgfSxcbiAgICAgICAgYXVkaW86IGZhbHNlLFxuICAgICAgfSk7XG4gICAgICBhY3RpdmVNZWRpYVN0cmVhbVJlZi5jdXJyZW50ID0gc3RyZWFtO1xuICAgICAgc2V0SXNTaGFyaW5nTWVkaWEodHJ1ZSk7XG4gICAgICBzZXRNZWRpYVR5cGUoJ2NhbWVyYScpO1xuICAgICAgaWYgKGNoaWxkVmlkZW9SZWYuY3VycmVudCkge1xuICAgICAgICBjaGlsZFZpZGVvUmVmLmN1cnJlbnQuc3JjT2JqZWN0ID0gc3RyZWFtO1xuICAgICAgfVxuICAgICAgYXdhaXQgcmVzcG9uZENhbWVyYVJlcXVlc3QoY2hpbGQuaWQsICdhY2NlcHRlZCcpO1xuICAgICAgb25SZWZyZXNoKCk7XG4gICAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgICBhbGVydCgnQ2FtZXJhIHBlcm1pc3Npb24gZGVuaWVkIG9yIGNhbWVyYSBkZXZpY2Ugbm90IGZvdW5kOiAnICsgZS5tZXNzYWdlKTtcbiAgICAgIGF3YWl0IHJlc3BvbmRDYW1lcmFSZXF1ZXN0KGNoaWxkLmlkLCAnZGVuaWVkJyk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURlY2xpbmVDYW1lcmEgPSBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgcmVzcG9uZENhbWVyYVJlcXVlc3QoY2hpbGQuaWQsICdkZW5pZWQnKTtcbiAgICBvblJlZnJlc2goKTtcbiAgfTtcblxuICAvLyBIYW5kbGUgUGFyZW50IFNjcmVlbiBTaGFyZSBSZXF1ZXN0IEFjY2VwdFxuICBjb25zdCBoYW5kbGVBY2NlcHRTY3JlZW4gPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGlmICghbmF2aWdhdG9yLm1lZGlhRGV2aWNlcy5nZXREaXNwbGF5TWVkaWEpIHtcbiAgICAgICAgYWxlcnQoJ1NjcmVlbiBzaGFyaW5nIGlzIG5vdCBzdXBwb3J0ZWQgb24gdGhpcyBkZXZpY2UvYnJvd3Nlci4nKTtcbiAgICAgICAgYXdhaXQgcmVzcG9uZFNjcmVlblJlcXVlc3QoY2hpbGQuaWQsICdkZW5pZWQnKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgbmF2aWdhdG9yLm1lZGlhRGV2aWNlcy5nZXREaXNwbGF5TWVkaWEoeyB2aWRlbzogdHJ1ZSB9KTtcbiAgICAgIHN0cmVhbS5nZXRWaWRlb1RyYWNrcygpWzBdLm9uZW5kZWQgPSAoKSA9PiB7XG4gICAgICAgIGhhbmRsZVN0b3BTaGFyaW5nKCk7XG4gICAgICB9O1xuICAgICAgYWN0aXZlTWVkaWFTdHJlYW1SZWYuY3VycmVudCA9IHN0cmVhbTtcbiAgICAgIHNldElzU2hhcmluZ01lZGlhKHRydWUpO1xuICAgICAgc2V0TWVkaWFUeXBlKCdzY3JlZW4nKTtcbiAgICAgIGlmIChjaGlsZFZpZGVvUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgY2hpbGRWaWRlb1JlZi5jdXJyZW50LnNyY09iamVjdCA9IHN0cmVhbTtcbiAgICAgIH1cbiAgICAgIGF3YWl0IHJlc3BvbmRTY3JlZW5SZXF1ZXN0KGNoaWxkLmlkLCAnYWNjZXB0ZWQnKTtcbiAgICAgIG9uUmVmcmVzaCgpO1xuICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgYXdhaXQgcmVzcG9uZFNjcmVlblJlcXVlc3QoY2hpbGQuaWQsICdkZW5pZWQnKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlRGVjbGluZVNjcmVlbiA9IGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCByZXNwb25kU2NyZWVuUmVxdWVzdChjaGlsZC5pZCwgJ2RlbmllZCcpO1xuICAgIG9uUmVmcmVzaCgpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVN0b3BTaGFyaW5nID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmIChhY3RpdmVNZWRpYVN0cmVhbVJlZi5jdXJyZW50KSB7XG4gICAgICBhY3RpdmVNZWRpYVN0cmVhbVJlZi5jdXJyZW50LmdldFRyYWNrcygpLmZvckVhY2goKHQpID0+IHQuc3RvcCgpKTtcbiAgICAgIGFjdGl2ZU1lZGlhU3RyZWFtUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH1cbiAgICBzZXRJc1NoYXJpbmdNZWRpYShmYWxzZSk7XG4gICAgaWYgKG1lZGlhVHlwZSA9PT0gJ2NhbWVyYScpIHtcbiAgICAgIGF3YWl0IHJlc3BvbmRDYW1lcmFSZXF1ZXN0KGNoaWxkLmlkLCAnZW5kZWQnKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgcmVzcG9uZFNjcmVlblJlcXVlc3QoY2hpbGQuaWQsICdlbmRlZCcpO1xuICAgIH1cbiAgICBzZXRNZWRpYVR5cGUobnVsbCk7XG4gICAgb25SZWZyZXNoKCk7XG4gIH07XG5cbiAgLy8gVGltZSBFeHRlbnNpb24gU3VibWlzc2lvblxuICBjb25zdCBoYW5kbGVTdWJtaXRUaW1lUmVxdWVzdCA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgYXdhaXQgcmVxdWVzdFRpbWVFeHRlbnNpb24oY2hpbGQuaWQsIHJlcXVlc3RNaW51dGVzLCByZXF1ZXN0UmVhc29uKTtcbiAgICBzZXRUaW1lUmVxdWVzdFNlbnQodHJ1ZSk7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzZXRUaW1lUmVxdWVzdFNlbnQoZmFsc2UpO1xuICAgICAgc2V0U2hvd1RpbWVSZXF1ZXN0TW9kYWwoZmFsc2UpO1xuICAgIH0sIDIwMDApO1xuICAgIG9uUmVmcmVzaCgpO1xuICB9O1xuXG4gIC8vIFNlbmQgbWVzc2FnZSB0byBwYXJlbnRcbiAgY29uc3QgaGFuZGxlU2VuZENoYXQgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFxdWlja01zZy50cmltKCkpIHJldHVybjtcbiAgICBhd2FpdCBzZW5kTWVzc2FnZShjaGlsZC5pZCwgJ2NoaWxkJywgcXVpY2tNc2cudHJpbSgpKTtcbiAgICBzZXRRdWlja01zZygnJyk7XG4gICAgc2V0Q2hhdFNlbnQodHJ1ZSk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRDaGF0U2VudChmYWxzZSksIDIwMDApO1xuICAgIG9uUmVmcmVzaCgpO1xuICB9O1xuXG4gIGNvbnN0IHJlbWFpbmluZ01pbnV0ZXMgPSBNYXRoLm1heCgwLCBjaGlsZC5zY3JlZW5UaW1lLmRhaWx5TGltaXRNaW51dGVzIC0gY2hpbGQuc2NyZWVuVGltZS50b2RheVVzYWdlTWludXRlcyk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1zbGF0ZS05MDAgdGV4dC13aGl0ZSBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBwYi0xMFwiPlxuICAgICAgey8qIFRvcCBDaGlsZCBEZXZpY2UgU3RhdHVzIEJhciAqL31cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwLzgwIGJhY2tkcm9wLWJsdXItbWQgcHgtNCBweS0zIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgc3RpY2t5IHRvcC0wIHotMzAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOSBoLTkgcm91bmRlZC1mdWxsIGJnLWJsdWUtNjAwIHRleHQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LW1kXCI+XG4gICAgICAgICAgICB7Y2hpbGQuYXZhdGFyfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc20gdHJhY2tpbmctdGlnaHRcIj57Y2hpbGQubmFtZX0mYXBvcztzIFBob25lPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBiZy1lbWVyYWxkLTUwMC8yMCB0ZXh0LWVtZXJhbGQtNDAwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvNDAgcHgtMS41IHB5LTAuNSByb3VuZGVkIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgIFNBRkVcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxzcGFuPntjaGlsZC5kZXZpY2VNb2RlbH08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuPuKAojwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICB7aXNDaGFyZ2luZyA/IChcbiAgICAgICAgICAgICAgICAgIDxCYXR0ZXJ5Q2hhcmdpbmcgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPEJhdHRlcnkgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LXNsYXRlLTMwMFwiIC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICB7YmF0dGVyeUxldmVsfSVcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBFeGl0IENoaWxkIE1vZGUgKFBhcmVudCBQSU4gUHJvdGVjdGVkKSAqL31cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e29uRXhpdENoaWxkTW9kZX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMzAwIHRleHQteHMgcm91bmRlZC14bCBmb250LW1lZGl1bSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxMb2NrIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYmx1ZS00MDBcIiAvPiBQYXJlbnQgRXhpdFxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICB7LyogRmxvYXRpbmcgQWN0aXZlIFByaXZhY3kgSW5kaWNhdG9yIChXaGVuIGNhbWVyYSBvciBzY3JlZW4gc2hhcmluZyBpcyBhY3RpdmUpICovfVxuICAgICAge2lzU2hhcmluZ01lZGlhICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNoYWRvdy1sZyBzdGlja3kgdG9wLVs1N3B4XSB6LTQwIGFuaW1hdGUtcHVsc2VcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIuNSBoLTIuNSByb3VuZGVkLWZ1bGwgYmctd2hpdGVcIj48L3NwYW4+XG4gICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgTElWRSB7bWVkaWFUeXBlID09PSAnY2FtZXJhJyA/ICdDQU1FUkEnIDogJ1NDUkVFTid9IFNIQVJJTkcgSVMgQUNUSVZFIFdJVEggWU9VUiBQQVJFTlRTXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU3RvcFNoYXJpbmd9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMSBiZy13aGl0ZSB0ZXh0LWVtZXJhbGQtODAwIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LWJvbGQgaG92ZXI6Ymctc2xhdGUtMTAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBTVE9QIFNIQVJJTkdcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogTWFpbiBDaGlsZCBJbnRlcmZhY2UgQ29udGVudCAqL31cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cIm1heC13LXhsIG14LWF1dG8gdy1mdWxsIHAtNCBzcGFjZS15LTUgZmxleC0xXCI+XG4gICAgICAgIHsvKiBFbWVyZ2VuY3kgU09TIEJhbm5lciBDYXJkICovfVxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9e2Byb3VuZGVkLTN4bCBwLTUgYm9yZGVyIHRyYW5zaXRpb24tYWxsIHRleHQtY2VudGVyICR7XG4gICAgICAgICAgc29zQWN0aXZlIFxuICAgICAgICAgICAgPyAnYmctcm9zZS05NTAvODAgYm9yZGVyLXJvc2UtNTAwIHNoYWRvdy0yeGwgc2hhZG93LXJvc2UtOTAwLzUwIGFuaW1hdGUtYm91bmNlJyBcbiAgICAgICAgICAgIDogJ2JnLWdyYWRpZW50LXRvLWIgZnJvbS1yb3NlLTkwMC80MCB0by1zbGF0ZS05MDAgYm9yZGVyLXJvc2UtOTAwLzYwJ1xuICAgICAgICB9YH0+XG4gICAgICAgICAge3Nvc0FjdGl2ZSA/IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHJvdW5kZWQtZnVsbCBiZy1yb3NlLTYwMCBteC1hdXRvIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGFuaW1hdGUtcGluZ1wiPlxuICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC13aGl0ZVwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJsYWNrIHRleHQtcm9zZS0zMDAgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICDwn5qoIFNPUyBBTEVSVCBUUkFOU01JVFRFRCFcbiAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXJvc2UtMjAwXCI+XG4gICAgICAgICAgICAgICAgWW91ciBwYXJlbnRzIGhhdmUgYmVlbiBub3RpZmllZCB3aXRoIHlvdXIgZXhhY3QgR1BTIGNvb3JkaW5hdGVzIGFuZCBoaWdoLXByaW9yaXR5IHNpcmVuLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2FuY2VsU09TfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgYm9yZGVyIGJvcmRlci1zbGF0ZS02MDBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIEkgQW0gU2FmZSAoQ2FuY2VsIFNPUylcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgaHJlZj1cInRlbDo5MTFcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgYmctcm9zZS02MDAgaG92ZXI6Ymctcm9zZS03MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxQaG9uZUNhbGwgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBDYWxsIEVtZXJnZW5jeSAoOTExKVxuICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiB0ZXh0LXJvc2UtNDAwIGZvbnQtYm9sZCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3RcIj5cbiAgICAgICAgICAgICAgICA8U2hpZWxkIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBFbWVyZ2VuY3kgUHJvdGVjdGlvblxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVRyaWdnZXJTT1N9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTQgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLXJvc2UtNjAwIHRvLXJlZC02MDAgaG92ZXI6ZnJvbS1yb3NlLTUwMCBob3Zlcjp0by1yZWQtNTAwIHRleHQtd2hpdGUgZm9udC1ibGFjayB0ZXh0LWJhc2Ugc2hhZG93LWxnIHNoYWRvdy1yb3NlLTcwMC80MCBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdHJhY2tpbmctd2lkZVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQteWVsbG93LTMwMFwiIC8+IFRBUCBGT1IgRU1FUkdFTkNZIFNPU1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICBJbnN0YW50bHkgYWxlcnRzIHlvdXIgcGFyZW50cywgc2hhcmVzIHlvdXIgR1BTLCBhbmQgc291bmRzIGFuIGF1ZGlibGUgZW1lcmdlbmN5IHNpcmVuLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgey8qIFNjcmVlbiBUaW1lIFJlbWFpbmluZyBXaWRnZXQgKi99XG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJnLXNsYXRlLTgwMC84MCByb3VuZGVkLTJ4bCBwLTQgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAvODAgc2hhZG93LW1kXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTkgaC05IHJvdW5kZWQteGwgYmctYmx1ZS02MDAvMzAgdGV4dC1ibHVlLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNtIHRleHQtc2xhdGUtMTAwXCI+RGFpbHkgU2NyZWVuIFRpbWU8L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgIHtyZW1haW5pbmdNaW51dGVzID4gMCA/IGAke3JlbWFpbmluZ01pbnV0ZXN9IG1pbnV0ZXMgcmVtYWluaW5nYCA6ICdEYWlseSB0aW1lIGxpbWl0IHJlYWNoZWQhJ31cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1RpbWVSZXF1ZXN0TW9kYWwodHJ1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgc2hhZG93LXNtIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQteWVsbG93LTMwMFwiIC8+IEFzayBmb3IgVGltZVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUHJvZ3Jlc3MgQmFyICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIHJvdW5kZWQtZnVsbCBoLTIuNSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGgtZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDAgJHtcbiAgICAgICAgICAgICAgICAgIHJlbWFpbmluZ01pbnV0ZXMgPD0gMTUgPyAnYmctYW1iZXItNTAwJyA6ICdiZy1ibHVlLTUwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgd2lkdGg6IGAke01hdGgubWluKDEwMCwgKGNoaWxkLnNjcmVlblRpbWUudG9kYXlVc2FnZU1pbnV0ZXMgLyBNYXRoLm1heCgxLCBjaGlsZC5zY3JlZW5UaW1lLmRhaWx5TGltaXRNaW51dGVzKSkgKiAxMDApfSVgLFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgbXQtMS41XCI+XG4gICAgICAgICAgICAgIDxzcGFuPlVzZWQ6IHtjaGlsZC5zY3JlZW5UaW1lLnRvZGF5VXNhZ2VNaW51dGVzfW08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuPkxpbWl0OiB7Y2hpbGQuc2NyZWVuVGltZS5kYWlseUxpbWl0TWludXRlc31tPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICB7LyogQ2hpbGQgU2FmZSBCcm93c2VyIFNhbmRib3ggKi99XG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJnLXNsYXRlLTgwMC84MCByb3VuZGVkLTJ4bCBwLTQgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAvODAgc2hhZG93LW1kIHNwYWNlLXktM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWxnIGJnLWVtZXJhbGQtNjAwLzMwIHRleHQtZW1lcmFsZC00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8Q29tcGFzcyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNtIHRleHQtc2xhdGUtMTAwXCI+U2FmZSBXZWIgRXhwbG9yZXI8L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+U2FmZVNlYXJjaCAmIEZpbHRlciBBY3RpdmU8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBiZy1lbWVyYWxkLTUwMC8yMCB0ZXh0LWVtZXJhbGQtMzAwIHB4LTIgcHktMC41IHJvdW5kZWQgZm9udC1tZWRpdW0gYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMFwiPlxuICAgICAgICAgICAgICBGaWx0ZXJlZFxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFVSTCBJbnB1dCBCYXIgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICB2YWx1ZT17YnJvd3NlclVybH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRCcm93c2VyVXJsKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgb25LZXlEb3duPXsoZSkgPT4gZS5rZXkgPT09ICdFbnRlcicgJiYgaGFuZGxlTmF2aWdhdGVCcm93c2VyKGJyb3dzZXJVcmwpfVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBvciBlbnRlciB3ZWJzaXRlIChlLmcuIHdpa2lwZWRpYS5vcmcpLi4uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYmx1ZS01MDBcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlTmF2aWdhdGVCcm93c2VyKGJyb3dzZXJVcmwpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBHb1xuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQmxvY2tlZCBVUkwgQmFubmVyICovfVxuICAgICAgICAgIHtibG9ja2VkQXR0ZW1wdCAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJvc2UtOTUwLzcwIGJvcmRlciBib3JkZXItcm9zZS02MDAvNzAgcm91bmRlZC14bCBwLTMgdGV4dC14cyB0ZXh0LXJvc2UtMjAwIHNwYWNlLXktMiBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZm9udC1ib2xkIHRleHQtcm9zZS0zMDBcIj5cbiAgICAgICAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcm9zZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPldlYnNpdGUgQmxvY2tlZCBieSBTYWZlS2lkcyBGaWx0ZXI8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtMzAwLzkwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgIHtibG9ja2VkQXR0ZW1wdC5yZWFzb24gfHwgJ1RoaXMgc2l0ZSBpcyBub3QgcGVybWl0dGVkIHVuZGVyIGZhbWlseSBzYWZldHkgcnVsZXMuJ31cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgcHQtMVwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgc2VuZE1lc3NhZ2UoY2hpbGQuaWQsICdjaGlsZCcsIGBEYWQvTW9tLCBjYW4geW91IHBsZWFzZSB1bmJsb2NrIFwiJHtibG9ja2VkQXR0ZW1wdC51cmx9XCI/IEkgbmVlZCBpdCBmb3IgcmVzZWFyY2guYCk7XG4gICAgICAgICAgICAgICAgICAgIGFsZXJ0KCdSZXF1ZXN0IHNlbnQgdG8gcGFyZW50cyEnKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0QmxvY2tlZEF0dGVtcHQobnVsbCk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgYmctcm9zZS04MDAgaG92ZXI6Ymctcm9zZS03MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIEFzayBQYXJlbnQgdG8gVW5ibG9ja1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEJsb2NrZWRBdHRlbXB0KG51bGwpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTMwMCByb3VuZGVkLWxnIHRleHQtWzExcHhdXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBEaXNtaXNzXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBBY3RpdmUgU2FmZSBCcm93c2VyIFBhZ2UgUHJldmlldyAqL31cbiAgICAgICAgICB7Y3VycmVudEJyb3dzZXJQYWdlICYmICFibG9ja2VkQXR0ZW1wdCAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBweC0zIHB5LTIgdGV4dC14cyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LVsxMXB4XSB0ZXh0LWVtZXJhbGQtNDAwIHRydW5jYXRlIG1heC13LVsyNDBweF1cIj5cbiAgICAgICAgICAgICAgICAgIPCflJIge2N1cnJlbnRCcm93c2VyUGFnZS51cmx9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgIGhyZWY9e2N1cnJlbnRCcm93c2VyUGFnZS51cmx9XG4gICAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNDAwIGhvdmVyOnRleHQtYmx1ZS0zMDAgdGV4dC1bMTFweF0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBPcGVuIDxFeHRlcm5hbExpbmsgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEN1cnJlbnRCcm93c2VyUGFnZShudWxsKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS0yMDBcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHRleHQtY2VudGVyIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIFNhZmVseSBuYXZpZ2F0ZWQgdG8gPHN0cm9uZz57Y3VycmVudEJyb3dzZXJQYWdlLnRpdGxlfTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgUHJvdGVjdGVkIHdpdGggcGFyZW50YWwgY29udGVudCBmaWx0ZXIgJiB0cmFja2luZyBibG9ja2VyLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIEN1cmF0ZWQgS2lkIFNhZmUgQm9va21hcmtzICovfVxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBmb250LXNlbWlib2xkIGJsb2NrIG1iLTJcIj5cbiAgICAgICAgICAgICAgVmVyaWZpZWQgS2lkLUZyaWVuZGx5IFdlYnNpdGVzOlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC0yXCI+XG4gICAgICAgICAgICAgIHtDVVJBVEVEX1NBRkVfU0lURVMuc2xpY2UoMCwgNCkubWFwKChzaXRlKSA9PiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAga2V5PXtzaXRlLm5hbWV9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVOYXZpZ2F0ZUJyb3dzZXIoc2l0ZS51cmwpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yLjUgYmctc2xhdGUtOTAwLzkwIGhvdmVyOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMC84MCByb3VuZGVkLXhsIHRleHQtbGVmdCB0cmFuc2l0aW9uLWFsbCBncm91cFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1iYXNlIGJsb2NrIG1iLTFcIj57c2l0ZS5pY29ufTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQteHMgdGV4dC1zbGF0ZS0yMDAgZ3JvdXAtaG92ZXI6dGV4dC1ibHVlLTQwMCBibG9jayB0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICAgICAgICB7c2l0ZS5uYW1lfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgYmxvY2sgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAge3NpdGUuY2F0ZWdvcnl9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICB7LyogUXVpY2sgSW50ZXJjb20gdG8gUGFyZW50cyAqL31cbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYmctc2xhdGUtODAwLzgwIHJvdW5kZWQtMnhsIHAtNCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMC84MCBzaGFkb3ctbWQgc3BhY2UteS0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtbGcgYmctaW5kaWdvLTYwMC8zMCB0ZXh0LWluZGlnby00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICA8TWVzc2FnZVNxdWFyZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNtIHRleHQtc2xhdGUtMTAwXCI+UGFyZW50IEludGVyY29tPC9oMz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPkRpcmVjdCBpbnN0YW50IGNoZWNrLWluIG1lc3NhZ2U8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB7Y2hhdFNlbnQgJiYgKFxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWVtZXJhbGQtNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gU2VudCFcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBRdWljayBSZXBseSBQaWxscyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTEuNSBvdmVyZmxvdy14LWF1dG8gcGItMSB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAge1snSSBhbSBzYWZlIGF0IGhvbWUg8J+RjScsICdGaW5pc2hlZCBob21ld29yayDwn5OaJywgJ0NhbiBJIGhhdmUgMTVtIG1vcmU/JywgJ1BsZWFzZSBjYWxsIG1lIPCfk54nXS5tYXAoKHByZXNldCkgPT4gKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAga2V5PXtwcmVzZXR9XG4gICAgICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgYXdhaXQgc2VuZE1lc3NhZ2UoY2hpbGQuaWQsICdjaGlsZCcsIHByZXNldCk7XG4gICAgICAgICAgICAgICAgICBzZXRDaGF0U2VudCh0cnVlKTtcbiAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Q2hhdFNlbnQoZmFsc2UpLCAyMDAwKTtcbiAgICAgICAgICAgICAgICAgIG9uUmVmcmVzaCgpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGhvdmVyOmJvcmRlci1pbmRpZ28tNTAwIHRleHQtc2xhdGUtMzAwIHJvdW5kZWQtbGcgd2hpdGVzcGFjZS1ub3dyYXAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3ByZXNldH1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgdmFsdWU9e3F1aWNrTXNnfVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFF1aWNrTXNnKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgb25LZXlEb3duPXsoZSkgPT4gZS5rZXkgPT09ICdFbnRlcicgJiYgaGFuZGxlU2VuZENoYXQoKX1cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZW5kIG1lc3NhZ2UgdG8gcGFyZW50cy4uLlwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC14cyB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWluZGlnby01MDBcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU2VuZENoYXR9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0yIGJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNlbmQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICB7LyogQW50aS1Vbmluc3RhbGwgJiBEZXZpY2UgUHJvdGVjdGlvbiBTdGF0dXMgQmFyICovfVxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAvODAgcm91bmRlZC0yeGwgcC0zLjUgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1jZW50ZXIgc3BhY2UteS0xLjUgc2hhZG93LXNtXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPkFudGktVW5pbnN0YWxsICYgRGV2aWNlIEFkbWluIFByb3RlY3RlZDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgU2FmZUtpZHMgaXMgbG9ja2VkIHRvIHRoaXMgZGV2aWNlLiBEZWxldGluZyBvciBkaXNhYmxpbmcgdGhpcyBhcHAgcmVxdWlyZXMgUGFyZW50IE1hc3RlciBQSU4gYXV0aG9yaXphdGlvbi5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgICB7LyogQ2hpbGQgTW9kZSBGb290ZXIgd2l0aCBEZXZlbG9wZXIgQnJhbmRpbmcgKi99XG4gICAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMiB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIHNwYWNlLXktMVwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICBTYWZlS2lkcyBDaGlsZCBTaGllbGQg4oCiIERldmVsb3BlZCBieSA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZFwiPlJhamFuIFZpc2h3YWthcm1hPC9zdHJvbmc+XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Zvb3Rlcj5cblxuICAgICAgICB7LyogSGlkZGVuIHZpZGVvIGVsZW1lbnQgZm9yIGxvY2FsIHN0cmVhbSBmZWVkYmFjayAqL31cbiAgICAgICAgPHZpZGVvIHJlZj17Y2hpbGRWaWRlb1JlZn0gYXV0b1BsYXkgcGxheXNJbmxpbmUgbXV0ZWQgY2xhc3NOYW1lPVwiaGlkZGVuXCIgLz5cbiAgICAgIDwvbWFpbj5cblxuICAgICAgey8qIE1vZGFsOiBQYXJlbnQgSW5jb21pbmcgQ2FtZXJhIFJlcXVlc3QgKi99XG4gICAgICB7Y2FtZXJhUmVxdWVzdCAmJiBjYW1lcmFSZXF1ZXN0LnN0YXR1cyA9PT0gJ3BlbmRpbmcnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzgwIGJhY2tkcm9wLWJsdXItbWQgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXItMiBib3JkZXItYmx1ZS01MDAgcm91bmRlZC0zeGwgbWF4LXctc20gdy1mdWxsIHAtNiB0ZXh0LWNlbnRlciBzcGFjZS15LTQgc2hhZG93LTJ4bCBhbmltYXRlLWluIHpvb20taW4tOTVcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHJvdW5kZWQtMnhsIGJnLWJsdWUtNjAwLzMwIHRleHQtYmx1ZS00MDAgbXgtYXV0byBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBhbmltYXRlLWJvdW5jZVwiPlxuICAgICAgICAgICAgICA8Q2FtZXJhIGNsYXNzTmFtZT1cInctOCBoLThcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC13aGl0ZVwiPlBhcmVudCBWaWRlbyBDaGVjay1JbjwvaDM+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0zMDAgbXQtMVwiPlxuICAgICAgICAgICAgICAgIFlvdXIgcGFyZW50IGlzIHJlcXVlc3RpbmcgYSAyLW1pbnV0ZSBsaXZlIGNhbWVyYSBsb29rLWluLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIHtjYW1lcmFSZXF1ZXN0LnJlYXNvbiAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS04MDAgcC0yIHJvdW5kZWQteGwgdGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0yIGl0YWxpY1wiPlxuICAgICAgICAgICAgICAgICAgJnF1b3Q7e2NhbWVyYVJlcXVlc3QucmVhc29ufSZxdW90O1xuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS05NTAvNDAgcC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ibHVlLTgwMCB0ZXh0LVsxMXB4XSB0ZXh0LWJsdWUtMjAwXCI+XG4gICAgICAgICAgICAgIPCfm6HvuI8gU2FmZUtpZHMgTm90aWNlOiBZb3UgaGF2ZSBmdWxsIGNvbnRyb2wuIFlvdSBjYW4gYWNjZXB0IG9yIGRlbnkuIFlvdSBjYW4gc3RvcCBzaGFyaW5nIGF0IGFueSBzZWNvbmQuXG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zIHB0LTJcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURlY2xpbmVDYW1lcmF9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMi41IHB4LTQgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTMwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBEZWNsaW5lXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQWNjZXB0Q2FtZXJhfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB5LTIuNSBweC00IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBzaGFkb3ctbGcgc2hhZG93LWJsdWUtNjAwLzMwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEFjY2VwdCAmIFNoYXJlXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIE1vZGFsOiBQYXJlbnQgSW5jb21pbmcgU2NyZWVuIFNoYXJlIFJlcXVlc3QgKi99XG4gICAgICB7c2NyZWVuUmVxdWVzdCAmJiBzY3JlZW5SZXF1ZXN0LnN0YXR1cyA9PT0gJ3BlbmRpbmcnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzgwIGJhY2tkcm9wLWJsdXItbWQgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXItMiBib3JkZXItaW5kaWdvLTUwMCByb3VuZGVkLTN4bCBtYXgtdy1zbSB3LWZ1bGwgcC02IHRleHQtY2VudGVyIHNwYWNlLXktNCBzaGFkb3ctMnhsIGFuaW1hdGUtaW4gem9vbS1pbi05NVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgcm91bmRlZC0yeGwgYmctaW5kaWdvLTYwMC8zMCB0ZXh0LWluZGlnby00MDAgbXgtYXV0byBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBhbmltYXRlLWJvdW5jZVwiPlxuICAgICAgICAgICAgICA8TW9uaXRvciBjbGFzc05hbWU9XCJ3LTggaC04XCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5TY3JlZW4gU2hhcmluZyBSZXF1ZXN0PC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTMwMCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgWW91ciBwYXJlbnQgcmVxdWVzdGVkIHRvIHJldmlldyB5b3VyIHNjcmVlbiB2aWEgQW5kcm9pZCBNZWRpYVByb2plY3Rpb24uXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAge3NjcmVlblJlcXVlc3QucmVhc29uICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTgwMCBwLTIgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTIgaXRhbGljXCI+XG4gICAgICAgICAgICAgICAgICAmcXVvdDt7c2NyZWVuUmVxdWVzdC5yZWFzb259JnF1b3Q7XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1pbmRpZ28tOTUwLzQwIHAtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItaW5kaWdvLTgwMCB0ZXh0LVsxMXB4XSB0ZXh0LWluZGlnby0yMDBcIj5cbiAgICAgICAgICAgICAg8J+boe+4jyBTYWZlS2lkcyBOb3RpY2U6IEFuZHJvaWQgd2lsbCBkaXNwbGF5IGFuIG9mZmljaWFsIHBlcm1pc3Npb24gcHJvbXB0LiBZb3UgY2FuIGVuZCBzY3JlZW4gc2hhcmluZyBhdCBhbnkgdGltZS5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgcHQtMlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRGVjbGluZVNjcmVlbn1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweS0yLjUgcHgtNCBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkIGJvcmRlciBib3JkZXItc2xhdGUtNzAwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIERlY2xpbmVcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVBY2NlcHRTY3JlZW59XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMi41IHB4LTQgYmctaW5kaWdvLTYwMCBob3ZlcjpiZy1pbmRpZ28tNTAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBzaGFkb3ctbGcgc2hhZG93LWluZGlnby02MDAvMzBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQWxsb3cgU2NyZWVuIFNoYXJlXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIE1vZGFsOiBSZXF1ZXN0IFRpbWUgRXh0ZW5zaW9uICovfVxuICAgICAge3Nob3dUaW1lUmVxdWVzdE1vZGFsICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzgwIGJhY2tkcm9wLWJsdXItbWQgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLTN4bCBtYXgtdy1zbSB3LWZ1bGwgcC02IHNwYWNlLXktNCBzaGFkb3ctMnhsXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmFzZSB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC15ZWxsb3ctNDAwXCIgLz4gQXNrIGZvciBTY3JlZW4gVGltZVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1RpbWVSZXF1ZXN0TW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHt0aW1lUmVxdWVzdFNlbnQgPyAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiB0ZXh0LWNlbnRlciBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctMTIgaC0xMiB0ZXh0LWVtZXJhbGQtNDAwIG14LWF1dG9cIiAvPlxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZVwiPlJlcXVlc3QgU2VudCB0byBQYXJlbnRzITwvaDQ+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgVGhleSB3aWxsIHJlY2VpdmUgYSBub3RpZmljYXRpb24gdG8gYXBwcm92ZSB5b3VyIHRpbWUuXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXRUaW1lUmVxdWVzdH0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0zMDAgYmxvY2sgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICBIb3cgbWFueSBtaW51dGVzIGRvIHlvdSBuZWVkP1xuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICB7WzE1LCAzMCwgNDVdLm1hcCgobWlucykgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXttaW5zfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmVxdWVzdE1pbnV0ZXMobWlucyl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yIHRleHQteHMgcm91bmRlZC14bCBmb250LWJvbGQgYm9yZGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVlc3RNaW51dGVzID09PSBtaW5zXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBib3JkZXItYmx1ZS01MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ymctc2xhdGUtNzAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgK3ttaW5zfSBtaW5zXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTMwMCBibG9jayBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgV2hhdCBhcmUgeW91IHdvcmtpbmcgb24/XG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3JlcXVlc3RSZWFzb259XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVxdWVzdFJlYXNvbihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBTY2llbmNlIHByb2plY3QsIFJlYWRpbmcsIE1hdGguLi5cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC13aGl0ZSBwbGFjZWhvbGRlci1zbGF0ZS01MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1ibHVlLTUwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMi41IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgdGV4dC14cyBmb250LWJvbGQgcm91bmRlZC14bCBzaGFkb3ctbWQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIFNlbmQgUmVxdWVzdCB0byBQYXJlbnRzXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=