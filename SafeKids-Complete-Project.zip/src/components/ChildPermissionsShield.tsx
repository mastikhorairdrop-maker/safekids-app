const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=d3d47fa4";
import { ShieldCheck, MapPin, Camera, Lock, Zap, BatteryCharging, RefreshCw, CheckCircle2, Info } from "/node_modules/.vite/deps/lucide-react.js?v=d3d47fa4";
var _jsxFileName = "/app/applet/src/components/ChildPermissionsShield.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d3d47fa4";
const STORAGE_KEY = "safekids_child_permissions_state";
export const ChildPermissionsShield = () => {
	const [permissions, setPermissions] = useState(() => {
		const saved = localStorage.getItem(STORAGE_KEY);
		if (saved) {
			try {
				return JSON.parse(saved);
			} catch {}
		}
		return [
			{
				id: "location",
				name: "Foreground Location Service",
				androidPermission: "android.permission.ACCESS_FINE_LOCATION & FOREGROUND_SERVICE_LOCATION",
				description: "Enables real-time GPS tracking and safe-zone geofence enter/exit alerts without interruption.",
				granted: true,
				isForegroundService: true,
				icon: MapPin
			},
			{
				id: "camera",
				name: "Foreground Camera Look-In",
				androidPermission: "android.permission.CAMERA & FOREGROUND_SERVICE_CAMERA",
				description: "Allows parent-requested live camera check-in with child consent dialog and persistent notification.",
				granted: true,
				isForegroundService: true,
				icon: Camera
			},
			{
				id: "device_admin",
				name: "Device Administrator (Anti-Uninstall)",
				androidPermission: "android.permission.BIND_DEVICE_ADMIN",
				description: "Locks uninstallation in Android settings. Child cannot delete or deactivate without Parent PIN.",
				granted: true,
				isForegroundService: false,
				icon: Lock
			},
			{
				id: "accessibility",
				name: "Accessibility Tamper Guard",
				androidPermission: "android.permission.BIND_ACCESSIBILITY_SERVICE",
				description: "Intercepts attempts to Force Stop, Clear Storage, or bypass app limits in Android Settings.",
				granted: true,
				isForegroundService: false,
				icon: Zap
			},
			{
				id: "battery_exempt",
				name: "Ignore Battery Optimization (No Kill)",
				androidPermission: "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS",
				description: "Exempts SafeKids from Android Doze mode so background services are never killed while sleeping.",
				granted: true,
				isForegroundService: true,
				icon: BatteryCharging
			},
			{
				id: "auto_reset_disallowed",
				name: "Permission Auto-Reset Disabled",
				androidPermission: "PackageManager.setAutoRevokePermissionsMode(MODE_DISALLOWED)",
				description: "Prevents Android 11+ from automatically revoking location & camera permissions after inactivity.",
				granted: true,
				isForegroundService: false,
				icon: RefreshCw
			}
		];
	});
	const [promptMessage, setPromptMessage] = useState(null);
	useEffect(() => {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(permissions));
	}, [permissions]);
	const handleTogglePermission = async (id) => {
		const item = permissions.find((p) => p.id === id);
		if (!item) return;
		if (!item.granted) {
			// If toggling on, request real browser permission if applicable
			if (id === "location" && navigator.geolocation) {
				navigator.geolocation.getCurrentPosition(() => {}, () => {}, { timeout: 3e3 });
			} else if (id === "camera" && navigator.mediaDevices) {
				try {
					const stream = await navigator.mediaDevices.getUserMedia({ video: true });
					stream.getTracks().forEach((t) => t.stop());
				} catch {}
			}
		}
		setPermissions((prev) => prev.map((p) => p.id === id ? {
			...p,
			granted: !p.granted
		} : p));
		setPromptMessage(`Status updated: "${item.name}" is now ${!item.granted ? "Enforced & Protected" : "Disabled"}.`);
		setTimeout(() => setPromptMessage(null), 3e3);
	};
	const handleGrantAll = () => {
		setPermissions((prev) => prev.map((p) => ({
			...p,
			granted: true
		})));
		setPromptMessage("All foreground service and anti-uninstall permissions locked & verified!");
		setTimeout(() => setPromptMessage(null), 3e3);
	};
	const allGranted = permissions.every((p) => p.granted);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-5",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center",
						children: /* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("h3", {
						className: "font-bold text-base text-slate-900 dark:text-slate-100",
						children: "Android Runtime Permissions & Foreground Services"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
					children: "Permanent permission persistence. Disables Android Doze kills and auto-revocation."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 128,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: allGranted ? /* @__PURE__ */ _jsxDEV("span", {
						className: "bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 text-xs px-3 py-1 rounded-full font-bold border border-emerald-300 dark:border-emerald-800 flex items-center gap-1",
						children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 15
						}, this), " All Permissions Enforced"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleGrantAll,
						className: "px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors",
						children: "Grant All Permissions"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 127,
				columnNumber: 7
			}, this),
			promptMessage && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 rounded-xl p-3 text-xs text-blue-800 dark:text-blue-300 flex items-center gap-2 animate-in fade-in",
				children: [/* @__PURE__ */ _jsxDEV(Info, { className: "w-4 h-4 shrink-0 text-blue-600" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 160,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: promptMessage }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 161,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 159,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-3.5",
				children: permissions.map((perm) => {
					const Icon = perm.icon;
					return /* @__PURE__ */ _jsxDEV("div", {
						className: `p-4 rounded-2xl border transition-all ${perm.granted ? "bg-emerald-50/40 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900/60" : "bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800"}`,
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-start gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: `w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${perm.granted ? "bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400" : "bg-slate-200 dark:bg-slate-700 text-slate-500"}`,
									children: /* @__PURE__ */ _jsxDEV(Icon, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 187,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 180,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-xs text-slate-900 dark:text-slate-100",
									children: perm.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 190,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono text-[10px] text-slate-400 block break-all",
									children: perm.androidPermission
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 193,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 189,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 179,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleTogglePermission(perm.id),
								className: `px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${perm.granted ? "bg-emerald-600 text-white" : "bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-300"}`,
								children: perm.granted ? "Active" : "Grant"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 199,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 178,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-slate-600 dark:text-slate-400 mt-2.5 leading-relaxed",
							children: perm.description
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 211,
							columnNumber: 15
						}, this)]
					}, perm.id, true, {
						fileName: _jsxFileName,
						lineNumber: 170,
						columnNumber: 13
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 166,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-100 dark:bg-slate-800/60 rounded-2xl p-4 text-xs text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 space-y-2",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "font-bold text-slate-900 dark:text-slate-100 block",
					children: "🔒 Prevention of Permission Auto-Reset & Service Kills (Android 11–14):"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 221,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("ul", {
					className: "list-disc list-inside space-y-1 text-[11px] text-slate-500 dark:text-slate-400",
					children: [
						/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Foreground Service Notifications:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 225,
							columnNumber: 15
						}, this), " Location and Camera run with ongoing, high-priority notifications that prevent OS process termination."] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 225,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: [
							/* @__PURE__ */ _jsxDEV("strong", { children: "Auto-Revoke Disallowed:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 226,
								columnNumber: 15
							}, this),
							" SafeKids sets ",
							/* @__PURE__ */ _jsxDEV("code", { children: "AUTO_REVOKE_DISALLOWED" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 226,
								columnNumber: 70
							}, this),
							" so permissions never expire even if the app remains in the background."
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 226,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Battery Optimization Exemption:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 227,
							columnNumber: 15
						}, this), " Bypasses Android Doze to ensure instant SOS triggers and 24/7 geofence notifications."] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 227,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 224,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 220,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 125,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsYUFBYSxRQUFRLFFBQVEsTUFBTSxLQUFLLGlCQUFpQixXQUFXLGNBQTJCLFlBQTBCOzs7QUFZbEksTUFBTSxjQUFjO0FBRXBCLE9BQU8sTUFBTSwrQkFBeUM7Q0FDcEQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLGVBQWlDO0VBQ3JFLE1BQU0sUUFBUSxhQUFhLFFBQVEsV0FBVztFQUM5QyxJQUFJLE9BQU87R0FDVCxJQUFJO0lBQ0YsT0FBTyxLQUFLLE1BQU0sS0FBSztHQUN6QixRQUFRLENBQUM7RUFDWDtFQUNBLE9BQU87R0FDTDtJQUNFLElBQUk7SUFDSixNQUFNO0lBQ04sbUJBQW1CO0lBQ25CLGFBQWE7SUFDYixTQUFTO0lBQ1QscUJBQXFCO0lBQ3JCLE1BQU07R0FDUjtHQUNBO0lBQ0UsSUFBSTtJQUNKLE1BQU07SUFDTixtQkFBbUI7SUFDbkIsYUFBYTtJQUNiLFNBQVM7SUFDVCxxQkFBcUI7SUFDckIsTUFBTTtHQUNSO0dBQ0E7SUFDRSxJQUFJO0lBQ0osTUFBTTtJQUNOLG1CQUFtQjtJQUNuQixhQUFhO0lBQ2IsU0FBUztJQUNULHFCQUFxQjtJQUNyQixNQUFNO0dBQ1I7R0FDQTtJQUNFLElBQUk7SUFDSixNQUFNO0lBQ04sbUJBQW1CO0lBQ25CLGFBQWE7SUFDYixTQUFTO0lBQ1QscUJBQXFCO0lBQ3JCLE1BQU07R0FDUjtHQUNBO0lBQ0UsSUFBSTtJQUNKLE1BQU07SUFDTixtQkFBbUI7SUFDbkIsYUFBYTtJQUNiLFNBQVM7SUFDVCxxQkFBcUI7SUFDckIsTUFBTTtHQUNSO0dBQ0E7SUFDRSxJQUFJO0lBQ0osTUFBTTtJQUNOLG1CQUFtQjtJQUNuQixhQUFhO0lBQ2IsU0FBUztJQUNULHFCQUFxQjtJQUNyQixNQUFNO0dBQ1I7RUFDRjtDQUNGLENBQUM7Q0FFRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBd0IsSUFBSTtDQUV0RSxnQkFBZ0I7RUFDZCxhQUFhLFFBQVEsYUFBYSxLQUFLLFVBQVUsV0FBVyxDQUFDO0NBQy9ELEdBQUcsQ0FBQyxXQUFXLENBQUM7Q0FFaEIsTUFBTSx5QkFBeUIsT0FBTyxPQUFlO0VBQ25ELE1BQU0sT0FBTyxZQUFZLE1BQU0sTUFBTSxFQUFFLE9BQU8sRUFBRTtFQUNoRCxJQUFJLENBQUMsTUFBTTtFQUVYLElBQUksQ0FBQyxLQUFLLFNBQVM7O0dBRWpCLElBQUksT0FBTyxjQUFjLFVBQVUsYUFBYTtJQUM5QyxVQUFVLFlBQVkseUJBQ2QsQ0FBQyxTQUNELENBQUMsR0FDUCxFQUFFLFNBQVMsSUFBSyxDQUNsQjtHQUNGLE9BQU8sSUFBSSxPQUFPLFlBQVksVUFBVSxjQUFjO0lBQ3BELElBQUk7S0FDRixNQUFNLFNBQVMsTUFBTSxVQUFVLGFBQWEsYUFBYSxFQUFFLE9BQU8sS0FBSyxDQUFDO0tBQ3hFLE9BQU8sVUFBVSxDQUFDLENBQUMsU0FBUyxNQUFNLEVBQUUsS0FBSyxDQUFDO0lBQzVDLFFBQVEsQ0FBQztHQUNYO0VBQ0Y7RUFFQSxnQkFBZ0IsU0FDZCxLQUFLLEtBQUssTUFBTyxFQUFFLE9BQU8sS0FBSztHQUFFLEdBQUc7R0FBRyxTQUFTLENBQUMsRUFBRTtFQUFRLElBQUksQ0FBRSxDQUNuRTtFQUVBLGlCQUFpQixvQkFBb0IsS0FBSyxLQUFLLFdBQVcsQ0FBQyxLQUFLLFVBQVUseUJBQXlCLFdBQVcsRUFBRTtFQUNoSCxpQkFBaUIsaUJBQWlCLElBQUksR0FBRyxHQUFJO0NBQy9DO0NBRUEsTUFBTSx1QkFBdUI7RUFDM0IsZ0JBQWdCLFNBQVMsS0FBSyxLQUFLLE9BQU87R0FBRSxHQUFHO0dBQUcsU0FBUztFQUFLLEVBQUUsQ0FBQztFQUNuRSxpQkFBaUIsMEVBQTBFO0VBQzNGLGlCQUFpQixpQkFBaUIsSUFBSSxHQUFHLEdBQUk7Q0FDL0M7Q0FFQSxNQUFNLGFBQWEsWUFBWSxPQUFPLE1BQU0sRUFBRSxPQUFPO0NBRXJELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUNkLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7O0tBQzlCOzs7O2VBQ04sd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXlEO0tBRW5FOzs7O2FBQ0Q7Ozs7O2NBQ0wsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBa0Q7SUFFNUQ7Ozs7WUFDQTs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osYUFDQyx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEIsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSxjQUFlOzs7O2dCQUFDLDJCQUNwQzs7Ozs7Z0JBRU4sd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUNYO0tBRU87Ozs7O0lBRVA7Ozs7WUFDRjs7Ozs7O0dBRUosaUJBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGlDQUFrQzs7OztjQUNsRCx3QkFBQyxRQUFELFlBQU8sY0FBb0I7Ozs7WUFDeEI7Ozs7OztHQUlQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osWUFBWSxLQUFLLFNBQVM7S0FDekIsTUFBTSxPQUFPLEtBQUs7S0FDbEIsT0FDRSx3QkFBQyxPQUFEO01BRUUsV0FBVyx5Q0FDVCxLQUFLLFVBQ0QsMEZBQ0E7Z0JBTFIsQ0FRRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUNFLFdBQVcsZ0VBQ1QsS0FBSyxVQUNELGlGQUNBO21CQUdOLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7O1FBQ3hCOzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWCxLQUFLO1FBQ0o7Ozs7a0JBQ0osd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2IsS0FBSztRQUNGOzs7O2dCQUNIOzs7O2dCQUNGOzs7OztpQkFFTCx3QkFBQyxVQUFEO1FBQ0UsZUFBZSx1QkFBdUIsS0FBSyxFQUFFO1FBQzdDLFdBQVcsMkRBQ1QsS0FBSyxVQUNELDhCQUNBO2tCQUdMLEtBQUssVUFBVSxXQUFXO09BQ3JCOzs7O2VBQ0w7Ozs7O2dCQUVMLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUNWLEtBQUs7TUFDTDs7OztjQUNBO1FBM0NFLEtBQUs7Ozs7WUEyQ1A7SUFFVCxDQUFDO0dBQ0U7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQXFEO0lBRS9EOzs7O2NBQ04sd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZDtNQUNFLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxVQUFELFlBQVEsb0NBQXlDOzs7O2dCQUFDLHlHQUEyRzs7Ozs7TUFDakssd0JBQUMsTUFBRDtPQUFJLHdCQUFDLFVBQUQsWUFBUSwwQkFBK0I7Ozs7O09BQUM7T0FBZSx3QkFBQyxRQUFELFlBQU0seUJBQTRCOzs7OztPQUFDO01BQTJFOzs7OztNQUN6Syx3QkFBQyxNQUFELGFBQUksd0JBQUMsVUFBRCxZQUFRLGtDQUF1Qzs7OztnQkFBQyx3RkFBMEY7Ozs7O0tBQzVJOzs7OztZQUNEOzs7Ozs7RUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2hpbGRQZXJtaXNzaW9uc1NoaWVsZC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBTaGllbGRDaGVjaywgTWFwUGluLCBDYW1lcmEsIExvY2ssIFphcCwgQmF0dGVyeUNoYXJnaW5nLCBSZWZyZXNoQ3csIENoZWNrQ2lyY2xlMiwgQWxlcnRDaXJjbGUsIEluZm8sIEV4dGVybmFsTGluayB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmludGVyZmFjZSBQZXJtaXNzaW9uSXRlbSB7XG4gIGlkOiBzdHJpbmc7XG4gIG5hbWU6IHN0cmluZztcbiAgYW5kcm9pZFBlcm1pc3Npb246IHN0cmluZztcbiAgZGVzY3JpcHRpb246IHN0cmluZztcbiAgZ3JhbnRlZDogYm9vbGVhbjtcbiAgaXNGb3JlZ3JvdW5kU2VydmljZTogYm9vbGVhbjtcbiAgaWNvbjogYW55O1xufVxuXG5jb25zdCBTVE9SQUdFX0tFWSA9ICdzYWZla2lkc19jaGlsZF9wZXJtaXNzaW9uc19zdGF0ZSc7XG5cbmV4cG9ydCBjb25zdCBDaGlsZFBlcm1pc3Npb25zU2hpZWxkOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgW3Blcm1pc3Npb25zLCBzZXRQZXJtaXNzaW9uc10gPSB1c2VTdGF0ZTxQZXJtaXNzaW9uSXRlbVtdPigoKSA9PiB7XG4gICAgY29uc3Qgc2F2ZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShTVE9SQUdFX0tFWSk7XG4gICAgaWYgKHNhdmVkKSB7XG4gICAgICB0cnkge1xuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShzYXZlZCk7XG4gICAgICB9IGNhdGNoIHt9XG4gICAgfVxuICAgIHJldHVybiBbXG4gICAgICB7XG4gICAgICAgIGlkOiAnbG9jYXRpb24nLFxuICAgICAgICBuYW1lOiAnRm9yZWdyb3VuZCBMb2NhdGlvbiBTZXJ2aWNlJyxcbiAgICAgICAgYW5kcm9pZFBlcm1pc3Npb246ICdhbmRyb2lkLnBlcm1pc3Npb24uQUNDRVNTX0ZJTkVfTE9DQVRJT04gJiBGT1JFR1JPVU5EX1NFUlZJQ0VfTE9DQVRJT04nLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ0VuYWJsZXMgcmVhbC10aW1lIEdQUyB0cmFja2luZyBhbmQgc2FmZS16b25lIGdlb2ZlbmNlIGVudGVyL2V4aXQgYWxlcnRzIHdpdGhvdXQgaW50ZXJydXB0aW9uLicsXG4gICAgICAgIGdyYW50ZWQ6IHRydWUsXG4gICAgICAgIGlzRm9yZWdyb3VuZFNlcnZpY2U6IHRydWUsXG4gICAgICAgIGljb246IE1hcFBpbixcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGlkOiAnY2FtZXJhJyxcbiAgICAgICAgbmFtZTogJ0ZvcmVncm91bmQgQ2FtZXJhIExvb2stSW4nLFxuICAgICAgICBhbmRyb2lkUGVybWlzc2lvbjogJ2FuZHJvaWQucGVybWlzc2lvbi5DQU1FUkEgJiBGT1JFR1JPVU5EX1NFUlZJQ0VfQ0FNRVJBJyxcbiAgICAgICAgZGVzY3JpcHRpb246ICdBbGxvd3MgcGFyZW50LXJlcXVlc3RlZCBsaXZlIGNhbWVyYSBjaGVjay1pbiB3aXRoIGNoaWxkIGNvbnNlbnQgZGlhbG9nIGFuZCBwZXJzaXN0ZW50IG5vdGlmaWNhdGlvbi4nLFxuICAgICAgICBncmFudGVkOiB0cnVlLFxuICAgICAgICBpc0ZvcmVncm91bmRTZXJ2aWNlOiB0cnVlLFxuICAgICAgICBpY29uOiBDYW1lcmEsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBpZDogJ2RldmljZV9hZG1pbicsXG4gICAgICAgIG5hbWU6ICdEZXZpY2UgQWRtaW5pc3RyYXRvciAoQW50aS1Vbmluc3RhbGwpJyxcbiAgICAgICAgYW5kcm9pZFBlcm1pc3Npb246ICdhbmRyb2lkLnBlcm1pc3Npb24uQklORF9ERVZJQ0VfQURNSU4nLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ0xvY2tzIHVuaW5zdGFsbGF0aW9uIGluIEFuZHJvaWQgc2V0dGluZ3MuIENoaWxkIGNhbm5vdCBkZWxldGUgb3IgZGVhY3RpdmF0ZSB3aXRob3V0IFBhcmVudCBQSU4uJyxcbiAgICAgICAgZ3JhbnRlZDogdHJ1ZSxcbiAgICAgICAgaXNGb3JlZ3JvdW5kU2VydmljZTogZmFsc2UsXG4gICAgICAgIGljb246IExvY2ssXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBpZDogJ2FjY2Vzc2liaWxpdHknLFxuICAgICAgICBuYW1lOiAnQWNjZXNzaWJpbGl0eSBUYW1wZXIgR3VhcmQnLFxuICAgICAgICBhbmRyb2lkUGVybWlzc2lvbjogJ2FuZHJvaWQucGVybWlzc2lvbi5CSU5EX0FDQ0VTU0lCSUxJVFlfU0VSVklDRScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAnSW50ZXJjZXB0cyBhdHRlbXB0cyB0byBGb3JjZSBTdG9wLCBDbGVhciBTdG9yYWdlLCBvciBieXBhc3MgYXBwIGxpbWl0cyBpbiBBbmRyb2lkIFNldHRpbmdzLicsXG4gICAgICAgIGdyYW50ZWQ6IHRydWUsXG4gICAgICAgIGlzRm9yZWdyb3VuZFNlcnZpY2U6IGZhbHNlLFxuICAgICAgICBpY29uOiBaYXAsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBpZDogJ2JhdHRlcnlfZXhlbXB0JyxcbiAgICAgICAgbmFtZTogJ0lnbm9yZSBCYXR0ZXJ5IE9wdGltaXphdGlvbiAoTm8gS2lsbCknLFxuICAgICAgICBhbmRyb2lkUGVybWlzc2lvbjogJ2FuZHJvaWQucGVybWlzc2lvbi5SRVFVRVNUX0lHTk9SRV9CQVRURVJZX09QVElNSVpBVElPTlMnLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ0V4ZW1wdHMgU2FmZUtpZHMgZnJvbSBBbmRyb2lkIERvemUgbW9kZSBzbyBiYWNrZ3JvdW5kIHNlcnZpY2VzIGFyZSBuZXZlciBraWxsZWQgd2hpbGUgc2xlZXBpbmcuJyxcbiAgICAgICAgZ3JhbnRlZDogdHJ1ZSxcbiAgICAgICAgaXNGb3JlZ3JvdW5kU2VydmljZTogdHJ1ZSxcbiAgICAgICAgaWNvbjogQmF0dGVyeUNoYXJnaW5nLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6ICdhdXRvX3Jlc2V0X2Rpc2FsbG93ZWQnLFxuICAgICAgICBuYW1lOiAnUGVybWlzc2lvbiBBdXRvLVJlc2V0IERpc2FibGVkJyxcbiAgICAgICAgYW5kcm9pZFBlcm1pc3Npb246ICdQYWNrYWdlTWFuYWdlci5zZXRBdXRvUmV2b2tlUGVybWlzc2lvbnNNb2RlKE1PREVfRElTQUxMT1dFRCknLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ1ByZXZlbnRzIEFuZHJvaWQgMTErIGZyb20gYXV0b21hdGljYWxseSByZXZva2luZyBsb2NhdGlvbiAmIGNhbWVyYSBwZXJtaXNzaW9ucyBhZnRlciBpbmFjdGl2aXR5LicsXG4gICAgICAgIGdyYW50ZWQ6IHRydWUsXG4gICAgICAgIGlzRm9yZWdyb3VuZFNlcnZpY2U6IGZhbHNlLFxuICAgICAgICBpY29uOiBSZWZyZXNoQ3csXG4gICAgICB9LFxuICAgIF07XG4gIH0pO1xuXG4gIGNvbnN0IFtwcm9tcHRNZXNzYWdlLCBzZXRQcm9tcHRNZXNzYWdlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oU1RPUkFHRV9LRVksIEpTT04uc3RyaW5naWZ5KHBlcm1pc3Npb25zKSk7XG4gIH0sIFtwZXJtaXNzaW9uc10pO1xuXG4gIGNvbnN0IGhhbmRsZVRvZ2dsZVBlcm1pc3Npb24gPSBhc3luYyAoaWQ6IHN0cmluZykgPT4ge1xuICAgIGNvbnN0IGl0ZW0gPSBwZXJtaXNzaW9ucy5maW5kKChwKSA9PiBwLmlkID09PSBpZCk7XG4gICAgaWYgKCFpdGVtKSByZXR1cm47XG5cbiAgICBpZiAoIWl0ZW0uZ3JhbnRlZCkge1xuICAgICAgLy8gSWYgdG9nZ2xpbmcgb24sIHJlcXVlc3QgcmVhbCBicm93c2VyIHBlcm1pc3Npb24gaWYgYXBwbGljYWJsZVxuICAgICAgaWYgKGlkID09PSAnbG9jYXRpb24nICYmIG5hdmlnYXRvci5nZW9sb2NhdGlvbikge1xuICAgICAgICBuYXZpZ2F0b3IuZ2VvbG9jYXRpb24uZ2V0Q3VycmVudFBvc2l0aW9uKFxuICAgICAgICAgICgpID0+IHt9LFxuICAgICAgICAgICgpID0+IHt9LFxuICAgICAgICAgIHsgdGltZW91dDogMzAwMCB9XG4gICAgICAgICk7XG4gICAgICB9IGVsc2UgaWYgKGlkID09PSAnY2FtZXJhJyAmJiBuYXZpZ2F0b3IubWVkaWFEZXZpY2VzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgbmF2aWdhdG9yLm1lZGlhRGV2aWNlcy5nZXRVc2VyTWVkaWEoeyB2aWRlbzogdHJ1ZSB9KTtcbiAgICAgICAgICBzdHJlYW0uZ2V0VHJhY2tzKCkuZm9yRWFjaCgodCkgPT4gdC5zdG9wKCkpO1xuICAgICAgICB9IGNhdGNoIHt9XG4gICAgICB9XG4gICAgfVxuXG4gICAgc2V0UGVybWlzc2lvbnMoKHByZXYpID0+XG4gICAgICBwcmV2Lm1hcCgocCkgPT4gKHAuaWQgPT09IGlkID8geyAuLi5wLCBncmFudGVkOiAhcC5ncmFudGVkIH0gOiBwKSlcbiAgICApO1xuXG4gICAgc2V0UHJvbXB0TWVzc2FnZShgU3RhdHVzIHVwZGF0ZWQ6IFwiJHtpdGVtLm5hbWV9XCIgaXMgbm93ICR7IWl0ZW0uZ3JhbnRlZCA/ICdFbmZvcmNlZCAmIFByb3RlY3RlZCcgOiAnRGlzYWJsZWQnfS5gKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldFByb21wdE1lc3NhZ2UobnVsbCksIDMwMDApO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUdyYW50QWxsID0gKCkgPT4ge1xuICAgIHNldFBlcm1pc3Npb25zKChwcmV2KSA9PiBwcmV2Lm1hcCgocCkgPT4gKHsgLi4ucCwgZ3JhbnRlZDogdHJ1ZSB9KSkpO1xuICAgIHNldFByb21wdE1lc3NhZ2UoJ0FsbCBmb3JlZ3JvdW5kIHNlcnZpY2UgYW5kIGFudGktdW5pbnN0YWxsIHBlcm1pc3Npb25zIGxvY2tlZCAmIHZlcmlmaWVkIScpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0UHJvbXB0TWVzc2FnZShudWxsKSwgMzAwMCk7XG4gIH07XG5cbiAgY29uc3QgYWxsR3JhbnRlZCA9IHBlcm1pc3Npb25zLmV2ZXJ5KChwKSA9PiBwLmdyYW50ZWQpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTN4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcC01IHNoYWRvdy1zbSBzcGFjZS15LTVcIj5cbiAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwYi00XCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLXhsIGJnLWJsdWUtMTAwIGRhcms6YmctYmx1ZS05MDAvNDAgdGV4dC1ibHVlLTYwMCBkYXJrOnRleHQtYmx1ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJhc2UgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAgICBBbmRyb2lkIFJ1bnRpbWUgUGVybWlzc2lvbnMgJiBGb3JlZ3JvdW5kIFNlcnZpY2VzXG4gICAgICAgICAgICA8L2gzPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBtdC0xXCI+XG4gICAgICAgICAgICBQZXJtYW5lbnQgcGVybWlzc2lvbiBwZXJzaXN0ZW5jZS4gRGlzYWJsZXMgQW5kcm9pZCBEb3plIGtpbGxzIGFuZCBhdXRvLXJldm9jYXRpb24uXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAge2FsbEdyYW50ZWQgPyAoXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTEwMCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIHRleHQteHMgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCBmb250LWJvbGQgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTMwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gQWxsIFBlcm1pc3Npb25zIEVuZm9yY2VkXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlR3JhbnRBbGx9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNzAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgc2hhZG93LXNtIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgR3JhbnQgQWxsIFBlcm1pc3Npb25zXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7cHJvbXB0TWVzc2FnZSAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS01MCBkYXJrOmJnLWJsdWUtOTUwLzQwIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgZGFyazpib3JkZXItYmx1ZS05MDAgcm91bmRlZC14bCBwLTMgdGV4dC14cyB0ZXh0LWJsdWUtODAwIGRhcms6dGV4dC1ibHVlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBhbmltYXRlLWluIGZhZGUtaW5cIj5cbiAgICAgICAgICA8SW5mbyBjbGFzc05hbWU9XCJ3LTQgaC00IHNocmluay0wIHRleHQtYmx1ZS02MDBcIiAvPlxuICAgICAgICAgIDxzcGFuPntwcm9tcHRNZXNzYWdlfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogUGVybWlzc2lvbnMgTGlzdCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtMy41XCI+XG4gICAgICAgIHtwZXJtaXNzaW9ucy5tYXAoKHBlcm0pID0+IHtcbiAgICAgICAgICBjb25zdCBJY29uID0gcGVybS5pY29uO1xuICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgIGtleT17cGVybS5pZH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC00IHJvdW5kZWQtMnhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgIHBlcm0uZ3JhbnRlZFxuICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MC80MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzIwIGJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTkwMC82MCdcbiAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzQwIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctOSBoLTkgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaHJpbmstMCAke1xuICAgICAgICAgICAgICAgICAgICAgIHBlcm0uZ3JhbnRlZFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC0xMDAgZGFyazpiZy1lbWVyYWxkLTkwMC80MCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTUwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteHMgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtwZXJtLm5hbWV9XG4gICAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBibG9jayBicmVhay1hbGxcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7cGVybS5hbmRyb2lkUGVybWlzc2lvbn1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVUb2dnbGVQZXJtaXNzaW9uKHBlcm0uaWQpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMi41IHB5LTEgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICBwZXJtLmdyYW50ZWRcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTMwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtwZXJtLmdyYW50ZWQgPyAnQWN0aXZlJyA6ICdHcmFudCd9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbXQtMi41IGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgIHtwZXJtLmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApO1xuICAgICAgICB9KX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQW5kcm9pZCAxNCBQb2xpY3kgR3VhcmFudGVlICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAvNjAgcm91bmRlZC0yeGwgcC00IHRleHQteHMgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgc3BhY2UteS0yXCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGJsb2NrXCI+XG4gICAgICAgICAg8J+UkiBQcmV2ZW50aW9uIG9mIFBlcm1pc3Npb24gQXV0by1SZXNldCAmIFNlcnZpY2UgS2lsbHMgKEFuZHJvaWQgMTHigJMxNCk6XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPHVsIGNsYXNzTmFtZT1cImxpc3QtZGlzYyBsaXN0LWluc2lkZSBzcGFjZS15LTEgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgIDxsaT48c3Ryb25nPkZvcmVncm91bmQgU2VydmljZSBOb3RpZmljYXRpb25zOjwvc3Ryb25nPiBMb2NhdGlvbiBhbmQgQ2FtZXJhIHJ1biB3aXRoIG9uZ29pbmcsIGhpZ2gtcHJpb3JpdHkgbm90aWZpY2F0aW9ucyB0aGF0IHByZXZlbnQgT1MgcHJvY2VzcyB0ZXJtaW5hdGlvbi48L2xpPlxuICAgICAgICAgIDxsaT48c3Ryb25nPkF1dG8tUmV2b2tlIERpc2FsbG93ZWQ6PC9zdHJvbmc+IFNhZmVLaWRzIHNldHMgPGNvZGU+QVVUT19SRVZPS0VfRElTQUxMT1dFRDwvY29kZT4gc28gcGVybWlzc2lvbnMgbmV2ZXIgZXhwaXJlIGV2ZW4gaWYgdGhlIGFwcCByZW1haW5zIGluIHRoZSBiYWNrZ3JvdW5kLjwvbGk+XG4gICAgICAgICAgPGxpPjxzdHJvbmc+QmF0dGVyeSBPcHRpbWl6YXRpb24gRXhlbXB0aW9uOjwvc3Ryb25nPiBCeXBhc3NlcyBBbmRyb2lkIERvemUgdG8gZW5zdXJlIGluc3RhbnQgU09TIHRyaWdnZXJzIGFuZCAyNC83IGdlb2ZlbmNlIG5vdGlmaWNhdGlvbnMuPC9saT5cbiAgICAgICAgPC91bD5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==