const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=d3d47fa4";
import { Shield, Plus, Trash2, X } from "/node_modules/.vite/deps/lucide-react.js?v=d3d47fa4";
import { updateSafeZones } from "/src/services/api.ts";
var _jsxFileName = "/app/applet/src/components/SafeZonesModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d3d47fa4";
export const SafeZonesModal = ({ isOpen, childId, currentZones, currentLatitude, currentLongitude, onClose, onSaved }) => {
	const [zones, setZones] = useState(currentZones);
	const [newZoneName, setNewZoneName] = useState("");
	const [newRadius, setNewRadius] = useState(250);
	const [newLat, setNewLat] = useState(currentLatitude);
	const [newLng, setNewLng] = useState(currentLongitude);
	const [isSaving, setIsSaving] = useState(false);
	if (!isOpen) return null;
	const handleToggleZone = (id) => {
		setZones(zones.map((z) => z.id === id ? {
			...z,
			enabled: !z.enabled
		} : z));
	};
	const handleDeleteZone = (id) => {
		setZones(zones.filter((z) => z.id !== id));
	};
	const handleAddZone = () => {
		if (!newZoneName.trim()) return;
		const newZone = {
			id: `zone-${Date.now()}`,
			name: newZoneName.trim(),
			latitude: newLat,
			longitude: newLng,
			radiusMeters: newRadius,
			icon: "Home",
			enabled: true
		};
		setZones([...zones, newZone]);
		setNewZoneName("");
	};
	const handleSave = async () => {
		setIsSaving(true);
		await updateSafeZones(childId, zones);
		setIsSaving(false);
		onSaved();
		onClose();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl animate-in zoom-in-95 max-h-[90vh] overflow-y-auto",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center",
							children: /* @__PURE__ */ _jsxDEV(Shield, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-bold text-base text-slate-900 dark:text-slate-100",
							children: "Safe Zones & Geofencing"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 dark:text-slate-400",
							children: "Get alerted when child enters or leaves these zones"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded-lg",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs font-bold text-slate-500 uppercase tracking-wider block",
						children: [
							"Active Geofences (",
							zones.length,
							")"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						children: zones.map((zone) => /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "checkbox",
									checked: zone.enabled,
									onChange: () => handleToggleZone(zone.id),
									className: "w-4 h-4 text-emerald-600 rounded border-slate-300 dark:border-slate-600 focus:ring-emerald-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 104,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-semibold text-xs text-slate-800 dark:text-slate-200 block",
									children: zone.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 111,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] text-slate-500 dark:text-slate-400",
									children: [
										"Radius: ",
										zone.radiusMeters,
										"m • ",
										zone.latitude.toFixed(4),
										", ",
										zone.longitude.toFixed(4)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 21
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 110,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 103,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleDeleteZone(zone.id),
								className: "p-1.5 text-slate-400 hover:text-rose-500 transition-colors",
								title: "Delete Zone",
								children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 17
							}, this)]
						}, zone.id, true, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "border-t border-slate-100 dark:border-slate-800 pt-4 space-y-3",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-slate-700 dark:text-slate-300 block",
							children: "Add New Safe Zone"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 134,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "font-medium text-slate-600 dark:text-slate-400 block mb-1",
								children: "Zone Label"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: newZoneName,
								onChange: (e) => setNewZoneName(e.target.value),
								placeholder: "e.g. Grandma's House, Soccer Field...",
								className: "w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "font-medium text-slate-600 dark:text-slate-400 block mb-1",
								children: "Radius (Meters)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("select", {
								value: newRadius,
								onChange: (e) => setNewRadius(parseInt(e.target.value, 10)),
								className: "w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200",
								children: [
									/* @__PURE__ */ _jsxDEV("option", {
										value: 100,
										children: "100 meters (Building)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 160,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: 200,
										children: "200 meters (Block)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 161,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: 300,
										children: "300 meters (Neighborhood)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 162,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: 500,
										children: "500 meters (School Campus)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 163,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("option", {
										value: 1e3,
										children: "1,000 meters (1 km)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 164,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 151,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between text-xs text-slate-500 bg-slate-50 dark:bg-slate-800/40 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: [
								"Using Child's Current GPS (",
								newLat.toFixed(4),
								", ",
								newLng.toFixed(4),
								")"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: handleAddZone,
								disabled: !newZoneName.trim(),
								className: "px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold flex items-center gap-1 transition-colors disabled:opacity-50",
								children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 177,
									columnNumber: 15
								}, this), " Add Zone"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 171,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 169,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 133,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex gap-2 pt-2",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "flex-1 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold",
						children: "Cancel"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 183,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleSave,
						disabled: isSaving,
						className: "flex-1 py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-sm",
						children: "Save Geofences"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 182,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 69,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 68,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLFFBQVEsTUFBTSxRQUFnQixTQUE2QjtBQUVwRSxTQUFTLHVCQUF1Qjs7O0FBWWhDLE9BQU8sTUFBTSxrQkFBaUQsRUFDNUQsUUFDQSxTQUNBLGNBQ0EsaUJBQ0Esa0JBQ0EsU0FDQSxjQUNJO0NBQ0osTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFxQixZQUFZO0NBQzNELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsR0FBRztDQUM5QyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsZUFBZTtDQUNwRCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsZ0JBQWdCO0NBQ3JELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxLQUFLO0NBRTlDLElBQUksQ0FBQyxRQUFRLE9BQU87Q0FFcEIsTUFBTSxvQkFBb0IsT0FBZTtFQUN2QyxTQUNFLE1BQU0sS0FBSyxNQUFPLEVBQUUsT0FBTyxLQUFLO0dBQUUsR0FBRztHQUFHLFNBQVMsQ0FBQyxFQUFFO0VBQVEsSUFBSSxDQUFFLENBQ3BFO0NBQ0Y7Q0FFQSxNQUFNLG9CQUFvQixPQUFlO0VBQ3ZDLFNBQVMsTUFBTSxRQUFRLE1BQU0sRUFBRSxPQUFPLEVBQUUsQ0FBQztDQUMzQztDQUVBLE1BQU0sc0JBQXNCO0VBQzFCLElBQUksQ0FBQyxZQUFZLEtBQUssR0FBRztFQUN6QixNQUFNLFVBQW9CO0dBQ3hCLElBQUksUUFBUSxLQUFLLElBQUk7R0FDckIsTUFBTSxZQUFZLEtBQUs7R0FDdkIsVUFBVTtHQUNWLFdBQVc7R0FDWCxjQUFjO0dBQ2QsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUNBLFNBQVMsQ0FBQyxHQUFHLE9BQU8sT0FBTyxDQUFDO0VBQzVCLGVBQWUsRUFBRTtDQUNuQjtDQUVBLE1BQU0sYUFBYSxZQUFZO0VBQzdCLFlBQVksSUFBSTtFQUNoQixNQUFNLGdCQUFnQixTQUFTLEtBQUs7RUFDcEMsWUFBWSxLQUFLO0VBQ2pCLFFBQVE7RUFDUixRQUFRO0NBQ1Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7O01BQzFCOzs7O2dCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBeUQ7TUFFbkU7Ozs7Z0JBQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTZDO01BRXZEOzs7O2NBQ0E7Ozs7Y0FDRjs7Ozs7ZUFDTCx3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7S0FDbEI7Ozs7YUFDTDs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQjtPQUFrRjtPQUM3RCxNQUFNO09BQU87TUFDNUI7Ozs7O2VBQ04sd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osTUFBTSxLQUFLLFNBQ1Ysd0JBQUMsT0FBRDtPQUVFLFdBQVU7aUJBRlosQ0FJRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsU0FBUyxLQUFLO1NBQ2QsZ0JBQWdCLGlCQUFpQixLQUFLLEVBQUU7U0FDeEMsV0FBVTtRQUNYOzs7O2tCQUNELHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFDYixLQUFLO1FBQ0Y7Ozs7a0JBQ04sd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCO1VBQWlFO1VBQ3RELEtBQUs7VUFBYTtVQUFLLEtBQUssU0FBUyxRQUFRLENBQUM7VUFBRTtVQUFHLEtBQUssVUFBVSxRQUFRLENBQUM7U0FDaEY7Ozs7O2dCQUNIOzs7O2dCQUNGOzs7OztpQkFFTCx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxpQkFBaUIsS0FBSyxFQUFFO1FBQ3ZDLFdBQVU7UUFDVixPQUFNO2tCQUVOLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7O09BQ3ZCOzs7O2VBQ0w7U0EzQkUsS0FBSzs7OzthQTJCUCxDQUNOO0tBQ0U7Ozs7YUFDRjs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUE2RDtNQUV2RTs7Ozs7TUFFTix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FFdEU7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLEtBQUs7UUFDOUMsYUFBWTtRQUNaLFdBQVU7T0FDWDs7OztlQUNFOzs7O2lCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBNEQ7T0FFdEU7Ozs7aUJBQ1Asd0JBQUMsVUFBRDtRQUNFLE9BQU87UUFDUCxXQUFXLE1BQU0sYUFBYSxTQUFTLEVBQUUsT0FBTyxPQUFPLEVBQUUsQ0FBQztRQUMxRCxXQUFVO2tCQUhaO1NBS0Usd0JBQUMsVUFBRDtVQUFRLE9BQU87b0JBQUs7U0FBNkI7Ozs7O1NBQ2pELHdCQUFDLFVBQUQ7VUFBUSxPQUFPO29CQUFLO1NBQTBCOzs7OztTQUM5Qyx3QkFBQyxVQUFEO1VBQVEsT0FBTztvQkFBSztTQUFpQzs7Ozs7U0FDckQsd0JBQUMsVUFBRDtVQUFRLE9BQU87b0JBQUs7U0FBa0M7Ozs7O1NBQ3RELHdCQUFDLFVBQUQ7VUFBUSxPQUFPO29CQUFNO1NBQTJCOzs7OztRQUMxQzs7Ozs7ZUFDTDs7OztlQUNGOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTTtRQUFpQyxPQUFPLFFBQVEsQ0FBQztRQUFFO1FBQUcsT0FBTyxRQUFRLENBQUM7UUFBRTtPQUFPOzs7O2lCQUNyRix3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLFNBQVM7UUFDVCxVQUFVLENBQUMsWUFBWSxLQUFLO1FBQzVCLFdBQVU7a0JBSlosQ0FNRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O2tCQUFDLFdBQzFCOzs7OztlQUNMOzs7Ozs7S0FDRjs7Ozs7O0lBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFDWDtLQUVPOzs7O2VBQ1Isd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxVQUFVO01BQ1YsV0FBVTtnQkFDWDtLQUVPOzs7O2FBQ0w7Ozs7OztHQUNGOzs7Ozs7Q0FDRjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTYWZlWm9uZXNNb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgU2hpZWxkLCBQbHVzLCBUcmFzaDIsIE1hcFBpbiwgWCwgQ2hlY2ssIEFsZXJ0Q2lyY2xlIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IFNhZmVab25lIH0gZnJvbSAnLi4vdHlwZXMvc2FmZWtpZHMnO1xuaW1wb3J0IHsgdXBkYXRlU2FmZVpvbmVzIH0gZnJvbSAnLi4vc2VydmljZXMvYXBpJztcblxuaW50ZXJmYWNlIFNhZmVab25lc01vZGFsUHJvcHMge1xuICBpc09wZW46IGJvb2xlYW47XG4gIGNoaWxkSWQ6IHN0cmluZztcbiAgY3VycmVudFpvbmVzOiBTYWZlWm9uZVtdO1xuICBjdXJyZW50TGF0aXR1ZGU6IG51bWJlcjtcbiAgY3VycmVudExvbmdpdHVkZTogbnVtYmVyO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBvblNhdmVkOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgU2FmZVpvbmVzTW9kYWw6IFJlYWN0LkZDPFNhZmVab25lc01vZGFsUHJvcHM+ID0gKHtcbiAgaXNPcGVuLFxuICBjaGlsZElkLFxuICBjdXJyZW50Wm9uZXMsXG4gIGN1cnJlbnRMYXRpdHVkZSxcbiAgY3VycmVudExvbmdpdHVkZSxcbiAgb25DbG9zZSxcbiAgb25TYXZlZCxcbn0pID0+IHtcbiAgY29uc3QgW3pvbmVzLCBzZXRab25lc10gPSB1c2VTdGF0ZTxTYWZlWm9uZVtdPihjdXJyZW50Wm9uZXMpO1xuICBjb25zdCBbbmV3Wm9uZU5hbWUsIHNldE5ld1pvbmVOYW1lXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW25ld1JhZGl1cywgc2V0TmV3UmFkaXVzXSA9IHVzZVN0YXRlKDI1MCk7XG4gIGNvbnN0IFtuZXdMYXQsIHNldE5ld0xhdF0gPSB1c2VTdGF0ZShjdXJyZW50TGF0aXR1ZGUpO1xuICBjb25zdCBbbmV3TG5nLCBzZXROZXdMbmddID0gdXNlU3RhdGUoY3VycmVudExvbmdpdHVkZSk7XG4gIGNvbnN0IFtpc1NhdmluZywgc2V0SXNTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGlmICghaXNPcGVuKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBoYW5kbGVUb2dnbGVab25lID0gKGlkOiBzdHJpbmcpID0+IHtcbiAgICBzZXRab25lcyhcbiAgICAgIHpvbmVzLm1hcCgoeikgPT4gKHouaWQgPT09IGlkID8geyAuLi56LCBlbmFibGVkOiAhei5lbmFibGVkIH0gOiB6KSlcbiAgICApO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZVpvbmUgPSAoaWQ6IHN0cmluZykgPT4ge1xuICAgIHNldFpvbmVzKHpvbmVzLmZpbHRlcigoeikgPT4gei5pZCAhPT0gaWQpKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVBZGRab25lID0gKCkgPT4ge1xuICAgIGlmICghbmV3Wm9uZU5hbWUudHJpbSgpKSByZXR1cm47XG4gICAgY29uc3QgbmV3Wm9uZTogU2FmZVpvbmUgPSB7XG4gICAgICBpZDogYHpvbmUtJHtEYXRlLm5vdygpfWAsXG4gICAgICBuYW1lOiBuZXdab25lTmFtZS50cmltKCksXG4gICAgICBsYXRpdHVkZTogbmV3TGF0LFxuICAgICAgbG9uZ2l0dWRlOiBuZXdMbmcsXG4gICAgICByYWRpdXNNZXRlcnM6IG5ld1JhZGl1cyxcbiAgICAgIGljb246ICdIb21lJyxcbiAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgfTtcbiAgICBzZXRab25lcyhbLi4uem9uZXMsIG5ld1pvbmVdKTtcbiAgICBzZXROZXdab25lTmFtZSgnJyk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU2F2ZSA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRJc1NhdmluZyh0cnVlKTtcbiAgICBhd2FpdCB1cGRhdGVTYWZlWm9uZXMoY2hpbGRJZCwgem9uZXMpO1xuICAgIHNldElzU2F2aW5nKGZhbHNlKTtcbiAgICBvblNhdmVkKCk7XG4gICAgb25DbG9zZSgpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzcwIGJhY2tkcm9wLWJsdXItc20gei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIG1heC13LWxnIHctZnVsbCBwLTYgc3BhY2UteS01IHNoYWRvdy0yeGwgYW5pbWF0ZS1pbiB6b29tLWluLTk1IG1heC1oLVs5MHZoXSBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcGItM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLXhsIGJnLWVtZXJhbGQtMTAwIGRhcms6YmctZW1lcmFsZC05MDAvNDAgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgPFNoaWVsZCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJhc2UgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAgICAgIFNhZmUgWm9uZXMgJiBHZW9mZW5jaW5nXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgIEdldCBhbGVydGVkIHdoZW4gY2hpbGQgZW50ZXJzIG9yIGxlYXZlcyB0aGVzZSB6b25lc1xuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCBwLTEgcm91bmRlZC1sZ1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBFeGlzdGluZyBab25lcyBMaXN0ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBibG9ja1wiPlxuICAgICAgICAgICAgQWN0aXZlIEdlb2ZlbmNlcyAoe3pvbmVzLmxlbmd0aH0pXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICB7em9uZXMubWFwKCh6b25lKSA9PiAoXG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBrZXk9e3pvbmUuaWR9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC80MFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17em9uZS5lbmFibGVkfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gaGFuZGxlVG9nZ2xlWm9uZSh6b25lLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNjAwIHJvdW5kZWQgYm9yZGVyLXNsYXRlLTMwMCBkYXJrOmJvcmRlci1zbGF0ZS02MDAgZm9jdXM6cmluZy1lbWVyYWxkLTUwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXhzIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgYmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7em9uZS5uYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICBSYWRpdXM6IHt6b25lLnJhZGl1c01ldGVyc31tIOKAoiB7em9uZS5sYXRpdHVkZS50b0ZpeGVkKDQpfSwge3pvbmUubG9uZ2l0dWRlLnRvRml4ZWQoNCl9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlWm9uZSh6b25lLmlkKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtcm9zZS01MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJEZWxldGUgWm9uZVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEFkZCBOZXcgWm9uZSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwdC00IHNwYWNlLXktM1wiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgYmxvY2tcIj5cbiAgICAgICAgICAgIEFkZCBOZXcgU2FmZSBab25lXG4gICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0zIHRleHQteHNcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5cbiAgICAgICAgICAgICAgICBab25lIExhYmVsXG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bmV3Wm9uZU5hbWV9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdab25lTmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIEdyYW5kbWEncyBIb3VzZSwgU29jY2VyIEZpZWxkLi4uXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+XG4gICAgICAgICAgICAgICAgUmFkaXVzIChNZXRlcnMpXG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICB2YWx1ZT17bmV3UmFkaXVzfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3UmFkaXVzKHBhcnNlSW50KGUudGFyZ2V0LnZhbHVlLCAxMCkpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPXsxMDB9PjEwMCBtZXRlcnMgKEJ1aWxkaW5nKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezIwMH0+MjAwIG1ldGVycyAoQmxvY2spPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17MzAwfT4zMDAgbWV0ZXJzIChOZWlnaGJvcmhvb2QpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT17NTAwfT41MDAgbWV0ZXJzIChTY2hvb2wgQ2FtcHVzKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9ezEwMDB9PjEsMDAwIG1ldGVycyAoMSBrbSk8L29wdGlvbj5cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgdGV4dC1zbGF0ZS01MDAgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNDAgcC0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgIDxzcGFuPlVzaW5nIENoaWxkJmFwb3M7cyBDdXJyZW50IEdQUyAoe25ld0xhdC50b0ZpeGVkKDQpfSwge25ld0xuZy50b0ZpeGVkKDQpfSk8L3NwYW4+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVBZGRab25lfVxuICAgICAgICAgICAgICBkaXNhYmxlZD17IW5ld1pvbmVOYW1lLnRyaW0oKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC03MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGZvbnQtc2VtaWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdHJhbnNpdGlvbi1jb2xvcnMgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gQWRkIFpvbmVcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgcHQtMlwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMi41IHB4LTQgYmctc2xhdGUtMTAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTgwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTYXZlfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU2F2aW5nfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTIuNSBweC00IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNzAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgc2hhZG93LXNtXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBTYXZlIEdlb2ZlbmNlc1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==