const React = __vite__cjsImport0_react; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const L = __vite__cjsImport1_leaflet;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=d3d47fa4";
import __vite__cjsImport1_leaflet from "/node_modules/.vite/deps/leaflet.js?v=d3d47fa4";
var _jsxFileName = "/app/applet/src/components/SafeKidsMap.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d3d47fa4";
export const SafeKidsMap = ({ location, safeZones, locationHistory = [], childName, isOnline, batteryLevel, onZoneClick, className = "h-96 w-full rounded-2xl overflow-hidden shadow-sm border border-slate-200 dark:border-slate-800" }) => {
	const mapContainerRef = useRef(null);
	const mapInstanceRef = useRef(null);
	const markerRef = useRef(null);
	const accuracyCircleRef = useRef(null);
	const zonesLayerGroupRef = useRef(null);
	const historyPolylineRef = useRef(null);
	useEffect(() => {
		if (!mapContainerRef.current) return;
		try {
			if (!mapInstanceRef.current) {
				// Initialize Leaflet map
				const map = L.map(mapContainerRef.current, {
					center: [location.latitude, location.longitude],
					zoom: 15,
					zoomControl: true
				});
				// Free OpenStreetMap CartoDB Positron / OSM Standard tiles
				L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
					attribution: "&copy; <a href=\"https://www.openstreetmap.org/copyright\">OpenStreetMap</a> contributors",
					maxZoom: 19
				}).addTo(map);
				zonesLayerGroupRef.current = L.layerGroup().addTo(map);
				mapInstanceRef.current = map;
			}
			const map = mapInstanceRef.current;
			// Update Child Marker
			const customIcon = L.divIcon({
				className: "custom-child-pin",
				html: `
        <div style="position: relative; display: flex; flex-direction: column; align-items: center; transform: translate(-50%, -100%);">
          <div style="
            background: #2563eb; 
            color: white; 
            font-size: 11px; 
            font-weight: 700; 
            padding: 3px 8px; 
            border-radius: 9999px; 
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.2); 
            white-space: nowrap; 
            margin-bottom: 4px;
            display: flex;
            align-items: center;
            gap: 4px;
            border: 1px solid rgba(255,255,255,0.4);
          ">
            <span style="width: 7px; height: 7px; border-radius: 9999px; background: ${isOnline ? "#22c55e" : "#94a3b8"};"></span>
            ${childName} (${batteryLevel}%)
          </div>
          <div style="
            width: 38px; 
            height: 38px; 
            border-radius: 9999px; 
            background: #3b82f6; 
            border: 3px solid white; 
            box-shadow: 0 10px 15px -3px rgba(37, 99, 235, 0.4); 
            display: flex; 
            align-items: center; 
            justify-content: center;
            font-size: 18px;
          ">
            👦
          </div>
          <div style="
            width: 0; 
            height: 0; 
            border-left: 6px solid transparent; 
            border-right: 6px solid transparent; 
            border-top: 8px solid #3b82f6;
          "></div>
        </div>
      `,
				iconSize: [0, 0]
			});
			if (markerRef.current) {
				markerRef.current.setLatLng([location.latitude, location.longitude]);
				markerRef.current.setIcon(customIcon);
			} else {
				markerRef.current = L.marker([location.latitude, location.longitude], { icon: customIcon }).addTo(map);
			}
			// Accuracy Circle
			if (accuracyCircleRef.current) {
				accuracyCircleRef.current.setLatLng([location.latitude, location.longitude]);
				accuracyCircleRef.current.setRadius(location.accuracy || 15);
			} else {
				accuracyCircleRef.current = L.circle([location.latitude, location.longitude], {
					radius: location.accuracy || 15,
					color: "#3b82f6",
					fillColor: "#93c5fd",
					fillOpacity: .18,
					weight: 1
				}).addTo(map);
			}
			// Render Safe Zones
			if (zonesLayerGroupRef.current) {
				zonesLayerGroupRef.current.clearLayers();
				safeZones.forEach((zone) => {
					if (!zone.enabled) return;
					const circle = L.circle([zone.latitude, zone.longitude], {
						radius: zone.radiusMeters,
						color: "#10b981",
						fillColor: "#6ee7b7",
						fillOpacity: .22,
						dashArray: "4, 6",
						weight: 2
					});
					circle.bindTooltip(`<b>🛡️ Safe Zone:</b> ${zone.name} (${zone.radiusMeters}m)`, {
						permanent: false,
						direction: "top"
					});
					if (onZoneClick) {
						circle.on("click", () => onZoneClick(zone));
					}
					circle.addTo(zonesLayerGroupRef.current);
				});
			}
			// Render Location History Breadcrumbs
			if (locationHistory.length > 1) {
				const latlngs = locationHistory.map((h) => [h.latitude, h.longitude]);
				if (historyPolylineRef.current) {
					historyPolylineRef.current.setLatLngs(latlngs);
				} else {
					historyPolylineRef.current = L.polyline(latlngs, {
						color: "#6366f1",
						weight: 3,
						opacity: .7,
						dashArray: "5, 8"
					}).addTo(map);
				}
			}
			map.panTo([location.latitude, location.longitude], {
				animate: true,
				duration: .5
			});
		} catch (err) {
			console.warn("Leaflet map rendering warning:", err);
		}
	}, [
		location,
		safeZones,
		locationHistory,
		childName,
		isOnline,
		batteryLevel
	]);
	// Clean up on unmount
	useEffect(() => {
		return () => {
			if (mapInstanceRef.current) {
				mapInstanceRef.current.remove();
				mapInstanceRef.current = null;
			}
		};
	}, []);
	return /* @__PURE__ */ _jsxDEV("div", {
		ref: mapContainerRef,
		className
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 185,
		columnNumber: 10
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFdBQVcsY0FBYztBQUN6QyxPQUFPLE9BQU87OztBQWNkLE9BQU8sTUFBTSxlQUEyQyxFQUN0RCxVQUNBLFdBQ0Esa0JBQWtCLENBQUMsR0FDbkIsV0FDQSxVQUNBLGNBQ0EsYUFDQSxZQUFZLHdHQUNSO0NBQ0osTUFBTSxrQkFBa0IsT0FBdUIsSUFBSTtDQUNuRCxNQUFNLGlCQUFpQixPQUFxQixJQUFJO0NBQ2hELE1BQU0sWUFBWSxPQUF3QixJQUFJO0NBQzlDLE1BQU0sb0JBQW9CLE9BQXdCLElBQUk7Q0FDdEQsTUFBTSxxQkFBcUIsT0FBNEIsSUFBSTtDQUMzRCxNQUFNLHFCQUFxQixPQUEwQixJQUFJO0NBRXpELGdCQUFnQjtFQUNkLElBQUksQ0FBQyxnQkFBZ0IsU0FBUztFQUU5QixJQUFJO0dBQ0YsSUFBSSxDQUFDLGVBQWUsU0FBUzs7SUFFM0IsTUFBTSxNQUFNLEVBQUUsSUFBSSxnQkFBZ0IsU0FBUztLQUN6QyxRQUFRLENBQUMsU0FBUyxVQUFVLFNBQVMsU0FBUztLQUM5QyxNQUFNO0tBQ04sYUFBYTtJQUNmLENBQUM7O0lBR0gsRUFBRSxVQUFVLHNEQUFzRDtLQUNoRSxhQUFhO0tBQ2IsU0FBUztJQUNYLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRztJQUVaLG1CQUFtQixVQUFVLEVBQUUsV0FBVyxDQUFDLENBQUMsTUFBTSxHQUFHO0lBQ3JELGVBQWUsVUFBVTtHQUMzQjtHQUVBLE1BQU0sTUFBTSxlQUFlOztHQUczQixNQUFNLGFBQWEsRUFBRSxRQUFRO0lBQzNCLFdBQVc7SUFDWCxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Ozt1RkFpQjJFLFdBQVcsWUFBWSxVQUFVO2NBQzFHLFVBQVUsSUFBSSxhQUFhOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lBeUJuQyxVQUFVLENBQUMsR0FBRyxDQUFDO0dBQ2pCLENBQUM7R0FFRCxJQUFJLFVBQVUsU0FBUztJQUNyQixVQUFVLFFBQVEsVUFBVSxDQUFDLFNBQVMsVUFBVSxTQUFTLFNBQVMsQ0FBQztJQUNuRSxVQUFVLFFBQVEsUUFBUSxVQUFVO0dBQ3RDLE9BQU87SUFDTCxVQUFVLFVBQVUsRUFBRSxPQUFPLENBQUMsU0FBUyxVQUFVLFNBQVMsU0FBUyxHQUFHLEVBQUUsTUFBTSxXQUFXLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRztHQUN2Rzs7R0FHQSxJQUFJLGtCQUFrQixTQUFTO0lBQzdCLGtCQUFrQixRQUFRLFVBQVUsQ0FBQyxTQUFTLFVBQVUsU0FBUyxTQUFTLENBQUM7SUFDM0Usa0JBQWtCLFFBQVEsVUFBVSxTQUFTLFlBQVksRUFBRTtHQUM3RCxPQUFPO0lBQ0wsa0JBQWtCLFVBQVUsRUFBRSxPQUFPLENBQUMsU0FBUyxVQUFVLFNBQVMsU0FBUyxHQUFHO0tBQzVFLFFBQVEsU0FBUyxZQUFZO0tBQzdCLE9BQU87S0FDUCxXQUFXO0tBQ1gsYUFBYTtLQUNiLFFBQVE7SUFDVixDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUc7R0FDZDs7R0FHQSxJQUFJLG1CQUFtQixTQUFTO0lBQzlCLG1CQUFtQixRQUFRLFlBQVk7SUFDdkMsVUFBVSxTQUFTLFNBQVM7S0FDMUIsSUFBSSxDQUFDLEtBQUssU0FBUztLQUNuQixNQUFNLFNBQVMsRUFBRSxPQUFPLENBQUMsS0FBSyxVQUFVLEtBQUssU0FBUyxHQUFHO01BQ3ZELFFBQVEsS0FBSztNQUNiLE9BQU87TUFDUCxXQUFXO01BQ1gsYUFBYTtNQUNiLFdBQVc7TUFDWCxRQUFRO0tBQ1YsQ0FBQztLQUVELE9BQU8sWUFBWSx5QkFBeUIsS0FBSyxLQUFLLElBQUksS0FBSyxhQUFhLEtBQUs7TUFDL0UsV0FBVztNQUNYLFdBQVc7S0FDYixDQUFDO0tBRUQsSUFBSSxhQUFhO01BQ2YsT0FBTyxHQUFHLGVBQWUsWUFBWSxJQUFJLENBQUM7S0FDNUM7S0FFQSxPQUFPLE1BQU0sbUJBQW1CLE9BQVE7SUFDMUMsQ0FBQztHQUNIOztHQUdBLElBQUksZ0JBQWdCLFNBQVMsR0FBRztJQUM5QixNQUFNLFVBQThCLGdCQUFnQixLQUFLLE1BQU0sQ0FBQyxFQUFFLFVBQVUsRUFBRSxTQUFTLENBQUM7SUFDeEYsSUFBSSxtQkFBbUIsU0FBUztLQUM5QixtQkFBbUIsUUFBUSxXQUFXLE9BQU87SUFDL0MsT0FBTztLQUNMLG1CQUFtQixVQUFVLEVBQUUsU0FBUyxTQUFTO01BQy9DLE9BQU87TUFDUCxRQUFRO01BQ1IsU0FBUztNQUNULFdBQVc7S0FDYixDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUc7SUFDZDtHQUNGO0dBRUUsSUFBSSxNQUFNLENBQUMsU0FBUyxVQUFVLFNBQVMsU0FBUyxHQUFHO0lBQUUsU0FBUztJQUFNLFVBQVU7R0FBSSxDQUFDO0VBQ3JGLFNBQVMsS0FBSztHQUNaLFFBQVEsS0FBSyxrQ0FBa0MsR0FBRztFQUNwRDtDQUNGLEdBQUc7RUFBQztFQUFVO0VBQVc7RUFBaUI7RUFBVztFQUFVO0NBQVksQ0FBQzs7Q0FHNUUsZ0JBQWdCO0VBQ2QsYUFBYTtHQUNYLElBQUksZUFBZSxTQUFTO0lBQzFCLGVBQWUsUUFBUSxPQUFPO0lBQzlCLGVBQWUsVUFBVTtHQUMzQjtFQUNGO0NBQ0YsR0FBRyxDQUFDLENBQUM7Q0FFTCxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxLQUFLO0VBQTRCO0NBQVk7Ozs7O0FBQzNEIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNhZmVLaWRzTWFwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgTCBmcm9tICdsZWFmbGV0JztcbmltcG9ydCB7IExvY2F0aW9uUG9pbnQsIFNhZmVab25lIH0gZnJvbSAnLi4vdHlwZXMvc2FmZWtpZHMnO1xuXG5pbnRlcmZhY2UgU2FmZUtpZHNNYXBQcm9wcyB7XG4gIGxvY2F0aW9uOiBMb2NhdGlvblBvaW50O1xuICBzYWZlWm9uZXM6IFNhZmVab25lW107XG4gIGxvY2F0aW9uSGlzdG9yeT86IEFycmF5PHsgbGF0aXR1ZGU6IG51bWJlcjsgbG9uZ2l0dWRlOiBudW1iZXI7IHRpbWVzdGFtcDogc3RyaW5nOyBhZGRyZXNzOiBzdHJpbmcgfT47XG4gIGNoaWxkTmFtZTogc3RyaW5nO1xuICBpc09ubGluZTogYm9vbGVhbjtcbiAgYmF0dGVyeUxldmVsOiBudW1iZXI7XG4gIG9uWm9uZUNsaWNrPzogKHpvbmU6IFNhZmVab25lKSA9PiB2b2lkO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBjb25zdCBTYWZlS2lkc01hcDogUmVhY3QuRkM8U2FmZUtpZHNNYXBQcm9wcz4gPSAoe1xuICBsb2NhdGlvbixcbiAgc2FmZVpvbmVzLFxuICBsb2NhdGlvbkhpc3RvcnkgPSBbXSxcbiAgY2hpbGROYW1lLFxuICBpc09ubGluZSxcbiAgYmF0dGVyeUxldmVsLFxuICBvblpvbmVDbGljayxcbiAgY2xhc3NOYW1lID0gJ2gtOTYgdy1mdWxsIHJvdW5kZWQtMnhsIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwJyxcbn0pID0+IHtcbiAgY29uc3QgbWFwQ29udGFpbmVyUmVmID0gdXNlUmVmPEhUTUxEaXZFbGVtZW50PihudWxsKTtcbiAgY29uc3QgbWFwSW5zdGFuY2VSZWYgPSB1c2VSZWY8TC5NYXAgfCBudWxsPihudWxsKTtcbiAgY29uc3QgbWFya2VyUmVmID0gdXNlUmVmPEwuTWFya2VyIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IGFjY3VyYWN5Q2lyY2xlUmVmID0gdXNlUmVmPEwuQ2lyY2xlIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHpvbmVzTGF5ZXJHcm91cFJlZiA9IHVzZVJlZjxMLkxheWVyR3JvdXAgfCBudWxsPihudWxsKTtcbiAgY29uc3QgaGlzdG9yeVBvbHlsaW5lUmVmID0gdXNlUmVmPEwuUG9seWxpbmUgfCBudWxsPihudWxsKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghbWFwQ29udGFpbmVyUmVmLmN1cnJlbnQpIHJldHVybjtcblxuICAgIHRyeSB7XG4gICAgICBpZiAoIW1hcEluc3RhbmNlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgLy8gSW5pdGlhbGl6ZSBMZWFmbGV0IG1hcFxuICAgICAgICBjb25zdCBtYXAgPSBMLm1hcChtYXBDb250YWluZXJSZWYuY3VycmVudCwge1xuICAgICAgICAgIGNlbnRlcjogW2xvY2F0aW9uLmxhdGl0dWRlLCBsb2NhdGlvbi5sb25naXR1ZGVdLFxuICAgICAgICAgIHpvb206IDE1LFxuICAgICAgICAgIHpvb21Db250cm9sOiB0cnVlLFxuICAgICAgICB9KTtcblxuICAgICAgLy8gRnJlZSBPcGVuU3RyZWV0TWFwIENhcnRvREIgUG9zaXRyb24gLyBPU00gU3RhbmRhcmQgdGlsZXNcbiAgICAgIEwudGlsZUxheWVyKCdodHRwczovL3tzfS50aWxlLm9wZW5zdHJlZXRtYXAub3JnL3t6fS97eH0ve3l9LnBuZycsIHtcbiAgICAgICAgYXR0cmlidXRpb246ICcmY29weTsgPGEgaHJlZj1cImh0dHBzOi8vd3d3Lm9wZW5zdHJlZXRtYXAub3JnL2NvcHlyaWdodFwiPk9wZW5TdHJlZXRNYXA8L2E+IGNvbnRyaWJ1dG9ycycsXG4gICAgICAgIG1heFpvb206IDE5LFxuICAgICAgfSkuYWRkVG8obWFwKTtcblxuICAgICAgem9uZXNMYXllckdyb3VwUmVmLmN1cnJlbnQgPSBMLmxheWVyR3JvdXAoKS5hZGRUbyhtYXApO1xuICAgICAgbWFwSW5zdGFuY2VSZWYuY3VycmVudCA9IG1hcDtcbiAgICB9XG5cbiAgICBjb25zdCBtYXAgPSBtYXBJbnN0YW5jZVJlZi5jdXJyZW50O1xuXG4gICAgLy8gVXBkYXRlIENoaWxkIE1hcmtlclxuICAgIGNvbnN0IGN1c3RvbUljb24gPSBMLmRpdkljb24oe1xuICAgICAgY2xhc3NOYW1lOiAnY3VzdG9tLWNoaWxkLXBpbicsXG4gICAgICBodG1sOiBgXG4gICAgICAgIDxkaXYgc3R5bGU9XCJwb3NpdGlvbjogcmVsYXRpdmU7IGRpc3BsYXk6IGZsZXg7IGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47IGFsaWduLWl0ZW1zOiBjZW50ZXI7IHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC0xMDAlKTtcIj5cbiAgICAgICAgICA8ZGl2IHN0eWxlPVwiXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjMjU2M2ViOyBcbiAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTsgXG4gICAgICAgICAgICBmb250LXNpemU6IDExcHg7IFxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDcwMDsgXG4gICAgICAgICAgICBwYWRkaW5nOiAzcHggOHB4OyBcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDk5OTlweDsgXG4gICAgICAgICAgICBib3gtc2hhZG93OiAwIDRweCA2cHggLTFweCByZ2JhKDAsIDAsIDAsIDAuMik7IFxuICAgICAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDsgXG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiA0cHg7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgICAgIGdhcDogNHB4O1xuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgyNTUsMjU1LDI1NSwwLjQpO1xuICAgICAgICAgIFwiPlxuICAgICAgICAgICAgPHNwYW4gc3R5bGU9XCJ3aWR0aDogN3B4OyBoZWlnaHQ6IDdweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4OyBiYWNrZ3JvdW5kOiAke2lzT25saW5lID8gJyMyMmM1NWUnIDogJyM5NGEzYjgnfTtcIj48L3NwYW4+XG4gICAgICAgICAgICAke2NoaWxkTmFtZX0gKCR7YmF0dGVyeUxldmVsfSUpXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBzdHlsZT1cIlxuICAgICAgICAgICAgd2lkdGg6IDM4cHg7IFxuICAgICAgICAgICAgaGVpZ2h0OiAzOHB4OyBcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDk5OTlweDsgXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjM2I4MmY2OyBcbiAgICAgICAgICAgIGJvcmRlcjogM3B4IHNvbGlkIHdoaXRlOyBcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IDAgMTBweCAxNXB4IC0zcHggcmdiYSgzNywgOTksIDIzNSwgMC40KTsgXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4OyBcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7IFxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICAgICAgXCI+XG4gICAgICAgICAgICDwn5GmXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBzdHlsZT1cIlxuICAgICAgICAgICAgd2lkdGg6IDA7IFxuICAgICAgICAgICAgaGVpZ2h0OiAwOyBcbiAgICAgICAgICAgIGJvcmRlci1sZWZ0OiA2cHggc29saWQgdHJhbnNwYXJlbnQ7IFxuICAgICAgICAgICAgYm9yZGVyLXJpZ2h0OiA2cHggc29saWQgdHJhbnNwYXJlbnQ7IFxuICAgICAgICAgICAgYm9yZGVyLXRvcDogOHB4IHNvbGlkICMzYjgyZjY7XG4gICAgICAgICAgXCI+PC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgYCxcbiAgICAgIGljb25TaXplOiBbMCwgMF0sXG4gICAgfSk7XG5cbiAgICBpZiAobWFya2VyUmVmLmN1cnJlbnQpIHtcbiAgICAgIG1hcmtlclJlZi5jdXJyZW50LnNldExhdExuZyhbbG9jYXRpb24ubGF0aXR1ZGUsIGxvY2F0aW9uLmxvbmdpdHVkZV0pO1xuICAgICAgbWFya2VyUmVmLmN1cnJlbnQuc2V0SWNvbihjdXN0b21JY29uKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbWFya2VyUmVmLmN1cnJlbnQgPSBMLm1hcmtlcihbbG9jYXRpb24ubGF0aXR1ZGUsIGxvY2F0aW9uLmxvbmdpdHVkZV0sIHsgaWNvbjogY3VzdG9tSWNvbiB9KS5hZGRUbyhtYXApO1xuICAgIH1cblxuICAgIC8vIEFjY3VyYWN5IENpcmNsZVxuICAgIGlmIChhY2N1cmFjeUNpcmNsZVJlZi5jdXJyZW50KSB7XG4gICAgICBhY2N1cmFjeUNpcmNsZVJlZi5jdXJyZW50LnNldExhdExuZyhbbG9jYXRpb24ubGF0aXR1ZGUsIGxvY2F0aW9uLmxvbmdpdHVkZV0pO1xuICAgICAgYWNjdXJhY3lDaXJjbGVSZWYuY3VycmVudC5zZXRSYWRpdXMobG9jYXRpb24uYWNjdXJhY3kgfHwgMTUpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhY2N1cmFjeUNpcmNsZVJlZi5jdXJyZW50ID0gTC5jaXJjbGUoW2xvY2F0aW9uLmxhdGl0dWRlLCBsb2NhdGlvbi5sb25naXR1ZGVdLCB7XG4gICAgICAgIHJhZGl1czogbG9jYXRpb24uYWNjdXJhY3kgfHwgMTUsXG4gICAgICAgIGNvbG9yOiAnIzNiODJmNicsXG4gICAgICAgIGZpbGxDb2xvcjogJyM5M2M1ZmQnLFxuICAgICAgICBmaWxsT3BhY2l0eTogMC4xOCxcbiAgICAgICAgd2VpZ2h0OiAxLFxuICAgICAgfSkuYWRkVG8obWFwKTtcbiAgICB9XG5cbiAgICAvLyBSZW5kZXIgU2FmZSBab25lc1xuICAgIGlmICh6b25lc0xheWVyR3JvdXBSZWYuY3VycmVudCkge1xuICAgICAgem9uZXNMYXllckdyb3VwUmVmLmN1cnJlbnQuY2xlYXJMYXllcnMoKTtcbiAgICAgIHNhZmVab25lcy5mb3JFYWNoKCh6b25lKSA9PiB7XG4gICAgICAgIGlmICghem9uZS5lbmFibGVkKSByZXR1cm47XG4gICAgICAgIGNvbnN0IGNpcmNsZSA9IEwuY2lyY2xlKFt6b25lLmxhdGl0dWRlLCB6b25lLmxvbmdpdHVkZV0sIHtcbiAgICAgICAgICByYWRpdXM6IHpvbmUucmFkaXVzTWV0ZXJzLFxuICAgICAgICAgIGNvbG9yOiAnIzEwYjk4MScsXG4gICAgICAgICAgZmlsbENvbG9yOiAnIzZlZTdiNycsXG4gICAgICAgICAgZmlsbE9wYWNpdHk6IDAuMjIsXG4gICAgICAgICAgZGFzaEFycmF5OiAnNCwgNicsXG4gICAgICAgICAgd2VpZ2h0OiAyLFxuICAgICAgICB9KTtcblxuICAgICAgICBjaXJjbGUuYmluZFRvb2x0aXAoYDxiPvCfm6HvuI8gU2FmZSBab25lOjwvYj4gJHt6b25lLm5hbWV9ICgke3pvbmUucmFkaXVzTWV0ZXJzfW0pYCwge1xuICAgICAgICAgIHBlcm1hbmVudDogZmFsc2UsXG4gICAgICAgICAgZGlyZWN0aW9uOiAndG9wJyxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKG9uWm9uZUNsaWNrKSB7XG4gICAgICAgICAgY2lyY2xlLm9uKCdjbGljaycsICgpID0+IG9uWm9uZUNsaWNrKHpvbmUpKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNpcmNsZS5hZGRUbyh6b25lc0xheWVyR3JvdXBSZWYuY3VycmVudCEpO1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gUmVuZGVyIExvY2F0aW9uIEhpc3RvcnkgQnJlYWRjcnVtYnNcbiAgICBpZiAobG9jYXRpb25IaXN0b3J5Lmxlbmd0aCA+IDEpIHtcbiAgICAgIGNvbnN0IGxhdGxuZ3M6IFtudW1iZXIsIG51bWJlcl1bXSA9IGxvY2F0aW9uSGlzdG9yeS5tYXAoKGgpID0+IFtoLmxhdGl0dWRlLCBoLmxvbmdpdHVkZV0pO1xuICAgICAgaWYgKGhpc3RvcnlQb2x5bGluZVJlZi5jdXJyZW50KSB7XG4gICAgICAgIGhpc3RvcnlQb2x5bGluZVJlZi5jdXJyZW50LnNldExhdExuZ3MobGF0bG5ncyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBoaXN0b3J5UG9seWxpbmVSZWYuY3VycmVudCA9IEwucG9seWxpbmUobGF0bG5ncywge1xuICAgICAgICAgIGNvbG9yOiAnIzYzNjZmMScsXG4gICAgICAgICAgd2VpZ2h0OiAzLFxuICAgICAgICAgIG9wYWNpdHk6IDAuNyxcbiAgICAgICAgICBkYXNoQXJyYXk6ICc1LCA4JyxcbiAgICAgICAgfSkuYWRkVG8obWFwKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAgIG1hcC5wYW5UbyhbbG9jYXRpb24ubGF0aXR1ZGUsIGxvY2F0aW9uLmxvbmdpdHVkZV0sIHsgYW5pbWF0ZTogdHJ1ZSwgZHVyYXRpb246IDAuNSB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUud2FybignTGVhZmxldCBtYXAgcmVuZGVyaW5nIHdhcm5pbmc6JywgZXJyKTtcbiAgICB9XG4gIH0sIFtsb2NhdGlvbiwgc2FmZVpvbmVzLCBsb2NhdGlvbkhpc3RvcnksIGNoaWxkTmFtZSwgaXNPbmxpbmUsIGJhdHRlcnlMZXZlbF0pO1xuXG4gIC8vIENsZWFuIHVwIG9uIHVubW91bnRcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaWYgKG1hcEluc3RhbmNlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgbWFwSW5zdGFuY2VSZWYuY3VycmVudC5yZW1vdmUoKTtcbiAgICAgICAgbWFwSW5zdGFuY2VSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIHJldHVybiA8ZGl2IHJlZj17bWFwQ29udGFpbmVyUmVmfSBjbGFzc05hbWU9e2NsYXNzTmFtZX0gLz47XG59O1xuIl19