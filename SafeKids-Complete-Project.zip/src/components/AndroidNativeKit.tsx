const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=d3d47fa4";
import { Download, Copy, Check, Code, ShieldCheck, FileText, Smartphone, Terminal } from "/node_modules/.vite/deps/lucide-react.js?v=d3d47fa4";
var _jsxFileName = "/app/applet/src/components/AndroidNativeKit.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d3d47fa4";
const ANDROID_SNIPPETS = [
	{
		filename: "SafeKidsAccessibilityService.kt",
		language: "kotlin",
		description: "Enforces app lock & strict anti-uninstall protection by detecting settings tampering and intercepting uninstaller dialogs.",
		content: `package com.safekids.parentalcontrol.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.safekids.parentalcontrol.ui.AppBlockActivity
import com.safekids.parentalcontrol.ui.ParentPinAuthActivity
import com.safekids.parentalcontrol.repository.RulesRepository
import com.safekids.parentalcontrol.worker.SafeKidsSyncWorker

/**
 * SafeKids Accessibility Service
 * Compliant with Google Play Store accessibility policy for Parental Control apps.
 * Provides strict anti-uninstall protection and app limit enforcement.
 */
class SafeKidsAccessibilityService : AccessibilityService() {

    private lateinit var rulesRepository: RulesRepository

    override fun onCreate() {
        super.onCreate()
        rulesRepository = RulesRepository.getInstance(applicationContext)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            return
        }

        val packageName = event.packageName?.toString() ?: return

        // Ignore self
        if (packageName == applicationContext.packageName) return

        // 🛡️ STRICT ANTI-UNINSTALL PROTECTION:
        // Intercept Android Settings (App Info, Device Admin Apps) & Package Installers
        if (packageName == "com.android.settings" || 
            packageName == "com.google.android.packageinstaller" || 
            packageName == "com.android.packageinstaller") {

            val textContent = event.text.joinToString(" ").lowercase()
            val className = event.className?.toString()?.lowercase() ?: ""

            val isTargetingSafeKids = textContent.contains("safekids") || 
                                     className.contains("installedappdetails") || 
                                     className.contains("deviceadmin")

            val isDangerousAction = textContent.contains("uninstall") || 
                                    textContent.contains("force stop") || 
                                    textContent.contains("clear storage") || 
                                    textContent.contains("clear data") || 
                                    textContent.contains("deactivate")

            if (isTargetingSafeKids || (isDangerousAction && textContent.contains("safekids"))) {
                // Immediately navigate BACK to block the uninstall dialog
                performGlobalAction(GLOBAL_ACTION_BACK)

                // Launch Master Parent PIN verification overlay
                val pinAuthIntent = Intent(this, ParentPinAuthActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra(ParentPinAuthActivity.EXTRA_REASON, "ANTI_UNINSTALL_INTERCEPT")
                    putExtra(ParentPinAuthActivity.EXTRA_MESSAGE, "Master Parent PIN required to uninstall SafeKids or deactivate device protection.")
                }
                startActivity(pinAuthIntent)

                // Report tampering attempt to Parent Dashboard
                SafeKidsSyncWorker.reportTamperAttempt(
                    applicationContext,
                    "Child attempted to access SafeKids uninstall/deactivate settings"
                )
                return
            }
        }

        // Standard App Lock & Bedtime enforcement
        val isLocked = rulesRepository.isPackageLocked(packageName)
        val isBedtime = rulesRepository.isBedtimeActive()

        if (isLocked || isBedtime) {
            val blockIntent = Intent(this, AppBlockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra(AppBlockActivity.EXTRA_BLOCKED_PACKAGE, packageName)
                putExtra(AppBlockActivity.EXTRA_REASON, if (isBedtime) "Bedtime Mode" else "Time Limit Exceeded")
            }
            startActivity(blockIntent)
        }
    }

    override fun onInterrupt() {
        // Service interrupted
    }
}
`
	},
	{
		filename: "SafeKidsDeviceAdminReceiver.kt",
		language: "kotlin",
		description: "Device Administrator receiver preventing app uninstallation at OS level, intercepting deactivation with PIN.",
		content: `package com.safekids.parentalcontrol.receiver

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.safekids.parentalcontrol.ui.ParentPinAuthActivity
import com.safekids.parentalcontrol.worker.SafeKidsSyncWorker

/**
 * SafeKids Device Administrator Receiver
 * Prevents unauthorized uninstallation and enforces PIN protection upon deactivation attempts.
 */
class SafeKidsDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Toast.makeText(context, "🛡️ SafeKids Strict Anti-Uninstall Protection Activated", Toast.LENGTH_LONG).show()

        // If configured as Device Owner via ADB/Knox, enforce permanent OS-level uninstall block
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = ComponentName(context, SafeKidsDeviceAdminReceiver::class.java)
        if (dpm.isDeviceOwnerApp(context.packageName)) {
            dpm.setUninstallBlocked(admin, context.packageName, true)
        }
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence? {
        // Intercept deactivation: report urgent alert to Parent Dashboard
        SafeKidsSyncWorker.reportTamperAttempt(
            context,
            "Deactivate Device Administrator requested on child device"
        )

        // Launch mandatory Parent PIN prompt
        val pinIntent = Intent(context, ParentPinAuthActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(ParentPinAuthActivity.EXTRA_REASON, "DEVICE_ADMIN_DEACTIVATION")
        }
        context.startActivity(pinIntent)

        return "⚠️ CRITICAL SECURITY ALERT: Deactivating SafeKids requires Parent Master PIN verification. Any unauthorized attempt is immediately alerted to parents."
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        // If somehow disabled without PIN, instantly lock device screen and alert parents
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        try {
            dpm.lockNow()
        } catch (e: Exception) {
            // lockNow fallback
        }
        SafeKidsSyncWorker.reportTamperAttempt(context, "Device Admin Deactivated! Device locked for security.")
    }
}
`
	},
	{
		filename: "device_admin_rules.xml",
		language: "xml",
		description: "Device Administrator policy manifest declaring force-lock, wipe-data, and device security capabilities.",
		content: `<?xml version="1.0" encoding="utf-8"?>
<device-admin xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-policies>
        <!-- Allows SafeKids to lock device during bedtime or tampering attempts -->
        <force-lock />
        <!-- Prohibits camera bypass -->
        <disable-camera />
        <!-- Limits password failure resets -->
        <limit-password />
        <watch-login />
        <!-- Protects keyguard -->
        <disable-keyguard-features />
    </uses-policies>
</device-admin>
`
	},
	{
		filename: "SafeKidsDeviceAdminHelper.kt",
		language: "kotlin",
		description: "Helper class for checking Device Admin status and requesting user permission.",
		content: `package com.safekids.parentalcontrol.util

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import com.safekids.parentalcontrol.receiver.SafeKidsDeviceAdminReceiver

object SafeKidsDeviceAdminHelper {

    fun getComponentName(context: Context): ComponentName {
        return ComponentName(context, SafeKidsDeviceAdminReceiver::class.java)
    }

    fun isDeviceAdminActive(context: Context): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(getComponentName(context))
    }

    fun requestDeviceAdminActivation(activity: Activity, requestCode: Int = 2001) {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, getComponentName(activity))
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "SafeKids requires Device Administrator permission to prevent unauthorized app uninstallation by children and ensure 24/7 safety protection."
            )
        }
        activity.startActivityForResult(intent, requestCode)
    }
}
`
	},
	{
		filename: "SafeKidsPermissionHelper.kt",
		language: "kotlin",
		description: "Manages runtime permissions, foreground service declarations, battery optimization whitelist, and disables permission auto-revocation.",
		content: `package com.safekids.parentalcontrol.util

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

object SafeKidsPermissionHelper {

    val REQUIRED_PERMISSIONS = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO
    )

    fun hasAllPermissions(context: Context): Boolean {
        return REQUIRED_PERMISSIONS.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun requestForegroundPermissions(activity: Activity, requestCode: Int = 3001) {
        ActivityCompat.requestPermissions(activity, REQUIRED_PERMISSIONS, requestCode)
    }

    /**
     * Prevents Android 11+ from auto-resetting permissions after inactivity
     */
    fun disablePermissionAutoReset(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val pm = context.packageManager
            try {
                pm.setAutoRevokePermissionsMode(
                    context.packageName,
                    PackageManager.AUTO_REVOKE_DISALLOWED
                )
            } catch (e: Exception) {
                val intent = Intent(Intent.ACTION_AUTO_REVOKE_PERMISSIONS).apply {
                    data = Uri.parse("package:" + context.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        }
    }

    /**
     * Exempts SafeKids from Doze Mode to ensure 24/7 background GPS and SOS alerts
     */
    fun requestIgnoreBatteryOptimization(context: Context) {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!powerManager.isIgnoringBatteryOptimizations(context.packageName)) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:" + context.packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}
`
	},
	{
		filename: "SafeKidsLocationForegroundService.kt",
		language: "kotlin",
		description: "Foreground service for continuous high-accuracy GPS tracking and geofence enter/exit triggers.",
		content: `package com.safekids.parentalcontrol.service

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.safekids.parentalcontrol.R

class SafeKidsLocationForegroundService : Service() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback

    companion object {
        const val CHANNEL_ID = "safekids_location_channel"
        const val NOTIFICATION_ID = 1001
    }

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        createNotificationChannel()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                for (location in result.locations) {
                    // Send to backend and check local geofences
                    SafeKidsSyncWorker.enqueueLocationUpdate(applicationContext, location)
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SafeKids Active")
            .setContentText("Location safety & emergency SOS monitoring active")
            .setSmallIcon(R.drawable.ic_shield)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
        startLocationUpdates()
        return START_STICKY
    }

    private fun startLocationUpdates() {
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 30000)
            .setMinUpdateIntervalMillis(15000)
            .setMinUpdateDistanceMeters(10f)
            .build()

        try {
            fusedLocationClient.requestLocationUpdates(request, locationCallback, Looper.getMainLooper())
        } catch (e: SecurityException) {
            // Permission revoked
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "SafeKids Safety Monitoring",
            NotificationManager.IMPORTANCE_LOW
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
`
	},
	{
		filename: "SafeKidsScreenSharingService.kt",
		language: "kotlin",
		description: "Consent-first Android MediaProjection foreground service for live screen sharing with persistent notification.",
		content: `package com.safekids.parentalcontrol.service

import android.app.*
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.safekids.parentalcontrol.R

class SafeKidsScreenSharingService : Service() {

    private var mediaProjection: MediaProjection? = null

    companion object {
        const val CHANNEL_ID = "safekids_screenshare_channel"
        const val NOTIFICATION_ID = 2002
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SafeKids Screen Sharing")
            .setContentText("Live screen check-in shared with parent")
            .setSmallIcon(R.drawable.ic_cast)
            .setOngoing(true)
            .addAction(R.drawable.ic_stop, "Stop Sharing", getStopPendingIntent())
            .build()

        startForeground(NOTIFICATION_ID, notification)

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

        if (resultCode == Activity.RESULT_OK && resultData != null) {
            val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
            // Stream frames over secure WebRTC peer connection
        }

        return START_NOT_STICKY
    }

    private fun getStopPendingIntent(): PendingIntent {
        val stopIntent = Intent(this, SafeKidsScreenSharingService::class.java).apply {
            action = "ACTION_STOP"
        }
        return PendingIntent.getService(this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE)
    }

    override fun onDestroy() {
        mediaProjection?.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
`
	},
	{
		filename: "AndroidManifest.xml",
		language: "xml",
		description: "Full manifest configured for Android 14 (API 34) with transparent parental control declarations.",
		content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.safekids.parentalcontrol">

    <!-- Location & Safety Permissions -->
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_BACKGROUND_LOCATION" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_CAMERA" />

    <!-- Screen Time & App Management -->
    <uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" />
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />

    <!-- Camera & Audio Permissions for Check-In -->
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:name=".SafeKidsApplication"
        android:allowBackup="false"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.SafeKids">

        <activity
            android:name=".ui.MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <activity
            android:name=".ui.AppBlockActivity"
            android:theme="@style/Theme.SafeKids.Fullscreen"
            android:exported="false" />

        <!-- Accessibility Service for App & Web Guard -->
        <service
            android:name=".service.SafeKidsAccessibilityService"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>

        <!-- Device Admin Receiver -->
        <receiver
            android:name=".receiver.SafeKidsDeviceAdminReceiver"
            android:permission="android.permission.BIND_DEVICE_ADMIN"
            android:exported="true">
            <meta-data
                android:name="android.app.device_admin"
                android:resource="@xml/device_admin_rules" />
            <intent-filter>
                <action android:name="android.app.action.DEVICE_ADMIN_ENABLED" />
            </intent-filter>
        </receiver>

        <!-- Foreground Services -->
        <service
            android:name=".service.SafeKidsLocationForegroundService"
            android:foregroundServiceType="location" />

        <service
            android:name=".service.SafeKidsScreenSharingService"
            android:foregroundServiceType="mediaProjection" />
    </application>
</manifest>
`
	},
	{
		filename: "build.gradle.kts",
		language: "kotlin",
		description: "Gradle build script configured with Kotlin DSL, Jetpack Compose, and CameraX.",
		content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.compose.compiler)
}

android {
    namespace = "com.safekids.parentalcontrol"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.safekids.parentalcontrol"
        minSdk = 26
        targetSdk = 34
        versionCode = 100
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

dependencies {
    // AndroidX & Jetpack Compose
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.material3)

    // Play Services Location & Geofencing
    implementation("com.google.android.gms:play-services-location:21.2.0")

    // CameraX for Live Camera Look-In
    implementation("androidx.camera:camera-core:1.3.3")
    implementation("androidx.camera:camera-camera2:1.3.3")
    implementation("androidx.camera:camera-lifecycle:1.3.3")
    implementation("androidx.camera:camera-view:1.3.3")

    // Coroutines & Lifecycle
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
}
`
	}
];
export const AndroidNativeKit = () => {
	const [selectedSnippet, setSelectedSnippet] = useState(0);
	const [copied, setCopied] = useState(false);
	const [activeTab, setActiveTab] = useState("source");
	const handleCopy = () => {
		navigator.clipboard.writeText(ANDROID_SNIPPETS[selectedSnippet].content);
		setCopied(true);
		setTimeout(() => setCopied(false), 2e3);
	};
	const handleDownload = () => {
		const snippet = ANDROID_SNIPPETS[selectedSnippet];
		const blob = new Blob([snippet.content], { type: "text/plain" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = snippet.filename;
		a.click();
		URL.revokeObjectURL(url);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-700 text-white rounded-2xl p-6 shadow-md",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col md:flex-row md:items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Smartphone, { className: "w-6 h-6 text-blue-200" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 630,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xl font-bold tracking-tight",
								children: "Android Native Architecture & Google Play Release Kit"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 631,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 629,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-sm text-blue-100 max-w-2xl leading-relaxed",
							children: "SafeKids is engineered for real Android deployment. Explore the production Kotlin services, Accessibility & Device Admin policies, Google Play Data Safety answers, and reproducible build scripts."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 635,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 628,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 shrink-0",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "bg-white/20 backdrop-blur-md px-3 py-1.5 rounded-lg text-xs font-semibold border border-white/30",
							children: "Target SDK: 34 (Android 14)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 640,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "bg-emerald-500/80 px-3 py-1.5 rounded-lg text-xs font-semibold",
							children: "100% Free & Open Source"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 643,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 639,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 627,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 mt-6 overflow-x-auto pb-1 border-t border-white/20 pt-4",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("source"),
							className: `px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${activeTab === "source" ? "bg-white text-blue-700 shadow-sm" : "text-blue-100 hover:bg-white/10"}`,
							children: [/* @__PURE__ */ _jsxDEV(Code, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 657,
								columnNumber: 13
							}, this), " Kotlin & XML Source"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 651,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("datasafety"),
							className: `px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${activeTab === "datasafety" ? "bg-white text-blue-700 shadow-sm" : "text-blue-100 hover:bg-white/10"}`,
							children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 665,
								columnNumber: 13
							}, this), " Google Play Data Safety"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 659,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("build"),
							className: `px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${activeTab === "build" ? "bg-white text-blue-700 shadow-sm" : "text-blue-100 hover:bg-white/10"}`,
							children: [/* @__PURE__ */ _jsxDEV(Terminal, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 673,
								columnNumber: 13
							}, this), " Build & Release Guide"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 667,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("privacy"),
							className: `px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap ${activeTab === "privacy" ? "bg-white text-blue-700 shadow-sm" : "text-blue-100 hover:bg-white/10"}`,
							children: [/* @__PURE__ */ _jsxDEV(FileText, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 681,
								columnNumber: 13
							}, this), " COPPA / Privacy Policy"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 675,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 650,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 626,
				columnNumber: 7
			}, this),
			activeTab === "source" && /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-5",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-4 space-y-2",
					children: [/* @__PURE__ */ _jsxDEV("h4", {
						className: "text-xs font-bold text-slate-500 uppercase tracking-wider px-2",
						children: "Android Source Modules"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 691,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-1.5",
						children: ANDROID_SNIPPETS.map((snippet, idx) => /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setSelectedSnippet(idx),
							className: `w-full text-left p-3 rounded-xl border text-xs transition-all ${selectedSnippet === idx ? "bg-blue-50 dark:bg-blue-950/40 border-blue-500 text-blue-900 dark:text-blue-200 font-semibold shadow-sm" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/50"}`,
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono text-xs",
									children: snippet.filename
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 706,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] uppercase font-bold text-slate-400",
									children: snippet.language
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 707,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 705,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-1",
								children: snippet.description
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 711,
								columnNumber: 19
							}, this)]
						}, snippet.filename, true, {
							fileName: _jsxFileName,
							lineNumber: 696,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 694,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 690,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-8 bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-lg flex flex-col",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/90 px-4 py-3 border-b border-slate-800 flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-mono text-xs text-blue-400 font-semibold",
							children: ANDROID_SNIPPETS[selectedSnippet].filename
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 723,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-slate-400",
							children: ANDROID_SNIPPETS[selectedSnippet].description
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 726,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 722,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: handleCopy,
								className: "px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition-colors flex items-center gap-1 border border-slate-700",
								children: [copied ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 735,
									columnNumber: 29
								}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 735,
									columnNumber: 82
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: copied ? "Copied" : "Copy" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 736,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 731,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleDownload,
								className: "px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs rounded-lg transition-colors flex items-center gap-1 font-medium",
								children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 742,
									columnNumber: 19
								}, this), " Download"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 738,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 730,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 721,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("pre", {
						className: "p-4 text-xs font-mono text-slate-200 overflow-x-auto max-h-[500px] leading-relaxed selection:bg-blue-700",
						children: /* @__PURE__ */ _jsxDEV("code", { children: ANDROID_SNIPPETS[selectedSnippet].content }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 748,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 747,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 720,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 688,
				columnNumber: 9
			}, this),
			activeTab === "datasafety" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3 border-b border-slate-100 dark:border-slate-800 pb-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold",
						children: "✓"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 758,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-base font-bold text-slate-800 dark:text-slate-100",
						children: "Google Play Console — Data Safety Form Specification"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 762,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-500 dark:text-slate-400",
						children: "Exact responses required for Google Play approval under the Family & Parental Control category."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 765,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 761,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 757,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50 dark:bg-slate-800/40 space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-semibold text-xs text-blue-600 dark:text-blue-400 uppercase tracking-wider",
									children: "1. Location (Approximate & Precise)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 773,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-600 dark:text-slate-300",
									children: [
										/* @__PURE__ */ _jsxDEV("strong", { children: "Collected:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 777,
											columnNumber: 17
										}, this),
										" Yes | ",
										/* @__PURE__ */ _jsxDEV("strong", { children: "Shared with 3rd parties:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 777,
											columnNumber: 51
										}, this),
										" No"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 776,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Purpose:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 780,
										columnNumber: 17
									}, this), " App functionality, Parental Controls (Live GPS location and safe-zone geofencing notifications)."]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 779,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Encrypted in transit:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 783,
										columnNumber: 17
									}, this), " Yes (HTTPS/TLS 1.3)."]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 782,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 772,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50 dark:bg-slate-800/40 space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-semibold text-xs text-indigo-600 dark:text-indigo-400 uppercase tracking-wider",
									children: "2. App Activity & Usage"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 788,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-600 dark:text-slate-300",
									children: [
										/* @__PURE__ */ _jsxDEV("strong", { children: "Collected:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 792,
											columnNumber: 17
										}, this),
										" Yes | ",
										/* @__PURE__ */ _jsxDEV("strong", { children: "Shared with 3rd parties:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 792,
											columnNumber: 51
										}, this),
										" No"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 791,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Purpose:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 795,
										columnNumber: 17
									}, this), " Screen time calculation and app-blocking rules enforcement requested by parent."]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 794,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Ephemeral Processing:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 798,
										columnNumber: 17
									}, this), " Stored locally or in family-only authenticated database."]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 797,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 787,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50 dark:bg-slate-800/40 space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-semibold text-xs text-amber-600 dark:text-amber-400 uppercase tracking-wider",
									children: "3. Camera & Audio Stream"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 803,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-600 dark:text-slate-300",
									children: [
										/* @__PURE__ */ _jsxDEV("strong", { children: "Collected:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 807,
											columnNumber: 17
										}, this),
										" No permanent storage | ",
										/* @__PURE__ */ _jsxDEV("strong", { children: "Shared with 3rd parties:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 807,
											columnNumber: 68
										}, this),
										" No"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 806,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Purpose:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 810,
										columnNumber: 17
									}, this), " Parent check-in with explicit child interactive consent prompt and persistent foreground indicator."]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 809,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 802,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50 dark:bg-slate-800/40 space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-semibold text-xs text-emerald-600 dark:text-emerald-400 uppercase tracking-wider",
									children: "4. Account & Deletion Rights"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 815,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-600 dark:text-slate-300",
									children: [/* @__PURE__ */ _jsxDEV("strong", { children: "User Account Deletion:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 819,
										columnNumber: 17
									}, this), " Fully supported inside app settings."]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 818,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: "All location histories, alerts, and pairing records are wiped immediately upon unpairing or account termination."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 821,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 814,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 771,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 756,
				columnNumber: 9
			}, this),
			activeTab === "build" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-5",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Terminal, { className: "w-5 h-5 text-blue-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 833,
						columnNumber: 13
					}, this), "Reproducible Android Build Instructions"]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 832,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-4 text-xs text-slate-700 dark:text-slate-300",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ _jsxDEV("h4", {
								className: "font-semibold text-slate-900 dark:text-slate-100",
								children: "Step 1: Prerequisites"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 839,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-slate-600 dark:text-slate-400",
								children: "Install Android Studio Hedgehog (2023.1.1) or newer, with JDK 17 and Android SDK 34."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 842,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 838,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ _jsxDEV("h4", {
								className: "font-semibold text-slate-900 dark:text-slate-100",
								children: "Step 2: Generate Release Keystore"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 848,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 p-3 rounded-xl font-mono text-emerald-400 text-[11px] overflow-x-auto",
								children: "keytool -genkey -v -keystore safekids-release.jks -alias safekids -keyalg RSA -keysize 2048 -validity 10000"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 851,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 847,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-semibold text-slate-900 dark:text-slate-100",
									children: "Step 3: Compile Signed Android App Bundle (AAB)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 857,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-950 p-3 rounded-xl font-mono text-emerald-400 text-[11px] overflow-x-auto",
									children: "./gradlew bundleRelease"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 860,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-500 text-[11px]",
									children: [
										"The generated output will be located at: ",
										/* @__PURE__ */ _jsxDEV("code", { children: "app/build/outputs/bundle/release/app-release.aab" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 864,
											columnNumber: 58
										}, this),
										"."
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 863,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 856,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ _jsxDEV("h4", {
								className: "font-semibold text-slate-900 dark:text-slate-100",
								children: "Step 4: Target SDK & Google Play Compliance Verification"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 869,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("ul", {
								className: "list-disc list-inside space-y-1 text-slate-600 dark:text-slate-400",
								children: [
									/* @__PURE__ */ _jsxDEV("li", { children: [
										"Verify ",
										/* @__PURE__ */ _jsxDEV("code", { children: "targetSdk = 34" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 873,
											columnNumber: 28
										}, this),
										" in ",
										/* @__PURE__ */ _jsxDEV("code", { children: "app/build.gradle.kts" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 873,
											columnNumber: 59
										}, this),
										"."
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 873,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("li", { children: "Ensure Foreground Service permissions declare appropriate service types (location, mediaProjection)." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 874,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("li", { children: "Submit Accessibility Service declaration video showing parental control functionality to the Google Play review team." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 875,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 872,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 868,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 837,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 831,
				columnNumber: 9
			}, this),
			activeTab === "privacy" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-base font-bold text-slate-800 dark:text-slate-100",
						children: "SafeKids Free Parental Control Privacy Policy"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 887,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-500 dark:text-slate-400",
						children: "Compliant with COPPA, GDPR-K, and Google Play Families Policy."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 890,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 886,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs font-semibold px-2.5 py-1 bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300 rounded-lg",
						children: "Open Policy v1.0"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 894,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 885,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-50 dark:bg-slate-800/40 rounded-xl p-4 text-xs text-slate-600 dark:text-slate-300 space-y-3 leading-relaxed max-h-96 overflow-y-auto",
					children: [
						/* @__PURE__ */ _jsxDEV("h4", {
							className: "font-bold text-slate-900 dark:text-slate-100",
							children: "1. Commitment to Child Privacy & Safety"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 900,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "SafeKids is built as a 100% free parental control tool designed to protect children while upholding digital dignity. SafeKids does NOT sell, monetize, or broker personal data, location traces, or device telemetry to any third party or advertiser." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 901,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h4", {
							className: "font-bold text-slate-900 dark:text-slate-100",
							children: "2. Real-Time Location & Geofencing"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 905,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Location coordinates are fetched strictly with parental consent for the sole purpose of displaying child location on the family map and alerting guardians when children enter or exit designated safe zones (Home, School, Park)." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 906,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h4", {
							className: "font-bold text-slate-900 dark:text-slate-100",
							children: "3. Camera & Screen Check-In Transparency"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 910,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "SafeKids strictly prohibits covert spyware, secret microphone recording, or hidden surveillance. Live look-in sessions require interactive child consent and show a continuous, high-visibility indicator with an instant child termination button." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 911,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h4", {
							className: "font-bold text-slate-900 dark:text-slate-100",
							children: "4. Parental Rights & Data Erasure"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 915,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Parents have full authority to purge all historical data, unpair devices, or delete accounts directly within the app settings. All cached locations are expunged permanently." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 916,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 899,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 884,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 624,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLFVBQVUsTUFBTSxPQUFPLE1BQU0sYUFBYSxVQUFVLFlBQTBCLGdCQUF3Qjs7O0FBUy9HLE1BQU0sbUJBQWtDO0NBQ3RDO0VBQ0UsVUFBVTtFQUNWLFVBQVU7RUFDVixhQUFhO0VBQ2IsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBNkZYO0NBQ0E7RUFDRSxVQUFVO0VBQ1YsVUFBVTtFQUNWLGFBQWE7RUFDYixTQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTJEWDtDQUNBO0VBQ0UsVUFBVTtFQUNWLFVBQVU7RUFDVixhQUFhO0VBQ2IsU0FBUzs7Ozs7Ozs7Ozs7Ozs7O0NBZVg7Q0FDQTtFQUNFLFVBQVU7RUFDVixVQUFVO0VBQ1YsYUFBYTtFQUNiLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBZ0NYO0NBQ0E7RUFDRSxVQUFVO0VBQ1YsVUFBVTtFQUNWLGFBQWE7RUFDYixTQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxRVg7Q0FDQTtFQUNFLFVBQVU7RUFDVixVQUFVO0VBQ1YsYUFBYTtFQUNiLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMEVYO0NBQ0E7RUFDRSxVQUFVO0VBQ1YsVUFBVTtFQUNWLGFBQWE7RUFDYixTQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTJEWDtDQUNBO0VBQ0UsVUFBVTtFQUNWLFVBQVU7RUFDVixhQUFhO0VBQ2IsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzRlg7Q0FDQTtFQUNFLFVBQVU7RUFDVixVQUFVO0VBQ1YsYUFBYTtFQUNiLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F1RFg7QUFDRjtBQUVBLE9BQU8sTUFBTSx5QkFBbUM7Q0FDOUMsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBaUIsQ0FBQztDQUNoRSxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsS0FBSztDQUMxQyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBd0QsUUFBUTtDQUVsRyxNQUFNLG1CQUFtQjtFQUN2QixVQUFVLFVBQVUsVUFBVSxpQkFBaUIsZ0JBQWdCLENBQUMsT0FBTztFQUN2RSxVQUFVLElBQUk7RUFDZCxpQkFBaUIsVUFBVSxLQUFLLEdBQUcsR0FBSTtDQUN6QztDQUVBLE1BQU0sdUJBQXVCO0VBQzNCLE1BQU0sVUFBVSxpQkFBaUI7RUFDakMsTUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLFFBQVEsT0FBTyxHQUFHLEVBQUUsTUFBTSxhQUFhLENBQUM7RUFDL0QsTUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7RUFDcEMsTUFBTSxJQUFJLFNBQVMsY0FBYyxHQUFHO0VBQ3BDLEVBQUUsT0FBTztFQUNULEVBQUUsV0FBVyxRQUFRO0VBQ3JCLEVBQUUsTUFBTTtFQUNSLElBQUksZ0JBQWdCLEdBQUc7Q0FDekI7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxZQUFELEVBQVksV0FBVSx3QkFBeUI7Ozs7aUJBQy9DLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFtQztPQUU3Qzs7OztlQUNEOzs7OztnQkFDTCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBa0Q7TUFFNUQ7Ozs7Y0FDQTs7Ozs7ZUFDTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFtRztNQUU3Rzs7OztnQkFDTix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaUU7TUFFM0U7Ozs7Y0FDSDs7Ozs7YUFDRjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsVUFBRDtPQUNFLGVBQWUsYUFBYSxRQUFRO09BQ3BDLFdBQVcsNkdBQ1QsY0FBYyxXQUFXLHFDQUFxQztpQkFIbEUsQ0FNRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O2lCQUFDLHNCQUMxQjs7Ozs7O01BQ1Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsYUFBYSxZQUFZO09BQ3hDLFdBQVcsNkdBQ1QsY0FBYyxlQUFlLHFDQUFxQztpQkFIdEUsQ0FNRSx3QkFBQyxhQUFELEVBQWEsV0FBVSxjQUFlOzs7O2lCQUFDLDBCQUNqQzs7Ozs7O01BQ1Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsYUFBYSxPQUFPO09BQ25DLFdBQVcsNkdBQ1QsY0FBYyxVQUFVLHFDQUFxQztpQkFIakUsQ0FNRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O2lCQUFDLHdCQUM5Qjs7Ozs7O01BQ1Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsYUFBYSxTQUFTO09BQ3JDLFdBQVcsNkdBQ1QsY0FBYyxZQUFZLHFDQUFxQztpQkFIbkUsQ0FNRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O2lCQUFDLHlCQUM5Qjs7Ozs7O0tBQ0w7Ozs7O1lBQ0Y7Ozs7OztHQUdKLGNBQWMsWUFDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFpRTtLQUUzRTs7OztlQUNKLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLGlCQUFpQixLQUFLLFNBQVMsUUFDOUIsd0JBQUMsVUFBRDtPQUVFLGVBQWUsbUJBQW1CLEdBQUc7T0FDckMsV0FBVyxpRUFDVCxvQkFBb0IsTUFDaEIsNEdBQ0E7aUJBTlIsQ0FTRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFxQixRQUFRO1FBQWU7Ozs7a0JBQzVELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLFFBQVE7UUFDTDs7OztnQkFDSDs7Ozs7aUJBQ0wsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsUUFBUTtPQUNSOzs7O2VBQ0c7U0FqQkQsUUFBUTs7OzthQWlCUCxDQUNUO0tBQ0U7Ozs7YUFDRjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQ2IsaUJBQWlCLGdCQUFnQixDQUFDO01BQy9COzs7O2dCQUNOLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUNWLGlCQUFpQixnQkFBZ0IsQ0FBQztNQUNsQzs7OztjQUNBOzs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLFNBQVM7UUFDVCxXQUFVO2tCQUZaLENBSUcsU0FBUyx3QkFBQyxPQUFELEVBQU8sV0FBVSwrQkFBZ0M7Ozs7bUJBQUksd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OztrQkFDOUYsd0JBQUMsUUFBRCxZQUFPLFNBQVMsV0FBVyxPQUFhOzs7O2dCQUNsQzs7Ozs7aUJBQ1Isd0JBQUMsVUFBRDtRQUNFLFNBQVM7UUFDVCxXQUFVO2tCQUZaLENBSUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7OztrQkFBQyxXQUM5Qjs7Ozs7ZUFDTDs7Ozs7Y0FDRjs7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxRQUFELFlBQU8saUJBQWlCLGdCQUFnQixDQUFDLFFBQWM7Ozs7O0tBQ3BEOzs7O2FBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUlOLGNBQWMsZ0JBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBK0k7S0FFeko7Ozs7ZUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXlEO0tBRW5FOzs7O2VBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTZDO0tBRXZEOzs7O2FBQ0E7Ozs7YUFDRjs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBa0Y7UUFFNUY7Ozs7O1FBQ0osd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWI7VUFDRSx3QkFBQyxVQUFELFlBQVEsYUFBa0I7Ozs7O1VBQUM7VUFBTyx3QkFBQyxVQUFELFlBQVEsMkJBQWdDOzs7OztVQUFDO1NBQzFFOzs7Ozs7UUFDSCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYixDQUNFLHdCQUFDLFVBQUQsWUFBUSxXQUFnQjs7OzttQkFBQyxtR0FDeEI7Ozs7OztRQUNILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiLENBQ0Usd0JBQUMsVUFBRCxZQUFRLHdCQUE2Qjs7OzttQkFBQyx1QkFDckM7Ozs7OztPQUNBOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFzRjtRQUVoRzs7Ozs7UUFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYjtVQUNFLHdCQUFDLFVBQUQsWUFBUSxhQUFrQjs7Ozs7VUFBQztVQUFPLHdCQUFDLFVBQUQsWUFBUSwyQkFBZ0M7Ozs7O1VBQUM7U0FDMUU7Ozs7OztRQUNILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiLENBQ0Usd0JBQUMsVUFBRCxZQUFRLFdBQWdCOzs7O21CQUFDLGtGQUN4Qjs7Ozs7O1FBQ0gsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWIsQ0FDRSx3QkFBQyxVQUFELFlBQVEsd0JBQTZCOzs7O21CQUFDLDJEQUNyQzs7Ozs7O09BQ0E7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQW9GO1FBRTlGOzs7OztRQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQ0Usd0JBQUMsVUFBRCxZQUFRLGFBQWtCOzs7OztVQUFDO1VBQXdCLHdCQUFDLFVBQUQsWUFBUSwyQkFBZ0M7Ozs7O1VBQUM7U0FDM0Y7Ozs7OztRQUNILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiLENBQ0Usd0JBQUMsVUFBRCxZQUFRLFdBQWdCOzs7O21CQUFDLHNHQUN4Qjs7Ozs7O09BQ0E7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXdGO1FBRWxHOzs7OztRQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiLENBQ0Usd0JBQUMsVUFBRCxZQUFRLHlCQUE4Qjs7OzttQkFBQyx1Q0FDdEM7Ozs7OztRQUNILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUE2QztRQUV2RDs7Ozs7T0FDQTs7Ozs7O0tBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUlOLGNBQWMsV0FDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZCxDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHdCQUF5Qjs7OztlQUFDLHlDQUU1Qzs7Ozs7Y0FFSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBbUQ7T0FFN0Q7Ozs7aUJBQ0osd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQXFDO09BRS9DOzs7O2VBQ0E7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQW1EO09BRTdEOzs7O2lCQUNKLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFxRjtPQUUvRjs7OztlQUNGOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFtRDtRQUU3RDs7Ozs7UUFDSix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBcUY7UUFFL0Y7Ozs7O1FBQ0wsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWI7VUFBMEM7VUFDQyx3QkFBQyxRQUFELFlBQU0sbURBQXNEOzs7OztVQUFDO1NBQ3JHOzs7Ozs7T0FDQTs7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBbUQ7T0FFN0Q7Ozs7aUJBQ0osd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQ7U0FDRSx3QkFBQyxNQUFEO1VBQUk7VUFBTyx3QkFBQyxRQUFELFlBQU0saUJBQW9COzs7OztVQUFDO1VBQUksd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7Ozs7VUFBQztTQUFLOzs7OztTQUNoRix3QkFBQyxNQUFELFlBQUksdUdBQXdHOzs7OztTQUM1Ryx3QkFBQyxNQUFELFlBQUksd0hBQXlIOzs7OztRQUMzSDs7Ozs7ZUFDRDs7Ozs7O0tBQ0Y7Ozs7O1lBQ0Y7Ozs7OztHQUlOLGNBQWMsYUFDYix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBeUQ7S0FFbkU7Ozs7ZUFDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBNkM7S0FFdkQ7Ozs7YUFDQTs7OztlQUNMLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFnSDtLQUUxSDs7OzthQUNIOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBK0M7TUFBMkM7Ozs7O01BQ3hHLHdCQUFDLEtBQUQsWUFBRyx5UEFFQTs7Ozs7TUFFSCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBK0M7TUFBc0M7Ozs7O01BQ25HLHdCQUFDLEtBQUQsWUFBRyxxT0FFQTs7Ozs7TUFFSCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBK0M7TUFBNEM7Ozs7O01BQ3pHLHdCQUFDLEtBQUQsWUFBRyxzUEFFQTs7Ozs7TUFFSCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBK0M7TUFBcUM7Ozs7O01BQ2xHLHdCQUFDLEtBQUQsWUFBRyxnTEFFQTs7Ozs7S0FDQTs7Ozs7WUFDRjs7Ozs7O0VBRUo7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFuZHJvaWROYXRpdmVLaXQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IERvd25sb2FkLCBDb3B5LCBDaGVjaywgQ29kZSwgU2hpZWxkQ2hlY2ssIEZpbGVUZXh0LCBTbWFydHBob25lLCBFeHRlcm5hbExpbmssIFRlcm1pbmFsLCBMYXllcnMgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5pbnRlcmZhY2UgQ29kZVNuaXBwZXQge1xuICBmaWxlbmFtZTogc3RyaW5nO1xuICBsYW5ndWFnZTogc3RyaW5nO1xuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xuICBjb250ZW50OiBzdHJpbmc7XG59XG5cbmNvbnN0IEFORFJPSURfU05JUFBFVFM6IENvZGVTbmlwcGV0W10gPSBbXG4gIHtcbiAgICBmaWxlbmFtZTogJ1NhZmVLaWRzQWNjZXNzaWJpbGl0eVNlcnZpY2Uua3QnLFxuICAgIGxhbmd1YWdlOiAna290bGluJyxcbiAgICBkZXNjcmlwdGlvbjogJ0VuZm9yY2VzIGFwcCBsb2NrICYgc3RyaWN0IGFudGktdW5pbnN0YWxsIHByb3RlY3Rpb24gYnkgZGV0ZWN0aW5nIHNldHRpbmdzIHRhbXBlcmluZyBhbmQgaW50ZXJjZXB0aW5nIHVuaW5zdGFsbGVyIGRpYWxvZ3MuJyxcbiAgICBjb250ZW50OiBgcGFja2FnZSBjb20uc2FmZWtpZHMucGFyZW50YWxjb250cm9sLnNlcnZpY2VcblxuaW1wb3J0IGFuZHJvaWQuYWNjZXNzaWJpbGl0eXNlcnZpY2UuQWNjZXNzaWJpbGl0eVNlcnZpY2VcbmltcG9ydCBhbmRyb2lkLmNvbnRlbnQuSW50ZW50XG5pbXBvcnQgYW5kcm9pZC52aWV3LmFjY2Vzc2liaWxpdHkuQWNjZXNzaWJpbGl0eUV2ZW50XG5pbXBvcnQgY29tLnNhZmVraWRzLnBhcmVudGFsY29udHJvbC51aS5BcHBCbG9ja0FjdGl2aXR5XG5pbXBvcnQgY29tLnNhZmVraWRzLnBhcmVudGFsY29udHJvbC51aS5QYXJlbnRQaW5BdXRoQWN0aXZpdHlcbmltcG9ydCBjb20uc2FmZWtpZHMucGFyZW50YWxjb250cm9sLnJlcG9zaXRvcnkuUnVsZXNSZXBvc2l0b3J5XG5pbXBvcnQgY29tLnNhZmVraWRzLnBhcmVudGFsY29udHJvbC53b3JrZXIuU2FmZUtpZHNTeW5jV29ya2VyXG5cbi8qKlxuICogU2FmZUtpZHMgQWNjZXNzaWJpbGl0eSBTZXJ2aWNlXG4gKiBDb21wbGlhbnQgd2l0aCBHb29nbGUgUGxheSBTdG9yZSBhY2Nlc3NpYmlsaXR5IHBvbGljeSBmb3IgUGFyZW50YWwgQ29udHJvbCBhcHBzLlxuICogUHJvdmlkZXMgc3RyaWN0IGFudGktdW5pbnN0YWxsIHByb3RlY3Rpb24gYW5kIGFwcCBsaW1pdCBlbmZvcmNlbWVudC5cbiAqL1xuY2xhc3MgU2FmZUtpZHNBY2Nlc3NpYmlsaXR5U2VydmljZSA6IEFjY2Vzc2liaWxpdHlTZXJ2aWNlKCkge1xuXG4gICAgcHJpdmF0ZSBsYXRlaW5pdCB2YXIgcnVsZXNSZXBvc2l0b3J5OiBSdWxlc1JlcG9zaXRvcnlcblxuICAgIG92ZXJyaWRlIGZ1biBvbkNyZWF0ZSgpIHtcbiAgICAgICAgc3VwZXIub25DcmVhdGUoKVxuICAgICAgICBydWxlc1JlcG9zaXRvcnkgPSBSdWxlc1JlcG9zaXRvcnkuZ2V0SW5zdGFuY2UoYXBwbGljYXRpb25Db250ZXh0KVxuICAgIH1cblxuICAgIG92ZXJyaWRlIGZ1biBvbkFjY2Vzc2liaWxpdHlFdmVudChldmVudDogQWNjZXNzaWJpbGl0eUV2ZW50Pykge1xuICAgICAgICBpZiAoZXZlbnQgPT0gbnVsbCB8fCBldmVudC5ldmVudFR5cGUgIT0gQWNjZXNzaWJpbGl0eUV2ZW50LlRZUEVfV0lORE9XX1NUQVRFX0NIQU5HRUQpIHtcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG5cbiAgICAgICAgdmFsIHBhY2thZ2VOYW1lID0gZXZlbnQucGFja2FnZU5hbWU/LnRvU3RyaW5nKCkgPzogcmV0dXJuXG5cbiAgICAgICAgLy8gSWdub3JlIHNlbGZcbiAgICAgICAgaWYgKHBhY2thZ2VOYW1lID09IGFwcGxpY2F0aW9uQ29udGV4dC5wYWNrYWdlTmFtZSkgcmV0dXJuXG5cbiAgICAgICAgLy8g8J+boe+4jyBTVFJJQ1QgQU5USS1VTklOU1RBTEwgUFJPVEVDVElPTjpcbiAgICAgICAgLy8gSW50ZXJjZXB0IEFuZHJvaWQgU2V0dGluZ3MgKEFwcCBJbmZvLCBEZXZpY2UgQWRtaW4gQXBwcykgJiBQYWNrYWdlIEluc3RhbGxlcnNcbiAgICAgICAgaWYgKHBhY2thZ2VOYW1lID09IFwiY29tLmFuZHJvaWQuc2V0dGluZ3NcIiB8fCBcbiAgICAgICAgICAgIHBhY2thZ2VOYW1lID09IFwiY29tLmdvb2dsZS5hbmRyb2lkLnBhY2thZ2VpbnN0YWxsZXJcIiB8fCBcbiAgICAgICAgICAgIHBhY2thZ2VOYW1lID09IFwiY29tLmFuZHJvaWQucGFja2FnZWluc3RhbGxlclwiKSB7XG5cbiAgICAgICAgICAgIHZhbCB0ZXh0Q29udGVudCA9IGV2ZW50LnRleHQuam9pblRvU3RyaW5nKFwiIFwiKS5sb3dlcmNhc2UoKVxuICAgICAgICAgICAgdmFsIGNsYXNzTmFtZSA9IGV2ZW50LmNsYXNzTmFtZT8udG9TdHJpbmcoKT8ubG93ZXJjYXNlKCkgPzogXCJcIlxuXG4gICAgICAgICAgICB2YWwgaXNUYXJnZXRpbmdTYWZlS2lkcyA9IHRleHRDb250ZW50LmNvbnRhaW5zKFwic2FmZWtpZHNcIikgfHwgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lLmNvbnRhaW5zKFwiaW5zdGFsbGVkYXBwZGV0YWlsc1wiKSB8fCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWUuY29udGFpbnMoXCJkZXZpY2VhZG1pblwiKVxuXG4gICAgICAgICAgICB2YWwgaXNEYW5nZXJvdXNBY3Rpb24gPSB0ZXh0Q29udGVudC5jb250YWlucyhcInVuaW5zdGFsbFwiKSB8fCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRDb250ZW50LmNvbnRhaW5zKFwiZm9yY2Ugc3RvcFwiKSB8fCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRDb250ZW50LmNvbnRhaW5zKFwiY2xlYXIgc3RvcmFnZVwiKSB8fCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRDb250ZW50LmNvbnRhaW5zKFwiY2xlYXIgZGF0YVwiKSB8fCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRDb250ZW50LmNvbnRhaW5zKFwiZGVhY3RpdmF0ZVwiKVxuXG4gICAgICAgICAgICBpZiAoaXNUYXJnZXRpbmdTYWZlS2lkcyB8fCAoaXNEYW5nZXJvdXNBY3Rpb24gJiYgdGV4dENvbnRlbnQuY29udGFpbnMoXCJzYWZla2lkc1wiKSkpIHtcbiAgICAgICAgICAgICAgICAvLyBJbW1lZGlhdGVseSBuYXZpZ2F0ZSBCQUNLIHRvIGJsb2NrIHRoZSB1bmluc3RhbGwgZGlhbG9nXG4gICAgICAgICAgICAgICAgcGVyZm9ybUdsb2JhbEFjdGlvbihHTE9CQUxfQUNUSU9OX0JBQ0spXG5cbiAgICAgICAgICAgICAgICAvLyBMYXVuY2ggTWFzdGVyIFBhcmVudCBQSU4gdmVyaWZpY2F0aW9uIG92ZXJsYXlcbiAgICAgICAgICAgICAgICB2YWwgcGluQXV0aEludGVudCA9IEludGVudCh0aGlzLCBQYXJlbnRQaW5BdXRoQWN0aXZpdHk6OmNsYXNzLmphdmEpLmFwcGx5IHtcbiAgICAgICAgICAgICAgICAgICAgYWRkRmxhZ3MoSW50ZW50LkZMQUdfQUNUSVZJVFlfTkVXX1RBU0sgb3IgSW50ZW50LkZMQUdfQUNUSVZJVFlfQ0xFQVJfVE9QKVxuICAgICAgICAgICAgICAgICAgICBwdXRFeHRyYShQYXJlbnRQaW5BdXRoQWN0aXZpdHkuRVhUUkFfUkVBU09OLCBcIkFOVElfVU5JTlNUQUxMX0lOVEVSQ0VQVFwiKVxuICAgICAgICAgICAgICAgICAgICBwdXRFeHRyYShQYXJlbnRQaW5BdXRoQWN0aXZpdHkuRVhUUkFfTUVTU0FHRSwgXCJNYXN0ZXIgUGFyZW50IFBJTiByZXF1aXJlZCB0byB1bmluc3RhbGwgU2FmZUtpZHMgb3IgZGVhY3RpdmF0ZSBkZXZpY2UgcHJvdGVjdGlvbi5cIilcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgc3RhcnRBY3Rpdml0eShwaW5BdXRoSW50ZW50KVxuXG4gICAgICAgICAgICAgICAgLy8gUmVwb3J0IHRhbXBlcmluZyBhdHRlbXB0IHRvIFBhcmVudCBEYXNoYm9hcmRcbiAgICAgICAgICAgICAgICBTYWZlS2lkc1N5bmNXb3JrZXIucmVwb3J0VGFtcGVyQXR0ZW1wdChcbiAgICAgICAgICAgICAgICAgICAgYXBwbGljYXRpb25Db250ZXh0LFxuICAgICAgICAgICAgICAgICAgICBcIkNoaWxkIGF0dGVtcHRlZCB0byBhY2Nlc3MgU2FmZUtpZHMgdW5pbnN0YWxsL2RlYWN0aXZhdGUgc2V0dGluZ3NcIlxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICByZXR1cm5cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFN0YW5kYXJkIEFwcCBMb2NrICYgQmVkdGltZSBlbmZvcmNlbWVudFxuICAgICAgICB2YWwgaXNMb2NrZWQgPSBydWxlc1JlcG9zaXRvcnkuaXNQYWNrYWdlTG9ja2VkKHBhY2thZ2VOYW1lKVxuICAgICAgICB2YWwgaXNCZWR0aW1lID0gcnVsZXNSZXBvc2l0b3J5LmlzQmVkdGltZUFjdGl2ZSgpXG5cbiAgICAgICAgaWYgKGlzTG9ja2VkIHx8IGlzQmVkdGltZSkge1xuICAgICAgICAgICAgdmFsIGJsb2NrSW50ZW50ID0gSW50ZW50KHRoaXMsIEFwcEJsb2NrQWN0aXZpdHk6OmNsYXNzLmphdmEpLmFwcGx5IHtcbiAgICAgICAgICAgICAgICBhZGRGbGFncyhJbnRlbnQuRkxBR19BQ1RJVklUWV9ORVdfVEFTSyBvciBJbnRlbnQuRkxBR19BQ1RJVklUWV9DTEVBUl9UT1ApXG4gICAgICAgICAgICAgICAgcHV0RXh0cmEoQXBwQmxvY2tBY3Rpdml0eS5FWFRSQV9CTE9DS0VEX1BBQ0tBR0UsIHBhY2thZ2VOYW1lKVxuICAgICAgICAgICAgICAgIHB1dEV4dHJhKEFwcEJsb2NrQWN0aXZpdHkuRVhUUkFfUkVBU09OLCBpZiAoaXNCZWR0aW1lKSBcIkJlZHRpbWUgTW9kZVwiIGVsc2UgXCJUaW1lIExpbWl0IEV4Y2VlZGVkXCIpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzdGFydEFjdGl2aXR5KGJsb2NrSW50ZW50KVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgb3ZlcnJpZGUgZnVuIG9uSW50ZXJydXB0KCkge1xuICAgICAgICAvLyBTZXJ2aWNlIGludGVycnVwdGVkXG4gICAgfVxufVxuYCxcbiAgfSxcbiAge1xuICAgIGZpbGVuYW1lOiAnU2FmZUtpZHNEZXZpY2VBZG1pblJlY2VpdmVyLmt0JyxcbiAgICBsYW5ndWFnZTogJ2tvdGxpbicsXG4gICAgZGVzY3JpcHRpb246ICdEZXZpY2UgQWRtaW5pc3RyYXRvciByZWNlaXZlciBwcmV2ZW50aW5nIGFwcCB1bmluc3RhbGxhdGlvbiBhdCBPUyBsZXZlbCwgaW50ZXJjZXB0aW5nIGRlYWN0aXZhdGlvbiB3aXRoIFBJTi4nLFxuICAgIGNvbnRlbnQ6IGBwYWNrYWdlIGNvbS5zYWZla2lkcy5wYXJlbnRhbGNvbnRyb2wucmVjZWl2ZXJcblxuaW1wb3J0IGFuZHJvaWQuYXBwLmFkbWluLkRldmljZUFkbWluUmVjZWl2ZXJcbmltcG9ydCBhbmRyb2lkLmFwcC5hZG1pbi5EZXZpY2VQb2xpY3lNYW5hZ2VyXG5pbXBvcnQgYW5kcm9pZC5jb250ZW50LkNvbXBvbmVudE5hbWVcbmltcG9ydCBhbmRyb2lkLmNvbnRlbnQuQ29udGV4dFxuaW1wb3J0IGFuZHJvaWQuY29udGVudC5JbnRlbnRcbmltcG9ydCBhbmRyb2lkLndpZGdldC5Ub2FzdFxuaW1wb3J0IGNvbS5zYWZla2lkcy5wYXJlbnRhbGNvbnRyb2wudWkuUGFyZW50UGluQXV0aEFjdGl2aXR5XG5pbXBvcnQgY29tLnNhZmVraWRzLnBhcmVudGFsY29udHJvbC53b3JrZXIuU2FmZUtpZHNTeW5jV29ya2VyXG5cbi8qKlxuICogU2FmZUtpZHMgRGV2aWNlIEFkbWluaXN0cmF0b3IgUmVjZWl2ZXJcbiAqIFByZXZlbnRzIHVuYXV0aG9yaXplZCB1bmluc3RhbGxhdGlvbiBhbmQgZW5mb3JjZXMgUElOIHByb3RlY3Rpb24gdXBvbiBkZWFjdGl2YXRpb24gYXR0ZW1wdHMuXG4gKi9cbmNsYXNzIFNhZmVLaWRzRGV2aWNlQWRtaW5SZWNlaXZlciA6IERldmljZUFkbWluUmVjZWl2ZXIoKSB7XG5cbiAgICBvdmVycmlkZSBmdW4gb25FbmFibGVkKGNvbnRleHQ6IENvbnRleHQsIGludGVudDogSW50ZW50KSB7XG4gICAgICAgIHN1cGVyLm9uRW5hYmxlZChjb250ZXh0LCBpbnRlbnQpXG4gICAgICAgIFRvYXN0Lm1ha2VUZXh0KGNvbnRleHQsIFwi8J+boe+4jyBTYWZlS2lkcyBTdHJpY3QgQW50aS1Vbmluc3RhbGwgUHJvdGVjdGlvbiBBY3RpdmF0ZWRcIiwgVG9hc3QuTEVOR1RIX0xPTkcpLnNob3coKVxuXG4gICAgICAgIC8vIElmIGNvbmZpZ3VyZWQgYXMgRGV2aWNlIE93bmVyIHZpYSBBREIvS25veCwgZW5mb3JjZSBwZXJtYW5lbnQgT1MtbGV2ZWwgdW5pbnN0YWxsIGJsb2NrXG4gICAgICAgIHZhbCBkcG0gPSBjb250ZXh0LmdldFN5c3RlbVNlcnZpY2UoQ29udGV4dC5ERVZJQ0VfUE9MSUNZX1NFUlZJQ0UpIGFzIERldmljZVBvbGljeU1hbmFnZXJcbiAgICAgICAgdmFsIGFkbWluID0gQ29tcG9uZW50TmFtZShjb250ZXh0LCBTYWZlS2lkc0RldmljZUFkbWluUmVjZWl2ZXI6OmNsYXNzLmphdmEpXG4gICAgICAgIGlmIChkcG0uaXNEZXZpY2VPd25lckFwcChjb250ZXh0LnBhY2thZ2VOYW1lKSkge1xuICAgICAgICAgICAgZHBtLnNldFVuaW5zdGFsbEJsb2NrZWQoYWRtaW4sIGNvbnRleHQucGFja2FnZU5hbWUsIHRydWUpXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBvdmVycmlkZSBmdW4gb25EaXNhYmxlUmVxdWVzdGVkKGNvbnRleHQ6IENvbnRleHQsIGludGVudDogSW50ZW50KTogQ2hhclNlcXVlbmNlPyB7XG4gICAgICAgIC8vIEludGVyY2VwdCBkZWFjdGl2YXRpb246IHJlcG9ydCB1cmdlbnQgYWxlcnQgdG8gUGFyZW50IERhc2hib2FyZFxuICAgICAgICBTYWZlS2lkc1N5bmNXb3JrZXIucmVwb3J0VGFtcGVyQXR0ZW1wdChcbiAgICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgICBcIkRlYWN0aXZhdGUgRGV2aWNlIEFkbWluaXN0cmF0b3IgcmVxdWVzdGVkIG9uIGNoaWxkIGRldmljZVwiXG4gICAgICAgIClcblxuICAgICAgICAvLyBMYXVuY2ggbWFuZGF0b3J5IFBhcmVudCBQSU4gcHJvbXB0XG4gICAgICAgIHZhbCBwaW5JbnRlbnQgPSBJbnRlbnQoY29udGV4dCwgUGFyZW50UGluQXV0aEFjdGl2aXR5OjpjbGFzcy5qYXZhKS5hcHBseSB7XG4gICAgICAgICAgICBhZGRGbGFncyhJbnRlbnQuRkxBR19BQ1RJVklUWV9ORVdfVEFTSylcbiAgICAgICAgICAgIHB1dEV4dHJhKFBhcmVudFBpbkF1dGhBY3Rpdml0eS5FWFRSQV9SRUFTT04sIFwiREVWSUNFX0FETUlOX0RFQUNUSVZBVElPTlwiKVxuICAgICAgICB9XG4gICAgICAgIGNvbnRleHQuc3RhcnRBY3Rpdml0eShwaW5JbnRlbnQpXG5cbiAgICAgICAgcmV0dXJuIFwi4pqg77iPIENSSVRJQ0FMIFNFQ1VSSVRZIEFMRVJUOiBEZWFjdGl2YXRpbmcgU2FmZUtpZHMgcmVxdWlyZXMgUGFyZW50IE1hc3RlciBQSU4gdmVyaWZpY2F0aW9uLiBBbnkgdW5hdXRob3JpemVkIGF0dGVtcHQgaXMgaW1tZWRpYXRlbHkgYWxlcnRlZCB0byBwYXJlbnRzLlwiXG4gICAgfVxuXG4gICAgb3ZlcnJpZGUgZnVuIG9uRGlzYWJsZWQoY29udGV4dDogQ29udGV4dCwgaW50ZW50OiBJbnRlbnQpIHtcbiAgICAgICAgc3VwZXIub25EaXNhYmxlZChjb250ZXh0LCBpbnRlbnQpXG4gICAgICAgIC8vIElmIHNvbWVob3cgZGlzYWJsZWQgd2l0aG91dCBQSU4sIGluc3RhbnRseSBsb2NrIGRldmljZSBzY3JlZW4gYW5kIGFsZXJ0IHBhcmVudHNcbiAgICAgICAgdmFsIGRwbSA9IGNvbnRleHQuZ2V0U3lzdGVtU2VydmljZShDb250ZXh0LkRFVklDRV9QT0xJQ1lfU0VSVklDRSkgYXMgRGV2aWNlUG9saWN5TWFuYWdlclxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgZHBtLmxvY2tOb3coKVxuICAgICAgICB9IGNhdGNoIChlOiBFeGNlcHRpb24pIHtcbiAgICAgICAgICAgIC8vIGxvY2tOb3cgZmFsbGJhY2tcbiAgICAgICAgfVxuICAgICAgICBTYWZlS2lkc1N5bmNXb3JrZXIucmVwb3J0VGFtcGVyQXR0ZW1wdChjb250ZXh0LCBcIkRldmljZSBBZG1pbiBEZWFjdGl2YXRlZCEgRGV2aWNlIGxvY2tlZCBmb3Igc2VjdXJpdHkuXCIpXG4gICAgfVxufVxuYCxcbiAgfSxcbiAge1xuICAgIGZpbGVuYW1lOiAnZGV2aWNlX2FkbWluX3J1bGVzLnhtbCcsXG4gICAgbGFuZ3VhZ2U6ICd4bWwnLFxuICAgIGRlc2NyaXB0aW9uOiAnRGV2aWNlIEFkbWluaXN0cmF0b3IgcG9saWN5IG1hbmlmZXN0IGRlY2xhcmluZyBmb3JjZS1sb2NrLCB3aXBlLWRhdGEsIGFuZCBkZXZpY2Ugc2VjdXJpdHkgY2FwYWJpbGl0aWVzLicsXG4gICAgY29udGVudDogYDw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cInV0Zi04XCI/PlxuPGRldmljZS1hZG1pbiB4bWxuczphbmRyb2lkPVwiaHR0cDovL3NjaGVtYXMuYW5kcm9pZC5jb20vYXBrL3Jlcy9hbmRyb2lkXCI+XG4gICAgPHVzZXMtcG9saWNpZXM+XG4gICAgICAgIDwhLS0gQWxsb3dzIFNhZmVLaWRzIHRvIGxvY2sgZGV2aWNlIGR1cmluZyBiZWR0aW1lIG9yIHRhbXBlcmluZyBhdHRlbXB0cyAtLT5cbiAgICAgICAgPGZvcmNlLWxvY2sgLz5cbiAgICAgICAgPCEtLSBQcm9oaWJpdHMgY2FtZXJhIGJ5cGFzcyAtLT5cbiAgICAgICAgPGRpc2FibGUtY2FtZXJhIC8+XG4gICAgICAgIDwhLS0gTGltaXRzIHBhc3N3b3JkIGZhaWx1cmUgcmVzZXRzIC0tPlxuICAgICAgICA8bGltaXQtcGFzc3dvcmQgLz5cbiAgICAgICAgPHdhdGNoLWxvZ2luIC8+XG4gICAgICAgIDwhLS0gUHJvdGVjdHMga2V5Z3VhcmQgLS0+XG4gICAgICAgIDxkaXNhYmxlLWtleWd1YXJkLWZlYXR1cmVzIC8+XG4gICAgPC91c2VzLXBvbGljaWVzPlxuPC9kZXZpY2UtYWRtaW4+XG5gLFxuICB9LFxuICB7XG4gICAgZmlsZW5hbWU6ICdTYWZlS2lkc0RldmljZUFkbWluSGVscGVyLmt0JyxcbiAgICBsYW5ndWFnZTogJ2tvdGxpbicsXG4gICAgZGVzY3JpcHRpb246ICdIZWxwZXIgY2xhc3MgZm9yIGNoZWNraW5nIERldmljZSBBZG1pbiBzdGF0dXMgYW5kIHJlcXVlc3RpbmcgdXNlciBwZXJtaXNzaW9uLicsXG4gICAgY29udGVudDogYHBhY2thZ2UgY29tLnNhZmVraWRzLnBhcmVudGFsY29udHJvbC51dGlsXG5cbmltcG9ydCBhbmRyb2lkLmFwcC5BY3Rpdml0eVxuaW1wb3J0IGFuZHJvaWQuYXBwLmFkbWluLkRldmljZVBvbGljeU1hbmFnZXJcbmltcG9ydCBhbmRyb2lkLmNvbnRlbnQuQ29tcG9uZW50TmFtZVxuaW1wb3J0IGFuZHJvaWQuY29udGVudC5Db250ZXh0XG5pbXBvcnQgYW5kcm9pZC5jb250ZW50LkludGVudFxuaW1wb3J0IGNvbS5zYWZla2lkcy5wYXJlbnRhbGNvbnRyb2wucmVjZWl2ZXIuU2FmZUtpZHNEZXZpY2VBZG1pblJlY2VpdmVyXG5cbm9iamVjdCBTYWZlS2lkc0RldmljZUFkbWluSGVscGVyIHtcblxuICAgIGZ1biBnZXRDb21wb25lbnROYW1lKGNvbnRleHQ6IENvbnRleHQpOiBDb21wb25lbnROYW1lIHtcbiAgICAgICAgcmV0dXJuIENvbXBvbmVudE5hbWUoY29udGV4dCwgU2FmZUtpZHNEZXZpY2VBZG1pblJlY2VpdmVyOjpjbGFzcy5qYXZhKVxuICAgIH1cblxuICAgIGZ1biBpc0RldmljZUFkbWluQWN0aXZlKGNvbnRleHQ6IENvbnRleHQpOiBCb29sZWFuIHtcbiAgICAgICAgdmFsIGRwbSA9IGNvbnRleHQuZ2V0U3lzdGVtU2VydmljZShDb250ZXh0LkRFVklDRV9QT0xJQ1lfU0VSVklDRSkgYXMgRGV2aWNlUG9saWN5TWFuYWdlclxuICAgICAgICByZXR1cm4gZHBtLmlzQWRtaW5BY3RpdmUoZ2V0Q29tcG9uZW50TmFtZShjb250ZXh0KSlcbiAgICB9XG5cbiAgICBmdW4gcmVxdWVzdERldmljZUFkbWluQWN0aXZhdGlvbihhY3Rpdml0eTogQWN0aXZpdHksIHJlcXVlc3RDb2RlOiBJbnQgPSAyMDAxKSB7XG4gICAgICAgIHZhbCBpbnRlbnQgPSBJbnRlbnQoRGV2aWNlUG9saWN5TWFuYWdlci5BQ1RJT05fQUREX0RFVklDRV9BRE1JTikuYXBwbHkge1xuICAgICAgICAgICAgcHV0RXh0cmEoRGV2aWNlUG9saWN5TWFuYWdlci5FWFRSQV9ERVZJQ0VfQURNSU4sIGdldENvbXBvbmVudE5hbWUoYWN0aXZpdHkpKVxuICAgICAgICAgICAgcHV0RXh0cmEoXG4gICAgICAgICAgICAgICAgRGV2aWNlUG9saWN5TWFuYWdlci5FWFRSQV9BRERfRVhQTEFOQVRJT04sXG4gICAgICAgICAgICAgICAgXCJTYWZlS2lkcyByZXF1aXJlcyBEZXZpY2UgQWRtaW5pc3RyYXRvciBwZXJtaXNzaW9uIHRvIHByZXZlbnQgdW5hdXRob3JpemVkIGFwcCB1bmluc3RhbGxhdGlvbiBieSBjaGlsZHJlbiBhbmQgZW5zdXJlIDI0Lzcgc2FmZXR5IHByb3RlY3Rpb24uXCJcbiAgICAgICAgICAgIClcbiAgICAgICAgfVxuICAgICAgICBhY3Rpdml0eS5zdGFydEFjdGl2aXR5Rm9yUmVzdWx0KGludGVudCwgcmVxdWVzdENvZGUpXG4gICAgfVxufVxuYCxcbiAgfSxcbiAge1xuICAgIGZpbGVuYW1lOiAnU2FmZUtpZHNQZXJtaXNzaW9uSGVscGVyLmt0JyxcbiAgICBsYW5ndWFnZTogJ2tvdGxpbicsXG4gICAgZGVzY3JpcHRpb246ICdNYW5hZ2VzIHJ1bnRpbWUgcGVybWlzc2lvbnMsIGZvcmVncm91bmQgc2VydmljZSBkZWNsYXJhdGlvbnMsIGJhdHRlcnkgb3B0aW1pemF0aW9uIHdoaXRlbGlzdCwgYW5kIGRpc2FibGVzIHBlcm1pc3Npb24gYXV0by1yZXZvY2F0aW9uLicsXG4gICAgY29udGVudDogYHBhY2thZ2UgY29tLnNhZmVraWRzLnBhcmVudGFsY29udHJvbC51dGlsXG5cbmltcG9ydCBhbmRyb2lkLk1hbmlmZXN0XG5pbXBvcnQgYW5kcm9pZC5hcHAuQWN0aXZpdHlcbmltcG9ydCBhbmRyb2lkLmNvbnRlbnQuQ29udGV4dFxuaW1wb3J0IGFuZHJvaWQuY29udGVudC5JbnRlbnRcbmltcG9ydCBhbmRyb2lkLmNvbnRlbnQucG0uUGFja2FnZU1hbmFnZXJcbmltcG9ydCBhbmRyb2lkLm5ldC5VcmlcbmltcG9ydCBhbmRyb2lkLm9zLkJ1aWxkXG5pbXBvcnQgYW5kcm9pZC5vcy5Qb3dlck1hbmFnZXJcbmltcG9ydCBhbmRyb2lkLnByb3ZpZGVyLlNldHRpbmdzXG5pbXBvcnQgYW5kcm9pZHguY29yZS5hcHAuQWN0aXZpdHlDb21wYXRcbmltcG9ydCBhbmRyb2lkeC5jb3JlLmNvbnRlbnQuQ29udGV4dENvbXBhdFxuXG5vYmplY3QgU2FmZUtpZHNQZXJtaXNzaW9uSGVscGVyIHtcblxuICAgIHZhbCBSRVFVSVJFRF9QRVJNSVNTSU9OUyA9IGFycmF5T2YoXG4gICAgICAgIE1hbmlmZXN0LnBlcm1pc3Npb24uQUNDRVNTX0ZJTkVfTE9DQVRJT04sXG4gICAgICAgIE1hbmlmZXN0LnBlcm1pc3Npb24uQUNDRVNTX0NPQVJTRV9MT0NBVElPTixcbiAgICAgICAgTWFuaWZlc3QucGVybWlzc2lvbi5DQU1FUkEsXG4gICAgICAgIE1hbmlmZXN0LnBlcm1pc3Npb24uUkVDT1JEX0FVRElPXG4gICAgKVxuXG4gICAgZnVuIGhhc0FsbFBlcm1pc3Npb25zKGNvbnRleHQ6IENvbnRleHQpOiBCb29sZWFuIHtcbiAgICAgICAgcmV0dXJuIFJFUVVJUkVEX1BFUk1JU1NJT05TLmFsbCB7XG4gICAgICAgICAgICBDb250ZXh0Q29tcGF0LmNoZWNrU2VsZlBlcm1pc3Npb24oY29udGV4dCwgaXQpID09IFBhY2thZ2VNYW5hZ2VyLlBFUk1JU1NJT05fR1JBTlRFRFxuICAgICAgICB9XG4gICAgfVxuXG4gICAgZnVuIHJlcXVlc3RGb3JlZ3JvdW5kUGVybWlzc2lvbnMoYWN0aXZpdHk6IEFjdGl2aXR5LCByZXF1ZXN0Q29kZTogSW50ID0gMzAwMSkge1xuICAgICAgICBBY3Rpdml0eUNvbXBhdC5yZXF1ZXN0UGVybWlzc2lvbnMoYWN0aXZpdHksIFJFUVVJUkVEX1BFUk1JU1NJT05TLCByZXF1ZXN0Q29kZSlcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBQcmV2ZW50cyBBbmRyb2lkIDExKyBmcm9tIGF1dG8tcmVzZXR0aW5nIHBlcm1pc3Npb25zIGFmdGVyIGluYWN0aXZpdHlcbiAgICAgKi9cbiAgICBmdW4gZGlzYWJsZVBlcm1pc3Npb25BdXRvUmVzZXQoY29udGV4dDogQ29udGV4dCkge1xuICAgICAgICBpZiAoQnVpbGQuVkVSU0lPTi5TREtfSU5UID49IEJ1aWxkLlZFUlNJT05fQ09ERVMuUikge1xuICAgICAgICAgICAgdmFsIHBtID0gY29udGV4dC5wYWNrYWdlTWFuYWdlclxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBwbS5zZXRBdXRvUmV2b2tlUGVybWlzc2lvbnNNb2RlKFxuICAgICAgICAgICAgICAgICAgICBjb250ZXh0LnBhY2thZ2VOYW1lLFxuICAgICAgICAgICAgICAgICAgICBQYWNrYWdlTWFuYWdlci5BVVRPX1JFVk9LRV9ESVNBTExPV0VEXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgfSBjYXRjaCAoZTogRXhjZXB0aW9uKSB7XG4gICAgICAgICAgICAgICAgdmFsIGludGVudCA9IEludGVudChJbnRlbnQuQUNUSU9OX0FVVE9fUkVWT0tFX1BFUk1JU1NJT05TKS5hcHBseSB7XG4gICAgICAgICAgICAgICAgICAgIGRhdGEgPSBVcmkucGFyc2UoXCJwYWNrYWdlOlwiICsgY29udGV4dC5wYWNrYWdlTmFtZSlcbiAgICAgICAgICAgICAgICAgICAgYWRkRmxhZ3MoSW50ZW50LkZMQUdfQUNUSVZJVFlfTkVXX1RBU0spXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnRleHQuc3RhcnRBY3Rpdml0eShpbnRlbnQpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBFeGVtcHRzIFNhZmVLaWRzIGZyb20gRG96ZSBNb2RlIHRvIGVuc3VyZSAyNC83IGJhY2tncm91bmQgR1BTIGFuZCBTT1MgYWxlcnRzXG4gICAgICovXG4gICAgZnVuIHJlcXVlc3RJZ25vcmVCYXR0ZXJ5T3B0aW1pemF0aW9uKGNvbnRleHQ6IENvbnRleHQpIHtcbiAgICAgICAgdmFsIHBvd2VyTWFuYWdlciA9IGNvbnRleHQuZ2V0U3lzdGVtU2VydmljZShDb250ZXh0LlBPV0VSX1NFUlZJQ0UpIGFzIFBvd2VyTWFuYWdlclxuICAgICAgICBpZiAoIXBvd2VyTWFuYWdlci5pc0lnbm9yaW5nQmF0dGVyeU9wdGltaXphdGlvbnMoY29udGV4dC5wYWNrYWdlTmFtZSkpIHtcbiAgICAgICAgICAgIHZhbCBpbnRlbnQgPSBJbnRlbnQoU2V0dGluZ3MuQUNUSU9OX1JFUVVFU1RfSUdOT1JFX0JBVFRFUllfT1BUSU1JWkFUSU9OUykuYXBwbHkge1xuICAgICAgICAgICAgICAgIGRhdGEgPSBVcmkucGFyc2UoXCJwYWNrYWdlOlwiICsgY29udGV4dC5wYWNrYWdlTmFtZSlcbiAgICAgICAgICAgICAgICBhZGRGbGFncyhJbnRlbnQuRkxBR19BQ1RJVklUWV9ORVdfVEFTSylcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnRleHQuc3RhcnRBY3Rpdml0eShpbnRlbnQpXG4gICAgICAgIH1cbiAgICB9XG59XG5gLFxuICB9LFxuICB7XG4gICAgZmlsZW5hbWU6ICdTYWZlS2lkc0xvY2F0aW9uRm9yZWdyb3VuZFNlcnZpY2Uua3QnLFxuICAgIGxhbmd1YWdlOiAna290bGluJyxcbiAgICBkZXNjcmlwdGlvbjogJ0ZvcmVncm91bmQgc2VydmljZSBmb3IgY29udGludW91cyBoaWdoLWFjY3VyYWN5IEdQUyB0cmFja2luZyBhbmQgZ2VvZmVuY2UgZW50ZXIvZXhpdCB0cmlnZ2Vycy4nLFxuICAgIGNvbnRlbnQ6IGBwYWNrYWdlIGNvbS5zYWZla2lkcy5wYXJlbnRhbGNvbnRyb2wuc2VydmljZVxuXG5pbXBvcnQgYW5kcm9pZC5hcHAuKlxuaW1wb3J0IGFuZHJvaWQuY29udGVudC5JbnRlbnRcbmltcG9ydCBhbmRyb2lkLm9zLklCaW5kZXJcbmltcG9ydCBhbmRyb2lkLm9zLkxvb3BlclxuaW1wb3J0IGFuZHJvaWR4LmNvcmUuYXBwLk5vdGlmaWNhdGlvbkNvbXBhdFxuaW1wb3J0IGNvbS5nb29nbGUuYW5kcm9pZC5nbXMubG9jYXRpb24uKlxuaW1wb3J0IGNvbS5zYWZla2lkcy5wYXJlbnRhbGNvbnRyb2wuUlxuXG5jbGFzcyBTYWZlS2lkc0xvY2F0aW9uRm9yZWdyb3VuZFNlcnZpY2UgOiBTZXJ2aWNlKCkge1xuXG4gICAgcHJpdmF0ZSBsYXRlaW5pdCB2YXIgZnVzZWRMb2NhdGlvbkNsaWVudDogRnVzZWRMb2NhdGlvblByb3ZpZGVyQ2xpZW50XG4gICAgcHJpdmF0ZSBsYXRlaW5pdCB2YXIgbG9jYXRpb25DYWxsYmFjazogTG9jYXRpb25DYWxsYmFja1xuXG4gICAgY29tcGFuaW9uIG9iamVjdCB7XG4gICAgICAgIGNvbnN0IHZhbCBDSEFOTkVMX0lEID0gXCJzYWZla2lkc19sb2NhdGlvbl9jaGFubmVsXCJcbiAgICAgICAgY29uc3QgdmFsIE5PVElGSUNBVElPTl9JRCA9IDEwMDFcbiAgICB9XG5cbiAgICBvdmVycmlkZSBmdW4gb25DcmVhdGUoKSB7XG4gICAgICAgIHN1cGVyLm9uQ3JlYXRlKClcbiAgICAgICAgZnVzZWRMb2NhdGlvbkNsaWVudCA9IExvY2F0aW9uU2VydmljZXMuZ2V0RnVzZWRMb2NhdGlvblByb3ZpZGVyQ2xpZW50KHRoaXMpXG4gICAgICAgIGNyZWF0ZU5vdGlmaWNhdGlvbkNoYW5uZWwoKVxuXG4gICAgICAgIGxvY2F0aW9uQ2FsbGJhY2sgPSBvYmplY3QgOiBMb2NhdGlvbkNhbGxiYWNrKCkge1xuICAgICAgICAgICAgb3ZlcnJpZGUgZnVuIG9uTG9jYXRpb25SZXN1bHQocmVzdWx0OiBMb2NhdGlvblJlc3VsdCkge1xuICAgICAgICAgICAgICAgIGZvciAobG9jYXRpb24gaW4gcmVzdWx0LmxvY2F0aW9ucykge1xuICAgICAgICAgICAgICAgICAgICAvLyBTZW5kIHRvIGJhY2tlbmQgYW5kIGNoZWNrIGxvY2FsIGdlb2ZlbmNlc1xuICAgICAgICAgICAgICAgICAgICBTYWZlS2lkc1N5bmNXb3JrZXIuZW5xdWV1ZUxvY2F0aW9uVXBkYXRlKGFwcGxpY2F0aW9uQ29udGV4dCwgbG9jYXRpb24pXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgb3ZlcnJpZGUgZnVuIG9uU3RhcnRDb21tYW5kKGludGVudDogSW50ZW50PywgZmxhZ3M6IEludCwgc3RhcnRJZDogSW50KTogSW50IHtcbiAgICAgICAgdmFsIG5vdGlmaWNhdGlvbiA9IE5vdGlmaWNhdGlvbkNvbXBhdC5CdWlsZGVyKHRoaXMsIENIQU5ORUxfSUQpXG4gICAgICAgICAgICAuc2V0Q29udGVudFRpdGxlKFwiU2FmZUtpZHMgQWN0aXZlXCIpXG4gICAgICAgICAgICAuc2V0Q29udGVudFRleHQoXCJMb2NhdGlvbiBzYWZldHkgJiBlbWVyZ2VuY3kgU09TIG1vbml0b3JpbmcgYWN0aXZlXCIpXG4gICAgICAgICAgICAuc2V0U21hbGxJY29uKFIuZHJhd2FibGUuaWNfc2hpZWxkKVxuICAgICAgICAgICAgLnNldE9uZ29pbmcodHJ1ZSlcbiAgICAgICAgICAgIC5idWlsZCgpXG5cbiAgICAgICAgc3RhcnRGb3JlZ3JvdW5kKE5PVElGSUNBVElPTl9JRCwgbm90aWZpY2F0aW9uKVxuICAgICAgICBzdGFydExvY2F0aW9uVXBkYXRlcygpXG4gICAgICAgIHJldHVybiBTVEFSVF9TVElDS1lcbiAgICB9XG5cbiAgICBwcml2YXRlIGZ1biBzdGFydExvY2F0aW9uVXBkYXRlcygpIHtcbiAgICAgICAgdmFsIHJlcXVlc3QgPSBMb2NhdGlvblJlcXVlc3QuQnVpbGRlcihQcmlvcml0eS5QUklPUklUWV9ISUdIX0FDQ1VSQUNZLCAzMDAwMClcbiAgICAgICAgICAgIC5zZXRNaW5VcGRhdGVJbnRlcnZhbE1pbGxpcygxNTAwMClcbiAgICAgICAgICAgIC5zZXRNaW5VcGRhdGVEaXN0YW5jZU1ldGVycygxMGYpXG4gICAgICAgICAgICAuYnVpbGQoKVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBmdXNlZExvY2F0aW9uQ2xpZW50LnJlcXVlc3RMb2NhdGlvblVwZGF0ZXMocmVxdWVzdCwgbG9jYXRpb25DYWxsYmFjaywgTG9vcGVyLmdldE1haW5Mb29wZXIoKSlcbiAgICAgICAgfSBjYXRjaCAoZTogU2VjdXJpdHlFeGNlcHRpb24pIHtcbiAgICAgICAgICAgIC8vIFBlcm1pc3Npb24gcmV2b2tlZFxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBmdW4gY3JlYXRlTm90aWZpY2F0aW9uQ2hhbm5lbCgpIHtcbiAgICAgICAgdmFsIGNoYW5uZWwgPSBOb3RpZmljYXRpb25DaGFubmVsKFxuICAgICAgICAgICAgQ0hBTk5FTF9JRCxcbiAgICAgICAgICAgIFwiU2FmZUtpZHMgU2FmZXR5IE1vbml0b3JpbmdcIixcbiAgICAgICAgICAgIE5vdGlmaWNhdGlvbk1hbmFnZXIuSU1QT1JUQU5DRV9MT1dcbiAgICAgICAgKVxuICAgICAgICB2YWwgbWFuYWdlciA9IGdldFN5c3RlbVNlcnZpY2UoTm90aWZpY2F0aW9uTWFuYWdlcjo6Y2xhc3MuamF2YSlcbiAgICAgICAgbWFuYWdlci5jcmVhdGVOb3RpZmljYXRpb25DaGFubmVsKGNoYW5uZWwpXG4gICAgfVxuXG4gICAgb3ZlcnJpZGUgZnVuIG9uQmluZChpbnRlbnQ6IEludGVudD8pOiBJQmluZGVyPyA9IG51bGxcbn1cbmAsXG4gIH0sXG4gIHtcbiAgICBmaWxlbmFtZTogJ1NhZmVLaWRzU2NyZWVuU2hhcmluZ1NlcnZpY2Uua3QnLFxuICAgIGxhbmd1YWdlOiAna290bGluJyxcbiAgICBkZXNjcmlwdGlvbjogJ0NvbnNlbnQtZmlyc3QgQW5kcm9pZCBNZWRpYVByb2plY3Rpb24gZm9yZWdyb3VuZCBzZXJ2aWNlIGZvciBsaXZlIHNjcmVlbiBzaGFyaW5nIHdpdGggcGVyc2lzdGVudCBub3RpZmljYXRpb24uJyxcbiAgICBjb250ZW50OiBgcGFja2FnZSBjb20uc2FmZWtpZHMucGFyZW50YWxjb250cm9sLnNlcnZpY2VcblxuaW1wb3J0IGFuZHJvaWQuYXBwLipcbmltcG9ydCBhbmRyb2lkLmNvbnRlbnQuSW50ZW50XG5pbXBvcnQgYW5kcm9pZC5tZWRpYS5wcm9qZWN0aW9uLk1lZGlhUHJvamVjdGlvblxuaW1wb3J0IGFuZHJvaWQubWVkaWEucHJvamVjdGlvbi5NZWRpYVByb2plY3Rpb25NYW5hZ2VyXG5pbXBvcnQgYW5kcm9pZC5vcy5JQmluZGVyXG5pbXBvcnQgYW5kcm9pZHguY29yZS5hcHAuTm90aWZpY2F0aW9uQ29tcGF0XG5pbXBvcnQgY29tLnNhZmVraWRzLnBhcmVudGFsY29udHJvbC5SXG5cbmNsYXNzIFNhZmVLaWRzU2NyZWVuU2hhcmluZ1NlcnZpY2UgOiBTZXJ2aWNlKCkge1xuXG4gICAgcHJpdmF0ZSB2YXIgbWVkaWFQcm9qZWN0aW9uOiBNZWRpYVByb2plY3Rpb24/ID0gbnVsbFxuXG4gICAgY29tcGFuaW9uIG9iamVjdCB7XG4gICAgICAgIGNvbnN0IHZhbCBDSEFOTkVMX0lEID0gXCJzYWZla2lkc19zY3JlZW5zaGFyZV9jaGFubmVsXCJcbiAgICAgICAgY29uc3QgdmFsIE5PVElGSUNBVElPTl9JRCA9IDIwMDJcbiAgICAgICAgY29uc3QgdmFsIEVYVFJBX1JFU1VMVF9DT0RFID0gXCJleHRyYV9yZXN1bHRfY29kZVwiXG4gICAgICAgIGNvbnN0IHZhbCBFWFRSQV9SRVNVTFRfREFUQSA9IFwiZXh0cmFfcmVzdWx0X2RhdGFcIlxuICAgIH1cblxuICAgIG92ZXJyaWRlIGZ1biBvblN0YXJ0Q29tbWFuZChpbnRlbnQ6IEludGVudD8sIGZsYWdzOiBJbnQsIHN0YXJ0SWQ6IEludCk6IEludCB7XG4gICAgICAgIHZhbCBub3RpZmljYXRpb24gPSBOb3RpZmljYXRpb25Db21wYXQuQnVpbGRlcih0aGlzLCBDSEFOTkVMX0lEKVxuICAgICAgICAgICAgLnNldENvbnRlbnRUaXRsZShcIlNhZmVLaWRzIFNjcmVlbiBTaGFyaW5nXCIpXG4gICAgICAgICAgICAuc2V0Q29udGVudFRleHQoXCJMaXZlIHNjcmVlbiBjaGVjay1pbiBzaGFyZWQgd2l0aCBwYXJlbnRcIilcbiAgICAgICAgICAgIC5zZXRTbWFsbEljb24oUi5kcmF3YWJsZS5pY19jYXN0KVxuICAgICAgICAgICAgLnNldE9uZ29pbmcodHJ1ZSlcbiAgICAgICAgICAgIC5hZGRBY3Rpb24oUi5kcmF3YWJsZS5pY19zdG9wLCBcIlN0b3AgU2hhcmluZ1wiLCBnZXRTdG9wUGVuZGluZ0ludGVudCgpKVxuICAgICAgICAgICAgLmJ1aWxkKClcblxuICAgICAgICBzdGFydEZvcmVncm91bmQoTk9USUZJQ0FUSU9OX0lELCBub3RpZmljYXRpb24pXG5cbiAgICAgICAgdmFsIHJlc3VsdENvZGUgPSBpbnRlbnQ/LmdldEludEV4dHJhKEVYVFJBX1JFU1VMVF9DT0RFLCBBY3Rpdml0eS5SRVNVTFRfQ0FOQ0VMRUQpID86IEFjdGl2aXR5LlJFU1VMVF9DQU5DRUxFRFxuICAgICAgICB2YWwgcmVzdWx0RGF0YSA9IGludGVudD8uZ2V0UGFyY2VsYWJsZUV4dHJhPEludGVudD4oRVhUUkFfUkVTVUxUX0RBVEEpXG5cbiAgICAgICAgaWYgKHJlc3VsdENvZGUgPT0gQWN0aXZpdHkuUkVTVUxUX09LICYmIHJlc3VsdERhdGEgIT0gbnVsbCkge1xuICAgICAgICAgICAgdmFsIHByb2plY3Rpb25NYW5hZ2VyID0gZ2V0U3lzdGVtU2VydmljZShNRURJQV9QUk9KRUNUSU9OX1NFUlZJQ0UpIGFzIE1lZGlhUHJvamVjdGlvbk1hbmFnZXJcbiAgICAgICAgICAgIG1lZGlhUHJvamVjdGlvbiA9IHByb2plY3Rpb25NYW5hZ2VyLmdldE1lZGlhUHJvamVjdGlvbihyZXN1bHRDb2RlLCByZXN1bHREYXRhKVxuICAgICAgICAgICAgLy8gU3RyZWFtIGZyYW1lcyBvdmVyIHNlY3VyZSBXZWJSVEMgcGVlciBjb25uZWN0aW9uXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gU1RBUlRfTk9UX1NUSUNLWVxuICAgIH1cblxuICAgIHByaXZhdGUgZnVuIGdldFN0b3BQZW5kaW5nSW50ZW50KCk6IFBlbmRpbmdJbnRlbnQge1xuICAgICAgICB2YWwgc3RvcEludGVudCA9IEludGVudCh0aGlzLCBTYWZlS2lkc1NjcmVlblNoYXJpbmdTZXJ2aWNlOjpjbGFzcy5qYXZhKS5hcHBseSB7XG4gICAgICAgICAgICBhY3Rpb24gPSBcIkFDVElPTl9TVE9QXCJcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gUGVuZGluZ0ludGVudC5nZXRTZXJ2aWNlKHRoaXMsIDAsIHN0b3BJbnRlbnQsIFBlbmRpbmdJbnRlbnQuRkxBR19JTU1VVEFCTEUpXG4gICAgfVxuXG4gICAgb3ZlcnJpZGUgZnVuIG9uRGVzdHJveSgpIHtcbiAgICAgICAgbWVkaWFQcm9qZWN0aW9uPy5zdG9wKClcbiAgICAgICAgc3VwZXIub25EZXN0cm95KClcbiAgICB9XG5cbiAgICBvdmVycmlkZSBmdW4gb25CaW5kKGludGVudDogSW50ZW50Pyk6IElCaW5kZXI/ID0gbnVsbFxufVxuYCxcbiAgfSxcbiAge1xuICAgIGZpbGVuYW1lOiAnQW5kcm9pZE1hbmlmZXN0LnhtbCcsXG4gICAgbGFuZ3VhZ2U6ICd4bWwnLFxuICAgIGRlc2NyaXB0aW9uOiAnRnVsbCBtYW5pZmVzdCBjb25maWd1cmVkIGZvciBBbmRyb2lkIDE0IChBUEkgMzQpIHdpdGggdHJhbnNwYXJlbnQgcGFyZW50YWwgY29udHJvbCBkZWNsYXJhdGlvbnMuJyxcbiAgICBjb250ZW50OiBgPD94bWwgdmVyc2lvbj1cIjEuMFwiIGVuY29kaW5nPVwidXRmLThcIj8+XG48bWFuaWZlc3QgeG1sbnM6YW5kcm9pZD1cImh0dHA6Ly9zY2hlbWFzLmFuZHJvaWQuY29tL2Fway9yZXMvYW5kcm9pZFwiXG4gICAgcGFja2FnZT1cImNvbS5zYWZla2lkcy5wYXJlbnRhbGNvbnRyb2xcIj5cblxuICAgIDwhLS0gTG9jYXRpb24gJiBTYWZldHkgUGVybWlzc2lvbnMgLS0+XG4gICAgPHVzZXMtcGVybWlzc2lvbiBhbmRyb2lkOm5hbWU9XCJhbmRyb2lkLnBlcm1pc3Npb24uQUNDRVNTX0ZJTkVfTE9DQVRJT05cIiAvPlxuICAgIDx1c2VzLXBlcm1pc3Npb24gYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5wZXJtaXNzaW9uLkFDQ0VTU19DT0FSU0VfTE9DQVRJT05cIiAvPlxuICAgIDx1c2VzLXBlcm1pc3Npb24gYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5wZXJtaXNzaW9uLkFDQ0VTU19CQUNLR1JPVU5EX0xPQ0FUSU9OXCIgLz5cbiAgICA8dXNlcy1wZXJtaXNzaW9uIGFuZHJvaWQ6bmFtZT1cImFuZHJvaWQucGVybWlzc2lvbi5GT1JFR1JPVU5EX1NFUlZJQ0VcIiAvPlxuICAgIDx1c2VzLXBlcm1pc3Npb24gYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5wZXJtaXNzaW9uLkZPUkVHUk9VTkRfU0VSVklDRV9MT0NBVElPTlwiIC8+XG4gICAgPHVzZXMtcGVybWlzc2lvbiBhbmRyb2lkOm5hbWU9XCJhbmRyb2lkLnBlcm1pc3Npb24uRk9SRUdST1VORF9TRVJWSUNFX01FRElBX1BST0pFQ1RJT05cIiAvPlxuICAgIDx1c2VzLXBlcm1pc3Npb24gYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5wZXJtaXNzaW9uLkZPUkVHUk9VTkRfU0VSVklDRV9DQU1FUkFcIiAvPlxuXG4gICAgPCEtLSBTY3JlZW4gVGltZSAmIEFwcCBNYW5hZ2VtZW50IC0tPlxuICAgIDx1c2VzLXBlcm1pc3Npb24gYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5wZXJtaXNzaW9uLlBBQ0tBR0VfVVNBR0VfU1RBVFNcIiAvPlxuICAgIDx1c2VzLXBlcm1pc3Npb24gYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5wZXJtaXNzaW9uLlFVRVJZX0FMTF9QQUNLQUdFU1wiIC8+XG4gICAgPHVzZXMtcGVybWlzc2lvbiBhbmRyb2lkOm5hbWU9XCJhbmRyb2lkLnBlcm1pc3Npb24uU1lTVEVNX0FMRVJUX1dJTkRPV1wiIC8+XG5cbiAgICA8IS0tIENhbWVyYSAmIEF1ZGlvIFBlcm1pc3Npb25zIGZvciBDaGVjay1JbiAtLT5cbiAgICA8dXNlcy1wZXJtaXNzaW9uIGFuZHJvaWQ6bmFtZT1cImFuZHJvaWQucGVybWlzc2lvbi5DQU1FUkFcIiAvPlxuICAgIDx1c2VzLXBlcm1pc3Npb24gYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5wZXJtaXNzaW9uLlJFQ09SRF9BVURJT1wiIC8+XG4gICAgPHVzZXMtcGVybWlzc2lvbiBhbmRyb2lkOm5hbWU9XCJhbmRyb2lkLnBlcm1pc3Npb24uSU5URVJORVRcIiAvPlxuICAgIDx1c2VzLXBlcm1pc3Npb24gYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5wZXJtaXNzaW9uLkFDQ0VTU19ORVRXT1JLX1NUQVRFXCIgLz5cbiAgICA8dXNlcy1wZXJtaXNzaW9uIGFuZHJvaWQ6bmFtZT1cImFuZHJvaWQucGVybWlzc2lvbi5SRUNFSVZFX0JPT1RfQ09NUExFVEVEXCIgLz5cbiAgICA8dXNlcy1wZXJtaXNzaW9uIGFuZHJvaWQ6bmFtZT1cImFuZHJvaWQucGVybWlzc2lvbi5WSUJSQVRFXCIgLz5cblxuICAgIDxhcHBsaWNhdGlvblxuICAgICAgICBhbmRyb2lkOm5hbWU9XCIuU2FmZUtpZHNBcHBsaWNhdGlvblwiXG4gICAgICAgIGFuZHJvaWQ6YWxsb3dCYWNrdXA9XCJmYWxzZVwiXG4gICAgICAgIGFuZHJvaWQ6aWNvbj1cIkBtaXBtYXAvaWNfbGF1bmNoZXJcIlxuICAgICAgICBhbmRyb2lkOmxhYmVsPVwiQHN0cmluZy9hcHBfbmFtZVwiXG4gICAgICAgIGFuZHJvaWQ6cm91bmRJY29uPVwiQG1pcG1hcC9pY19sYXVuY2hlcl9yb3VuZFwiXG4gICAgICAgIGFuZHJvaWQ6c3VwcG9ydHNSdGw9XCJ0cnVlXCJcbiAgICAgICAgYW5kcm9pZDp0aGVtZT1cIkBzdHlsZS9UaGVtZS5TYWZlS2lkc1wiPlxuXG4gICAgICAgIDxhY3Rpdml0eVxuICAgICAgICAgICAgYW5kcm9pZDpuYW1lPVwiLnVpLk1haW5BY3Rpdml0eVwiXG4gICAgICAgICAgICBhbmRyb2lkOmV4cG9ydGVkPVwidHJ1ZVwiPlxuICAgICAgICAgICAgPGludGVudC1maWx0ZXI+XG4gICAgICAgICAgICAgICAgPGFjdGlvbiBhbmRyb2lkOm5hbWU9XCJhbmRyb2lkLmludGVudC5hY3Rpb24uTUFJTlwiIC8+XG4gICAgICAgICAgICAgICAgPGNhdGVnb3J5IGFuZHJvaWQ6bmFtZT1cImFuZHJvaWQuaW50ZW50LmNhdGVnb3J5LkxBVU5DSEVSXCIgLz5cbiAgICAgICAgICAgIDwvaW50ZW50LWZpbHRlcj5cbiAgICAgICAgPC9hY3Rpdml0eT5cblxuICAgICAgICA8YWN0aXZpdHlcbiAgICAgICAgICAgIGFuZHJvaWQ6bmFtZT1cIi51aS5BcHBCbG9ja0FjdGl2aXR5XCJcbiAgICAgICAgICAgIGFuZHJvaWQ6dGhlbWU9XCJAc3R5bGUvVGhlbWUuU2FmZUtpZHMuRnVsbHNjcmVlblwiXG4gICAgICAgICAgICBhbmRyb2lkOmV4cG9ydGVkPVwiZmFsc2VcIiAvPlxuXG4gICAgICAgIDwhLS0gQWNjZXNzaWJpbGl0eSBTZXJ2aWNlIGZvciBBcHAgJiBXZWIgR3VhcmQgLS0+XG4gICAgICAgIDxzZXJ2aWNlXG4gICAgICAgICAgICBhbmRyb2lkOm5hbWU9XCIuc2VydmljZS5TYWZlS2lkc0FjY2Vzc2liaWxpdHlTZXJ2aWNlXCJcbiAgICAgICAgICAgIGFuZHJvaWQ6cGVybWlzc2lvbj1cImFuZHJvaWQucGVybWlzc2lvbi5CSU5EX0FDQ0VTU0lCSUxJVFlfU0VSVklDRVwiXG4gICAgICAgICAgICBhbmRyb2lkOmV4cG9ydGVkPVwidHJ1ZVwiPlxuICAgICAgICAgICAgPGludGVudC1maWx0ZXI+XG4gICAgICAgICAgICAgICAgPGFjdGlvbiBhbmRyb2lkOm5hbWU9XCJhbmRyb2lkLmFjY2Vzc2liaWxpdHlzZXJ2aWNlLkFjY2Vzc2liaWxpdHlTZXJ2aWNlXCIgLz5cbiAgICAgICAgICAgIDwvaW50ZW50LWZpbHRlcj5cbiAgICAgICAgICAgIDxtZXRhLWRhdGFcbiAgICAgICAgICAgICAgICBhbmRyb2lkOm5hbWU9XCJhbmRyb2lkLmFjY2Vzc2liaWxpdHlzZXJ2aWNlXCJcbiAgICAgICAgICAgICAgICBhbmRyb2lkOnJlc291cmNlPVwiQHhtbC9hY2Nlc3NpYmlsaXR5X3NlcnZpY2VfY29uZmlnXCIgLz5cbiAgICAgICAgPC9zZXJ2aWNlPlxuXG4gICAgICAgIDwhLS0gRGV2aWNlIEFkbWluIFJlY2VpdmVyIC0tPlxuICAgICAgICA8cmVjZWl2ZXJcbiAgICAgICAgICAgIGFuZHJvaWQ6bmFtZT1cIi5yZWNlaXZlci5TYWZlS2lkc0RldmljZUFkbWluUmVjZWl2ZXJcIlxuICAgICAgICAgICAgYW5kcm9pZDpwZXJtaXNzaW9uPVwiYW5kcm9pZC5wZXJtaXNzaW9uLkJJTkRfREVWSUNFX0FETUlOXCJcbiAgICAgICAgICAgIGFuZHJvaWQ6ZXhwb3J0ZWQ9XCJ0cnVlXCI+XG4gICAgICAgICAgICA8bWV0YS1kYXRhXG4gICAgICAgICAgICAgICAgYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5hcHAuZGV2aWNlX2FkbWluXCJcbiAgICAgICAgICAgICAgICBhbmRyb2lkOnJlc291cmNlPVwiQHhtbC9kZXZpY2VfYWRtaW5fcnVsZXNcIiAvPlxuICAgICAgICAgICAgPGludGVudC1maWx0ZXI+XG4gICAgICAgICAgICAgICAgPGFjdGlvbiBhbmRyb2lkOm5hbWU9XCJhbmRyb2lkLmFwcC5hY3Rpb24uREVWSUNFX0FETUlOX0VOQUJMRURcIiAvPlxuICAgICAgICAgICAgPC9pbnRlbnQtZmlsdGVyPlxuICAgICAgICA8L3JlY2VpdmVyPlxuXG4gICAgICAgIDwhLS0gRm9yZWdyb3VuZCBTZXJ2aWNlcyAtLT5cbiAgICAgICAgPHNlcnZpY2VcbiAgICAgICAgICAgIGFuZHJvaWQ6bmFtZT1cIi5zZXJ2aWNlLlNhZmVLaWRzTG9jYXRpb25Gb3JlZ3JvdW5kU2VydmljZVwiXG4gICAgICAgICAgICBhbmRyb2lkOmZvcmVncm91bmRTZXJ2aWNlVHlwZT1cImxvY2F0aW9uXCIgLz5cblxuICAgICAgICA8c2VydmljZVxuICAgICAgICAgICAgYW5kcm9pZDpuYW1lPVwiLnNlcnZpY2UuU2FmZUtpZHNTY3JlZW5TaGFyaW5nU2VydmljZVwiXG4gICAgICAgICAgICBhbmRyb2lkOmZvcmVncm91bmRTZXJ2aWNlVHlwZT1cIm1lZGlhUHJvamVjdGlvblwiIC8+XG4gICAgPC9hcHBsaWNhdGlvbj5cbjwvbWFuaWZlc3Q+XG5gLFxuICB9LFxuICB7XG4gICAgZmlsZW5hbWU6ICdidWlsZC5ncmFkbGUua3RzJyxcbiAgICBsYW5ndWFnZTogJ2tvdGxpbicsXG4gICAgZGVzY3JpcHRpb246ICdHcmFkbGUgYnVpbGQgc2NyaXB0IGNvbmZpZ3VyZWQgd2l0aCBLb3RsaW4gRFNMLCBKZXRwYWNrIENvbXBvc2UsIGFuZCBDYW1lcmFYLicsXG4gICAgY29udGVudDogYHBsdWdpbnMge1xuICAgIGFsaWFzKGxpYnMucGx1Z2lucy5hbmRyb2lkLmFwcGxpY2F0aW9uKVxuICAgIGFsaWFzKGxpYnMucGx1Z2lucy5rb3RsaW4uYW5kcm9pZClcbiAgICBhbGlhcyhsaWJzLnBsdWdpbnMuY29tcG9zZS5jb21waWxlcilcbn1cblxuYW5kcm9pZCB7XG4gICAgbmFtZXNwYWNlID0gXCJjb20uc2FmZWtpZHMucGFyZW50YWxjb250cm9sXCJcbiAgICBjb21waWxlU2RrID0gMzRcblxuICAgIGRlZmF1bHRDb25maWcge1xuICAgICAgICBhcHBsaWNhdGlvbklkID0gXCJjb20uc2FmZWtpZHMucGFyZW50YWxjb250cm9sXCJcbiAgICAgICAgbWluU2RrID0gMjZcbiAgICAgICAgdGFyZ2V0U2RrID0gMzRcbiAgICAgICAgdmVyc2lvbkNvZGUgPSAxMDBcbiAgICAgICAgdmVyc2lvbk5hbWUgPSBcIjEuMC4wXCJcblxuICAgICAgICB0ZXN0SW5zdHJ1bWVudGF0aW9uUnVubmVyID0gXCJhbmRyb2lkeC50ZXN0LnJ1bm5lci5BbmRyb2lkSlVuaXRSdW5uZXJcIlxuICAgICAgICB2ZWN0b3JEcmF3YWJsZXMge1xuICAgICAgICAgICAgdXNlU3VwcG9ydExpYnJhcnkgPSB0cnVlXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBidWlsZFR5cGVzIHtcbiAgICAgICAgcmVsZWFzZSB7XG4gICAgICAgICAgICBpc01pbmlmeUVuYWJsZWQgPSB0cnVlXG4gICAgICAgICAgICBpc1Nocmlua1Jlc291cmNlcyA9IHRydWVcbiAgICAgICAgICAgIHByb2d1YXJkRmlsZXMoXG4gICAgICAgICAgICAgICAgZ2V0RGVmYXVsdFByb2d1YXJkRmlsZShcInByb2d1YXJkLWFuZHJvaWQtb3B0aW1pemUudHh0XCIpLFxuICAgICAgICAgICAgICAgIFwicHJvZ3VhcmQtcnVsZXMucHJvXCJcbiAgICAgICAgICAgIClcbiAgICAgICAgfVxuICAgIH1cbn1cblxuZGVwZW5kZW5jaWVzIHtcbiAgICAvLyBBbmRyb2lkWCAmIEpldHBhY2sgQ29tcG9zZVxuICAgIGltcGxlbWVudGF0aW9uKHBsYXRmb3JtKGxpYnMuYW5kcm9pZHguY29tcG9zZS5ib20pKVxuICAgIGltcGxlbWVudGF0aW9uKGxpYnMuYW5kcm9pZHgudWkpXG4gICAgaW1wbGVtZW50YXRpb24obGlicy5hbmRyb2lkeC5tYXRlcmlhbDMpXG5cbiAgICAvLyBQbGF5IFNlcnZpY2VzIExvY2F0aW9uICYgR2VvZmVuY2luZ1xuICAgIGltcGxlbWVudGF0aW9uKFwiY29tLmdvb2dsZS5hbmRyb2lkLmdtczpwbGF5LXNlcnZpY2VzLWxvY2F0aW9uOjIxLjIuMFwiKVxuXG4gICAgLy8gQ2FtZXJhWCBmb3IgTGl2ZSBDYW1lcmEgTG9vay1JblxuICAgIGltcGxlbWVudGF0aW9uKFwiYW5kcm9pZHguY2FtZXJhOmNhbWVyYS1jb3JlOjEuMy4zXCIpXG4gICAgaW1wbGVtZW50YXRpb24oXCJhbmRyb2lkeC5jYW1lcmE6Y2FtZXJhLWNhbWVyYTI6MS4zLjNcIilcbiAgICBpbXBsZW1lbnRhdGlvbihcImFuZHJvaWR4LmNhbWVyYTpjYW1lcmEtbGlmZWN5Y2xlOjEuMy4zXCIpXG4gICAgaW1wbGVtZW50YXRpb24oXCJhbmRyb2lkeC5jYW1lcmE6Y2FtZXJhLXZpZXc6MS4zLjNcIilcblxuICAgIC8vIENvcm91dGluZXMgJiBMaWZlY3ljbGVcbiAgICBpbXBsZW1lbnRhdGlvbihcIm9yZy5qZXRicmFpbnMua290bGlueDprb3RsaW54LWNvcm91dGluZXMtYW5kcm9pZDoxLjguMFwiKVxuICAgIGltcGxlbWVudGF0aW9uKFwiYW5kcm9pZHgubGlmZWN5Y2xlOmxpZmVjeWNsZS12aWV3bW9kZWwtY29tcG9zZToyLjcuMFwiKVxufVxuYCxcbiAgfSxcbl07XG5cbmV4cG9ydCBjb25zdCBBbmRyb2lkTmF0aXZlS2l0OiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgW3NlbGVjdGVkU25pcHBldCwgc2V0U2VsZWN0ZWRTbmlwcGV0XSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG4gIGNvbnN0IFtjb3BpZWQsIHNldENvcGllZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZTwnc291cmNlJyB8ICdkYXRhc2FmZXR5JyB8ICdidWlsZCcgfCAncHJpdmFjeSc+KCdzb3VyY2UnKTtcblxuICBjb25zdCBoYW5kbGVDb3B5ID0gKCkgPT4ge1xuICAgIG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KEFORFJPSURfU05JUFBFVFNbc2VsZWN0ZWRTbmlwcGV0XS5jb250ZW50KTtcbiAgICBzZXRDb3BpZWQodHJ1ZSk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRDb3BpZWQoZmFsc2UpLCAyMDAwKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVEb3dubG9hZCA9ICgpID0+IHtcbiAgICBjb25zdCBzbmlwcGV0ID0gQU5EUk9JRF9TTklQUEVUU1tzZWxlY3RlZFNuaXBwZXRdO1xuICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbc25pcHBldC5jb250ZW50XSwgeyB0eXBlOiAndGV4dC9wbGFpbicgfSk7XG4gICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgIGEuaHJlZiA9IHVybDtcbiAgICBhLmRvd25sb2FkID0gc25pcHBldC5maWxlbmFtZTtcbiAgICBhLmNsaWNrKCk7XG4gICAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgIHsvKiBUb3AgQmFubmVyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdmlhLWluZGlnby02MDAgdG8tdmlvbGV0LTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtMnhsIHAtNiBzaGFkb3ctbWRcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8U21hcnRwaG9uZSBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtYmx1ZS0yMDBcIiAvPlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgICAgICBBbmRyb2lkIE5hdGl2ZSBBcmNoaXRlY3R1cmUgJiBHb29nbGUgUGxheSBSZWxlYXNlIEtpdFxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtYmx1ZS0xMDAgbWF4LXctMnhsIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICBTYWZlS2lkcyBpcyBlbmdpbmVlcmVkIGZvciByZWFsIEFuZHJvaWQgZGVwbG95bWVudC4gRXhwbG9yZSB0aGUgcHJvZHVjdGlvbiBLb3RsaW4gc2VydmljZXMsIEFjY2Vzc2liaWxpdHkgJiBEZXZpY2UgQWRtaW4gcG9saWNpZXMsIEdvb2dsZSBQbGF5IERhdGEgU2FmZXR5IGFuc3dlcnMsIGFuZCByZXByb2R1Y2libGUgYnVpbGQgc2NyaXB0cy5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHNocmluay0wXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy13aGl0ZS8yMCBiYWNrZHJvcC1ibHVyLW1kIHB4LTMgcHktMS41IHJvdW5kZWQtbGcgdGV4dC14cyBmb250LXNlbWlib2xkIGJvcmRlciBib3JkZXItd2hpdGUvMzBcIj5cbiAgICAgICAgICAgICAgVGFyZ2V0IFNESzogMzQgKEFuZHJvaWQgMTQpXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTUwMC84MCBweC0zIHB5LTEuNSByb3VuZGVkLWxnIHRleHQteHMgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAxMDAlIEZyZWUgJiBPcGVuIFNvdXJjZVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVGFiIFN3aXRjaGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG10LTYgb3ZlcmZsb3cteC1hdXRvIHBiLTEgYm9yZGVyLXQgYm9yZGVyLXdoaXRlLzIwIHB0LTRcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ3NvdXJjZScpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMy41IHB5LTEuNSByb3VuZGVkLWxnIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHdoaXRlc3BhY2Utbm93cmFwICR7XG4gICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ3NvdXJjZScgPyAnYmctd2hpdGUgdGV4dC1ibHVlLTcwMCBzaGFkb3ctc20nIDogJ3RleHQtYmx1ZS0xMDAgaG92ZXI6Ymctd2hpdGUvMTAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8Q29kZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IEtvdGxpbiAmIFhNTCBTb3VyY2VcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2RhdGFzYWZldHknKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMuNSBweS0xLjUgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1hbGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB3aGl0ZXNwYWNlLW5vd3JhcCAke1xuICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICdkYXRhc2FmZXR5JyA/ICdiZy13aGl0ZSB0ZXh0LWJsdWUtNzAwIHNoYWRvdy1zbScgOiAndGV4dC1ibHVlLTEwMCBob3ZlcjpiZy13aGl0ZS8xMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IEdvb2dsZSBQbGF5IERhdGEgU2FmZXR5XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdidWlsZCcpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMy41IHB5LTEuNSByb3VuZGVkLWxnIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHdoaXRlc3BhY2Utbm93cmFwICR7XG4gICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ2J1aWxkJyA/ICdiZy13aGl0ZSB0ZXh0LWJsdWUtNzAwIHNoYWRvdy1zbScgOiAndGV4dC1ibHVlLTEwMCBob3ZlcjpiZy13aGl0ZS8xMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxUZXJtaW5hbCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IEJ1aWxkICYgUmVsZWFzZSBHdWlkZVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYigncHJpdmFjeScpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMy41IHB5LTEuNSByb3VuZGVkLWxnIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHdoaXRlc3BhY2Utbm93cmFwICR7XG4gICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ3ByaXZhY3knID8gJ2JnLXdoaXRlIHRleHQtYmx1ZS03MDAgc2hhZG93LXNtJyA6ICd0ZXh0LWJsdWUtMTAwIGhvdmVyOmJnLXdoaXRlLzEwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEZpbGVUZXh0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gQ09QUEEgLyBQcml2YWN5IFBvbGljeVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogVGFiOiBTb3VyY2UgQ29kZSAqL31cbiAgICAgIHthY3RpdmVUYWIgPT09ICdzb3VyY2UnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0xMiBnYXAtNVwiPlxuICAgICAgICAgIHsvKiBGaWxlIFNlbGVjdG9yICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNCBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgcHgtMlwiPlxuICAgICAgICAgICAgICBBbmRyb2lkIFNvdXJjZSBNb2R1bGVzXG4gICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICB7QU5EUk9JRF9TTklQUEVUUy5tYXAoKHNuaXBwZXQsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIGtleT17c25pcHBldC5maWxlbmFtZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkU25pcHBldChpZHgpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHRleHQtbGVmdCBwLTMgcm91bmRlZC14bCBib3JkZXIgdGV4dC14cyB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFNuaXBwZXQgPT09IGlkeFxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWJsdWUtNTAgZGFyazpiZy1ibHVlLTk1MC80MCBib3JkZXItYmx1ZS01MDAgdGV4dC1ibHVlLTkwMCBkYXJrOnRleHQtYmx1ZS0yMDAgZm9udC1zZW1pYm9sZCBzaGFkb3ctc20nXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS01MCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMC81MCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXhzXCI+e3NuaXBwZXQuZmlsZW5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3NuaXBwZXQubGFuZ3VhZ2V9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBtdC0xIGxpbmUtY2xhbXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICB7c25pcHBldC5kZXNjcmlwdGlvbn1cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBDb2RlIFZpZXdlciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTggYmctc2xhdGUtOTUwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIG92ZXJmbG93LWhpZGRlbiBzaGFkb3ctbGcgZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvOTAgcHgtNCBweS0zIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgdGV4dC1ibHVlLTQwMCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICB7QU5EUk9JRF9TTklQUEVUU1tzZWxlY3RlZFNuaXBwZXRdLmZpbGVuYW1lfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAge0FORFJPSURfU05JUFBFVFNbc2VsZWN0ZWRTbmlwcGV0XS5kZXNjcmlwdGlvbn1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ29weX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIuNSBweS0xLjUgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTIwMCB0ZXh0LXhzIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtjb3BpZWQgPyA8Q2hlY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTQwMFwiIC8+IDogPENvcHkgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPn1cbiAgICAgICAgICAgICAgICAgIDxzcGFuPntjb3BpZWQgPyAnQ29waWVkJyA6ICdDb3B5J308L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRG93bmxvYWR9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMS41IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNzAwIHRleHQtd2hpdGUgdGV4dC14cyByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGZvbnQtbWVkaXVtXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBEb3dubG9hZFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8cHJlIGNsYXNzTmFtZT1cInAtNCB0ZXh0LXhzIGZvbnQtbW9ubyB0ZXh0LXNsYXRlLTIwMCBvdmVyZmxvdy14LWF1dG8gbWF4LWgtWzUwMHB4XSBsZWFkaW5nLXJlbGF4ZWQgc2VsZWN0aW9uOmJnLWJsdWUtNzAwXCI+XG4gICAgICAgICAgICAgIDxjb2RlPntBTkRST0lEX1NOSVBQRVRTW3NlbGVjdGVkU25pcHBldF0uY29udGVudH08L2NvZGU+XG4gICAgICAgICAgICA8L3ByZT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogVGFiOiBEYXRhIFNhZmV0eSAqL31cbiAgICAgIHthY3RpdmVUYWIgPT09ICdkYXRhc2FmZXR5JyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHAtNiBzcGFjZS15LTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHBiLTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctZW1lcmFsZC0xMDAgZGFyazpiZy1lbWVyYWxkLTkwMC80MCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAg4pyTXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICBHb29nbGUgUGxheSBDb25zb2xlIOKAlCBEYXRhIFNhZmV0eSBGb3JtIFNwZWNpZmljYXRpb25cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgRXhhY3QgcmVzcG9uc2VzIHJlcXVpcmVkIGZvciBHb29nbGUgUGxheSBhcHByb3ZhbCB1bmRlciB0aGUgRmFtaWx5ICYgUGFyZW50YWwgQ29udHJvbCBjYXRlZ29yeS5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC00IGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzQwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXhzIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LWJsdWUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICAgIDEuIExvY2F0aW9uIChBcHByb3hpbWF0ZSAmIFByZWNpc2UpXG4gICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgIDxzdHJvbmc+Q29sbGVjdGVkOjwvc3Ryb25nPiBZZXMgfCA8c3Ryb25nPlNoYXJlZCB3aXRoIDNyZCBwYXJ0aWVzOjwvc3Ryb25nPiBOb1xuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgIDxzdHJvbmc+UHVycG9zZTo8L3N0cm9uZz4gQXBwIGZ1bmN0aW9uYWxpdHksIFBhcmVudGFsIENvbnRyb2xzIChMaXZlIEdQUyBsb2NhdGlvbiBhbmQgc2FmZS16b25lIGdlb2ZlbmNpbmcgbm90aWZpY2F0aW9ucykuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgPHN0cm9uZz5FbmNyeXB0ZWQgaW4gdHJhbnNpdDo8L3N0cm9uZz4gWWVzIChIVFRQUy9UTFMgMS4zKS5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHJvdW5kZWQteGwgcC00IGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzQwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXhzIHRleHQtaW5kaWdvLTYwMCBkYXJrOnRleHQtaW5kaWdvLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICAyLiBBcHAgQWN0aXZpdHkgJiBVc2FnZVxuICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICA8c3Ryb25nPkNvbGxlY3RlZDo8L3N0cm9uZz4gWWVzIHwgPHN0cm9uZz5TaGFyZWQgd2l0aCAzcmQgcGFydGllczo8L3N0cm9uZz4gTm9cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICA8c3Ryb25nPlB1cnBvc2U6PC9zdHJvbmc+IFNjcmVlbiB0aW1lIGNhbGN1bGF0aW9uIGFuZCBhcHAtYmxvY2tpbmcgcnVsZXMgZW5mb3JjZW1lbnQgcmVxdWVzdGVkIGJ5IHBhcmVudC5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICA8c3Ryb25nPkVwaGVtZXJhbCBQcm9jZXNzaW5nOjwvc3Ryb25nPiBTdG9yZWQgbG9jYWxseSBvciBpbiBmYW1pbHktb25seSBhdXRoZW50aWNhdGVkIGRhdGFiYXNlLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTQgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQteHMgdGV4dC1hbWJlci02MDAgZGFyazp0ZXh0LWFtYmVyLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICAzLiBDYW1lcmEgJiBBdWRpbyBTdHJlYW1cbiAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgPHN0cm9uZz5Db2xsZWN0ZWQ6PC9zdHJvbmc+IE5vIHBlcm1hbmVudCBzdG9yYWdlIHwgPHN0cm9uZz5TaGFyZWQgd2l0aCAzcmQgcGFydGllczo8L3N0cm9uZz4gTm9cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICA8c3Ryb25nPlB1cnBvc2U6PC9zdHJvbmc+IFBhcmVudCBjaGVjay1pbiB3aXRoIGV4cGxpY2l0IGNoaWxkIGludGVyYWN0aXZlIGNvbnNlbnQgcHJvbXB0IGFuZCBwZXJzaXN0ZW50IGZvcmVncm91bmQgaW5kaWNhdG9yLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTQgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQteHMgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgNC4gQWNjb3VudCAmIERlbGV0aW9uIFJpZ2h0c1xuICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICA8c3Ryb25nPlVzZXIgQWNjb3VudCBEZWxldGlvbjo8L3N0cm9uZz4gRnVsbHkgc3VwcG9ydGVkIGluc2lkZSBhcHAgc2V0dGluZ3MuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgQWxsIGxvY2F0aW9uIGhpc3RvcmllcywgYWxlcnRzLCBhbmQgcGFpcmluZyByZWNvcmRzIGFyZSB3aXBlZCBpbW1lZGlhdGVseSB1cG9uIHVucGFpcmluZyBvciBhY2NvdW50IHRlcm1pbmF0aW9uLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogVGFiOiBCdWlsZCAmIFJlbGVhc2UgR3VpZGUgKi99XG4gICAgICB7YWN0aXZlVGFiID09PSAnYnVpbGQnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcC02IHNwYWNlLXktNVwiPlxuICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxUZXJtaW5hbCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYmx1ZS02MDBcIiAvPlxuICAgICAgICAgICAgUmVwcm9kdWNpYmxlIEFuZHJvaWQgQnVpbGQgSW5zdHJ1Y3Rpb25zXG4gICAgICAgICAgPC9oMz5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00IHRleHQteHMgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAgICAgIFN0ZXAgMTogUHJlcmVxdWlzaXRlc1xuICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgSW5zdGFsbCBBbmRyb2lkIFN0dWRpbyBIZWRnZWhvZyAoMjAyMy4xLjEpIG9yIG5ld2VyLCB3aXRoIEpESyAxNyBhbmQgQW5kcm9pZCBTREsgMzQuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgU3RlcCAyOiBHZW5lcmF0ZSBSZWxlYXNlIEtleXN0b3JlXG4gICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMyByb3VuZGVkLXhsIGZvbnQtbW9ubyB0ZXh0LWVtZXJhbGQtNDAwIHRleHQtWzExcHhdIG92ZXJmbG93LXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgIGtleXRvb2wgLWdlbmtleSAtdiAta2V5c3RvcmUgc2FmZWtpZHMtcmVsZWFzZS5qa3MgLWFsaWFzIHNhZmVraWRzIC1rZXlhbGcgUlNBIC1rZXlzaXplIDIwNDggLXZhbGlkaXR5IDEwMDAwXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICBTdGVwIDM6IENvbXBpbGUgU2lnbmVkIEFuZHJvaWQgQXBwIEJ1bmRsZSAoQUFCKVxuICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTMgcm91bmRlZC14bCBmb250LW1vbm8gdGV4dC1lbWVyYWxkLTQwMCB0ZXh0LVsxMXB4XSBvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAuL2dyYWRsZXcgYnVuZGxlUmVsZWFzZVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICBUaGUgZ2VuZXJhdGVkIG91dHB1dCB3aWxsIGJlIGxvY2F0ZWQgYXQ6IDxjb2RlPmFwcC9idWlsZC9vdXRwdXRzL2J1bmRsZS9yZWxlYXNlL2FwcC1yZWxlYXNlLmFhYjwvY29kZT4uXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgU3RlcCA0OiBUYXJnZXQgU0RLICYgR29vZ2xlIFBsYXkgQ29tcGxpYW5jZSBWZXJpZmljYXRpb25cbiAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImxpc3QtZGlzYyBsaXN0LWluc2lkZSBzcGFjZS15LTEgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgIDxsaT5WZXJpZnkgPGNvZGU+dGFyZ2V0U2RrID0gMzQ8L2NvZGU+IGluIDxjb2RlPmFwcC9idWlsZC5ncmFkbGUua3RzPC9jb2RlPi48L2xpPlxuICAgICAgICAgICAgICAgIDxsaT5FbnN1cmUgRm9yZWdyb3VuZCBTZXJ2aWNlIHBlcm1pc3Npb25zIGRlY2xhcmUgYXBwcm9wcmlhdGUgc2VydmljZSB0eXBlcyAobG9jYXRpb24sIG1lZGlhUHJvamVjdGlvbikuPC9saT5cbiAgICAgICAgICAgICAgICA8bGk+U3VibWl0IEFjY2Vzc2liaWxpdHkgU2VydmljZSBkZWNsYXJhdGlvbiB2aWRlbyBzaG93aW5nIHBhcmVudGFsIGNvbnRyb2wgZnVuY3Rpb25hbGl0eSB0byB0aGUgR29vZ2xlIFBsYXkgcmV2aWV3IHRlYW0uPC9saT5cbiAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBUYWI6IFByaXZhY3kgUG9saWN5ICovfVxuICAgICAge2FjdGl2ZVRhYiA9PT0gJ3ByaXZhY3knICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcC02IHNwYWNlLXktNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHBiLTNcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICBTYWZlS2lkcyBGcmVlIFBhcmVudGFsIENvbnRyb2wgUHJpdmFjeSBQb2xpY3lcbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgQ29tcGxpYW50IHdpdGggQ09QUEEsIEdEUFItSywgYW5kIEdvb2dsZSBQbGF5IEZhbWlsaWVzIFBvbGljeS5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcHgtMi41IHB5LTEgYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTcwMCBkYXJrOmJnLWJsdWUtOTAwLzUwIGRhcms6dGV4dC1ibHVlLTMwMCByb3VuZGVkLWxnXCI+XG4gICAgICAgICAgICAgIE9wZW4gUG9saWN5IHYxLjBcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNDAgcm91bmRlZC14bCBwLTQgdGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHNwYWNlLXktMyBsZWFkaW5nLXJlbGF4ZWQgbWF4LWgtOTYgb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0xMDBcIj4xLiBDb21taXRtZW50IHRvIENoaWxkIFByaXZhY3kgJiBTYWZldHk8L2g0PlxuICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgIFNhZmVLaWRzIGlzIGJ1aWx0IGFzIGEgMTAwJSBmcmVlIHBhcmVudGFsIGNvbnRyb2wgdG9vbCBkZXNpZ25lZCB0byBwcm90ZWN0IGNoaWxkcmVuIHdoaWxlIHVwaG9sZGluZyBkaWdpdGFsIGRpZ25pdHkuIFNhZmVLaWRzIGRvZXMgTk9UIHNlbGwsIG1vbmV0aXplLCBvciBicm9rZXIgcGVyc29uYWwgZGF0YSwgbG9jYXRpb24gdHJhY2VzLCBvciBkZXZpY2UgdGVsZW1ldHJ5IHRvIGFueSB0aGlyZCBwYXJ0eSBvciBhZHZlcnRpc2VyLlxuICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0xMDBcIj4yLiBSZWFsLVRpbWUgTG9jYXRpb24gJiBHZW9mZW5jaW5nPC9oND5cbiAgICAgICAgICAgIDxwPlxuICAgICAgICAgICAgICBMb2NhdGlvbiBjb29yZGluYXRlcyBhcmUgZmV0Y2hlZCBzdHJpY3RseSB3aXRoIHBhcmVudGFsIGNvbnNlbnQgZm9yIHRoZSBzb2xlIHB1cnBvc2Ugb2YgZGlzcGxheWluZyBjaGlsZCBsb2NhdGlvbiBvbiB0aGUgZmFtaWx5IG1hcCBhbmQgYWxlcnRpbmcgZ3VhcmRpYW5zIHdoZW4gY2hpbGRyZW4gZW50ZXIgb3IgZXhpdCBkZXNpZ25hdGVkIHNhZmUgem9uZXMgKEhvbWUsIFNjaG9vbCwgUGFyaykuXG4gICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiPjMuIENhbWVyYSAmIFNjcmVlbiBDaGVjay1JbiBUcmFuc3BhcmVuY3k8L2g0PlxuICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgIFNhZmVLaWRzIHN0cmljdGx5IHByb2hpYml0cyBjb3ZlcnQgc3B5d2FyZSwgc2VjcmV0IG1pY3JvcGhvbmUgcmVjb3JkaW5nLCBvciBoaWRkZW4gc3VydmVpbGxhbmNlLiBMaXZlIGxvb2staW4gc2Vzc2lvbnMgcmVxdWlyZSBpbnRlcmFjdGl2ZSBjaGlsZCBjb25zZW50IGFuZCBzaG93IGEgY29udGludW91cywgaGlnaC12aXNpYmlsaXR5IGluZGljYXRvciB3aXRoIGFuIGluc3RhbnQgY2hpbGQgdGVybWluYXRpb24gYnV0dG9uLlxuICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0xMDBcIj40LiBQYXJlbnRhbCBSaWdodHMgJiBEYXRhIEVyYXN1cmU8L2g0PlxuICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgIFBhcmVudHMgaGF2ZSBmdWxsIGF1dGhvcml0eSB0byBwdXJnZSBhbGwgaGlzdG9yaWNhbCBkYXRhLCB1bnBhaXIgZGV2aWNlcywgb3IgZGVsZXRlIGFjY291bnRzIGRpcmVjdGx5IHdpdGhpbiB0aGUgYXBwIHNldHRpbmdzLiBBbGwgY2FjaGVkIGxvY2F0aW9ucyBhcmUgZXhwdW5nZWQgcGVybWFuZW50bHkuXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=