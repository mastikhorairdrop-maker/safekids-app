const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=d3d47fa4";
import { Shield, MapPin, Clock, Smartphone, Globe, Camera, MessageSquare, AlertTriangle, Code2, Plus, Battery, BatteryCharging, CheckCircle2, Moon, Sun, Lock, RefreshCw, Sliders, Trash2, Send, X, Download, FileArchive, ShieldCheck, ShieldAlert, Info } from "/node_modules/.vite/deps/lucide-react.js?v=d3d47fa4";
import { downloadProjectAsZip } from "/src/utils/exportProjectZip.ts";
import { SafeKidsMap } from "/src/components/SafeKidsMap.tsx";
import { CameraScreenSession } from "/src/components/CameraScreenSession.tsx";
import { AndroidNativeKit } from "/src/components/AndroidNativeKit.tsx";
import { DevicePairingModal } from "/src/components/DevicePairingModal.tsx";
import { SafeZonesModal } from "/src/components/SafeZonesModal.tsx";
import { AboutModal } from "/src/components/AboutModal.tsx";
import { ChildPermissionsShield } from "/src/components/ChildPermissionsShield.tsx";
import { updateScreenLimits, updateAppRule, updateWebFilter, respondTimeExtension, sendMessage, markAlertsAsRead, sendChildHeartbeat, reportTamperAttempt } from "/src/services/api.ts";
import { FILTER_CATEGORIES, checkUrlAllowed } from "/src/utils/webfilter.ts";
import { reverseGeocode } from "/src/utils/geofence.ts";
var _jsxFileName = "/app/applet/src/components/ParentDashboard.tsx";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d3d47fa4";
export const ParentDashboard = ({ state, onRefresh, onSwitchToChildMode, darkMode, onToggleDarkMode, onChangePinRequested }) => {
	const [selectedChildId, setSelectedChildId] = useState(state.children[0]?.id || "");
	const [activeTab, setActiveTab] = useState("location");
	// Modals
	const [showPairModal, setShowPairModal] = useState(false);
	const [showSafeZonesModal, setShowSafeZonesModal] = useState(false);
	const [showDownloadModal, setShowDownloadModal] = useState(false);
	const [showAboutModal, setShowAboutModal] = useState(false);
	const [isDownloadingZip, setIsDownloadingZip] = useState(false);
	// Anti-Uninstall Test Simulator Modal
	const [showTestUninstallModal, setShowTestUninstallModal] = useState(false);
	const [simulatedPin, setSimulatedPin] = useState("");
	const [simulatedError, setSimulatedError] = useState(null);
	const [simulatedSuccess, setSimulatedSuccess] = useState(false);
	// Quick message input
	const [messageInput, setMessageInput] = useState("");
	// Web filter live tester
	const [testUrlInput, setTestUrlInput] = useState("discord.com");
	const [testResult, setTestResult] = useState(null);
	// New domain inputs
	const [newBlockedDomain, setNewBlockedDomain] = useState("");
	const [newAllowedDomain, setNewAllowedDomain] = useState("");
	// Selected child object
	const activeChild = state.children.find((c) => c.id === selectedChildId) || state.children[0];
	// Active SOS alert if any
	const activeSOS = state.alerts.find((a) => a.type === "sos" && Date.now() - new Date(a.timestamp).getTime() < 30 * 6e4);
	// Handle live URL test
	const handleTestUrl = () => {
		if (!activeChild || !testUrlInput.trim()) return;
		const res = checkUrlAllowed(testUrlInput, activeChild.webFilter.blockedCategories, activeChild.webFilter.blockedDomains, activeChild.webFilter.allowedDomains);
		setTestResult(res);
	};
	// Quick simulation slider: Move child GPS to test geofencing
	const handleSimulateGPS = async (targetLat, targetLng, addressDesc) => {
		if (!activeChild) return;
		const address = await reverseGeocode(targetLat, targetLng);
		await sendChildHeartbeat(activeChild.id, { location: {
			latitude: targetLat,
			longitude: targetLng,
			accuracy: 8,
			speed: 1.1,
			address: addressDesc || address
		} });
		onRefresh();
	};
	// Toggle Category Filter
	const handleToggleCategory = async (categoryId) => {
		if (!activeChild) return;
		const current = activeChild.webFilter.blockedCategories;
		const updated = current.includes(categoryId) ? current.filter((c) => c !== categoryId) : [...current, categoryId];
		await updateWebFilter(activeChild.id, { blockedCategories: updated });
		onRefresh();
	};
	// Add Blocked Domain
	const handleAddBlockedDomain = async () => {
		if (!activeChild || !newBlockedDomain.trim()) return;
		const clean = newBlockedDomain.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "");
		const updated = [...activeChild.webFilter.blockedDomains, clean];
		await updateWebFilter(activeChild.id, { blockedDomains: updated });
		setNewBlockedDomain("");
		onRefresh();
	};
	// Remove Blocked Domain
	const handleRemoveBlockedDomain = async (domain) => {
		if (!activeChild) return;
		const updated = activeChild.webFilter.blockedDomains.filter((d) => d !== domain);
		await updateWebFilter(activeChild.id, { blockedDomains: updated });
		onRefresh();
	};
	// Add Allowed Domain
	const handleAddAllowedDomain = async () => {
		if (!activeChild || !newAllowedDomain.trim()) return;
		const clean = newAllowedDomain.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "");
		const updated = [...activeChild.webFilter.allowedDomains, clean];
		await updateWebFilter(activeChild.id, { allowedDomains: updated });
		setNewAllowedDomain("");
		onRefresh();
	};
	// Remove Allowed Domain
	const handleRemoveAllowedDomain = async (domain) => {
		if (!activeChild) return;
		const updated = activeChild.webFilter.allowedDomains.filter((d) => d !== domain);
		await updateWebFilter(activeChild.id, { allowedDomains: updated });
		onRefresh();
	};
	// Send message from parent
	const handleSendMessage = async (e) => {
		e.preventDefault();
		if (!activeChild || !messageInput.trim()) return;
		await sendMessage(activeChild.id, "parent", messageInput.trim());
		setMessageInput("");
		onRefresh();
	};
	// Child messages
	const childMessages = state.messages.filter((m) => m.childId === activeChild?.id);
	if (!activeChild) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "p-8 text-center space-y-4",
			children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-xl font-bold",
				children: "No Paired Child Devices"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 213,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				onClick: () => setShowPairModal(true),
				className: "px-4 py-2 bg-blue-600 text-white rounded-xl",
				children: "Pair First Child Device"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 214,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 212,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col",
		children: [
			activeSOS && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-rose-600 text-white px-4 py-3 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-pulse",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0",
						children: /* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-6 h-6 text-yellow-300" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 231,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 230,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "font-black text-sm uppercase tracking-wide",
						children: activeSOS.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 234,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-rose-100",
						children: activeSOS.message
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 237,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 233,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 229,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => markAlertsAsRead(activeSOS.id),
						className: "px-3 py-1.5 bg-white text-rose-700 hover:bg-rose-50 rounded-lg text-xs font-bold transition-colors",
						children: "Acknowledge Alert"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 241,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 240,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 228,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("header", {
				className: "bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-30 shadow-xs",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20",
									children: /* @__PURE__ */ _jsxDEV(Shield, { className: "w-6 h-6" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 257,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 256,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV("h1", {
										className: "font-black text-lg tracking-tight text-slate-900 dark:text-white",
										children: "SafeKids"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 261,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-400 text-[10px] px-2 py-0.5 rounded-full font-bold border border-emerald-300 dark:border-emerald-800",
										children: "100% FREE"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 264,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 260,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-500 dark:text-slate-400 hidden sm:block",
									children: "Open-Source Parental Control & Child Safety"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 268,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 255,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5 overflow-x-auto py-1",
								children: [state.children.map((c) => /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setSelectedChildId(c.id),
									className: `px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all shrink-0 ${c.id === activeChild.id ? "bg-blue-600 text-white shadow-sm" : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"}`,
									children: [
										/* @__PURE__ */ _jsxDEV("span", { children: c.avatar }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 286,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: c.name }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 287,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] opacity-80",
											children: [
												"(",
												c.batteryLevel,
												"%)"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 288,
											columnNumber: 17
										}, this)
									]
								}, c.id, true, {
									fileName: _jsxFileName,
									lineNumber: 277,
									columnNumber: 15
								}, this)), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setShowPairModal(true),
									className: "px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-medium flex items-center gap-1 shrink-0 border border-slate-200 dark:border-slate-700",
									children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 296,
										columnNumber: 15
									}, this), " Pair Device"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 292,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 275,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: onToggleDarkMode,
										className: "p-2 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
										title: "Toggle Theme",
										children: darkMode ? /* @__PURE__ */ _jsxDEV(Sun, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 307,
											columnNumber: 27
										}, this) : /* @__PURE__ */ _jsxDEV(Moon, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 307,
											columnNumber: 72
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 302,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setShowDownloadModal(true),
										className: "px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs",
										title: "Download Entire Project Source Code",
										children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 315,
											columnNumber: 15
										}, this), " Download ZIP"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 310,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => onSwitchToChildMode(activeChild.id),
										className: "px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 rounded-xl text-xs font-semibold border border-indigo-200 dark:border-indigo-800 flex items-center gap-1.5 transition-colors",
										children: [/* @__PURE__ */ _jsxDEV(Smartphone, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 322,
											columnNumber: 15
										}, this), " View Child Phone"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 318,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: onChangePinRequested,
										className: "p-2 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
										title: "Parent PIN Settings",
										children: /* @__PURE__ */ _jsxDEV(Lock, { className: "w-4 h-4 text-blue-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 330,
											columnNumber: 15
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 325,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setShowAboutModal(true),
										className: "p-2 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors",
										title: "About SafeKids & Developer (Rajan Vishwakarma)",
										children: /* @__PURE__ */ _jsxDEV(Info, { className: "w-4 h-4 text-indigo-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 338,
											columnNumber: 15
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 333,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 301,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 253,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-50/80 dark:bg-slate-900/50 border-t border-slate-200/60 dark:border-slate-800/60 px-4 py-2",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3 text-slate-600 dark:text-slate-300",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-semibold text-slate-900 dark:text-slate-100",
										children: [activeChild.name, "'s Device:"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 347,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 dark:text-slate-400 font-mono text-[11px]",
										children: [
											activeChild.deviceModel,
											" (",
											activeChild.osVersion,
											")"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 350,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1",
										children: [
											activeChild.isCharging ? /* @__PURE__ */ _jsxDEV(BatteryCharging, { className: "w-3.5 h-3.5 text-emerald-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 355,
												columnNumber: 19
											}, this) : /* @__PURE__ */ _jsxDEV(Battery, { className: "w-3.5 h-3.5 text-slate-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 357,
												columnNumber: 19
											}, this),
											activeChild.batteryLevel,
											"%"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 353,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1",
										children: activeChild.isOnline ? /* @__PURE__ */ _jsxDEV("span", {
											className: "flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-500 animate-pulse" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 364,
												columnNumber: 21
											}, this), "Online"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 363,
											columnNumber: 19
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: "flex items-center gap-1 text-slate-400",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-slate-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 369,
												columnNumber: 21
											}, this), "Offline"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 368,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 361,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 346,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3 text-slate-500 dark:text-slate-400 text-[11px]",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "truncate max-w-xs",
									children: ["📍 ", activeChild.location.address]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 377,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: onRefresh,
									className: "hover:text-blue-600 flex items-center gap-1 font-medium",
									children: [/* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-3 h-3" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 384,
										columnNumber: 17
									}, this), " Sync"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 380,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 376,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 345,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 344,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "max-w-7xl mx-auto px-4 overflow-x-auto",
						children: /* @__PURE__ */ _jsxDEV("nav", {
							className: "flex space-x-1 sm:space-x-2 py-2",
							children: [
								{
									id: "location",
									label: "Live Location & Safe Zones",
									icon: MapPin
								},
								{
									id: "screentime",
									label: "Screen Time & Limits",
									icon: Clock
								},
								{
									id: "apps",
									label: "App Controls",
									icon: Smartphone
								},
								{
									id: "webfilter",
									label: "Web Filter & SafeSearch",
									icon: Globe
								},
								{
									id: "camera",
									label: "Remote Look-In",
									icon: Camera
								},
								{
									id: "messages",
									label: "Intercom",
									icon: MessageSquare
								},
								{
									id: "antiuninstall",
									label: "Anti-Uninstall & Admin Lock",
									icon: ShieldCheck
								},
								{
									id: "alerts",
									label: "Alerts Center",
									icon: AlertTriangle,
									badge: state.alerts.filter((a) => !a.read).length
								},
								{
									id: "androidkit",
									label: "Android Play Store Kit",
									icon: Code2
								}
							].map((tab) => {
								const Icon = tab.icon;
								const isActive = activeTab === tab.id;
								return /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setActiveTab(tab.id),
									className: `px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-all ${isActive ? "bg-blue-600 text-white shadow-xs" : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"}`,
									children: [
										/* @__PURE__ */ _jsxDEV(Icon, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 416,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: tab.label }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 417,
											columnNumber: 19
										}, this),
										tab.badge ? /* @__PURE__ */ _jsxDEV("span", {
											className: "ml-1 px-1.5 py-0.2 bg-rose-500 text-white rounded-full text-[10px] font-bold",
											children: tab.badge
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 419,
											columnNumber: 21
										}, this) : null
									]
								}, tab.id, true, {
									fileName: _jsxFileName,
									lineNumber: 407,
									columnNumber: 17
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 392,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 391,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 252,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "max-w-7xl mx-auto w-full p-4 sm:p-6 space-y-6 flex-1",
				children: [
					activeTab === "location" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "font-bold text-base text-slate-900 dark:text-slate-100 flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-5 h-5 text-blue-600" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 439,
										columnNumber: 19
									}, this), "Live GPS Tracking & Geofences"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 438,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5",
									children: "Real GPS coordinates with OpenStreetMap high-accuracy telemetry"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 442,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 437,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setShowSafeZonesModal(true),
										className: "px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm",
										children: [
											/* @__PURE__ */ _jsxDEV(Shield, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 452,
												columnNumber: 19
											}, this),
											" Manage Safe Zones (",
											activeChild.safeZones.length,
											")"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 448,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 447,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 436,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "relative",
								children: [/* @__PURE__ */ _jsxDEV(SafeKidsMap, {
									location: activeChild.location,
									safeZones: activeChild.safeZones,
									locationHistory: activeChild.locationHistory,
									childName: activeChild.name,
									isOnline: activeChild.isOnline,
									batteryLevel: activeChild.batteryLevel,
									className: "h-[440px] w-full rounded-2xl overflow-hidden shadow-sm border border-slate-200 dark:border-slate-800"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 459,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "absolute bottom-4 left-4 z-[1000] bg-white/95 dark:bg-slate-900/95 backdrop-blur-md p-3 rounded-xl border border-slate-200 dark:border-slate-800 text-[11px] space-y-1.5 shadow-md",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 rounded-full bg-blue-600 border border-white" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 472,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "font-semibold text-slate-800 dark:text-slate-200",
												children: [activeChild.name, "'s Live Pin"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 473,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 471,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 rounded-full bg-emerald-500/40 border border-emerald-600" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 478,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-600 dark:text-slate-400",
												children: [
													"Safe Zones (",
													activeChild.safeZones.filter((z) => z.enabled).length,
													" Active)"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 479,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 477,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-1 bg-indigo-500 rounded" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 484,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-600 dark:text-slate-400",
												children: "Travel Path History"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 485,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 483,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 470,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 458,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-blue-50/70 dark:bg-slate-900 p-4 rounded-2xl border border-blue-200/80 dark:border-slate-800 space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-xs text-blue-900 dark:text-blue-300 flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(Sliders, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 496,
											columnNumber: 19
										}, this), " Test Location Simulation (Parent Demo Mode)"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 495,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-slate-500",
										children: "Simulate child moving between coordinates"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 498,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 494,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-wrap gap-2 pt-1",
									children: [
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => handleSimulateGPS(37.7749, -122.4194, "Home (Safe Zone)"),
											className: "px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-medium border border-slate-200 dark:border-slate-700 shadow-2xs",
											children: "🏡 Teleport to Home"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 503,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => handleSimulateGPS(37.778, -122.415, "Lincoln Middle School (Safe Zone)"),
											className: "px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-medium border border-slate-200 dark:border-slate-700 shadow-2xs",
											children: "🏫 Move to School"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 509,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => handleSimulateGPS(37.785, -122.402, "Yerba Buena Park (Safe Zone)"),
											className: "px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-medium border border-slate-200 dark:border-slate-700 shadow-2xs",
											children: "🌳 Move to Park"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 515,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => handleSimulateGPS(37.79, -122.39, "Embarcadero Pier 14 (Outside Safe Zone)"),
											className: "px-3 py-1.5 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 text-amber-800 dark:text-amber-300 rounded-lg text-xs font-medium border border-amber-300 dark:border-amber-800",
											children: "⚠️ Walk Outside Safe Zones"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 521,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 502,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 493,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-bold text-sm text-slate-800 dark:text-slate-100",
									children: "Recent Location Breadcrumbs"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 532,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2",
									children: activeChild.locationHistory.slice(0, 5).map((point, index) => /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-xs border border-slate-100 dark:border-slate-800",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2.5",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-blue-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 542,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-semibold text-slate-800 dark:text-slate-200 block",
												children: point.address
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 544,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[11px] text-slate-400",
												children: [
													point.latitude.toFixed(4),
													"°, ",
													point.longitude.toFixed(4),
													"°"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 547,
												columnNumber: 25
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 543,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 541,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] text-slate-500 font-mono",
											children: new Date(point.timestamp).toLocaleTimeString([], {
												hour: "2-digit",
												minute: "2-digit"
											})
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 552,
											columnNumber: 21
										}, this)]
									}, index, true, {
										fileName: _jsxFileName,
										lineNumber: 537,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 535,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 531,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 434,
						columnNumber: 11
					}, this),
					activeTab === "screentime" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 md:grid-cols-3 gap-5",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-sm text-slate-800 dark:text-slate-200",
												children: "Daily Screen Allowance"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 569,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV(Clock, { className: "w-4 h-4 text-blue-600" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 572,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 568,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "text-3xl font-black text-slate-900 dark:text-white",
												children: [
													Math.floor(activeChild.screenTime.dailyLimitMinutes / 60),
													"h ",
													activeChild.screenTime.dailyLimitMinutes % 60,
													"m"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 575,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-500",
												children: [
													"Today's usage: ",
													activeChild.screenTime.todayUsageMinutes,
													" mins (",
													Math.max(0, activeChild.screenTime.dailyLimitMinutes - activeChild.screenTime.todayUsageMinutes),
													" mins left)"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 578,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 574,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2 pt-2",
											children: [/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => updateScreenLimits(activeChild.id, { dailyLimitMinutes: Math.max(30, activeChild.screenTime.dailyLimitMinutes - 15) }).then(onRefresh),
												className: "flex-1 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-lg text-xs font-bold",
												children: "-15 mins"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 586,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												onClick: () => updateScreenLimits(activeChild.id, { dailyLimitMinutes: activeChild.screenTime.dailyLimitMinutes + 30 }).then(onRefresh),
												className: "flex-1 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold",
												children: "+30 mins"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 596,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 585,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 567,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-sm text-slate-800 dark:text-slate-200",
											children: "Bedtime Downtime"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 612,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV(Moon, { className: "w-4 h-4 text-indigo-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 615,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 611,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-3 text-xs",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-600 dark:text-slate-400",
												children: "Lock device at night:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 620,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: activeChild.screenTime.bedtimeEnforced,
												onChange: (e) => updateScreenLimits(activeChild.id, { bedtimeEnforced: e.target.checked }).then(onRefresh),
												className: "w-4 h-4 text-indigo-600 rounded"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 621,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 619,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "grid grid-cols-2 gap-2",
											children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-[11px] text-slate-500 block mb-1",
												children: "Bedtime Starts"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 635,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "time",
												value: activeChild.screenTime.bedtimeStart,
												onChange: (e) => updateScreenLimits(activeChild.id, { bedtimeStart: e.target.value }).then(onRefresh),
												className: "w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 636,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 634,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-[11px] text-slate-500 block mb-1",
												children: "Bedtime Ends"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 648,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "time",
												value: activeChild.screenTime.bedtimeEnd,
												onChange: (e) => updateScreenLimits(activeChild.id, { bedtimeEnd: e.target.value }).then(onRefresh),
												className: "w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 649,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 647,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 633,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 618,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 610,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-sm text-slate-800 dark:text-slate-200 block",
										children: "Time Extension Requests"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 666,
										columnNumber: 17
									}, this), activeChild.timeExtensionRequest && activeChild.timeExtensionRequest.status === "pending" ? /* @__PURE__ */ _jsxDEV("div", {
										className: "bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 rounded-xl p-3 space-y-2",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-xs text-amber-800 dark:text-amber-200 block",
												children: [
													"+",
													activeChild.timeExtensionRequest.minutes,
													" Minutes Requested"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 672,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("p", {
												className: "text-[11px] text-amber-700 dark:text-amber-300",
												children: [
													"Reason: \"",
													activeChild.timeExtensionRequest.reason,
													"\""
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 675,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex gap-2 pt-1",
												children: [/* @__PURE__ */ _jsxDEV("button", {
													onClick: () => respondTimeExtension(activeChild.id, "approved", activeChild.timeExtensionRequest?.minutes).then(onRefresh),
													className: "flex-1 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[11px] font-bold",
													children: "Approve"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 679,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("button", {
													onClick: () => respondTimeExtension(activeChild.id, "denied").then(onRefresh),
													className: "flex-1 py-1 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded text-[11px] font-semibold",
													children: "Deny"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 687,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 678,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 671,
										columnNumber: 19
									}, this) : /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400 py-4 text-center",
										children: [
											"No active time extension requests from ",
											activeChild.name,
											"."
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 696,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 665,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 565,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-bold text-sm text-slate-800 dark:text-slate-200",
								children: "Today's Category Breakdown"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 705,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [
									{
										category: "Video & Streaming",
										minutes: 30,
										color: "bg-red-500"
									},
									{
										category: "Education & Study",
										minutes: 35,
										color: "bg-emerald-500"
									},
									{
										category: "Games & Play",
										minutes: 20,
										color: "bg-indigo-500"
									},
									{
										category: "Browsing & Reading",
										minutes: 0,
										color: "bg-blue-500"
									}
								].map((item) => /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-xs font-medium",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: item.category }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 717,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: [item.minutes, " mins"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 718,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 716,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2",
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: `${item.color} h-2 rounded-full`,
											style: { width: `${item.minutes / Math.max(1, activeChild.screenTime.dailyLimitMinutes) * 100}%` }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 721,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 720,
										columnNumber: 21
									}, this)]
								}, item.category, true, {
									fileName: _jsxFileName,
									lineNumber: 715,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 708,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 704,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 564,
						columnNumber: 11
					}, this),
					activeTab === "apps" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "font-bold text-base text-slate-900 dark:text-slate-100",
								children: "Android App Controls & Lock Rules"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 738,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 dark:text-slate-400",
								children: "Enforce daily quotas or completely lock distraction apps via Android Accessibility Service."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 741,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 737,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										activeChild.screenTime.appRules.forEach((rule) => {
											if (rule.category === "games" || rule.category === "social") {
												updateAppRule(activeChild.id, rule.packageName, "locked");
											}
										});
										setTimeout(onRefresh, 300);
									},
									className: "px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-semibold",
									children: "🚫 Instant Lock Games & Social"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 747,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 746,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 736,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
							children: activeChild.screenTime.appRules.map((app) => /* @__PURE__ */ _jsxDEV("div", {
								className: `p-4 rounded-2xl border transition-all ${app.status === "locked" ? "bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900" : "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-start justify-between",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [
										/* @__PURE__ */ _jsxDEV("h4", {
											className: "font-bold text-sm text-slate-900 dark:text-slate-100",
											children: app.appName
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 776,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] text-slate-500 dark:text-slate-400 font-mono block",
											children: app.packageName
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 779,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "inline-block mt-1 text-[10px] uppercase font-bold text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded",
											children: app.category
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 782,
											columnNumber: 23
										}, this)
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 775,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: `text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${app.status === "locked" ? "bg-rose-600 text-white" : app.status === "limited" ? "bg-amber-500 text-white" : "bg-emerald-600 text-white"}`,
										children: app.status
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 787,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 774,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 text-[11px]",
										children: [
											"Used today: ",
											app.usedTodayMinutes,
											"m"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 801,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5",
										children: /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => updateAppRule(activeChild.id, app.packageName, app.status === "locked" ? "allowed" : "locked").then(onRefresh),
											className: `px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors ${app.status === "locked" ? "bg-emerald-600 text-white hover:bg-emerald-700" : "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300 hover:bg-rose-200"}`,
											children: app.status === "locked" ? "Unlock App" : "Lock App"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 807,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 806,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 800,
									columnNumber: 19
								}, this)]
							}, app.packageName, true, {
								fileName: _jsxFileName,
								lineNumber: 766,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 764,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 735,
						columnNumber: 11
					}, this),
					activeTab === "webfilter" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "font-bold text-base text-slate-900 dark:text-slate-100",
										children: "Content Category Blockers"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 837,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-500",
										children: "Websites matching checked categories are blocked in real-time."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 840,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 836,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-semibold text-slate-700 dark:text-slate-300",
											children: "SafeSearch:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 845,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "checkbox",
											checked: activeChild.webFilter.safeSearchEnabled,
											onChange: (e) => updateWebFilter(activeChild.id, { safeSearchEnabled: e.target.checked }).then(onRefresh),
											className: "w-4 h-4 text-blue-600 rounded"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 848,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 844,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 835,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3",
									children: FILTER_CATEGORIES.map((cat) => {
										const isBlocked = activeChild.webFilter.blockedCategories.includes(cat.id);
										return /* @__PURE__ */ _jsxDEV("div", {
											onClick: () => handleToggleCategory(cat.id),
											className: `p-3.5 rounded-xl border cursor-pointer transition-all ${isBlocked ? "bg-rose-50/70 dark:bg-rose-950/30 border-rose-300 dark:border-rose-900 text-rose-950 dark:text-rose-200" : "bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300"}`,
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "font-bold text-xs",
													children: cat.name
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 876,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "checkbox",
													checked: isBlocked,
													onChange: () => {},
													className: "w-4 h-4 text-rose-600 rounded"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 877,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 875,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-[11px] text-slate-500 dark:text-slate-400 mt-1",
												children: cat.description
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 884,
												columnNumber: 23
											}, this)]
										}, cat.id, true, {
											fileName: _jsxFileName,
											lineNumber: 866,
											columnNumber: 21
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 862,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 834,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4",
									children: [
										/* @__PURE__ */ _jsxDEV("h4", {
											className: "font-bold text-sm text-slate-900 dark:text-slate-100",
											children: "Custom Blocked Domains (Blacklist)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 897,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex gap-2",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: newBlockedDomain,
												onChange: (e) => setNewBlockedDomain(e.target.value),
												placeholder: "e.g. omegle.com, twitch.tv...",
												className: "flex-1 px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 901,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												onClick: handleAddBlockedDomain,
												className: "px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-semibold",
												children: "Block"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 908,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 900,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1.5 max-h-48 overflow-y-auto",
											children: activeChild.webFilter.blockedDomains.map((d) => /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-800/50 text-xs border border-slate-100 dark:border-slate-800",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono text-rose-600 dark:text-rose-400",
													children: d
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 921,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("button", {
													onClick: () => handleRemoveBlockedDomain(d),
													className: "text-slate-400 hover:text-rose-500",
													children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 926,
														columnNumber: 25
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 922,
													columnNumber: 23
												}, this)]
											}, d, true, {
												fileName: _jsxFileName,
												lineNumber: 917,
												columnNumber: 21
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 915,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 896,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4",
									children: [
										/* @__PURE__ */ _jsxDEV("h4", {
											className: "font-bold text-sm text-slate-900 dark:text-slate-100",
											children: "Always Allowed Domains (Whitelist)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 935,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex gap-2",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: newAllowedDomain,
												onChange: (e) => setNewAllowedDomain(e.target.value),
												placeholder: "e.g. schoolportal.edu...",
												className: "flex-1 px-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 939,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												onClick: handleAddAllowedDomain,
												className: "px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold",
												children: "Allow"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 946,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 938,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-1.5 max-h-48 overflow-y-auto",
											children: activeChild.webFilter.allowedDomains.map((d) => /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-800/50 text-xs border border-slate-100 dark:border-slate-800",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono text-emerald-600 dark:text-emerald-400",
													children: d
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 959,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("button", {
													onClick: () => handleRemoveAllowedDomain(d),
													className: "text-slate-400 hover:text-rose-500",
													children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 964,
														columnNumber: 25
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 960,
													columnNumber: 23
												}, this)]
											}, d, true, {
												fileName: _jsxFileName,
												lineNumber: 955,
												columnNumber: 21
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 953,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 934,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 894,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 space-y-3",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-xs uppercase tracking-wider text-blue-400 block",
										children: "Live URL Checker & Policy Inspector"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 974,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex gap-2",
										children: [/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: testUrlInput,
											onChange: (e) => setTestUrlInput(e.target.value),
											placeholder: "Enter any domain or URL to test...",
											className: "flex-1 px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-blue-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 978,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: handleTestUrl,
											className: "px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold",
											children: "Inspect URL"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 985,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 977,
										columnNumber: 15
									}, this),
									testResult && /* @__PURE__ */ _jsxDEV("div", {
										className: `p-3 rounded-xl text-xs border font-mono ${testResult.allowed ? "bg-emerald-950/60 border-emerald-700 text-emerald-300" : "bg-rose-950/60 border-rose-700 text-rose-300"}`,
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold",
											children: testResult.allowed ? "✓ ALLOWED" : "🛑 BLOCKED"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1001,
											columnNumber: 19
										}, this), testResult.blockedReason && /* @__PURE__ */ _jsxDEV("span", {
											className: "block mt-1",
											children: testResult.blockedReason
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1005,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 994,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 973,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 833,
						columnNumber: 11
					}, this),
					activeTab === "camera" && /* @__PURE__ */ _jsxDEV(CameraScreenSession, {
						child: activeChild,
						isParentView: true,
						onRefresh
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1015,
						columnNumber: 11
					}, this),
					activeTab === "messages" && /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-bold text-base text-slate-800 dark:text-slate-100 flex items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV(MessageSquare, { className: "w-5 h-5 text-indigo-600" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1026,
										columnNumber: 15
									}, this),
									"Direct Intercom with ",
									activeChild.name
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1025,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-50 dark:bg-slate-950/60 rounded-xl p-4 h-80 overflow-y-auto space-y-3 border border-slate-200 dark:border-slate-800",
								children: childMessages.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
									className: "text-center text-xs text-slate-400 py-10",
									children: [
										"No messages yet. Send a quick check-in note to ",
										activeChild.name,
										"!"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1033,
									columnNumber: 17
								}, this) : childMessages.map((msg) => /* @__PURE__ */ _jsxDEV("div", {
									className: `flex flex-col ${msg.sender === "parent" ? "items-end" : "items-start"}`,
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: `max-w-xs sm:max-w-md px-3.5 py-2 rounded-2xl text-xs shadow-2xs ${msg.sender === "parent" ? "bg-blue-600 text-white rounded-br-none" : "bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700 rounded-bl-none"}`,
										children: msg.text
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1044,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 mt-1 px-1",
										children: [
											msg.sender === "parent" ? "You" : activeChild.name,
											" •",
											" ",
											new Date(msg.timestamp).toLocaleTimeString([], {
												hour: "2-digit",
												minute: "2-digit"
											})
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1053,
										columnNumber: 21
									}, this)]
								}, msg.id, true, {
									fileName: _jsxFileName,
									lineNumber: 1038,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1031,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex gap-2 overflow-x-auto pb-1 text-xs",
								children: [
									"Dinner is ready! 🍽️",
									"Time to head home 🚲",
									"Please call mom/dad 📞",
									"Great job on homework ⭐"
								].map((preset) => /* @__PURE__ */ _jsxDEV("button", {
									onClick: async () => {
										await sendMessage(activeChild.id, "parent", preset);
										onRefresh();
									},
									className: "px-3 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg whitespace-nowrap",
									children: preset
								}, preset, false, {
									fileName: _jsxFileName,
									lineNumber: 1065,
									columnNumber: 17
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1063,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("form", {
								onSubmit: handleSendMessage,
								className: "flex gap-2",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: messageInput,
									onChange: (e) => setMessageInput(e.target.value),
									placeholder: `Message ${activeChild.name}...`,
									className: "flex-1 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-slate-100"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1080,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									className: "px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-sm flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(Send, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1091,
										columnNumber: 17
									}, this), " Send"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1087,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1079,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1024,
						columnNumber: 11
					}, this),
					activeTab === "alerts" && /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-bold text-base text-slate-900 dark:text-slate-100",
								children: "Safety Alerts & Notifications"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1102,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500",
								children: "SOS pings, geofence enter/exit, low battery, and filter triggers"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1105,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1101,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => markAlertsAsRead(undefined, true).then(onRefresh),
								className: "px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-semibold",
								children: "Mark All Read"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1109,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1100,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2.5",
							children: state.alerts.map((alert) => /* @__PURE__ */ _jsxDEV("div", {
								className: `p-3.5 rounded-xl border text-xs flex items-start justify-between gap-3 ${alert.severity === "critical" ? "bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-900" : alert.severity === "warning" ? "bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-900" : "bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-slate-900 dark:text-slate-100 block",
											children: alert.title
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1130,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-600 dark:text-slate-300 leading-relaxed",
											children: alert.message
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1133,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-400 font-mono block",
											children: new Date(alert.timestamp).toLocaleString()
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1136,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1129,
									columnNumber: 19
								}, this), !alert.read && /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => markAlertsAsRead(alert.id).then(onRefresh),
									className: "px-2.5 py-1 bg-white dark:bg-slate-800 border rounded text-[11px] font-medium shrink-0",
									children: "Dismiss"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1142,
									columnNumber: 21
								}, this)]
							}, alert.id, true, {
								fileName: _jsxFileName,
								lineNumber: 1119,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1117,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1099,
						columnNumber: 11
					}, this),
					activeTab === "antiuninstall" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 text-white p-6 rounded-3xl border border-indigo-900/60 shadow-lg space-y-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "w-10 h-10 rounded-2xl bg-indigo-600/30 text-indigo-400 flex items-center justify-center font-bold",
												children: /* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-6 h-6" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1164,
													columnNumber: 23
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1163,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
												className: "text-lg font-black tracking-tight",
												children: "Strict Anti-Uninstall & Device Protection"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1167,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs text-indigo-200",
												children: "Device Admin • Settings Interceptor • Parent Master PIN Enforced"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1170,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1166,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1162,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-300 max-w-2xl leading-relaxed",
											children: "Children cannot delete or bypass SafeKids. If uninstallation, app deactivation, or cache wiping is attempted in Android Settings, SafeKids immediately redirects to the Master PIN verification screen."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1175,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1161,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "shrink-0 flex items-center gap-2",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1182,
												columnNumber: 21
											}, this), "Protection Enforced"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1181,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1180,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1160,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-900/80 p-3.5 rounded-2xl border border-indigo-900/40 space-y-1",
											children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] font-bold uppercase tracking-wider text-slate-400",
													children: "Device Admin Status"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1191,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "text-sm font-bold text-emerald-400 flex items-center gap-1.5",
													children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1195,
														columnNumber: 21
													}, this), " Active & Bound"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1194,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[11px] text-slate-400 block font-mono",
													children: "SafeKidsDeviceAdmin"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1197,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1190,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-900/80 p-3.5 rounded-2xl border border-indigo-900/40 space-y-1",
											children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] font-bold uppercase tracking-wider text-slate-400",
													children: "Accessibility Intercept"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1203,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "text-sm font-bold text-emerald-400 flex items-center gap-1.5",
													children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1207,
														columnNumber: 21
													}, this), " Guarding Settings"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1206,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[11px] text-slate-400 block font-mono",
													children: "com.android.settings"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1209,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1202,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-900/80 p-3.5 rounded-2xl border border-indigo-900/40 space-y-1",
											children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] font-bold uppercase tracking-wider text-slate-400",
													children: "Parent Master PIN"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1215,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "text-sm font-bold text-blue-400 flex items-center gap-1.5",
													children: [/* @__PURE__ */ _jsxDEV(Lock, { className: "w-4 h-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1219,
														columnNumber: 21
													}, this), " 4-Digit Security"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1218,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[11px] text-slate-400 block",
													children: "Required for Removal"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1221,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1214,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-900/80 p-3.5 rounded-2xl border border-indigo-900/40 space-y-1",
											children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] font-bold uppercase tracking-wider text-slate-400",
													children: "Tamper Attempts Blocked"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1227,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "text-sm font-bold text-amber-400 flex items-center gap-1.5",
													children: [
														/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1231,
															columnNumber: 21
														}, this),
														" ",
														activeChild.antiUninstall?.uninstallAttemptsCount || 0,
														" Attempts"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1230,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[11px] text-slate-400 block",
													children: activeChild.antiUninstall?.lastTamperAttempt ? `Last: ${new Date(activeChild.antiUninstall.lastTamperAttempt).toLocaleTimeString([], {
														hour: "2-digit",
														minute: "2-digit"
													})}` : "Zero unauthorized attempts"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1233,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1226,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1189,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1159,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4",
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "font-bold text-base text-slate-900 dark:text-slate-100 flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "w-5 h-5 text-rose-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1247,
											columnNumber: 21
										}, this), "Live Anti-Uninstall Simulator (Test Protection)"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1246,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5",
										children: "Experience what happens when a child attempts to uninstall SafeKids or deactivate Device Admin."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1250,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1245,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => {
											setSimulatedPin("");
											setSimulatedError(null);
											setSimulatedSuccess(false);
											setShowTestUninstallModal(true);
										},
										className: "px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center gap-1.5 shrink-0",
										children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 text-yellow-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1264,
											columnNumber: 19
										}, this), "Simulate Child Uninstall Attempt"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1255,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1244,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 md:grid-cols-3 gap-4 text-xs",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-2",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2 font-bold text-slate-900 dark:text-slate-100",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "w-6 h-6 rounded-lg bg-blue-600 text-white flex items-center justify-center text-xs",
													children: "1"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1273,
													columnNumber: 21
												}, this), "Android Device Administration"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1272,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-slate-600 dark:text-slate-400 leading-relaxed text-[11px]",
												children: "SafeKids registers as an active Device Administrator. The native Android OS grays out the \"Uninstall\" button in standard app settings and warns that the device administrator must be deactivated first."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1278,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1271,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-2",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2 font-bold text-slate-900 dark:text-slate-100",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center text-xs",
													children: "2"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1285,
													columnNumber: 21
												}, this), "Accessibility Window Interceptor"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1284,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-slate-600 dark:text-slate-400 leading-relaxed text-[11px]",
												children: [
													"If the child attempts to open Device Admin settings, SafeKids App Info, or the Package Uninstaller, ",
													/* @__PURE__ */ _jsxDEV("code", { children: "SafeKidsAccessibilityService" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1291,
														columnNumber: 121
													}, this),
													" intercepts the window change, executes ",
													/* @__PURE__ */ _jsxDEV("code", { children: "GLOBAL_ACTION_BACK" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1291,
														columnNumber: 202
													}, this),
													", and pops up the Master PIN overlay."
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1290,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1283,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-2",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2 font-bold text-slate-900 dark:text-slate-100",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-xs",
													children: "3"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1297,
													columnNumber: 21
												}, this), "Device Owner (Kernel Level)"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1296,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-slate-600 dark:text-slate-400 leading-relaxed text-[11px]",
												children: [
													"When activated via ADB or Knox enterprise enrollment, ",
													/* @__PURE__ */ _jsxDEV("code", { children: "dpm.setUninstallBlocked(admin, packageName, true)" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1303,
														columnNumber: 75
													}, this),
													" is enforced, rendering uninstallation 100% impossible at the Android kernel level."
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1302,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1295,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1270,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1243,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 text-slate-200 rounded-2xl border border-slate-800 p-5 space-y-3",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs uppercase tracking-wider text-emerald-400 flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV(Code2, { className: "w-4 h-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1313,
												columnNumber: 19
											}, this), " Permanent Uninstall Blocking (Device Owner Mode)"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1312,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-400",
											children: "Optional / For Advanced Parents"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1315,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1311,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-300 leading-relaxed",
										children: "To make SafeKids completely impossible to uninstall even if the child boots into Safe Mode, run this one-time command from your computer via USB debugging:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1319,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "bg-black/80 p-3 rounded-xl font-mono text-emerald-400 text-xs overflow-x-auto select-all",
										children: "adb shell dpm set-device-owner com.safekids.parentalcontrol/.receiver.SafeKidsDeviceAdminReceiver"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1322,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-400",
										children: "This locks uninstallation directly in the Android OS framework until the parent enters their credentials."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1325,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1310,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(ChildPermissionsShield, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1331,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1157,
						columnNumber: 11
					}, this),
					activeTab === "androidkit" && /* @__PURE__ */ _jsxDEV(AndroidNativeKit, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1336,
						columnNumber: 40
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 431,
				columnNumber: 7
			}, this),
			showTestUninstallModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border-2 border-rose-500 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl animate-in zoom-in-95",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "w-16 h-16 rounded-2xl bg-rose-600/30 text-rose-400 mx-auto flex items-center justify-center animate-bounce",
							children: /* @__PURE__ */ _jsxDEV(ShieldAlert, { className: "w-8 h-8" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1344,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1343,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-bold uppercase tracking-widest text-rose-400 bg-rose-950/60 border border-rose-800 px-2.5 py-0.5 rounded-full",
								children: "DEVICE ADMIN INTERCEPT ACTIVE"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1348,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-base font-bold text-white mt-2",
								children: "Uninstallation Blocked!"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1351,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-300 mt-1",
								children: "SafeKids is protected by Android Device Administrator policies. Enter Master Parent PIN to authorize deactivation."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1354,
								columnNumber: 15
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1347,
							columnNumber: 13
						}, this),
						simulatedSuccess ? /* @__PURE__ */ _jsxDEV("div", {
							className: "bg-emerald-950/60 border border-emerald-600 p-4 rounded-2xl text-emerald-300 text-xs font-semibold space-y-1",
							children: [
								/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-6 h-6 mx-auto text-emerald-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1361,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", { children: "Parent PIN Verified!" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1362,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-300",
									children: "Authorized uninstallation window open for 60 seconds."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1363,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setShowTestUninstallModal(false),
									className: "mt-2 px-3 py-1 bg-emerald-600 text-white rounded-lg text-xs",
									children: "Close"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1364,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1360,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("input", {
									type: "password",
									inputMode: "numeric",
									maxLength: 6,
									value: simulatedPin,
									onChange: (e) => {
										setSimulatedPin(e.target.value.replace(/\D/g, ""));
										setSimulatedError(null);
									},
									placeholder: "Enter 4-Digit Parent PIN",
									className: "w-full text-center tracking-widest text-lg font-mono px-3 py-2.5 border rounded-xl border-slate-700 bg-slate-950 text-white focus:outline-none focus:border-rose-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1373,
									columnNumber: 17
								}, this),
								simulatedError && /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-rose-400 font-semibold",
									children: simulatedError
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1387,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-2 pt-1",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: async () => {
											// Log tamper alert to backend
											await reportTamperAttempt(activeChild.id, "Child attempted to uninstall SafeKids via Settings");
											onRefresh();
											setShowTestUninstallModal(false);
										},
										className: "py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold",
										children: "Cancel (Keep Protected)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1393,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: async () => {
											if (simulatedPin === state.parentPin) {
												setSimulatedSuccess(true);
											} else {
												setSimulatedError("Incorrect PIN. Tampering attempt reported to parents!");
												await reportTamperAttempt(activeChild.id, "Failed PIN attempt while trying to uninstall SafeKids");
												onRefresh();
											}
										},
										className: "py-2.5 px-3 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold",
										children: "Verify PIN"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1404,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1392,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1372,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1342,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1341,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(DevicePairingModal, {
				isOpen: showPairModal,
				onClose: () => setShowPairModal(false),
				onDevicePaired: onRefresh
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1426,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(SafeZonesModal, {
				isOpen: showSafeZonesModal,
				childId: activeChild.id,
				currentZones: activeChild.safeZones,
				currentLatitude: activeChild.location.latitude,
				currentLongitude: activeChild.location.longitude,
				onClose: () => setShowSafeZonesModal(false),
				onSaved: onRefresh
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1432,
				columnNumber: 7
			}, this),
			showDownloadModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 space-y-5 shadow-2xl animate-in zoom-in-95 max-h-[90vh] overflow-y-auto",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center",
									children: /* @__PURE__ */ _jsxDEV(FileArchive, { className: "w-5 h-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1449,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1448,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-bold text-base text-slate-900 dark:text-slate-100",
									children: "SafeKids Source Code (प्रोजेक्ट ज़िप डाउनलोड)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1452,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: "100% Free & Open-Source Full Application"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1455,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1451,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1447,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setShowDownloadModal(false),
								className: "text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded-lg",
								children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1464,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1460,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1446,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 rounded-2xl p-4 space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-xs text-emerald-800 dark:text-emerald-300 block",
								children: "📦 Instant Download Options:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1469,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col sm:flex-row gap-2",
								children: [/* @__PURE__ */ _jsxDEV("a", {
									href: "/api/download-zip",
									download: "SafeKids-Complete-Project.zip",
									className: "flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold text-center flex items-center justify-center gap-2 shadow-sm transition-colors",
									children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1478,
										columnNumber: 19
									}, this), " Server Direct ZIP"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1473,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									disabled: isDownloadingZip,
									onClick: async () => {
										setIsDownloadingZip(true);
										try {
											await downloadProjectAsZip();
										} finally {
											setIsDownloadingZip(false);
										}
									},
									className: "flex-1 py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold text-center flex items-center justify-center gap-2 shadow-sm transition-colors disabled:opacity-50",
									children: [
										/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1493,
											columnNumber: 19
										}, this),
										" ",
										isDownloadingZip ? "Zipping..." : "Client Browser ZIP"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1480,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1472,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1468,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-slate-800 dark:text-slate-200 block",
								children: "ज़िप फाइल में क्या-क्या शामिल है (Included in ZIP):"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1500,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("ul", {
								className: "list-disc list-inside space-y-1 text-slate-600 dark:text-slate-400 text-[11px] leading-relaxed",
								children: [
									/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "React 19 + TypeScript + Vite:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1504,
										columnNumber: 21
									}, this), " Complete parent & child dashboard with responsive design & dark mode."] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1504,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Express Full-Stack Server:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1505,
										columnNumber: 21
									}, this), " Pairing code generator, live sync, geofencing & alerts."] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1505,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "OpenStreetMap (Leaflet):" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1506,
										columnNumber: 21
									}, this), " Real GPS tracking with safe zones geofencing."] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1506,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Native Android Kotlin Sources:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1507,
										columnNumber: 21
									}, this), " Accessibility Service, Device Admin, Location Foreground Service, MediaProjection screen sharing."] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1507,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Google Play Store Kit:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1508,
										columnNumber: 21
									}, this), " AndroidManifest.xml, build.gradle.kts, Data Safety answers, COPPA Privacy Policy."] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1508,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1503,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1499,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-900 text-slate-200 rounded-xl p-3.5 space-y-2 text-xs font-mono",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-emerald-400 font-bold block text-[11px]",
								children: "अपने कंप्यूटर पर चलाने का तरीका (How to run locally):"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1514,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-black/60 p-2.5 rounded-lg text-[11px] space-y-1 text-slate-300 overflow-x-auto",
								children: [
									/* @__PURE__ */ _jsxDEV("p", { children: "# 1. Unzip the downloaded file" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1518,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", { children: "# 2. Open terminal inside the folder and run:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1519,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-yellow-300 font-bold",
										children: "npm install"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1520,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-yellow-300 font-bold",
										children: "npm run dev"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1521,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", { children: "# 3. Open http://localhost:3000 in your browser" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1522,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1517,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1513,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "pt-1",
							children: /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setShowDownloadModal(false),
								className: "w-full py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold",
								children: "Close"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1527,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1526,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1445,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1444,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV(AboutModal, {
				isOpen: showAboutModal,
				onClose: () => setShowAboutModal(false),
				parentPin: state.parentPin
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1539,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "mt-auto border-t border-slate-200 dark:border-slate-800/80 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md py-4 px-6",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-slate-900 dark:text-slate-100",
								children: "SafeKids Free Parental Control"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1549,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1552,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-emerald-600 dark:text-emerald-400 font-semibold",
								children: "Open-Source & 100% Free"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1553,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1548,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 font-medium",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: "Developed by" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1559,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("strong", {
								className: "text-slate-900 dark:text-white font-bold bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700",
								children: "Rajan Vishwakarma"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1560,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1563,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setShowAboutModal(true),
								className: "text-blue-600 dark:text-blue-400 hover:underline font-semibold",
								children: "About & Specs"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1564,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1558,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1547,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1546,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 225,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUEyQjtBQUMzQyxTQUNFLFFBQ0EsUUFDQSxPQUNBLFlBQ0EsT0FDQSxRQUNBLGVBQ0EsZUFDQSxPQUNBLE1BQ0EsU0FDQSxpQkFHQSxjQUNBLE1BQ0EsS0FDQSxNQUVBLFdBQ0EsU0FFQSxRQUNBLE1BR0EsR0FRQSxVQUNBLGFBQ0EsYUFDQSxhQUNBLFlBQ0s7QUFFUCxTQUFTLDRCQUE0QjtBQUNyQyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLDJCQUEyQjtBQUNwQyxTQUFTLHdCQUF3QjtBQUNqQyxTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLDhCQUE4QjtBQUN2QyxTQUNFLG9CQUNBLGVBQ0EsaUJBQ0Esc0JBQ0EsYUFDQSxrQkFDQSxvQkFFQSwyQkFDSztBQUNQLFNBQVMsbUJBQW1CLHVCQUF1QjtBQUNuRCxTQUFTLHNCQUFzQjs7O0FBVy9CLE9BQU8sTUFBTSxtQkFBbUQsRUFDOUQsT0FDQSxXQUNBLHFCQUNBLFVBQ0Esa0JBQ0EsMkJBQ0k7Q0FDSixNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUM1QyxNQUFNLFNBQVMsRUFBRSxFQUFFLE1BQU0sRUFDM0I7Q0FDQSxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FFaEMsVUFBVTs7Q0FHWixNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxLQUFLO0NBQ3hELE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQVMsS0FBSztDQUNsRSxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEtBQUs7Q0FDaEUsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxLQUFLO0NBQzFELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSzs7Q0FHOUQsTUFBTSxDQUFDLHdCQUF3Qiw2QkFBNkIsU0FBUyxLQUFLO0NBQzFFLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEVBQUU7Q0FDbkQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBd0IsSUFBSTtDQUN4RSxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLEtBQUs7O0NBRzlELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEVBQUU7O0NBR25ELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLGFBQWE7Q0FDOUQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQWMsSUFBSTs7Q0FHdEQsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxFQUFFO0NBQzNELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsRUFBRTs7Q0FHM0QsTUFBTSxjQUFjLE1BQU0sU0FBUyxNQUFNLE1BQU0sRUFBRSxPQUFPLGVBQWUsS0FBSyxNQUFNLFNBQVM7O0NBRzNGLE1BQU0sWUFBWSxNQUFNLE9BQU8sTUFDNUIsTUFBTSxFQUFFLFNBQVMsU0FBVSxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssRUFBRSxTQUFTLENBQUMsQ0FBQyxRQUFRLElBQUksS0FBSyxHQUNsRjs7Q0FHQSxNQUFNLHNCQUFzQjtFQUMxQixJQUFJLENBQUMsZUFBZSxDQUFDLGFBQWEsS0FBSyxHQUFHO0VBQzFDLE1BQU0sTUFBTSxnQkFDVixjQUNBLFlBQVksVUFBVSxtQkFDdEIsWUFBWSxVQUFVLGdCQUN0QixZQUFZLFVBQVUsY0FDeEI7RUFDQSxjQUFjLEdBQUc7Q0FDbkI7O0NBR0EsTUFBTSxvQkFBb0IsT0FBTyxXQUFtQixXQUFtQixnQkFBd0I7RUFDN0YsSUFBSSxDQUFDLGFBQWE7RUFDbEIsTUFBTSxVQUFVLE1BQU0sZUFBZSxXQUFXLFNBQVM7RUFDekQsTUFBTSxtQkFBbUIsWUFBWSxJQUFJLEVBQ3ZDLFVBQVU7R0FDUixVQUFVO0dBQ1YsV0FBVztHQUNYLFVBQVU7R0FDVixPQUFPO0dBQ1AsU0FBUyxlQUFlO0VBQzFCLEVBQ0YsQ0FBQztFQUNELFVBQVU7Q0FDWjs7Q0FHQSxNQUFNLHVCQUF1QixPQUFPLGVBQXVCO0VBQ3pELElBQUksQ0FBQyxhQUFhO0VBQ2xCLE1BQU0sVUFBVSxZQUFZLFVBQVU7RUFDdEMsTUFBTSxVQUFVLFFBQVEsU0FBUyxVQUFVLElBQ3ZDLFFBQVEsUUFBUSxNQUFNLE1BQU0sVUFBVSxJQUN0QyxDQUFDLEdBQUcsU0FBUyxVQUFVO0VBRTNCLE1BQU0sZ0JBQWdCLFlBQVksSUFBSSxFQUFFLG1CQUFtQixRQUFRLENBQUM7RUFDcEUsVUFBVTtDQUNaOztDQUdBLE1BQU0seUJBQXlCLFlBQVk7RUFDekMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsS0FBSyxHQUFHO0VBQzlDLE1BQU0sUUFBUSxpQkFBaUIsS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsUUFBUSxnQkFBZ0IsRUFBRSxDQUFDLENBQUMsUUFBUSxVQUFVLEVBQUU7RUFDcEcsTUFBTSxVQUFVLENBQUMsR0FBRyxZQUFZLFVBQVUsZ0JBQWdCLEtBQUs7RUFDL0QsTUFBTSxnQkFBZ0IsWUFBWSxJQUFJLEVBQUUsZ0JBQWdCLFFBQVEsQ0FBQztFQUNqRSxvQkFBb0IsRUFBRTtFQUN0QixVQUFVO0NBQ1o7O0NBR0EsTUFBTSw0QkFBNEIsT0FBTyxXQUFtQjtFQUMxRCxJQUFJLENBQUMsYUFBYTtFQUNsQixNQUFNLFVBQVUsWUFBWSxVQUFVLGVBQWUsUUFBUSxNQUFNLE1BQU0sTUFBTTtFQUMvRSxNQUFNLGdCQUFnQixZQUFZLElBQUksRUFBRSxnQkFBZ0IsUUFBUSxDQUFDO0VBQ2pFLFVBQVU7Q0FDWjs7Q0FHQSxNQUFNLHlCQUF5QixZQUFZO0VBQ3pDLElBQUksQ0FBQyxlQUFlLENBQUMsaUJBQWlCLEtBQUssR0FBRztFQUM5QyxNQUFNLFFBQVEsaUJBQWlCLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLFFBQVEsZ0JBQWdCLEVBQUUsQ0FBQyxDQUFDLFFBQVEsVUFBVSxFQUFFO0VBQ3BHLE1BQU0sVUFBVSxDQUFDLEdBQUcsWUFBWSxVQUFVLGdCQUFnQixLQUFLO0VBQy9ELE1BQU0sZ0JBQWdCLFlBQVksSUFBSSxFQUFFLGdCQUFnQixRQUFRLENBQUM7RUFDakUsb0JBQW9CLEVBQUU7RUFDdEIsVUFBVTtDQUNaOztDQUdBLE1BQU0sNEJBQTRCLE9BQU8sV0FBbUI7RUFDMUQsSUFBSSxDQUFDLGFBQWE7RUFDbEIsTUFBTSxVQUFVLFlBQVksVUFBVSxlQUFlLFFBQVEsTUFBTSxNQUFNLE1BQU07RUFDL0UsTUFBTSxnQkFBZ0IsWUFBWSxJQUFJLEVBQUUsZ0JBQWdCLFFBQVEsQ0FBQztFQUNqRSxVQUFVO0NBQ1o7O0NBR0EsTUFBTSxvQkFBb0IsT0FBTyxNQUF1QjtFQUN0RCxFQUFFLGVBQWU7RUFDakIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxhQUFhLEtBQUssR0FBRztFQUMxQyxNQUFNLFlBQVksWUFBWSxJQUFJLFVBQVUsYUFBYSxLQUFLLENBQUM7RUFDL0QsZ0JBQWdCLEVBQUU7RUFDbEIsVUFBVTtDQUNaOztDQUdBLE1BQU0sZ0JBQWdCLE1BQU0sU0FBUyxRQUFRLE1BQU0sRUFBRSxZQUFZLGFBQWEsRUFBRTtDQUVoRixJQUFJLENBQUMsYUFBYTtFQUNoQixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUFvQjtHQUEyQjs7OzthQUM3RCx3QkFBQyxVQUFEO0lBQ0UsZUFBZSxpQkFBaUIsSUFBSTtJQUNwQyxXQUFVO2NBQ1g7R0FFTzs7OztXQUNMOzs7Ozs7Q0FFVDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVHLGFBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFDZCx3QkFBQyxlQUFELEVBQWUsV0FBVSwwQkFBMkI7Ozs7O0tBQ2hEOzs7O2VBQ04sd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUNiLFVBQVU7S0FDUDs7OztlQUNOLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUF5QixVQUFVO0tBQVc7Ozs7YUFDeEQ7Ozs7YUFDRjs7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLGlCQUFpQixVQUFVLEVBQUU7TUFDNUMsV0FBVTtnQkFDWDtLQUVPOzs7OztJQUNMOzs7O1lBQ0Y7Ozs7OztHQUlQLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FFRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7O1FBQzFCOzs7O2tCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFtRTtTQUU3RTs7OzttQkFDSix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBZ0w7U0FFMUw7Ozs7aUJBQ0g7Ozs7O2tCQUNMLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFpRTtRQUUzRTs7OztnQkFDQTs7OztnQkFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRyxNQUFNLFNBQVMsS0FBSyxNQUNuQix3QkFBQyxVQUFEO1NBRUUsZUFBZSxtQkFBbUIsRUFBRSxFQUFFO1NBQ3RDLFdBQVcsZ0dBQ1QsRUFBRSxPQUFPLFlBQVksS0FDakIscUNBQ0E7bUJBTlI7VUFTRSx3QkFBQyxRQUFELFlBQU8sRUFBRSxPQUFhOzs7OztVQUN0Qix3QkFBQyxRQUFELFlBQU8sRUFBRSxLQUFXOzs7OztVQUNwQix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEI7WUFBeUM7WUFBRSxFQUFFO1lBQWE7V0FBUTs7Ozs7O1NBQzVEO1dBWEQsRUFBRTs7OztlQVdELENBQ1QsR0FFRCx3QkFBQyxVQUFEO1NBQ0UsZUFBZSxpQkFBaUIsSUFBSTtTQUNwQyxXQUFVO21CQUZaLENBSUUsd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OzttQkFBQyxjQUMxQjs7Ozs7Z0JBQ0w7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsVUFBRDtVQUNFLFNBQVM7VUFDVCxXQUFVO1VBQ1YsT0FBTTtvQkFFTCxXQUFXLHdCQUFDLEtBQUQsRUFBSyxXQUFVLHlCQUEwQjs7OztxQkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztTQUM5RTs7Ozs7U0FFUix3QkFBQyxVQUFEO1VBQ0UsZUFBZSxxQkFBcUIsSUFBSTtVQUN4QyxXQUFVO1VBQ1YsT0FBTTtvQkFIUixDQUtFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGNBQWU7Ozs7b0JBQUMsZUFDOUI7Ozs7OztTQUVSLHdCQUFDLFVBQUQ7VUFDRSxlQUFlLG9CQUFvQixZQUFZLEVBQUU7VUFDakQsV0FBVTtvQkFGWixDQUlFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLGNBQWU7Ozs7b0JBQUMsbUJBQ2hDOzs7Ozs7U0FFUix3QkFBQyxVQUFEO1VBQ0UsU0FBUztVQUNULFdBQVU7VUFDVixPQUFNO29CQUVOLHdCQUFDLE1BQUQsRUFBTSxXQUFVLHdCQUF5Qjs7Ozs7U0FDbkM7Ozs7O1NBRVIsd0JBQUMsVUFBRDtVQUNFLGVBQWUsa0JBQWtCLElBQUk7VUFDckMsV0FBVTtVQUNWLE9BQU07b0JBRU4sd0JBQUMsTUFBRCxFQUFNLFdBQVUsMEJBQTJCOzs7OztTQUNyQzs7Ozs7UUFDTDs7Ozs7O01BQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FDRyxZQUFZLE1BQUssWUFDZDs7Ozs7O1NBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQ0csWUFBWTtXQUFZO1dBQUcsWUFBWTtXQUFVO1VBQzlDOzs7Ozs7U0FDTix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEI7V0FDRyxZQUFZLGFBQ1gsd0JBQUMsaUJBQUQsRUFBaUIsV0FBVSwrQkFBZ0M7Ozs7c0JBRTNELHdCQUFDLFNBQUQsRUFBUyxXQUFVLDZCQUE4Qjs7Ozs7V0FFbEQsWUFBWTtXQUFhO1VBQ3RCOzs7Ozs7U0FDTix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixZQUFZLFdBQ1gsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsb0RBQTBEOzs7O3FCQUFDLFFBRXZFOzs7OztxQkFFTix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxvQ0FBMEM7Ozs7cUJBQUMsU0FFdkQ7Ozs7OztTQUVKOzs7OztRQUNIOzs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUFvQyxPQUM5QixZQUFZLFNBQVMsT0FDckI7Ozs7O2tCQUNOLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVTttQkFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7bUJBQUMsT0FDM0I7Ozs7O2dCQUNMOzs7OztlQUNGOzs7Ozs7S0FDRjs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWjtRQUNDO1NBQUUsSUFBSTtTQUFZLE9BQU87U0FBOEIsTUFBTTtRQUFPO1FBQ3BFO1NBQUUsSUFBSTtTQUFjLE9BQU87U0FBd0IsTUFBTTtRQUFNO1FBQy9EO1NBQUUsSUFBSTtTQUFRLE9BQU87U0FBZ0IsTUFBTTtRQUFXO1FBQ3REO1NBQUUsSUFBSTtTQUFhLE9BQU87U0FBMkIsTUFBTTtRQUFNO1FBQ2pFO1NBQUUsSUFBSTtTQUFVLE9BQU87U0FBa0IsTUFBTTtRQUFPO1FBQ3REO1NBQUUsSUFBSTtTQUFZLE9BQU87U0FBWSxNQUFNO1FBQWM7UUFDekQ7U0FBRSxJQUFJO1NBQWlCLE9BQU87U0FBK0IsTUFBTTtRQUFZO1FBQy9FO1NBQUUsSUFBSTtTQUFVLE9BQU87U0FBaUIsTUFBTTtTQUFlLE9BQU8sTUFBTSxPQUFPLFFBQVEsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFBTztRQUMvRztTQUFFLElBQUk7U0FBYyxPQUFPO1NBQTBCLE1BQU07UUFBTTtPQUNuRSxDQUFDLENBQUMsS0FBSyxRQUFRO1FBQ2IsTUFBTSxPQUFPLElBQUk7UUFDakIsTUFBTSxXQUFXLGNBQWMsSUFBSTtRQUNuQyxPQUNFLHdCQUFDLFVBQUQ7U0FFRSxlQUFlLGFBQWEsSUFBSSxFQUFTO1NBQ3pDLFdBQVcsMkdBQ1QsV0FDSSxxQ0FDQTttQkFOUjtVQVNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGNBQWU7Ozs7O1VBQy9CLHdCQUFDLFFBQUQsWUFBTyxJQUFJLE1BQVk7Ozs7O1VBQ3RCLElBQUksUUFDSCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYixJQUFJO1VBQ0Q7Ozs7cUJBQ0o7U0FDRTtXQWZELElBQUk7Ozs7ZUFlSDtPQUVaLENBQUM7TUFDRTs7Ozs7S0FDRjs7Ozs7SUFDQzs7Ozs7O0dBR1Isd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEI7S0FFRyxjQUFjLGNBQ2Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FFRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZCxDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHdCQUF5Qjs7OzttQkFBQywrQkFFMUM7Ozs7O2tCQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFvRDtRQUU5RDs7OztnQkFDQTs7OztrQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxVQUFEO1VBQ0UsZUFBZSxzQkFBc0IsSUFBSTtVQUN6QyxXQUFVO29CQUZaO1dBSUUsd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7Ozs7V0FBQztXQUFxQixZQUFZLFVBQVU7V0FBTztVQUM5RTs7Ozs7O1FBQ0w7Ozs7Z0JBQ0Y7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsYUFBRDtTQUNFLFVBQVUsWUFBWTtTQUN0QixXQUFXLFlBQVk7U0FDdkIsaUJBQWlCLFlBQVk7U0FDN0IsV0FBVyxZQUFZO1NBQ3ZCLFVBQVUsWUFBWTtTQUN0QixjQUFjLFlBQVk7U0FDMUIsV0FBVTtRQUNYOzs7O2tCQUdELHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSx1REFBNkQ7Ozs7cUJBQzdFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQixDQUNHLFlBQVksTUFBSyxhQUNkOzs7OzttQkFDSDs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxtRUFBeUU7Ozs7cUJBQ3pGLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQjthQUFxRDthQUN0QyxZQUFZLFVBQVUsUUFBUSxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7YUFBTztZQUMvRDs7Ozs7bUJBQ0g7Ozs7OztVQUNMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsZ0NBQXNDOzs7O3FCQUN0RCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBcUM7V0FFL0M7Ozs7bUJBQ0g7Ozs7OztTQUNGOzs7OztnQkFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGNBQWU7Ozs7b0JBQUMsOENBQy9COzs7OzttQkFDTix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBNkI7U0FFdkM7Ozs7aUJBQ0g7Ozs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsVUFBRDtXQUNFLGVBQWUsa0JBQWtCLFNBQVMsQ0FBQyxVQUFVLGtCQUFrQjtXQUN2RSxXQUFVO3FCQUNYO1VBRU87Ozs7O1VBQ1Isd0JBQUMsVUFBRDtXQUNFLGVBQWUsa0JBQWtCLFFBQVMsQ0FBQyxTQUFVLG1DQUFtQztXQUN4RixXQUFVO3FCQUNYO1VBRU87Ozs7O1VBQ1Isd0JBQUMsVUFBRDtXQUNFLGVBQWUsa0JBQWtCLFFBQVMsQ0FBQyxTQUFVLDhCQUE4QjtXQUNuRixXQUFVO3FCQUNYO1VBRU87Ozs7O1VBQ1Isd0JBQUMsVUFBRDtXQUNFLGVBQWUsa0JBQWtCLE9BQVMsQ0FBQyxRQUFVLHlDQUF5QztXQUM5RixXQUFVO3FCQUNYO1VBRU87Ozs7O1NBQ0w7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF1RDtRQUVqRTs7OztrQkFDSix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWixZQUFZLGdCQUFnQixNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxPQUFPLFVBQ25ELHdCQUFDLE9BQUQ7VUFFRSxXQUFVO29CQUZaLENBSUUsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxtQ0FBeUM7Ozs7cUJBQ3pELHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFDYixNQUFNO1dBQ0g7Ozs7cUJBQ04sd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWhCO2FBQ0csTUFBTSxTQUFTLFFBQVEsQ0FBQzthQUFFO2FBQUksTUFBTSxVQUFVLFFBQVEsQ0FBQzthQUFFO1lBQ3REOzs7OzttQkFDSDs7OzttQkFDRjs7Ozs7b0JBQ0wsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ2IsSUFBSSxLQUFLLE1BQU0sU0FBUyxDQUFDLENBQUMsbUJBQW1CLENBQUMsR0FBRztZQUFFLE1BQU07WUFBVyxRQUFRO1dBQVUsQ0FBQztVQUNwRjs7OztrQkFDSDtZQWpCRTs7OztnQkFpQkYsQ0FDTjtRQUNFOzs7O2dCQUNGOzs7Ozs7TUFDRjs7Ozs7O0tBSU4sY0FBYyxnQkFDYix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBRUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUF1RDtXQUVqRTs7OztxQkFDTix3QkFBQyxPQUFELEVBQU8sV0FBVSx3QkFBeUI7Ozs7bUJBQ3ZDOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmO2FBQ0csS0FBSyxNQUFNLFlBQVksV0FBVyxvQkFBb0IsRUFBRTthQUFFO2FBQUcsWUFBWSxXQUFXLG9CQUFvQjthQUFHO1lBQ3pHOzs7OztxQkFDTCx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBYjthQUFzQzthQUNmLFlBQVksV0FBVzthQUFrQjthQUM3RCxLQUFLLElBQUksR0FBRyxZQUFZLFdBQVcsb0JBQW9CLFlBQVksV0FBVyxpQkFBaUI7YUFBRTtZQUNqRzs7Ozs7bUJBQ0E7Ozs7OztVQUdMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsVUFBRDtZQUNFLGVBQ0UsbUJBQW1CLFlBQVksSUFBSSxFQUNqQyxtQkFBbUIsS0FBSyxJQUFJLElBQUksWUFBWSxXQUFXLG9CQUFvQixFQUFFLEVBQy9FLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUztZQUVuQixXQUFVO3NCQUNYO1dBRU87Ozs7cUJBQ1Isd0JBQUMsVUFBRDtZQUNFLGVBQ0UsbUJBQW1CLFlBQVksSUFBSSxFQUNqQyxtQkFBbUIsWUFBWSxXQUFXLG9CQUFvQixHQUNoRSxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVM7WUFFbkIsV0FBVTtzQkFDWDtXQUVPOzs7O21CQUNMOzs7Ozs7U0FDRjs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF1RDtVQUVqRTs7OztvQkFDTix3QkFBQyxNQUFELEVBQU0sV0FBVSwwQkFBMkI7Ozs7a0JBQ3hDOzs7OzttQkFFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXFDO1dBQTJCOzs7O3FCQUNoRix3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLFNBQVMsWUFBWSxXQUFXO1lBQ2hDLFdBQVcsTUFDVCxtQkFBbUIsWUFBWSxJQUFJLEVBQ2pDLGlCQUFpQixFQUFFLE9BQU8sUUFDNUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTO1lBRW5CLFdBQVU7V0FDWDs7OzttQkFDRTs7Ozs7b0JBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQXdDO1dBQXFCOzs7O3FCQUM5RSx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLE9BQU8sWUFBWSxXQUFXO1lBQzlCLFdBQVcsTUFDVCxtQkFBbUIsWUFBWSxJQUFJLEVBQ2pDLGNBQWMsRUFBRSxPQUFPLE1BQ3pCLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUztZQUVuQixXQUFVO1dBQ1g7Ozs7bUJBQ0U7Ozs7cUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUF3QztXQUFtQjs7OztxQkFDNUUsd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPLFlBQVksV0FBVztZQUM5QixXQUFXLE1BQ1QsbUJBQW1CLFlBQVksSUFBSSxFQUNqQyxZQUFZLEVBQUUsT0FBTyxNQUN2QixDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVM7WUFFbkIsV0FBVTtXQUNYOzs7O21CQUNFOzs7O21CQUNGOzs7OztrQkFDRjs7Ozs7aUJBQ0Y7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTZEO1NBRXZFOzs7O21CQUVMLFlBQVksd0JBQXdCLFlBQVkscUJBQXFCLFdBQVcsWUFDL0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEI7YUFBNkU7YUFDekUsWUFBWSxxQkFBcUI7YUFBUTtZQUN2Qzs7Ozs7O1dBQ04sd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQWI7YUFBOEQ7YUFDN0MsWUFBWSxxQkFBcUI7YUFBTztZQUN0RDs7Ozs7O1dBQ0gsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxVQUFEO2FBQ0UsZUFDRSxxQkFBcUIsWUFBWSxJQUFJLFlBQVksWUFBWSxzQkFBc0IsT0FBTyxDQUFDLENBQUMsS0FBSyxTQUFTO2FBRTVHLFdBQVU7dUJBQ1g7WUFFTzs7OztzQkFDUix3QkFBQyxVQUFEO2FBQ0UsZUFBZSxxQkFBcUIsWUFBWSxJQUFJLFFBQVEsQ0FBQyxDQUFDLEtBQUssU0FBUzthQUM1RSxXQUFVO3VCQUNYO1lBRU87Ozs7b0JBQ0w7Ozs7OztVQUNGOzs7OztvQkFFTCx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYjtXQUF1RDtXQUNiLFlBQVk7V0FBSztVQUN4RDs7Ozs7aUJBRUY7Ozs7OztPQUNGOzs7OztnQkFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUF1RDtPQUVqRTs7OztpQkFDSix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWjtTQUNDO1VBQUUsVUFBVTtVQUFxQixTQUFTO1VBQUksT0FBTztTQUFhO1NBQ2xFO1VBQUUsVUFBVTtVQUFxQixTQUFTO1VBQUksT0FBTztTQUFpQjtTQUN0RTtVQUFFLFVBQVU7VUFBZ0IsU0FBUztVQUFJLE9BQU87U0FBZ0I7U0FDaEU7VUFBRSxVQUFVO1VBQXNCLFNBQVM7VUFBRyxPQUFPO1NBQWM7UUFDckUsQ0FBQyxDQUFDLEtBQUssU0FDTCx3QkFBQyxPQUFEO1NBQXlCLFdBQVU7bUJBQW5DLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU8sS0FBSyxTQUFlOzs7O29CQUMzQix3QkFBQyxRQUFELGFBQU8sS0FBSyxTQUFRLE9BQVc7Ozs7a0JBQzVCOzs7OzttQkFDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxPQUFEO1dBQ0UsV0FBVyxHQUFHLEtBQUssTUFBTTtXQUN6QixPQUFPLEVBQUUsT0FBTyxHQUFJLEtBQUssVUFBVSxLQUFLLElBQUksR0FBRyxZQUFZLFdBQVcsaUJBQWlCLElBQUssSUFBSSxHQUFHO1VBQ3BHOzs7OztTQUNFOzs7O2lCQUNGO1dBWEssS0FBSzs7OztlQVdWLENBQ047T0FDRTs7OztlQUNGOzs7OztjQUNGOzs7Ozs7S0FJTixjQUFjLFVBQ2Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBeUQ7T0FFbkU7Ozs7aUJBQ0osd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQTZDO09BRXZEOzs7O2VBQ0E7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsVUFBRDtTQUNFLGVBQWU7VUFDYixZQUFZLFdBQVcsU0FBUyxTQUFTLFNBQVM7V0FDaEQsSUFBSSxLQUFLLGFBQWEsV0FBVyxLQUFLLGFBQWEsVUFBVTtZQUMzRCxjQUFjLFlBQVksSUFBSSxLQUFLLGFBQWEsUUFBUTtXQUMxRDtVQUNGLENBQUM7VUFDRCxXQUFXLFdBQVcsR0FBRztTQUMzQjtTQUNBLFdBQVU7bUJBQ1g7UUFFTzs7Ozs7T0FDTDs7OztlQUNGOzs7OztnQkFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWixZQUFZLFdBQVcsU0FBUyxLQUFLLFFBQ3BDLHdCQUFDLE9BQUQ7UUFFRSxXQUFXLHlDQUNULElBQUksV0FBVyxXQUNYLDJFQUNBO2tCQUxSLENBUUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQ0Usd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQ1gsSUFBSTtVQUNIOzs7OztVQUNKLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUNiLElBQUk7VUFDRDs7Ozs7VUFDTix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYixJQUFJO1VBQ0Q7Ozs7O1NBQ0g7Ozs7bUJBRUwsd0JBQUMsUUFBRDtVQUNFLFdBQVcsMkVBQ1QsSUFBSSxXQUFXLFdBQ1gsMkJBQ0EsSUFBSSxXQUFXLFlBQ2YsNEJBQ0E7b0JBR0wsSUFBSTtTQUNEOzs7O2lCQUNIOzs7OztrQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQjtXQUE2QztXQUM5QixJQUFJO1dBQWlCO1VBQzlCOzs7OzttQkFHTix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxVQUFEO1dBQ0UsZUFDRSxjQUNFLFlBQVksSUFDWixJQUFJLGFBQ0osSUFBSSxXQUFXLFdBQVcsWUFBWSxRQUN4QyxDQUFDLENBQUMsS0FBSyxTQUFTO1dBRWxCLFdBQVcsa0VBQ1QsSUFBSSxXQUFXLFdBQ1gsbURBQ0E7cUJBR0wsSUFBSSxXQUFXLFdBQVcsZUFBZTtVQUNwQzs7Ozs7U0FDTDs7OztpQkFDRjs7Ozs7Z0JBQ0Y7VUExREUsSUFBSTs7OztjQTBETixDQUNOO01BQ0U7Ozs7Y0FDRjs7Ozs7O0tBSU4sY0FBYyxlQUNiLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBeUQ7U0FFbkU7Ozs7bUJBQ0osd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQXlCO1NBRW5DOzs7O2lCQUNBOzs7O21CQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTJEO1VBRXJFOzs7O29CQUNOLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsU0FBUyxZQUFZLFVBQVU7V0FDL0IsV0FBVyxNQUNULGdCQUFnQixZQUFZLElBQUksRUFDOUIsbUJBQW1CLEVBQUUsT0FBTyxRQUM5QixDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVM7V0FFbkIsV0FBVTtVQUNYOzs7O2tCQUNFOzs7OztpQkFDRjs7Ozs7a0JBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1osa0JBQWtCLEtBQUssUUFBUTtVQUM5QixNQUFNLFlBQVksWUFBWSxVQUFVLGtCQUFrQixTQUFTLElBQUksRUFBRTtVQUN6RSxPQUNFLHdCQUFDLE9BQUQ7V0FFRSxlQUFlLHFCQUFxQixJQUFJLEVBQUU7V0FDMUMsV0FBVyx5REFDVCxZQUNJLDRHQUNBO3FCQU5SLENBU0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBcUIsSUFBSTtZQUFXOzs7O3NCQUNwRCx3QkFBQyxTQUFEO2FBQ0UsTUFBSzthQUNMLFNBQVM7YUFDVCxnQkFBZ0IsQ0FBQzthQUNqQixXQUFVO1lBQ1g7Ozs7b0JBQ0U7Ozs7O3FCQUNMLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUNWLElBQUk7V0FDSjs7OzttQkFDQTthQXBCRSxJQUFJOzs7O2lCQW9CTjtTQUVULENBQUM7UUFDRTs7OztnQkFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FFRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUF1RDtVQUVqRTs7Ozs7VUFDSix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsT0FBTztZQUNQLFdBQVcsTUFBTSxvQkFBb0IsRUFBRSxPQUFPLEtBQUs7WUFDbkQsYUFBWTtZQUNaLFdBQVU7V0FDWDs7OztxQkFDRCx3QkFBQyxVQUFEO1lBQ0UsU0FBUztZQUNULFdBQVU7c0JBQ1g7V0FFTzs7OzttQkFDTDs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1osWUFBWSxVQUFVLGVBQWUsS0FBSyxNQUN6Qyx3QkFBQyxPQUFEO1lBRUUsV0FBVTtzQkFGWixDQUlFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUE4QztZQUFROzs7O3NCQUN0RSx3QkFBQyxVQUFEO2FBQ0UsZUFBZSwwQkFBMEIsQ0FBQzthQUMxQyxXQUFVO3VCQUVWLHdCQUFDLFFBQUQsRUFBUSxXQUFVLGNBQWU7Ozs7O1lBQzNCOzs7O29CQUNMO2NBVkU7Ozs7a0JBVUYsQ0FDTjtVQUNFOzs7OztTQUNGOzs7OztrQkFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUF1RDtVQUVqRTs7Ozs7VUFDSix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsT0FBTztZQUNQLFdBQVcsTUFBTSxvQkFBb0IsRUFBRSxPQUFPLEtBQUs7WUFDbkQsYUFBWTtZQUNaLFdBQVU7V0FDWDs7OztxQkFDRCx3QkFBQyxVQUFEO1lBQ0UsU0FBUztZQUNULFdBQVU7c0JBQ1g7V0FFTzs7OzttQkFDTDs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQ1osWUFBWSxVQUFVLGVBQWUsS0FBSyxNQUN6Qyx3QkFBQyxPQUFEO1lBRUUsV0FBVTtzQkFGWixDQUlFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFvRDtZQUFROzs7O3NCQUM1RSx3QkFBQyxVQUFEO2FBQ0UsZUFBZSwwQkFBMEIsQ0FBQzthQUMxQyxXQUFVO3VCQUVWLHdCQUFDLFFBQUQsRUFBUSxXQUFVLGNBQWU7Ozs7O1lBQzNCOzs7O29CQUNMO2NBVkU7Ozs7a0JBVUYsQ0FDTjtVQUNFOzs7OztTQUNGOzs7OztnQkFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUU7U0FFM0U7Ozs7O1NBQ04sd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU87V0FDUCxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO1dBQy9DLGFBQVk7V0FDWixXQUFVO1VBQ1g7Ozs7b0JBQ0Qsd0JBQUMsVUFBRDtXQUNFLFNBQVM7V0FDVCxXQUFVO3FCQUNYO1VBRU87Ozs7a0JBQ0w7Ozs7OztTQUVKLGNBQ0Msd0JBQUMsT0FBRDtVQUNFLFdBQVcsMkNBQ1QsV0FBVyxVQUNQLDBEQUNBO29CQUpSLENBT0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ2IsV0FBVyxVQUFVLGNBQWM7VUFDaEM7Ozs7b0JBQ0wsV0FBVyxpQkFDVix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBYyxXQUFXO1VBQW9COzs7O2tCQUU1RDs7Ozs7O1FBRUo7Ozs7OztNQUNGOzs7Ozs7S0FJTixjQUFjLFlBQ2Isd0JBQUMscUJBQUQ7TUFDRSxPQUFPO01BQ1AsY0FBYztNQUNIO0tBQ1o7Ozs7O0tBSUYsY0FBYyxjQUNiLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQ7U0FDRSx3QkFBQyxlQUFELEVBQWUsV0FBVSwwQkFBMkI7Ozs7O1NBQUM7U0FDL0IsWUFBWTtRQUNoQzs7Ozs7O09BR0osd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osY0FBYyxXQUFXLElBQ3hCLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQXdEO1VBQ04sWUFBWTtVQUFLO1NBQ2hFOzs7OzttQkFFSCxjQUFjLEtBQUssUUFDakIsd0JBQUMsT0FBRDtTQUVFLFdBQVcsaUJBQ1QsSUFBSSxXQUFXLFdBQVcsY0FBYzttQkFINUMsQ0FNRSx3QkFBQyxPQUFEO1VBQ0UsV0FBVyxtRUFDVCxJQUFJLFdBQVcsV0FDWCwyQ0FDQTtvQkFHTCxJQUFJO1NBQ0Y7Ozs7bUJBQ0wsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQ0csSUFBSSxXQUFXLFdBQVcsUUFBUSxZQUFZO1dBQUs7V0FBRztXQUN0RCxJQUFJLEtBQUssSUFBSSxTQUFTLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHO1lBQUUsTUFBTTtZQUFXLFFBQVE7V0FBVSxDQUFDO1VBQ2xGOzs7OztpQkFDSDtXQWxCRSxJQUFJOzs7O2VBa0JOLENBQ047T0FFQTs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWjtTQUFDO1NBQXdCO1NBQXdCO1NBQTBCO1FBQXlCLENBQUMsQ0FBQyxLQUFLLFdBQzFHLHdCQUFDLFVBQUQ7U0FFRSxTQUFTLFlBQVk7VUFDbkIsTUFBTSxZQUFZLFlBQVksSUFBSSxVQUFVLE1BQU07VUFDbEQsVUFBVTtTQUNaO1NBQ0EsV0FBVTttQkFFVDtRQUNLLEdBUkQ7Ozs7ZUFRQyxDQUNUO09BQ0U7Ozs7O09BR0wsd0JBQUMsUUFBRDtRQUFNLFVBQVU7UUFBbUIsV0FBVTtrQkFBN0MsQ0FDRSx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE9BQU87U0FDUCxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxLQUFLO1NBQy9DLGFBQWEsV0FBVyxZQUFZLEtBQUs7U0FDekMsV0FBVTtRQUNYOzs7O2tCQUNELHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsV0FBVTttQkFGWixDQUlFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGNBQWU7Ozs7bUJBQUMsT0FDMUI7Ozs7O2dCQUNKOzs7Ozs7TUFDSDs7Ozs7O0tBSU4sY0FBYyxZQUNiLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXlEO09BRW5FOzs7O2lCQUNKLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUF5QjtPQUVuQzs7OztlQUNBOzs7O2lCQUNMLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGlCQUFpQixXQUFXLElBQUksQ0FBQyxDQUFDLEtBQUssU0FBUztRQUMvRCxXQUFVO2tCQUNYO09BRU87Ozs7ZUFDTDs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1osTUFBTSxPQUFPLEtBQUssVUFDakIsd0JBQUMsT0FBRDtRQUVFLFdBQVcsMEVBQ1QsTUFBTSxhQUFhLGFBQ2Ysd0VBQ0EsTUFBTSxhQUFhLFlBQ25CLDRFQUNBO2tCQVBSLENBVUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYixNQUFNO1VBQ0g7Ozs7O1VBQ04sd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQ1YsTUFBTTtVQUNOOzs7OztVQUNILHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUNiLElBQUksS0FBSyxNQUFNLFNBQVMsQ0FBQyxDQUFDLGVBQWU7VUFDdEM7Ozs7O1NBQ0g7Ozs7O2tCQUVKLENBQUMsTUFBTSxRQUNOLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLGlCQUFpQixNQUFNLEVBQUUsQ0FBQyxDQUFDLEtBQUssU0FBUztTQUN4RCxXQUFVO21CQUNYO1FBRU87Ozs7Z0JBRVA7VUE3QkUsTUFBTTs7OztjQTZCUixDQUNOO01BQ0U7Ozs7Y0FDRjs7Ozs7O0tBSU4sY0FBYyxtQkFDYix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUVFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQ2Qsd0JBQUMsYUFBRCxFQUFhLFdBQVUsVUFBVzs7Ozs7V0FDOUI7Ozs7cUJBQ04sd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFvQztXQUU5Qzs7OztxQkFDSix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBMEI7V0FFcEM7Ozs7bUJBQ0g7Ozs7bUJBQ0Y7Ozs7O29CQUNMLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFtRDtVQUU3RDs7OztrQkFDQTs7Ozs7bUJBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUsMkJBQTRCOzs7O3FCQUFDLHFCQUVqRDs7Ozs7O1NBQ0g7Ozs7aUJBQ0Y7Ozs7O2tCQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBZ0U7WUFFMUU7Ozs7O1lBQ04sd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSxVQUFXOzs7O3VCQUFDLGlCQUNqQzs7Ozs7O1lBQ0wsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQTZDO1lBRXZEOzs7OztXQUNIOzs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFnRTtZQUUxRTs7Ozs7WUFDTix3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7dUJBQUMsb0JBQ2pDOzs7Ozs7WUFDTCx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBNkM7WUFFdkQ7Ozs7O1dBQ0g7Ozs7OztVQUVMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQ0Usd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWdFO1lBRTFFOzs7OztZQUNOLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7Ozt1QkFBQyxtQkFDekI7Ozs7OztZQUNMLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFtQztZQUU3Qzs7Ozs7V0FDSDs7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBZ0U7WUFFMUU7Ozs7O1lBQ04sd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FDRSx3QkFBQyxlQUFELEVBQWUsV0FBVSxVQUFXOzs7OztjQUFDO2NBQUUsWUFBWSxlQUFlLDBCQUEwQjtjQUFFO2FBQzNGOzs7Ozs7WUFDTCx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFDYixZQUFZLGVBQWUsb0JBQ3hCLFNBQVMsSUFBSSxLQUFLLFlBQVksY0FBYyxpQkFBaUIsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLEdBQUc7Y0FBRSxNQUFNO2NBQVcsUUFBUTthQUFVLENBQUMsTUFDNUg7WUFDQTs7Ozs7V0FDSDs7Ozs7O1NBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsd0JBQXlCOzs7O29CQUFDLGlEQUUvQzs7Ozs7bUJBQ0osd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQW9EO1NBRTlEOzs7O2lCQUNBOzs7O21CQUVMLHdCQUFDLFVBQUQ7VUFDRSxlQUFlO1dBQ2IsZ0JBQWdCLEVBQUU7V0FDbEIsa0JBQWtCLElBQUk7V0FDdEIsb0JBQW9CLEtBQUs7V0FDekIsMEJBQTBCLElBQUk7VUFDaEM7VUFDQSxXQUFVO29CQVBaLENBU0Usd0JBQUMsZUFBRCxFQUFlLFdBQVUsMEJBQTJCOzs7O29CQUFDLGtDQUUvQzs7Ozs7aUJBQ0w7Ozs7O2tCQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFxRjtZQUUvRjs7OztzQkFBQywrQkFFSjs7Ozs7cUJBQ0wsd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQWlFO1dBRTNFOzs7O21CQUNBOzs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXVGO1lBRWpHOzs7O3NCQUFDLGtDQUVKOzs7OztxQkFDTCx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBYjthQUE4RTthQUN3Qix3QkFBQyxRQUFELFlBQU0sK0JBQWtDOzs7OzthQUFDO2FBQXdDLHdCQUFDLFFBQUQsWUFBTSxxQkFBd0I7Ozs7O2FBQUM7WUFDbk47Ozs7O21CQUNBOzs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXdGO1lBRWxHOzs7O3NCQUFDLDZCQUVKOzs7OztxQkFDTCx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBYjthQUE4RTthQUN0Qix3QkFBQyxRQUFELFlBQU0sb0RBQXVEOzs7OzthQUFDO1lBQ25IOzs7OzttQkFDQTs7Ozs7O1NBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7OztxQkFBQyxtREFDekI7Ozs7O29CQUNOLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUE4RDtVQUV4RTs7OztrQkFDSDs7Ozs7O1NBQ0wsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQXlDO1NBRW5EOzs7OztTQUNILHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUEyRjtTQUVyRzs7Ozs7U0FDTCx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBNkI7U0FFdkM7Ozs7O1FBQ0E7Ozs7OztPQUdMLHdCQUFDLHdCQUFELENBQXlCOzs7OztNQUN0Qjs7Ozs7O0tBSU4sY0FBYyxnQkFBZ0Isd0JBQUMsa0JBQUQsQ0FBbUI7Ozs7O0lBQzlDOzs7Ozs7R0FHTCwwQkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxhQUFELEVBQWEsV0FBVSxVQUFXOzs7OztNQUMvQjs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWlJO09BRTNJOzs7OztPQUNOLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFzQztPQUVoRDs7Ozs7T0FDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBOEI7T0FFeEM7Ozs7O01BQ0E7Ozs7O01BRUosbUJBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSxtQ0FBb0M7Ozs7O1FBQzVELHdCQUFDLEtBQUQsWUFBRyx1QkFBdUI7Ozs7O1FBQzFCLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUE2QjtRQUF3RDs7Ozs7UUFDbEcsd0JBQUMsVUFBRDtTQUNFLGVBQWUsMEJBQTBCLEtBQUs7U0FDOUMsV0FBVTttQkFDWDtRQUVPOzs7OztPQUNMOzs7OztpQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsV0FBVTtTQUNWLFdBQVc7U0FDWCxPQUFPO1NBQ1AsV0FBVyxNQUFNO1VBQ2YsZ0JBQWdCLEVBQUUsT0FBTyxNQUFNLFFBQVEsT0FBTyxFQUFFLENBQUM7VUFDakQsa0JBQWtCLElBQUk7U0FDeEI7U0FDQSxhQUFZO1NBQ1osV0FBVTtRQUNYOzs7OztRQUVBLGtCQUNDLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUNWO1FBQ0E7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1VBQ0UsU0FBUyxZQUFZOztXQUVuQixNQUFNLG9CQUFvQixZQUFZLElBQUksb0RBQW9EO1dBQzlGLFVBQVU7V0FDViwwQkFBMEIsS0FBSztVQUNqQztVQUNBLFdBQVU7b0JBQ1g7U0FFTzs7OzttQkFDUix3QkFBQyxVQUFEO1VBQ0UsU0FBUyxZQUFZO1dBQ25CLElBQUksaUJBQWlCLE1BQU0sV0FBVztZQUNwQyxvQkFBb0IsSUFBSTtXQUMxQixPQUFPO1lBQ0wsa0JBQWtCLHVEQUF1RDtZQUN6RSxNQUFNLG9CQUFvQixZQUFZLElBQUksdURBQXVEO1lBQ2pHLFVBQVU7V0FDWjtVQUNGO1VBQ0EsV0FBVTtvQkFDWDtTQUVPOzs7O2lCQUNMOzs7Ozs7T0FDRjs7Ozs7O0tBRUo7Ozs7OztHQUNGOzs7OztHQUlQLHdCQUFDLG9CQUFEO0lBQ0UsUUFBUTtJQUNSLGVBQWUsaUJBQWlCLEtBQUs7SUFDckMsZ0JBQWdCO0dBQ2pCOzs7OztHQUVELHdCQUFDLGdCQUFEO0lBQ0UsUUFBUTtJQUNSLFNBQVMsWUFBWTtJQUNyQixjQUFjLFlBQVk7SUFDMUIsaUJBQWlCLFlBQVksU0FBUztJQUN0QyxrQkFBa0IsWUFBWSxTQUFTO0lBQ3ZDLGVBQWUsc0JBQXNCLEtBQUs7SUFDMUMsU0FBUztHQUNWOzs7OztHQUdBLHFCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxhQUFELEVBQWEsV0FBVSxVQUFXOzs7OztRQUMvQjs7OztrQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXlEO1FBRW5FOzs7O2tCQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUE2QztRQUV2RDs7OztnQkFDQTs7OztnQkFDRjs7Ozs7aUJBQ0wsd0JBQUMsVUFBRDtRQUNFLGVBQWUscUJBQXFCLEtBQUs7UUFDekMsV0FBVTtrQkFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztPQUNsQjs7OztlQUNMOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFpRTtPQUUzRTs7OztpQkFDTix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLEtBQUQ7U0FDRSxNQUFLO1NBQ0wsVUFBUztTQUNULFdBQVU7bUJBSFosQ0FLRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O21CQUFDLG9CQUMvQjs7Ozs7a0JBQ0gsd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxVQUFVO1NBQ1YsU0FBUyxZQUFZO1VBQ25CLG9CQUFvQixJQUFJO1VBQ3hCLElBQUk7V0FDRixNQUFNLHFCQUFxQjtVQUM3QixVQUFVO1dBQ1Isb0JBQW9CLEtBQUs7VUFDM0I7U0FDRjtTQUNBLFdBQVU7bUJBWFo7VUFhRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7OztVQUFDO1VBQUUsbUJBQW1CLGVBQWU7U0FDOUQ7Ozs7O2dCQUNMOzs7OztlQUNGOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFxRDtPQUUvRDs7OztpQkFDTix3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZDtTQUNFLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxVQUFELFlBQVEsZ0NBQXFDOzs7O21CQUFDLHdFQUEwRTs7Ozs7U0FDNUgsd0JBQUMsTUFBRCxhQUFJLHdCQUFDLFVBQUQsWUFBUSw2QkFBa0M7Ozs7bUJBQUMsMERBQTREOzs7OztTQUMzRyx3QkFBQyxNQUFELGFBQUksd0JBQUMsVUFBRCxZQUFRLDJCQUFnQzs7OzttQkFBQyxnREFBa0Q7Ozs7O1NBQy9GLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxVQUFELFlBQVEsaUNBQXNDOzs7O21CQUFDLG9HQUFzRzs7Ozs7U0FDekosd0JBQUMsTUFBRCxhQUFJLHdCQUFDLFVBQUQsWUFBUSx5QkFBOEI7Ozs7bUJBQUMsb0ZBQXNGOzs7OztRQUMvSDs7Ozs7ZUFDRDs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBK0M7T0FFekQ7Ozs7aUJBQ04sd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxLQUFELFlBQUcsaUNBQWlDOzs7OztTQUNwQyx3QkFBQyxLQUFELFlBQUcsZ0RBQWdEOzs7OztTQUNuRCx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBNEI7U0FBYzs7Ozs7U0FDdkQsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQTRCO1NBQWM7Ozs7O1NBQ3ZELHdCQUFDLEtBQUQsWUFBRyxrREFBa0Q7Ozs7O1FBQ2xEOzs7OztlQUNGOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxVQUFEO1FBQ0UsZUFBZSxxQkFBcUIsS0FBSztRQUN6QyxXQUFVO2tCQUNYO09BRU87Ozs7O01BQ0w7Ozs7O0tBQ0Y7Ozs7OztHQUNGOzs7OztHQUlQLHdCQUFDLFlBQUQ7SUFDRSxRQUFRO0lBQ1IsZUFBZSxrQkFBa0IsS0FBSztJQUN0QyxXQUFXLE1BQU07R0FDbEI7Ozs7O0dBR0Qsd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FDaEIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQStDO09BRXpEOzs7OztPQUNOLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztPQUNiLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF1RDtPQUVqRTs7Ozs7TUFDSDs7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQsWUFBTSxlQUFrQjs7Ozs7T0FDeEIsd0JBQUMsVUFBRDtRQUFRLFdBQVU7a0JBQStJO09BRXpKOzs7OztPQUNSLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztPQUNiLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGtCQUFrQixJQUFJO1FBQ3JDLFdBQVU7a0JBQ1g7T0FFTzs7Ozs7TUFDTDs7Ozs7YUFDRjs7Ozs7O0dBQ0M7Ozs7O0VBQ0w7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBhcmVudERhc2hib2FyZC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgU2hpZWxkLCBcbiAgTWFwUGluLCBcbiAgQ2xvY2ssIFxuICBTbWFydHBob25lLCBcbiAgR2xvYmUsIFxuICBDYW1lcmEsIFxuICBNZXNzYWdlU3F1YXJlLCBcbiAgQWxlcnRUcmlhbmdsZSwgXG4gIENvZGUyLCBcbiAgUGx1cywgXG4gIEJhdHRlcnksIFxuICBCYXR0ZXJ5Q2hhcmdpbmcsIFxuICBXaWZpLCBcbiAgV2lmaU9mZiwgXG4gIENoZWNrQ2lyY2xlMiwgXG4gIE1vb24sIFxuICBTdW4sIFxuICBMb2NrLCBcbiAgVW5sb2NrLCBcbiAgUmVmcmVzaEN3LCBcbiAgU2xpZGVycywgXG4gIENoZXZyb25SaWdodCwgXG4gIFRyYXNoMiwgXG4gIFNlbmQsXG4gIEV5ZSxcbiAgQ2hlY2ssXG4gIFgsXG4gIFZvbHVtZTIsXG4gIFNoYXJlMixcbiAgR2FtZXBhZDIsXG4gIFlvdXR1YmUsXG4gIEJvb2tPcGVuLFxuICBHcmFkdWF0aW9uQ2FwLFxuICBDb21wYXNzLFxuICBEb3dubG9hZCxcbiAgRmlsZUFyY2hpdmUsXG4gIFNoaWVsZENoZWNrLFxuICBTaGllbGRBbGVydCxcbiAgSW5mb1xufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgREJTdGF0ZSwgQ2hpbGREZXZpY2UsIFNhZmVab25lLCBBcHBSdWxlIH0gZnJvbSAnLi4vdHlwZXMvc2FmZWtpZHMnO1xuaW1wb3J0IHsgZG93bmxvYWRQcm9qZWN0QXNaaXAgfSBmcm9tICcuLi91dGlscy9leHBvcnRQcm9qZWN0WmlwJztcbmltcG9ydCB7IFNhZmVLaWRzTWFwIH0gZnJvbSAnLi9TYWZlS2lkc01hcCc7XG5pbXBvcnQgeyBDYW1lcmFTY3JlZW5TZXNzaW9uIH0gZnJvbSAnLi9DYW1lcmFTY3JlZW5TZXNzaW9uJztcbmltcG9ydCB7IEFuZHJvaWROYXRpdmVLaXQgfSBmcm9tICcuL0FuZHJvaWROYXRpdmVLaXQnO1xuaW1wb3J0IHsgRGV2aWNlUGFpcmluZ01vZGFsIH0gZnJvbSAnLi9EZXZpY2VQYWlyaW5nTW9kYWwnO1xuaW1wb3J0IHsgU2FmZVpvbmVzTW9kYWwgfSBmcm9tICcuL1NhZmVab25lc01vZGFsJztcbmltcG9ydCB7IEFib3V0TW9kYWwgfSBmcm9tICcuL0Fib3V0TW9kYWwnO1xuaW1wb3J0IHsgQ2hpbGRQZXJtaXNzaW9uc1NoaWVsZCB9IGZyb20gJy4vQ2hpbGRQZXJtaXNzaW9uc1NoaWVsZCc7XG5pbXBvcnQgeyBcbiAgdXBkYXRlU2NyZWVuTGltaXRzLCBcbiAgdXBkYXRlQXBwUnVsZSwgXG4gIHVwZGF0ZVdlYkZpbHRlciwgXG4gIHJlc3BvbmRUaW1lRXh0ZW5zaW9uLCBcbiAgc2VuZE1lc3NhZ2UsIFxuICBtYXJrQWxlcnRzQXNSZWFkLFxuICBzZW5kQ2hpbGRIZWFydGJlYXQsXG4gIHVwZGF0ZUFudGlVbmluc3RhbGxTZXR0aW5ncyxcbiAgcmVwb3J0VGFtcGVyQXR0ZW1wdFxufSBmcm9tICcuLi9zZXJ2aWNlcy9hcGknO1xuaW1wb3J0IHsgRklMVEVSX0NBVEVHT1JJRVMsIGNoZWNrVXJsQWxsb3dlZCB9IGZyb20gJy4uL3V0aWxzL3dlYmZpbHRlcic7XG5pbXBvcnQgeyByZXZlcnNlR2VvY29kZSB9IGZyb20gJy4uL3V0aWxzL2dlb2ZlbmNlJztcblxuaW50ZXJmYWNlIFBhcmVudERhc2hib2FyZFByb3BzIHtcbiAgc3RhdGU6IERCU3RhdGU7XG4gIG9uUmVmcmVzaDogKCkgPT4gdm9pZDtcbiAgb25Td2l0Y2hUb0NoaWxkTW9kZTogKGNoaWxkSWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgZGFya01vZGU6IGJvb2xlYW47XG4gIG9uVG9nZ2xlRGFya01vZGU6ICgpID0+IHZvaWQ7XG4gIG9uQ2hhbmdlUGluUmVxdWVzdGVkOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgUGFyZW50RGFzaGJvYXJkOiBSZWFjdC5GQzxQYXJlbnREYXNoYm9hcmRQcm9wcz4gPSAoe1xuICBzdGF0ZSxcbiAgb25SZWZyZXNoLFxuICBvblN3aXRjaFRvQ2hpbGRNb2RlLFxuICBkYXJrTW9kZSxcbiAgb25Ub2dnbGVEYXJrTW9kZSxcbiAgb25DaGFuZ2VQaW5SZXF1ZXN0ZWQsXG59KSA9PiB7XG4gIGNvbnN0IFtzZWxlY3RlZENoaWxkSWQsIHNldFNlbGVjdGVkQ2hpbGRJZF0gPSB1c2VTdGF0ZTxzdHJpbmc+KFxuICAgIHN0YXRlLmNoaWxkcmVuWzBdPy5pZCB8fCAnJ1xuICApO1xuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGU8XG4gICAgJ2xvY2F0aW9uJyB8ICdzY3JlZW50aW1lJyB8ICdhcHBzJyB8ICd3ZWJmaWx0ZXInIHwgJ2NhbWVyYScgfCAnbWVzc2FnZXMnIHwgJ2FsZXJ0cycgfCAnYW50aXVuaW5zdGFsbCcgfCAnYW5kcm9pZGtpdCdcbiAgPignbG9jYXRpb24nKTtcblxuICAvLyBNb2RhbHNcbiAgY29uc3QgW3Nob3dQYWlyTW9kYWwsIHNldFNob3dQYWlyTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc2hvd1NhZmVab25lc01vZGFsLCBzZXRTaG93U2FmZVpvbmVzTW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc2hvd0Rvd25sb2FkTW9kYWwsIHNldFNob3dEb3dubG9hZE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Nob3dBYm91dE1vZGFsLCBzZXRTaG93QWJvdXRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpc0Rvd25sb2FkaW5nWmlwLCBzZXRJc0Rvd25sb2FkaW5nWmlwXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgXG4gIC8vIEFudGktVW5pbnN0YWxsIFRlc3QgU2ltdWxhdG9yIE1vZGFsXG4gIGNvbnN0IFtzaG93VGVzdFVuaW5zdGFsbE1vZGFsLCBzZXRTaG93VGVzdFVuaW5zdGFsbE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3NpbXVsYXRlZFBpbiwgc2V0U2ltdWxhdGVkUGluXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3NpbXVsYXRlZEVycm9yLCBzZXRTaW11bGF0ZWRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3NpbXVsYXRlZFN1Y2Nlc3MsIHNldFNpbXVsYXRlZFN1Y2Nlc3NdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIC8vIFF1aWNrIG1lc3NhZ2UgaW5wdXRcbiAgY29uc3QgW21lc3NhZ2VJbnB1dCwgc2V0TWVzc2FnZUlucHV0XSA9IHVzZVN0YXRlKCcnKTtcblxuICAvLyBXZWIgZmlsdGVyIGxpdmUgdGVzdGVyXG4gIGNvbnN0IFt0ZXN0VXJsSW5wdXQsIHNldFRlc3RVcmxJbnB1dF0gPSB1c2VTdGF0ZSgnZGlzY29yZC5jb20nKTtcbiAgY29uc3QgW3Rlc3RSZXN1bHQsIHNldFRlc3RSZXN1bHRdID0gdXNlU3RhdGU8YW55PihudWxsKTtcblxuICAvLyBOZXcgZG9tYWluIGlucHV0c1xuICBjb25zdCBbbmV3QmxvY2tlZERvbWFpbiwgc2V0TmV3QmxvY2tlZERvbWFpbl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtuZXdBbGxvd2VkRG9tYWluLCBzZXROZXdBbGxvd2VkRG9tYWluXSA9IHVzZVN0YXRlKCcnKTtcblxuICAvLyBTZWxlY3RlZCBjaGlsZCBvYmplY3RcbiAgY29uc3QgYWN0aXZlQ2hpbGQgPSBzdGF0ZS5jaGlsZHJlbi5maW5kKChjKSA9PiBjLmlkID09PSBzZWxlY3RlZENoaWxkSWQpIHx8IHN0YXRlLmNoaWxkcmVuWzBdO1xuXG4gIC8vIEFjdGl2ZSBTT1MgYWxlcnQgaWYgYW55XG4gIGNvbnN0IGFjdGl2ZVNPUyA9IHN0YXRlLmFsZXJ0cy5maW5kKFxuICAgIChhKSA9PiBhLnR5cGUgPT09ICdzb3MnICYmIChEYXRlLm5vdygpIC0gbmV3IERhdGUoYS50aW1lc3RhbXApLmdldFRpbWUoKSA8IDMwICogNjAwMDApXG4gICk7XG5cbiAgLy8gSGFuZGxlIGxpdmUgVVJMIHRlc3RcbiAgY29uc3QgaGFuZGxlVGVzdFVybCA9ICgpID0+IHtcbiAgICBpZiAoIWFjdGl2ZUNoaWxkIHx8ICF0ZXN0VXJsSW5wdXQudHJpbSgpKSByZXR1cm47XG4gICAgY29uc3QgcmVzID0gY2hlY2tVcmxBbGxvd2VkKFxuICAgICAgdGVzdFVybElucHV0LFxuICAgICAgYWN0aXZlQ2hpbGQud2ViRmlsdGVyLmJsb2NrZWRDYXRlZ29yaWVzLFxuICAgICAgYWN0aXZlQ2hpbGQud2ViRmlsdGVyLmJsb2NrZWREb21haW5zLFxuICAgICAgYWN0aXZlQ2hpbGQud2ViRmlsdGVyLmFsbG93ZWREb21haW5zXG4gICAgKTtcbiAgICBzZXRUZXN0UmVzdWx0KHJlcyk7XG4gIH07XG5cbiAgLy8gUXVpY2sgc2ltdWxhdGlvbiBzbGlkZXI6IE1vdmUgY2hpbGQgR1BTIHRvIHRlc3QgZ2VvZmVuY2luZ1xuICBjb25zdCBoYW5kbGVTaW11bGF0ZUdQUyA9IGFzeW5jICh0YXJnZXRMYXQ6IG51bWJlciwgdGFyZ2V0TG5nOiBudW1iZXIsIGFkZHJlc3NEZXNjOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoIWFjdGl2ZUNoaWxkKSByZXR1cm47XG4gICAgY29uc3QgYWRkcmVzcyA9IGF3YWl0IHJldmVyc2VHZW9jb2RlKHRhcmdldExhdCwgdGFyZ2V0TG5nKTtcbiAgICBhd2FpdCBzZW5kQ2hpbGRIZWFydGJlYXQoYWN0aXZlQ2hpbGQuaWQsIHtcbiAgICAgIGxvY2F0aW9uOiB7XG4gICAgICAgIGxhdGl0dWRlOiB0YXJnZXRMYXQsXG4gICAgICAgIGxvbmdpdHVkZTogdGFyZ2V0TG5nLFxuICAgICAgICBhY2N1cmFjeTogOCxcbiAgICAgICAgc3BlZWQ6IDEuMSxcbiAgICAgICAgYWRkcmVzczogYWRkcmVzc0Rlc2MgfHwgYWRkcmVzcyxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgb25SZWZyZXNoKCk7XG4gIH07XG5cbiAgLy8gVG9nZ2xlIENhdGVnb3J5IEZpbHRlclxuICBjb25zdCBoYW5kbGVUb2dnbGVDYXRlZ29yeSA9IGFzeW5jIChjYXRlZ29yeUlkOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoIWFjdGl2ZUNoaWxkKSByZXR1cm47XG4gICAgY29uc3QgY3VycmVudCA9IGFjdGl2ZUNoaWxkLndlYkZpbHRlci5ibG9ja2VkQ2F0ZWdvcmllcztcbiAgICBjb25zdCB1cGRhdGVkID0gY3VycmVudC5pbmNsdWRlcyhjYXRlZ29yeUlkKVxuICAgICAgPyBjdXJyZW50LmZpbHRlcigoYykgPT4gYyAhPT0gY2F0ZWdvcnlJZClcbiAgICAgIDogWy4uLmN1cnJlbnQsIGNhdGVnb3J5SWRdO1xuXG4gICAgYXdhaXQgdXBkYXRlV2ViRmlsdGVyKGFjdGl2ZUNoaWxkLmlkLCB7IGJsb2NrZWRDYXRlZ29yaWVzOiB1cGRhdGVkIH0pO1xuICAgIG9uUmVmcmVzaCgpO1xuICB9O1xuXG4gIC8vIEFkZCBCbG9ja2VkIERvbWFpblxuICBjb25zdCBoYW5kbGVBZGRCbG9ja2VkRG9tYWluID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghYWN0aXZlQ2hpbGQgfHwgIW5ld0Jsb2NrZWREb21haW4udHJpbSgpKSByZXR1cm47XG4gICAgY29uc3QgY2xlYW4gPSBuZXdCbG9ja2VkRG9tYWluLnRyaW0oKS50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL15odHRwcz86XFwvXFwvLywgJycpLnJlcGxhY2UoL153d3dcXC4vLCAnJyk7XG4gICAgY29uc3QgdXBkYXRlZCA9IFsuLi5hY3RpdmVDaGlsZC53ZWJGaWx0ZXIuYmxvY2tlZERvbWFpbnMsIGNsZWFuXTtcbiAgICBhd2FpdCB1cGRhdGVXZWJGaWx0ZXIoYWN0aXZlQ2hpbGQuaWQsIHsgYmxvY2tlZERvbWFpbnM6IHVwZGF0ZWQgfSk7XG4gICAgc2V0TmV3QmxvY2tlZERvbWFpbignJyk7XG4gICAgb25SZWZyZXNoKCk7XG4gIH07XG5cbiAgLy8gUmVtb3ZlIEJsb2NrZWQgRG9tYWluXG4gIGNvbnN0IGhhbmRsZVJlbW92ZUJsb2NrZWREb21haW4gPSBhc3luYyAoZG9tYWluOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoIWFjdGl2ZUNoaWxkKSByZXR1cm47XG4gICAgY29uc3QgdXBkYXRlZCA9IGFjdGl2ZUNoaWxkLndlYkZpbHRlci5ibG9ja2VkRG9tYWlucy5maWx0ZXIoKGQpID0+IGQgIT09IGRvbWFpbik7XG4gICAgYXdhaXQgdXBkYXRlV2ViRmlsdGVyKGFjdGl2ZUNoaWxkLmlkLCB7IGJsb2NrZWREb21haW5zOiB1cGRhdGVkIH0pO1xuICAgIG9uUmVmcmVzaCgpO1xuICB9O1xuXG4gIC8vIEFkZCBBbGxvd2VkIERvbWFpblxuICBjb25zdCBoYW5kbGVBZGRBbGxvd2VkRG9tYWluID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghYWN0aXZlQ2hpbGQgfHwgIW5ld0FsbG93ZWREb21haW4udHJpbSgpKSByZXR1cm47XG4gICAgY29uc3QgY2xlYW4gPSBuZXdBbGxvd2VkRG9tYWluLnRyaW0oKS50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL15odHRwcz86XFwvXFwvLywgJycpLnJlcGxhY2UoL153d3dcXC4vLCAnJyk7XG4gICAgY29uc3QgdXBkYXRlZCA9IFsuLi5hY3RpdmVDaGlsZC53ZWJGaWx0ZXIuYWxsb3dlZERvbWFpbnMsIGNsZWFuXTtcbiAgICBhd2FpdCB1cGRhdGVXZWJGaWx0ZXIoYWN0aXZlQ2hpbGQuaWQsIHsgYWxsb3dlZERvbWFpbnM6IHVwZGF0ZWQgfSk7XG4gICAgc2V0TmV3QWxsb3dlZERvbWFpbignJyk7XG4gICAgb25SZWZyZXNoKCk7XG4gIH07XG5cbiAgLy8gUmVtb3ZlIEFsbG93ZWQgRG9tYWluXG4gIGNvbnN0IGhhbmRsZVJlbW92ZUFsbG93ZWREb21haW4gPSBhc3luYyAoZG9tYWluOiBzdHJpbmcpID0+IHtcbiAgICBpZiAoIWFjdGl2ZUNoaWxkKSByZXR1cm47XG4gICAgY29uc3QgdXBkYXRlZCA9IGFjdGl2ZUNoaWxkLndlYkZpbHRlci5hbGxvd2VkRG9tYWlucy5maWx0ZXIoKGQpID0+IGQgIT09IGRvbWFpbik7XG4gICAgYXdhaXQgdXBkYXRlV2ViRmlsdGVyKGFjdGl2ZUNoaWxkLmlkLCB7IGFsbG93ZWREb21haW5zOiB1cGRhdGVkIH0pO1xuICAgIG9uUmVmcmVzaCgpO1xuICB9O1xuXG4gIC8vIFNlbmQgbWVzc2FnZSBmcm9tIHBhcmVudFxuICBjb25zdCBoYW5kbGVTZW5kTWVzc2FnZSA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFhY3RpdmVDaGlsZCB8fCAhbWVzc2FnZUlucHV0LnRyaW0oKSkgcmV0dXJuO1xuICAgIGF3YWl0IHNlbmRNZXNzYWdlKGFjdGl2ZUNoaWxkLmlkLCAncGFyZW50JywgbWVzc2FnZUlucHV0LnRyaW0oKSk7XG4gICAgc2V0TWVzc2FnZUlucHV0KCcnKTtcbiAgICBvblJlZnJlc2goKTtcbiAgfTtcblxuICAvLyBDaGlsZCBtZXNzYWdlc1xuICBjb25zdCBjaGlsZE1lc3NhZ2VzID0gc3RhdGUubWVzc2FnZXMuZmlsdGVyKChtKSA9PiBtLmNoaWxkSWQgPT09IGFjdGl2ZUNoaWxkPy5pZCk7XG5cbiAgaWYgKCFhY3RpdmVDaGlsZCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOCB0ZXh0LWNlbnRlciBzcGFjZS15LTRcIj5cbiAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkXCI+Tm8gUGFpcmVkIENoaWxkIERldmljZXM8L2gyPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1BhaXJNb2RhbCh0cnVlKX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsXCJcbiAgICAgICAgPlxuICAgICAgICAgIFBhaXIgRmlyc3QgQ2hpbGQgRGV2aWNlXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS05NTAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCBmbGV4IGZsZXgtY29sXCI+XG4gICAgICB7LyogSGlnaC1Qcmlvcml0eSBTT1MgQWxlcnQgQmFubmVyICovfVxuICAgICAge2FjdGl2ZVNPUyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcm9zZS02MDAgdGV4dC13aGl0ZSBweC00IHB5LTMgc2hhZG93LWxnIGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBhbmltYXRlLXB1bHNlXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctd2hpdGUvMjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgPEFsZXJ0VHJpYW5nbGUgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXllbGxvdy0zMDBcIiAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ibGFjayB0ZXh0LXNtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+XG4gICAgICAgICAgICAgICAge2FjdGl2ZVNPUy50aXRsZX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcm9zZS0xMDBcIj57YWN0aXZlU09TLm1lc3NhZ2V9PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBtYXJrQWxlcnRzQXNSZWFkKGFjdGl2ZVNPUy5pZCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IGJnLXdoaXRlIHRleHQtcm9zZS03MDAgaG92ZXI6Ymctcm9zZS01MCByb3VuZGVkLWxnIHRleHQteHMgZm9udC1ib2xkIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgQWNrbm93bGVkZ2UgQWxlcnRcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBNYWluIFBhcmVudCBIZWFkZXIgKi99XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHN0aWNreSB0b3AtMCB6LTMwIHNoYWRvdy14c1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIHB4LTQgcHktMyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICB7LyogTG9nbyAmIEZyZWUgQmFkZ2UgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tdHIgZnJvbS1ibHVlLTYwMCB0by1pbmRpZ28tNjAwIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LW1kIHNoYWRvdy1ibHVlLTUwMC8yMFwiPlxuICAgICAgICAgICAgICA8U2hpZWxkIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwiZm9udC1ibGFjayB0ZXh0LWxnIHRyYWNraW5nLXRpZ2h0IHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgU2FmZUtpZHNcbiAgICAgICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLWVtZXJhbGQtMTAwIGRhcms6YmctZW1lcmFsZC05NTAvNzAgdGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgdGV4dC1bMTBweF0gcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtYm9sZCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMzAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwXCI+XG4gICAgICAgICAgICAgICAgICAxMDAlIEZSRUVcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhpZGRlbiBzbTpibG9ja1wiPlxuICAgICAgICAgICAgICAgIE9wZW4tU291cmNlIFBhcmVudGFsIENvbnRyb2wgJiBDaGlsZCBTYWZldHlcbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ2hpbGQgRGV2aWNlIFNlbGVjdG9yIFBpbGxzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBvdmVyZmxvdy14LWF1dG8gcHktMVwiPlxuICAgICAgICAgICAge3N0YXRlLmNoaWxkcmVuLm1hcCgoYykgPT4gKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAga2V5PXtjLmlkfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkQ2hpbGRJZChjLmlkKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0cmFuc2l0aW9uLWFsbCBzaHJpbmstMCAke1xuICAgICAgICAgICAgICAgICAgYy5pZCA9PT0gYWN0aXZlQ2hpbGQuaWRcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3ctc20nXG4gICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxzcGFuPntjLmF2YXRhcn08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4+e2MubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gb3BhY2l0eS04MFwiPih7Yy5iYXR0ZXJ5TGV2ZWx9JSk8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKSl9XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1BhaXJNb2RhbCh0cnVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEuNSBiZy1zbGF0ZS0xMDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6Ymctc2xhdGUtODAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtbWVkaXVtIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHNocmluay0wIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gUGFpciBEZXZpY2VcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFRvcCBBY3Rpb25zOiBEYXJrIE1vZGUsIFN3aXRjaCB0byBDaGlsZCBNb2RlLCBTZXR0aW5ncyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17b25Ub2dnbGVEYXJrTW9kZX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCByb3VuZGVkLXhsIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgIHRpdGxlPVwiVG9nZ2xlIFRoZW1lXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2RhcmtNb2RlID8gPFN1biBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNDAwXCIgLz4gOiA8TW9vbiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz59XG4gICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93RG93bmxvYWRNb2RhbCh0cnVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC03MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRyYW5zaXRpb24tY29sb3JzIHNoYWRvdy14c1wiXG4gICAgICAgICAgICAgIHRpdGxlPVwiRG93bmxvYWQgRW50aXJlIFByb2plY3QgU291cmNlIENvZGVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBEb3dubG9hZCBaSVBcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uU3dpdGNoVG9DaGlsZE1vZGUoYWN0aXZlQ2hpbGQuaWQpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSBiZy1pbmRpZ28tNTAgaG92ZXI6YmctaW5kaWdvLTEwMCBkYXJrOmJnLWluZGlnby05NTAvNjAgZGFyazpob3ZlcjpiZy1pbmRpZ28tOTAwLzYwIHRleHQtaW5kaWdvLTcwMCBkYXJrOnRleHQtaW5kaWdvLTMwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBib3JkZXIgYm9yZGVyLWluZGlnby0yMDAgZGFyazpib3JkZXItaW5kaWdvLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNtYXJ0cGhvbmUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBWaWV3IENoaWxkIFBob25lXG4gICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNoYW5nZVBpblJlcXVlc3RlZH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCByb3VuZGVkLXhsIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgIHRpdGxlPVwiUGFyZW50IFBJTiBTZXR0aW5nc1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxMb2NrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ibHVlLTUwMFwiIC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWJvdXRNb2RhbCh0cnVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCByb3VuZGVkLXhsIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgIHRpdGxlPVwiQWJvdXQgU2FmZUtpZHMgJiBEZXZlbG9wZXIgKFJhamFuIFZpc2h3YWthcm1hKVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxJbmZvIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1pbmRpZ28tNTAwXCIgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogU2VsZWN0ZWQgQ2hpbGQgU3ViLUJhciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MC84MCBkYXJrOmJnLXNsYXRlLTkwMC81MCBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwLzYwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMC82MCBweC00IHB5LTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgdGV4dC14c1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAgICAgIHthY3RpdmVDaGlsZC5uYW1lfSZhcG9zO3MgRGV2aWNlOlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZm9udC1tb25vIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAge2FjdGl2ZUNoaWxkLmRldmljZU1vZGVsfSAoe2FjdGl2ZUNoaWxkLm9zVmVyc2lvbn0pXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICB7YWN0aXZlQ2hpbGQuaXNDaGFyZ2luZyA/IChcbiAgICAgICAgICAgICAgICAgIDxCYXR0ZXJ5Q2hhcmdpbmcgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxCYXR0ZXJ5IGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2xhdGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIHthY3RpdmVDaGlsZC5iYXR0ZXJ5TGV2ZWx9JVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAge2FjdGl2ZUNoaWxkLmlzT25saW5lID8gKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC01MDAgYW5pbWF0ZS1wdWxzZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgT25saW5lXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLXNsYXRlLTQwMFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgT2ZmbGluZVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGUgbWF4LXcteHNcIj5cbiAgICAgICAgICAgICAgICDwn5ONIHthY3RpdmVDaGlsZC5sb2NhdGlvbi5hZGRyZXNzfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtvblJlZnJlc2h9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaG92ZXI6dGV4dC1ibHVlLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBmb250LW1lZGl1bVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8UmVmcmVzaEN3IGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPiBTeW5jXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBOYXZpZ2F0aW9uIFRhYnMgQmFyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIHB4LTQgb3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtMSBzbTpzcGFjZS14LTIgcHktMlwiPlxuICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgeyBpZDogJ2xvY2F0aW9uJywgbGFiZWw6ICdMaXZlIExvY2F0aW9uICYgU2FmZSBab25lcycsIGljb246IE1hcFBpbiB9LFxuICAgICAgICAgICAgICB7IGlkOiAnc2NyZWVudGltZScsIGxhYmVsOiAnU2NyZWVuIFRpbWUgJiBMaW1pdHMnLCBpY29uOiBDbG9jayB9LFxuICAgICAgICAgICAgICB7IGlkOiAnYXBwcycsIGxhYmVsOiAnQXBwIENvbnRyb2xzJywgaWNvbjogU21hcnRwaG9uZSB9LFxuICAgICAgICAgICAgICB7IGlkOiAnd2ViZmlsdGVyJywgbGFiZWw6ICdXZWIgRmlsdGVyICYgU2FmZVNlYXJjaCcsIGljb246IEdsb2JlIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdjYW1lcmEnLCBsYWJlbDogJ1JlbW90ZSBMb29rLUluJywgaWNvbjogQ2FtZXJhIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdtZXNzYWdlcycsIGxhYmVsOiAnSW50ZXJjb20nLCBpY29uOiBNZXNzYWdlU3F1YXJlIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdhbnRpdW5pbnN0YWxsJywgbGFiZWw6ICdBbnRpLVVuaW5zdGFsbCAmIEFkbWluIExvY2snLCBpY29uOiBTaGllbGRDaGVjayB9LFxuICAgICAgICAgICAgICB7IGlkOiAnYWxlcnRzJywgbGFiZWw6ICdBbGVydHMgQ2VudGVyJywgaWNvbjogQWxlcnRUcmlhbmdsZSwgYmFkZ2U6IHN0YXRlLmFsZXJ0cy5maWx0ZXIoKGEpID0+ICFhLnJlYWQpLmxlbmd0aCB9LFxuICAgICAgICAgICAgICB7IGlkOiAnYW5kcm9pZGtpdCcsIGxhYmVsOiAnQW5kcm9pZCBQbGF5IFN0b3JlIEtpdCcsIGljb246IENvZGUyIH0sXG4gICAgICAgICAgICBdLm1hcCgodGFiKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IEljb24gPSB0YWIuaWNvbjtcbiAgICAgICAgICAgICAgY29uc3QgaXNBY3RpdmUgPSBhY3RpdmVUYWIgPT09IHRhYi5pZDtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e3RhYi5pZH1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYih0YWIuaWQgYXMgYW55KX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMuNSBweS0yIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgd2hpdGVzcGFjZS1ub3dyYXAgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgaXNBY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy14cydcbiAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPnt0YWIubGFiZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAge3RhYi5iYWRnZSA/IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMSBweC0xLjUgcHktMC4yIGJnLXJvc2UtNTAwIHRleHQtd2hpdGUgcm91bmRlZC1mdWxsIHRleHQtWzEwcHhdIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHt0YWIuYmFkZ2V9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC9uYXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9oZWFkZXI+XG5cbiAgICAgIHsvKiBNYWluIFRhYiBDb250ZW50ICovfVxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gdy1mdWxsIHAtNCBzbTpwLTYgc3BhY2UteS02IGZsZXgtMVwiPlxuICAgICAgICB7LyogVEFCIDE6IExPQ0FUSU9OICYgU0FGRSBaT05FUyAqL31cbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2xvY2F0aW9uJyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgIHsvKiBUb3AgVG9vbGJhciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHAtNCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmFzZSB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8TWFwUGluIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ibHVlLTYwMFwiIC8+XG4gICAgICAgICAgICAgICAgICBMaXZlIEdQUyBUcmFja2luZyAmIEdlb2ZlbmNlc1xuICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgUmVhbCBHUFMgY29vcmRpbmF0ZXMgd2l0aCBPcGVuU3RyZWV0TWFwIGhpZ2gtYWNjdXJhY3kgdGVsZW1ldHJ5XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1NhZmVab25lc01vZGFsKHRydWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC03MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRyYW5zaXRpb24tY29sb3JzIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFNoaWVsZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IE1hbmFnZSBTYWZlIFpvbmVzICh7YWN0aXZlQ2hpbGQuc2FmZVpvbmVzLmxlbmd0aH0pXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBJbnRlcmFjdGl2ZSBMZWFmbGV0IE1hcCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgPFNhZmVLaWRzTWFwXG4gICAgICAgICAgICAgICAgbG9jYXRpb249e2FjdGl2ZUNoaWxkLmxvY2F0aW9ufVxuICAgICAgICAgICAgICAgIHNhZmVab25lcz17YWN0aXZlQ2hpbGQuc2FmZVpvbmVzfVxuICAgICAgICAgICAgICAgIGxvY2F0aW9uSGlzdG9yeT17YWN0aXZlQ2hpbGQubG9jYXRpb25IaXN0b3J5fVxuICAgICAgICAgICAgICAgIGNoaWxkTmFtZT17YWN0aXZlQ2hpbGQubmFtZX1cbiAgICAgICAgICAgICAgICBpc09ubGluZT17YWN0aXZlQ2hpbGQuaXNPbmxpbmV9XG4gICAgICAgICAgICAgICAgYmF0dGVyeUxldmVsPXthY3RpdmVDaGlsZC5iYXR0ZXJ5TGV2ZWx9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC1bNDQwcHhdIHctZnVsbCByb3VuZGVkLTJ4bCBvdmVyZmxvdy1oaWRkZW4gc2hhZG93LXNtIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiXG4gICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgey8qIEZsb2F0aW5nIE1hcCBMZWdlbmQgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTQgbGVmdC00IHotWzEwMDBdIGJnLXdoaXRlLzk1IGRhcms6Ymctc2xhdGUtOTAwLzk1IGJhY2tkcm9wLWJsdXItbWQgcC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHRleHQtWzExcHhdIHNwYWNlLXktMS41IHNoYWRvdy1tZFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMyBoLTMgcm91bmRlZC1mdWxsIGJnLWJsdWUtNjAwIGJvcmRlciBib3JkZXItd2hpdGVcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAge2FjdGl2ZUNoaWxkLm5hbWV9JmFwb3M7cyBMaXZlIFBpblxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMyBoLTMgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNTAwLzQwIGJvcmRlciBib3JkZXItZW1lcmFsZC02MDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIFNhZmUgWm9uZXMgKHthY3RpdmVDaGlsZC5zYWZlWm9uZXMuZmlsdGVyKCh6KSA9PiB6LmVuYWJsZWQpLmxlbmd0aH0gQWN0aXZlKVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMyBoLTEgYmctaW5kaWdvLTUwMCByb3VuZGVkXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICBUcmF2ZWwgUGF0aCBIaXN0b3J5XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBTaW11bGF0aW9uIFF1aWNrIEJhciAoQWxsb3dzIHRlc3Rpbmcgc2FmZS16b25lIHRyaWdnZXJzIHdpdGhvdXQgd2Fsa2luZykgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNTAvNzAgZGFyazpiZy1zbGF0ZS05MDAgcC00IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItYmx1ZS0yMDAvODAgZGFyazpib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtYmx1ZS05MDAgZGFyazp0ZXh0LWJsdWUtMzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxTbGlkZXJzIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gVGVzdCBMb2NhdGlvbiBTaW11bGF0aW9uIChQYXJlbnQgRGVtbyBNb2RlKVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgU2ltdWxhdGUgY2hpbGQgbW92aW5nIGJldHdlZW4gY29vcmRpbmF0ZXNcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yIHB0LTFcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTaW11bGF0ZUdQUygzNy43NzQ5LCAtMTIyLjQxOTQsICdIb21lIChTYWZlIFpvbmUpJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSBiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCByb3VuZGVkLWxnIHRleHQteHMgZm9udC1tZWRpdW0gYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHNoYWRvdy0yeHNcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIPCfj6EgVGVsZXBvcnQgdG8gSG9tZVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNpbXVsYXRlR1BTKDM3Ljc3ODAsIC0xMjIuNDE1MCwgJ0xpbmNvbG4gTWlkZGxlIFNjaG9vbCAoU2FmZSBab25lKScpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtMTAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtbWVkaXVtIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBzaGFkb3ctMnhzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICDwn4+rIE1vdmUgdG8gU2Nob29sXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2ltdWxhdGVHUFMoMzcuNzg1MCwgLTEyMi40MDIwLCAnWWVyYmEgQnVlbmEgUGFyayAoU2FmZSBab25lKScpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtMTAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtbWVkaXVtIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBzaGFkb3ctMnhzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICDwn4yzIE1vdmUgdG8gUGFya1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNpbXVsYXRlR1BTKDM3Ljc5MDAsIC0xMjIuMzkwMCwgJ0VtYmFyY2FkZXJvIFBpZXIgMTQgKE91dHNpZGUgU2FmZSBab25lKScpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgYmctYW1iZXItNTAgZGFyazpiZy1hbWJlci05NTAvNDAgaG92ZXI6YmctYW1iZXItMTAwIHRleHQtYW1iZXItODAwIGRhcms6dGV4dC1hbWJlci0zMDAgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtbWVkaXVtIGJvcmRlciBib3JkZXItYW1iZXItMzAwIGRhcms6Ym9yZGVyLWFtYmVyLTgwMFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAg4pqg77iPIFdhbGsgT3V0c2lkZSBTYWZlIFpvbmVzXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBMb2NhdGlvbiBIaXN0b3J5IExvZyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHAtNSBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNtIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICBSZWNlbnQgTG9jYXRpb24gQnJlYWRjcnVtYnNcbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICB7YWN0aXZlQ2hpbGQubG9jYXRpb25IaXN0b3J5LnNsaWNlKDAsIDUpLm1hcCgocG9pbnQsIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTMgcm91bmRlZC14bCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC80MCB0ZXh0LXhzIGJvcmRlciBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLWJsdWUtNTAwXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgYmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3BvaW50LmFkZHJlc3N9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7cG9pbnQubGF0aXR1ZGUudG9GaXhlZCg0KX3CsCwge3BvaW50LmxvbmdpdHVkZS50b0ZpeGVkKDQpfcKwXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUocG9pbnQudGltZXN0YW1wKS50b0xvY2FsZVRpbWVTdHJpbmcoW10sIHsgaG91cjogJzItZGlnaXQnLCBtaW51dGU6ICcyLWRpZ2l0JyB9KX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFRBQiAyOiBTQ1JFRU4gVElNRSAmIFNDSEVEVUxFUyAqL31cbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ3NjcmVlbnRpbWUnICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC01XCI+XG4gICAgICAgICAgICAgIHsvKiBEYWlseSBBbGxvd2FuY2UgQ2FyZCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIERhaWx5IFNjcmVlbiBBbGxvd2FuY2VcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYmx1ZS02MDBcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgIHtNYXRoLmZsb29yKGFjdGl2ZUNoaWxkLnNjcmVlblRpbWUuZGFpbHlMaW1pdE1pbnV0ZXMgLyA2MCl9aCB7YWN0aXZlQ2hpbGQuc2NyZWVuVGltZS5kYWlseUxpbWl0TWludXRlcyAlIDYwfW1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICBUb2RheSZhcG9zO3MgdXNhZ2U6IHthY3RpdmVDaGlsZC5zY3JlZW5UaW1lLnRvZGF5VXNhZ2VNaW51dGVzfSBtaW5zIChcbiAgICAgICAgICAgICAgICAgICAge01hdGgubWF4KDAsIGFjdGl2ZUNoaWxkLnNjcmVlblRpbWUuZGFpbHlMaW1pdE1pbnV0ZXMgLSBhY3RpdmVDaGlsZC5zY3JlZW5UaW1lLnRvZGF5VXNhZ2VNaW51dGVzKX0gbWlucyBsZWZ0KVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEFkanVzdCBTdGVwcGVyICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHQtMlwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxuICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZVNjcmVlbkxpbWl0cyhhY3RpdmVDaGlsZC5pZCwge1xuICAgICAgICAgICAgICAgICAgICAgICAgZGFpbHlMaW1pdE1pbnV0ZXM6IE1hdGgubWF4KDMwLCBhY3RpdmVDaGlsZC5zY3JlZW5UaW1lLmRhaWx5TGltaXRNaW51dGVzIC0gMTUpLFxuICAgICAgICAgICAgICAgICAgICAgIH0pLnRoZW4ob25SZWZyZXNoKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0xLjUgYmctc2xhdGUtMTAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAtMTUgbWluc1xuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgICAgICAgdXBkYXRlU2NyZWVuTGltaXRzKGFjdGl2ZUNoaWxkLmlkLCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBkYWlseUxpbWl0TWludXRlczogYWN0aXZlQ2hpbGQuc2NyZWVuVGltZS5kYWlseUxpbWl0TWludXRlcyArIDMwLFxuICAgICAgICAgICAgICAgICAgICAgIH0pLnRoZW4ob25SZWZyZXNoKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0xLjUgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHRleHQteHMgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgKzMwIG1pbnNcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQmVkdGltZSBMb2NrIFNjaGVkdWxlICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHAtNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNtIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgQmVkdGltZSBEb3dudGltZVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPE1vb24gY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWluZGlnby01MDBcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPkxvY2sgZGV2aWNlIGF0IG5pZ2h0Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXthY3RpdmVDaGlsZC5zY3JlZW5UaW1lLmJlZHRpbWVFbmZvcmNlZH1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVTY3JlZW5MaW1pdHMoYWN0aXZlQ2hpbGQuaWQsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgYmVkdGltZUVuZm9yY2VkOiBlLnRhcmdldC5jaGVja2VkLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSkudGhlbihvblJlZnJlc2gpXG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1pbmRpZ28tNjAwIHJvdW5kZWRcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBibG9jayBtYi0xXCI+QmVkdGltZSBTdGFydHM8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRpbWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2FjdGl2ZUNoaWxkLnNjcmVlblRpbWUuYmVkdGltZVN0YXJ0fVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVTY3JlZW5MaW1pdHMoYWN0aXZlQ2hpbGQuaWQsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiZWR0aW1lU3RhcnQ6IGUudGFyZ2V0LnZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KS50aGVuKG9uUmVmcmVzaClcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0yLjUgcHktMS41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIHRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBibG9jayBtYi0xXCI+QmVkdGltZSBFbmRzPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0aW1lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXthY3RpdmVDaGlsZC5zY3JlZW5UaW1lLmJlZHRpbWVFbmR9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZVNjcmVlbkxpbWl0cyhhY3RpdmVDaGlsZC5pZCwge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJlZHRpbWVFbmQ6IGUudGFyZ2V0LnZhbHVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KS50aGVuKG9uUmVmcmVzaClcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0yLjUgcHktMS41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIHRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBQZW5kaW5nIFRpbWUgUmVxdWVzdCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNtIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgYmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgIFRpbWUgRXh0ZW5zaW9uIFJlcXVlc3RzXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICAgICAge2FjdGl2ZUNoaWxkLnRpbWVFeHRlbnNpb25SZXF1ZXN0ICYmIGFjdGl2ZUNoaWxkLnRpbWVFeHRlbnNpb25SZXF1ZXN0LnN0YXR1cyA9PT0gJ3BlbmRpbmcnID8gKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC80MCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCBkYXJrOmJvcmRlci1hbWJlci05MDAgcm91bmRlZC14bCBwLTMgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtYW1iZXItODAwIGRhcms6dGV4dC1hbWJlci0yMDAgYmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICAre2FjdGl2ZUNoaWxkLnRpbWVFeHRlbnNpb25SZXF1ZXN0Lm1pbnV0ZXN9IE1pbnV0ZXMgUmVxdWVzdGVkXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1hbWJlci03MDAgZGFyazp0ZXh0LWFtYmVyLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIFJlYXNvbjogJnF1b3Q7e2FjdGl2ZUNoaWxkLnRpbWVFeHRlbnNpb25SZXF1ZXN0LnJlYXNvbn0mcXVvdDtcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgcHQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbmRUaW1lRXh0ZW5zaW9uKGFjdGl2ZUNoaWxkLmlkLCAnYXBwcm92ZWQnLCBhY3RpdmVDaGlsZC50aW1lRXh0ZW5zaW9uUmVxdWVzdD8ubWludXRlcykudGhlbihvblJlZnJlc2gpXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMSBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQgdGV4dC1bMTFweF0gZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBBcHByb3ZlXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVzcG9uZFRpbWVFeHRlbnNpb24oYWN0aXZlQ2hpbGQuaWQsICdkZW5pZWQnKS50aGVuKG9uUmVmcmVzaCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMSBiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCByb3VuZGVkIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIERlbnlcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBweS00IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIE5vIGFjdGl2ZSB0aW1lIGV4dGVuc2lvbiByZXF1ZXN0cyBmcm9tIHthY3RpdmVDaGlsZC5uYW1lfS5cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQXBwIFVzYWdlIERpc3RyaWJ1dGlvbiAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNtIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICBUb2RheSZhcG9zO3MgQ2F0ZWdvcnkgQnJlYWtkb3duXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgIHsgY2F0ZWdvcnk6ICdWaWRlbyAmIFN0cmVhbWluZycsIG1pbnV0ZXM6IDMwLCBjb2xvcjogJ2JnLXJlZC01MDAnIH0sXG4gICAgICAgICAgICAgICAgICB7IGNhdGVnb3J5OiAnRWR1Y2F0aW9uICYgU3R1ZHknLCBtaW51dGVzOiAzNSwgY29sb3I6ICdiZy1lbWVyYWxkLTUwMCcgfSxcbiAgICAgICAgICAgICAgICAgIHsgY2F0ZWdvcnk6ICdHYW1lcyAmIFBsYXknLCBtaW51dGVzOiAyMCwgY29sb3I6ICdiZy1pbmRpZ28tNTAwJyB9LFxuICAgICAgICAgICAgICAgICAgeyBjYXRlZ29yeTogJ0Jyb3dzaW5nICYgUmVhZGluZycsIG1pbnV0ZXM6IDAsIGNvbG9yOiAnYmctYmx1ZS01MDAnIH0sXG4gICAgICAgICAgICAgICAgXS5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpdGVtLmNhdGVnb3J5fSBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2l0ZW0uY2F0ZWdvcnl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntpdGVtLm1pbnV0ZXN9IG1pbnM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgcm91bmRlZC1mdWxsIGgtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7aXRlbS5jb2xvcn0gaC0yIHJvdW5kZWQtZnVsbGB9XG4gICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7KGl0ZW0ubWludXRlcyAvIE1hdGgubWF4KDEsIGFjdGl2ZUNoaWxkLnNjcmVlblRpbWUuZGFpbHlMaW1pdE1pbnV0ZXMpKSAqIDEwMH0lYCB9fVxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFRBQiAzOiBBUFAgQ09OVFJPTFMgJiBCTE9DS0lORyAqL31cbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2FwcHMnICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcC00IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1iYXNlIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgIEFuZHJvaWQgQXBwIENvbnRyb2xzICYgTG9jayBSdWxlc1xuICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICBFbmZvcmNlIGRhaWx5IHF1b3RhcyBvciBjb21wbGV0ZWx5IGxvY2sgZGlzdHJhY3Rpb24gYXBwcyB2aWEgQW5kcm9pZCBBY2Nlc3NpYmlsaXR5IFNlcnZpY2UuXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBhY3RpdmVDaGlsZC5zY3JlZW5UaW1lLmFwcFJ1bGVzLmZvckVhY2goKHJ1bGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBpZiAocnVsZS5jYXRlZ29yeSA9PT0gJ2dhbWVzJyB8fCBydWxlLmNhdGVnb3J5ID09PSAnc29jaWFsJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlQXBwUnVsZShhY3RpdmVDaGlsZC5pZCwgcnVsZS5wYWNrYWdlTmFtZSwgJ2xvY2tlZCcpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQob25SZWZyZXNoLCAzMDApO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IGJnLXJvc2UtNjAwIGhvdmVyOmJnLXJvc2UtNzAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIPCfmqsgSW5zdGFudCBMb2NrIEdhbWVzICYgU29jaWFsXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBBcHBzIEdyaWQgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cbiAgICAgICAgICAgICAge2FjdGl2ZUNoaWxkLnNjcmVlblRpbWUuYXBwUnVsZXMubWFwKChhcHApID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICBrZXk9e2FwcC5wYWNrYWdlTmFtZX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtNCByb3VuZGVkLTJ4bCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgYXBwLnN0YXR1cyA9PT0gJ2xvY2tlZCdcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1yb3NlLTUwLzUwIGRhcms6Ymctcm9zZS05NTAvMjAgYm9yZGVyLXJvc2UtMjAwIGRhcms6Ym9yZGVyLXJvc2UtOTAwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbSB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7YXBwLmFwcE5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIGZvbnQtbW9ubyBibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2FwcC5wYWNrYWdlTmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIG10LTEgdGV4dC1bMTBweF0gdXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgcHgtMiBweS0wLjUgcm91bmRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2FwcC5jYXRlZ29yeX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1bMTBweF0gZm9udC1ib2xkIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFwcC5zdGF0dXMgPT09ICdsb2NrZWQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXJvc2UtNjAwIHRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogYXBwLnN0YXR1cyA9PT0gJ2xpbWl0ZWQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWFtYmVyLTUwMCB0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge2FwcC5zdGF0dXN9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtMyBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMC84MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgIFVzZWQgdG9kYXk6IHthcHAudXNlZFRvZGF5TWludXRlc31tXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cblxuICAgICAgICAgICAgICAgICAgICB7LyogQWN0aW9uIGJ1dHRvbnMgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUFwcFJ1bGUoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZlQ2hpbGQuaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXBwLnBhY2thZ2VOYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFwcC5zdGF0dXMgPT09ICdsb2NrZWQnID8gJ2FsbG93ZWQnIDogJ2xvY2tlZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKS50aGVuKG9uUmVmcmVzaClcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xIHJvdW5kZWQtbGcgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFwcC5zdGF0dXMgPT09ICdsb2NrZWQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1lbWVyYWxkLTcwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1yb3NlLTEwMCB0ZXh0LXJvc2UtNzAwIGRhcms6Ymctcm9zZS05MDAvNDAgZGFyazp0ZXh0LXJvc2UtMzAwIGhvdmVyOmJnLXJvc2UtMjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge2FwcC5zdGF0dXMgPT09ICdsb2NrZWQnID8gJ1VubG9jayBBcHAnIDogJ0xvY2sgQXBwJ31cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogVEFCIDQ6IFdFQiBGSUxURVIgJiBTQUZFU0VBUkNIICovfVxuICAgICAgICB7YWN0aXZlVGFiID09PSAnd2ViZmlsdGVyJyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcGItM1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmFzZSB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIENvbnRlbnQgQ2F0ZWdvcnkgQmxvY2tlcnNcbiAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIFdlYnNpdGVzIG1hdGNoaW5nIGNoZWNrZWQgY2F0ZWdvcmllcyBhcmUgYmxvY2tlZCBpbiByZWFsLXRpbWUuXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgU2FmZVNlYXJjaDpcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXthY3RpdmVDaGlsZC53ZWJGaWx0ZXIuc2FmZVNlYXJjaEVuYWJsZWR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVXZWJGaWx0ZXIoYWN0aXZlQ2hpbGQuaWQsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNhZmVTZWFyY2hFbmFibGVkOiBlLnRhcmdldC5jaGVja2VkLFxuICAgICAgICAgICAgICAgICAgICAgIH0pLnRoZW4ob25SZWZyZXNoKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ibHVlLTYwMCByb3VuZGVkXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBDYXRlZ29yaWVzIEdyaWQgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIHtGSUxURVJfQ0FURUdPUklFUy5tYXAoKGNhdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgaXNCbG9ja2VkID0gYWN0aXZlQ2hpbGQud2ViRmlsdGVyLmJsb2NrZWRDYXRlZ29yaWVzLmluY2x1ZGVzKGNhdC5pZCk7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtjYXQuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVG9nZ2xlQ2F0ZWdvcnkoY2F0LmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTMuNSByb3VuZGVkLXhsIGJvcmRlciBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgaXNCbG9ja2VkXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXJvc2UtNTAvNzAgZGFyazpiZy1yb3NlLTk1MC8zMCBib3JkZXItcm9zZS0zMDAgZGFyazpib3JkZXItcm9zZS05MDAgdGV4dC1yb3NlLTk1MCBkYXJrOnRleHQtcm9zZS0yMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzQwIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC14c1wiPntjYXQubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17aXNCbG9ja2VkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4ge319IC8vIGhhbmRsZWQgYnkgcGFyZW50IG9uQ2xpY2tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXJvc2UtNjAwIHJvdW5kZWRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjYXQuZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBDdXN0b20gV2hpdGVsaXN0ICYgQmxhY2tsaXN0ICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC01XCI+XG4gICAgICAgICAgICAgIHsvKiBCbGFja2xpc3QgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc20gdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgQ3VzdG9tIEJsb2NrZWQgRG9tYWlucyAoQmxhY2tsaXN0KVxuICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3QmxvY2tlZERvbWFpbn1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdCbG9ja2VkRG9tYWluKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIG9tZWdsZS5jb20sIHR3aXRjaC50di4uLlwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweC0zIHB5LTEuNSB0ZXh0LXhzIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFkZEJsb2NrZWREb21haW59XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IGJnLXJvc2UtNjAwIGhvdmVyOmJnLXJvc2UtNzAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBCbG9ja1xuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNSBtYXgtaC00OCBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgIHthY3RpdmVDaGlsZC53ZWJGaWx0ZXIuYmxvY2tlZERvbWFpbnMubWFwKChkKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2R9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMiByb3VuZGVkLWxnIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwLzUwIHRleHQteHMgYm9yZGVyIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXJvc2UtNjAwIGRhcms6dGV4dC1yb3NlLTQwMFwiPntkfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZW1vdmVCbG9ja2VkRG9tYWluKGQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1yb3NlLTUwMFwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBXaGl0ZWxpc3QgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcC01IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc20gdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgQWx3YXlzIEFsbG93ZWQgRG9tYWlucyAoV2hpdGVsaXN0KVxuICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3QWxsb3dlZERvbWFpbn1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdBbGxvd2VkRG9tYWluKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIHNjaG9vbHBvcnRhbC5lZHUuLi5cIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHgtMyBweS0xLjUgdGV4dC14cyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVBZGRBbGxvd2VkRG9tYWlufVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgQWxsb3dcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjUgbWF4LWgtNDggb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICB7YWN0aXZlQ2hpbGQud2ViRmlsdGVyLmFsbG93ZWREb21haW5zLm1hcCgoZCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtkfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTIgcm91bmRlZC1sZyBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC81MCB0ZXh0LXhzIGJvcmRlciBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIj57ZH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUmVtb3ZlQWxsb3dlZERvbWFpbihkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtcm9zZS01MDBcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogTGl2ZSBGaWx0ZXIgVGVzdGVyICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgdGV4dC13aGl0ZSBwLTUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWJsdWUtNDAwIGJsb2NrXCI+XG4gICAgICAgICAgICAgICAgTGl2ZSBVUkwgQ2hlY2tlciAmIFBvbGljeSBJbnNwZWN0b3JcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt0ZXN0VXJsSW5wdXR9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRlc3RVcmxJbnB1dChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIGFueSBkb21haW4gb3IgVVJMIHRvIHRlc3QuLi5cIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB4LTMgcHktMiBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1ibHVlLTUwMFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVUZXN0VXJsfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgSW5zcGVjdCBVUkxcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAge3Rlc3RSZXN1bHQgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMyByb3VuZGVkLXhsIHRleHQteHMgYm9yZGVyIGZvbnQtbW9ubyAke1xuICAgICAgICAgICAgICAgICAgICB0ZXN0UmVzdWx0LmFsbG93ZWRcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTk1MC82MCBib3JkZXItZW1lcmFsZC03MDAgdGV4dC1lbWVyYWxkLTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1yb3NlLTk1MC82MCBib3JkZXItcm9zZS03MDAgdGV4dC1yb3NlLTMwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICB7dGVzdFJlc3VsdC5hbGxvd2VkID8gJ+KckyBBTExPV0VEJyA6ICfwn5uRIEJMT0NLRUQnfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAge3Rlc3RSZXN1bHQuYmxvY2tlZFJlYXNvbiAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIG10LTFcIj57dGVzdFJlc3VsdC5ibG9ja2VkUmVhc29ufTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogVEFCIDU6IFJFTU9URSBMT09LLUlOIENBTUVSQSAmIFNDUkVFTiBTSEFSRSAqL31cbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2NhbWVyYScgJiYgKFxuICAgICAgICAgIDxDYW1lcmFTY3JlZW5TZXNzaW9uXG4gICAgICAgICAgICBjaGlsZD17YWN0aXZlQ2hpbGR9XG4gICAgICAgICAgICBpc1BhcmVudFZpZXc9e3RydWV9XG4gICAgICAgICAgICBvblJlZnJlc2g9e29uUmVmcmVzaH1cbiAgICAgICAgICAvPlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBUQUIgNjogSU5URVJDT00gJiBDSEFUICovfVxuICAgICAgICB7YWN0aXZlVGFiID09PSAnbWVzc2FnZXMnICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwLTUgc3BhY2UteS00XCI+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmFzZSB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxNZXNzYWdlU3F1YXJlIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1pbmRpZ28tNjAwXCIgLz5cbiAgICAgICAgICAgICAgRGlyZWN0IEludGVyY29tIHdpdGgge2FjdGl2ZUNoaWxkLm5hbWV9XG4gICAgICAgICAgICA8L2gzPlxuXG4gICAgICAgICAgICB7LyogQ2hhdCBUaHJlYWQgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtOTUwLzYwIHJvdW5kZWQteGwgcC00IGgtODAgb3ZlcmZsb3cteS1hdXRvIHNwYWNlLXktMyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAge2NoaWxkTWVzc2FnZXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQteHMgdGV4dC1zbGF0ZS00MDAgcHktMTBcIj5cbiAgICAgICAgICAgICAgICAgIE5vIG1lc3NhZ2VzIHlldC4gU2VuZCBhIHF1aWNrIGNoZWNrLWluIG5vdGUgdG8ge2FjdGl2ZUNoaWxkLm5hbWV9IVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICBjaGlsZE1lc3NhZ2VzLm1hcCgobXNnKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGtleT17bXNnLmlkfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGZsZXgtY29sICR7XG4gICAgICAgICAgICAgICAgICAgICAgbXNnLnNlbmRlciA9PT0gJ3BhcmVudCcgPyAnaXRlbXMtZW5kJyA6ICdpdGVtcy1zdGFydCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BtYXgtdy14cyBzbTptYXgtdy1tZCBweC0zLjUgcHktMiByb3VuZGVkLTJ4bCB0ZXh0LXhzIHNoYWRvdy0yeHMgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1zZy5zZW5kZXIgPT09ICdwYXJlbnQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUgcm91bmRlZC1ici1ub25lJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWJsLW5vbmUnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7bXNnLnRleHR9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBtdC0xIHB4LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7bXNnLnNlbmRlciA9PT0gJ3BhcmVudCcgPyAnWW91JyA6IGFjdGl2ZUNoaWxkLm5hbWV9IOKAonsnICd9XG4gICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKG1zZy50aW1lc3RhbXApLnRvTG9jYWxlVGltZVN0cmluZyhbXSwgeyBob3VyOiAnMi1kaWdpdCcsIG1pbnV0ZTogJzItZGlnaXQnIH0pfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBRdWljayByZXBsaWVzIGZvciBwYXJlbnQgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTIgb3ZlcmZsb3cteC1hdXRvIHBiLTEgdGV4dC14c1wiPlxuICAgICAgICAgICAgICB7WydEaW5uZXIgaXMgcmVhZHkhIPCfjb3vuI8nLCAnVGltZSB0byBoZWFkIGhvbWUg8J+asicsICdQbGVhc2UgY2FsbCBtb20vZGFkIPCfk54nLCAnR3JlYXQgam9iIG9uIGhvbWV3b3JrIOKtkCddLm1hcCgocHJlc2V0KSA9PiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAga2V5PXtwcmVzZXR9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IHNlbmRNZXNzYWdlKGFjdGl2ZUNoaWxkLmlkLCAncGFyZW50JywgcHJlc2V0KTtcbiAgICAgICAgICAgICAgICAgICAgb25SZWZyZXNoKCk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xIGJnLXNsYXRlLTEwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCByb3VuZGVkLWxnIHdoaXRlc3BhY2Utbm93cmFwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7cHJlc2V0fVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogSW5wdXQgQmFyICovfVxuICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVNlbmRNZXNzYWdlfSBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bWVzc2FnZUlucHV0fVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TWVzc2FnZUlucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17YE1lc3NhZ2UgJHthY3RpdmVDaGlsZC5uYW1lfS4uLmB9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB4LTQgcHktMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHRleHQteHMgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTIuNSBiZy1pbmRpZ28tNjAwIGhvdmVyOmJnLWluZGlnby03MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsIHNoYWRvdy1zbSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxTZW5kIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gU2VuZFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogVEFCIDc6IEFMRVJUUyBDRU5URVIgKi99XG4gICAgICAgIHthY3RpdmVUYWIgPT09ICdhbGVydHMnICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwLTUgc3BhY2UteS00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwYi0zXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJhc2UgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgU2FmZXR5IEFsZXJ0cyAmIE5vdGlmaWNhdGlvbnNcbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgIFNPUyBwaW5ncywgZ2VvZmVuY2UgZW50ZXIvZXhpdCwgbG93IGJhdHRlcnksIGFuZCBmaWx0ZXIgdHJpZ2dlcnNcbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbWFya0FsZXJ0c0FzUmVhZCh1bmRlZmluZWQsIHRydWUpLnRoZW4ob25SZWZyZXNoKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSBiZy1zbGF0ZS0xMDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgTWFyayBBbGwgUmVhZFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMi41XCI+XG4gICAgICAgICAgICAgIHtzdGF0ZS5hbGVydHMubWFwKChhbGVydCkgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGtleT17YWxlcnQuaWR9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTMuNSByb3VuZGVkLXhsIGJvcmRlciB0ZXh0LXhzIGZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zICR7XG4gICAgICAgICAgICAgICAgICAgIGFsZXJ0LnNldmVyaXR5ID09PSAnY3JpdGljYWwnXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctcm9zZS01MCBkYXJrOmJnLXJvc2UtOTUwLzQwIGJvcmRlci1yb3NlLTMwMCBkYXJrOmJvcmRlci1yb3NlLTkwMCdcbiAgICAgICAgICAgICAgICAgICAgICA6IGFsZXJ0LnNldmVyaXR5ID09PSAnd2FybmluZydcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MCBkYXJrOmJnLWFtYmVyLTk1MC80MCBib3JkZXItYW1iZXItMzAwIGRhcms6Ym9yZGVyLWFtYmVyLTkwMCdcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC80MCBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGJsb2NrXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2FsZXJ0LnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2FsZXJ0Lm1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgZm9udC1tb25vIGJsb2NrXCI+XG4gICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKGFsZXJ0LnRpbWVzdGFtcCkudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHshYWxlcnQucmVhZCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBtYXJrQWxlcnRzQXNSZWFkKGFsZXJ0LmlkKS50aGVuKG9uUmVmcmVzaCl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIHJvdW5kZWQgdGV4dC1bMTFweF0gZm9udC1tZWRpdW0gc2hyaW5rLTBcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgRGlzbWlzc1xuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFRBQiA3YjogQU5USS1VTklOU1RBTEwgJiBERVZJQ0UgQURNSU4gUFJPVEVDVElPTiAqL31cbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2FudGl1bmluc3RhbGwnICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgey8qIFRvcCBCYW5uZXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1zbGF0ZS05MDAgdmlhLWluZGlnby05NTAgdG8tYmx1ZS05NTAgdGV4dC13aGl0ZSBwLTYgcm91bmRlZC0zeGwgYm9yZGVyIGJvcmRlci1pbmRpZ28tOTAwLzYwIHNoYWRvdy1sZyBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLTJ4bCBiZy1pbmRpZ28tNjAwLzMwIHRleHQtaW5kaWdvLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJsYWNrIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBTdHJpY3QgQW50aS1Vbmluc3RhbGwgJiBEZXZpY2UgUHJvdGVjdGlvblxuICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWluZGlnby0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIERldmljZSBBZG1pbiDigKIgU2V0dGluZ3MgSW50ZXJjZXB0b3Ig4oCiIFBhcmVudCBNYXN0ZXIgUElOIEVuZm9yY2VkXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTMwMCBtYXgtdy0yeGwgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgIENoaWxkcmVuIGNhbm5vdCBkZWxldGUgb3IgYnlwYXNzIFNhZmVLaWRzLiBJZiB1bmluc3RhbGxhdGlvbiwgYXBwIGRlYWN0aXZhdGlvbiwgb3IgY2FjaGUgd2lwaW5nIGlzIGF0dGVtcHRlZCBpbiBBbmRyb2lkIFNldHRpbmdzLCBTYWZlS2lkcyBpbW1lZGlhdGVseSByZWRpcmVjdHMgdG8gdGhlIE1hc3RlciBQSU4gdmVyaWZpY2F0aW9uIHNjcmVlbi5cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2hyaW5rLTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC0zMDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC80MCB0ZXh0LXhzIHB4LTMgcHktMS41IHJvdW5kZWQteGwgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICBQcm90ZWN0aW9uIEVuZm9yY2VkXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBTdGF0dXMgT3ZlcnZpZXcgQ2FyZHMgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtMyBwdC0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvODAgcC0zLjUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1pbmRpZ28tOTAwLzQwIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICBEZXZpY2UgQWRtaW4gU3RhdHVzXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZW1lcmFsZC00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBBY3RpdmUgJiBCb3VuZFxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBibG9jayBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgU2FmZUtpZHNEZXZpY2VBZG1pblxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvODAgcC0zLjUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1pbmRpZ28tOTAwLzQwIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICBBY2Nlc3NpYmlsaXR5IEludGVyY2VwdFxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gR3VhcmRpbmcgU2V0dGluZ3NcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgYmxvY2sgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAgIGNvbS5hbmRyb2lkLnNldHRpbmdzXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC84MCBwLTMuNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLWluZGlnby05MDAvNDAgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIFBhcmVudCBNYXN0ZXIgUElOXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtYmx1ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gNC1EaWdpdCBTZWN1cml0eVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgICBSZXF1aXJlZCBmb3IgUmVtb3ZhbFxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvODAgcC0zLjUgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1pbmRpZ28tOTAwLzQwIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICBUYW1wZXIgQXR0ZW1wdHMgQmxvY2tlZFxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiB7YWN0aXZlQ2hpbGQuYW50aVVuaW5zdGFsbD8udW5pbnN0YWxsQXR0ZW1wdHNDb3VudCB8fCAwfSBBdHRlbXB0c1xuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlQ2hpbGQuYW50aVVuaW5zdGFsbD8ubGFzdFRhbXBlckF0dGVtcHRcbiAgICAgICAgICAgICAgICAgICAgICA/IGBMYXN0OiAke25ldyBEYXRlKGFjdGl2ZUNoaWxkLmFudGlVbmluc3RhbGwubGFzdFRhbXBlckF0dGVtcHQpLnRvTG9jYWxlVGltZVN0cmluZyhbXSwgeyBob3VyOiAnMi1kaWdpdCcsIG1pbnV0ZTogJzItZGlnaXQnIH0pfWBcbiAgICAgICAgICAgICAgICAgICAgICA6ICdaZXJvIHVuYXV0aG9yaXplZCBhdHRlbXB0cyd9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBUZXN0IFNpbXVsYXRpb24gQ2FyZCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zbGF0ZS05MDAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHAtNSBzaGFkb3ctc20gc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHBiLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJhc2UgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8U2hpZWxkQWxlcnQgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXJvc2UtNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgTGl2ZSBBbnRpLVVuaW5zdGFsbCBTaW11bGF0b3IgKFRlc3QgUHJvdGVjdGlvbilcbiAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgIEV4cGVyaWVuY2Ugd2hhdCBoYXBwZW5zIHdoZW4gYSBjaGlsZCBhdHRlbXB0cyB0byB1bmluc3RhbGwgU2FmZUtpZHMgb3IgZGVhY3RpdmF0ZSBEZXZpY2UgQWRtaW4uXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldFNpbXVsYXRlZFBpbignJyk7XG4gICAgICAgICAgICAgICAgICAgIHNldFNpbXVsYXRlZEVycm9yKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICBzZXRTaW11bGF0ZWRTdWNjZXNzKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0U2hvd1Rlc3RVbmluc3RhbGxNb2RhbCh0cnVlKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSBiZy1yb3NlLTYwMCBob3ZlcjpiZy1yb3NlLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgc2hhZG93LXNtIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgc2hyaW5rLTBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC15ZWxsb3ctMzAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIFNpbXVsYXRlIENoaWxkIFVuaW5zdGFsbCBBdHRlbXB0XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBQcm90ZWN0aW9uIEFyY2hpdGVjdHVyZSBCcmVha2Rvd24gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctNiBoLTYgcm91bmRlZC1sZyBiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgQW5kcm9pZCBEZXZpY2UgQWRtaW5pc3RyYXRpb25cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgU2FmZUtpZHMgcmVnaXN0ZXJzIGFzIGFuIGFjdGl2ZSBEZXZpY2UgQWRtaW5pc3RyYXRvci4gVGhlIG5hdGl2ZSBBbmRyb2lkIE9TIGdyYXlzIG91dCB0aGUgJnF1b3Q7VW5pbnN0YWxsJnF1b3Q7IGJ1dHRvbiBpbiBzdGFuZGFyZCBhcHAgc2V0dGluZ3MgYW5kIHdhcm5zIHRoYXQgdGhlIGRldmljZSBhZG1pbmlzdHJhdG9yIG11c3QgYmUgZGVhY3RpdmF0ZWQgZmlyc3QuXG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC80MCBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy02IGgtNiByb3VuZGVkLWxnIGJnLWluZGlnby02MDAgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgMlxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIEFjY2Vzc2liaWxpdHkgV2luZG93IEludGVyY2VwdG9yXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbGVhZGluZy1yZWxheGVkIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgIElmIHRoZSBjaGlsZCBhdHRlbXB0cyB0byBvcGVuIERldmljZSBBZG1pbiBzZXR0aW5ncywgU2FmZUtpZHMgQXBwIEluZm8sIG9yIHRoZSBQYWNrYWdlIFVuaW5zdGFsbGVyLCA8Y29kZT5TYWZlS2lkc0FjY2Vzc2liaWxpdHlTZXJ2aWNlPC9jb2RlPiBpbnRlcmNlcHRzIHRoZSB3aW5kb3cgY2hhbmdlLCBleGVjdXRlcyA8Y29kZT5HTE9CQUxfQUNUSU9OX0JBQ0s8L2NvZGU+LCBhbmQgcG9wcyB1cCB0aGUgTWFzdGVyIFBJTiBvdmVybGF5LlxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAvNDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctNiBoLTYgcm91bmRlZC1sZyBiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAzXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgRGV2aWNlIE93bmVyIChLZXJuZWwgTGV2ZWwpXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbGVhZGluZy1yZWxheGVkIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgIFdoZW4gYWN0aXZhdGVkIHZpYSBBREIgb3IgS25veCBlbnRlcnByaXNlIGVucm9sbG1lbnQsIDxjb2RlPmRwbS5zZXRVbmluc3RhbGxCbG9ja2VkKGFkbWluLCBwYWNrYWdlTmFtZSwgdHJ1ZSk8L2NvZGU+IGlzIGVuZm9yY2VkLCByZW5kZXJpbmcgdW5pbnN0YWxsYXRpb24gMTAwJSBpbXBvc3NpYmxlIGF0IHRoZSBBbmRyb2lkIGtlcm5lbCBsZXZlbC5cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEFuZHJvaWQgU2V0dXAgJiBBREIgR3VpZGUgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCB0ZXh0LXNsYXRlLTIwMCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTUgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZW1lcmFsZC00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPENvZGUyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBQZXJtYW5lbnQgVW5pbnN0YWxsIEJsb2NraW5nIChEZXZpY2UgT3duZXIgTW9kZSlcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gYmctc2xhdGUtODAwIHB4LTIgcHktMC41IHJvdW5kZWQgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgIE9wdGlvbmFsIC8gRm9yIEFkdmFuY2VkIFBhcmVudHNcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgIFRvIG1ha2UgU2FmZUtpZHMgY29tcGxldGVseSBpbXBvc3NpYmxlIHRvIHVuaW5zdGFsbCBldmVuIGlmIHRoZSBjaGlsZCBib290cyBpbnRvIFNhZmUgTW9kZSwgcnVuIHRoaXMgb25lLXRpbWUgY29tbWFuZCBmcm9tIHlvdXIgY29tcHV0ZXIgdmlhIFVTQiBkZWJ1Z2dpbmc6XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibGFjay84MCBwLTMgcm91bmRlZC14bCBmb250LW1vbm8gdGV4dC1lbWVyYWxkLTQwMCB0ZXh0LXhzIG92ZXJmbG93LXgtYXV0byBzZWxlY3QtYWxsXCI+XG4gICAgICAgICAgICAgICAgYWRiIHNoZWxsIGRwbSBzZXQtZGV2aWNlLW93bmVyIGNvbS5zYWZla2lkcy5wYXJlbnRhbGNvbnRyb2wvLnJlY2VpdmVyLlNhZmVLaWRzRGV2aWNlQWRtaW5SZWNlaXZlclxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICBUaGlzIGxvY2tzIHVuaW5zdGFsbGF0aW9uIGRpcmVjdGx5IGluIHRoZSBBbmRyb2lkIE9TIGZyYW1ld29yayB1bnRpbCB0aGUgcGFyZW50IGVudGVycyB0aGVpciBjcmVkZW50aWFscy5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBDaGlsZCBEZXZpY2UgUnVudGltZSBQZXJtaXNzaW9ucyAmIEZvcmVncm91bmQgU2VydmljZXMgU2hpZWxkICovfVxuICAgICAgICAgICAgPENoaWxkUGVybWlzc2lvbnNTaGllbGQgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogVEFCIDg6IEFORFJPSUQgUExBWSBTVE9SRSAmIE5BVElWRSBLSVQgKi99XG4gICAgICAgIHthY3RpdmVUYWIgPT09ICdhbmRyb2lka2l0JyAmJiA8QW5kcm9pZE5hdGl2ZUtpdCAvPn1cbiAgICAgIDwvbWFpbj5cblxuICAgICAgey8qIFNpbXVsYXRlZCBDaGlsZCBVbmluc3RhbGwgQXR0ZW1wdCBJbnRlcmNlcHQgTW9kYWwgKi99XG4gICAgICB7c2hvd1Rlc3RVbmluc3RhbGxNb2RhbCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay84MCBiYWNrZHJvcC1ibHVyLW1kIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyLTIgYm9yZGVyLXJvc2UtNTAwIHJvdW5kZWQtM3hsIG1heC13LXNtIHctZnVsbCBwLTYgdGV4dC1jZW50ZXIgc3BhY2UteS00IHNoYWRvdy0yeGwgYW5pbWF0ZS1pbiB6b29tLWluLTk1XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiByb3VuZGVkLTJ4bCBiZy1yb3NlLTYwMC8zMCB0ZXh0LXJvc2UtNDAwIG14LWF1dG8gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYW5pbWF0ZS1ib3VuY2VcIj5cbiAgICAgICAgICAgICAgPFNoaWVsZEFsZXJ0IGNsYXNzTmFtZT1cInctOCBoLThcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IHRleHQtcm9zZS00MDAgYmctcm9zZS05NTAvNjAgYm9yZGVyIGJvcmRlci1yb3NlLTgwMCBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbFwiPlxuICAgICAgICAgICAgICAgIERFVklDRSBBRE1JTiBJTlRFUkNFUFQgQUNUSVZFXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC13aGl0ZSBtdC0yXCI+XG4gICAgICAgICAgICAgICAgVW5pbnN0YWxsYXRpb24gQmxvY2tlZCFcbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTMwMCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgU2FmZUtpZHMgaXMgcHJvdGVjdGVkIGJ5IEFuZHJvaWQgRGV2aWNlIEFkbWluaXN0cmF0b3IgcG9saWNpZXMuIEVudGVyIE1hc3RlciBQYXJlbnQgUElOIHRvIGF1dGhvcml6ZSBkZWFjdGl2YXRpb24uXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7c2ltdWxhdGVkU3VjY2VzcyA/IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTk1MC82MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNjAwIHAtNCByb3VuZGVkLTJ4bCB0ZXh0LWVtZXJhbGQtMzAwIHRleHQteHMgZm9udC1zZW1pYm9sZCBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNiBoLTYgbXgtYXV0byB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8cD5QYXJlbnQgUElOIFZlcmlmaWVkITwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTMwMFwiPkF1dGhvcml6ZWQgdW5pbnN0YWxsYXRpb24gd2luZG93IG9wZW4gZm9yIDYwIHNlY29uZHMuPC9wPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dUZXN0VW5pbnN0YWxsTW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMiBweC0zIHB5LTEgYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHRleHQteHNcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIENsb3NlXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICBpbnB1dE1vZGU9XCJudW1lcmljXCJcbiAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17Nn1cbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzaW11bGF0ZWRQaW59XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0U2ltdWxhdGVkUGluKGUudGFyZ2V0LnZhbHVlLnJlcGxhY2UoL1xcRC9nLCAnJykpO1xuICAgICAgICAgICAgICAgICAgICBzZXRTaW11bGF0ZWRFcnJvcihudWxsKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIDQtRGlnaXQgUGFyZW50IFBJTlwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1jZW50ZXIgdHJhY2tpbmctd2lkZXN0IHRleHQtbGcgZm9udC1tb25vIHB4LTMgcHktMi41IGJvcmRlciByb3VuZGVkLXhsIGJvcmRlci1zbGF0ZS03MDAgYmctc2xhdGUtOTUwIHRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1yb3NlLTUwMFwiXG4gICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgIHtzaW11bGF0ZWRFcnJvciAmJiAoXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcm9zZS00MDAgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICB7c2ltdWxhdGVkRXJyb3J9XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMiBwdC0xXCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2FzeW5jICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAvLyBMb2cgdGFtcGVyIGFsZXJ0IHRvIGJhY2tlbmRcbiAgICAgICAgICAgICAgICAgICAgICBhd2FpdCByZXBvcnRUYW1wZXJBdHRlbXB0KGFjdGl2ZUNoaWxkLmlkLCAnQ2hpbGQgYXR0ZW1wdGVkIHRvIHVuaW5zdGFsbCBTYWZlS2lkcyB2aWEgU2V0dGluZ3MnKTtcbiAgICAgICAgICAgICAgICAgICAgICBvblJlZnJlc2goKTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93VGVzdFVuaW5zdGFsbE1vZGFsKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTMwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIENhbmNlbCAoS2VlcCBQcm90ZWN0ZWQpXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17YXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChzaW11bGF0ZWRQaW4gPT09IHN0YXRlLnBhcmVudFBpbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2ltdWxhdGVkU3VjY2Vzcyh0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2ltdWxhdGVkRXJyb3IoJ0luY29ycmVjdCBQSU4uIFRhbXBlcmluZyBhdHRlbXB0IHJlcG9ydGVkIHRvIHBhcmVudHMhJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBhd2FpdCByZXBvcnRUYW1wZXJBdHRlbXB0KGFjdGl2ZUNoaWxkLmlkLCAnRmFpbGVkIFBJTiBhdHRlbXB0IHdoaWxlIHRyeWluZyB0byB1bmluc3RhbGwgU2FmZUtpZHMnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uUmVmcmVzaCgpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgYmctcm9zZS02MDAgaG92ZXI6Ymctcm9zZS03MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgVmVyaWZ5IFBJTlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogTW9kYWxzICovfVxuICAgICAgPERldmljZVBhaXJpbmdNb2RhbFxuICAgICAgICBpc09wZW49e3Nob3dQYWlyTW9kYWx9XG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dQYWlyTW9kYWwoZmFsc2UpfVxuICAgICAgICBvbkRldmljZVBhaXJlZD17b25SZWZyZXNofVxuICAgICAgLz5cblxuICAgICAgPFNhZmVab25lc01vZGFsXG4gICAgICAgIGlzT3Blbj17c2hvd1NhZmVab25lc01vZGFsfVxuICAgICAgICBjaGlsZElkPXthY3RpdmVDaGlsZC5pZH1cbiAgICAgICAgY3VycmVudFpvbmVzPXthY3RpdmVDaGlsZC5zYWZlWm9uZXN9XG4gICAgICAgIGN1cnJlbnRMYXRpdHVkZT17YWN0aXZlQ2hpbGQubG9jYXRpb24ubGF0aXR1ZGV9XG4gICAgICAgIGN1cnJlbnRMb25naXR1ZGU9e2FjdGl2ZUNoaWxkLmxvY2F0aW9uLmxvbmdpdHVkZX1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd1NhZmVab25lc01vZGFsKGZhbHNlKX1cbiAgICAgICAgb25TYXZlZD17b25SZWZyZXNofVxuICAgICAgLz5cblxuICAgICAgey8qIERvd25sb2FkIFNvdXJjZSBDb2RlIE1vZGFsICovfVxuICAgICAge3Nob3dEb3dubG9hZE1vZGFsICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzgwIGJhY2tkcm9wLWJsdXItc20gei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBtYXgtdy1sZyB3LWZ1bGwgcC02IHNwYWNlLXktNSBzaGFkb3ctMnhsIGFuaW1hdGUtaW4gem9vbS1pbi05NSBtYXgtaC1bOTB2aF0gb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwYi0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctZW1lcmFsZC0xMDAgZGFyazpiZy1lbWVyYWxkLTkwMC80MCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgPEZpbGVBcmNoaXZlIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmFzZSB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIFNhZmVLaWRzIFNvdXJjZSBDb2RlICjgpKrgpY3gpLDgpYvgpJzgpYfgpJXgpY3gpJ8g4KSc4KS84KS/4KSqIOCkoeCkvuCkieCkqOCksuCli+CkoSlcbiAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgMTAwJSBGcmVlICYgT3Blbi1Tb3VyY2UgRnVsbCBBcHBsaWNhdGlvblxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dEb3dubG9hZE1vZGFsKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTYwMCBkYXJrOmhvdmVyOnRleHQtc2xhdGUtMjAwIHAtMSByb3VuZGVkLWxnXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC80MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtOTAwIHJvdW5kZWQtMnhsIHAtNCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQteHMgdGV4dC1lbWVyYWxkLTgwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDAgYmxvY2tcIj5cbiAgICAgICAgICAgICAgICDwn5OmIEluc3RhbnQgRG93bmxvYWQgT3B0aW9uczpcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgaHJlZj1cIi9hcGkvZG93bmxvYWQtemlwXCJcbiAgICAgICAgICAgICAgICAgIGRvd25sb2FkPVwiU2FmZUtpZHMtQ29tcGxldGUtUHJvamVjdC56aXBcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTMgcHgtNCBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC1jZW50ZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgc2hhZG93LXNtIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IFNlcnZlciBEaXJlY3QgWklQXG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzRG93bmxvYWRpbmdaaXB9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXthc3luYyAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldElzRG93bmxvYWRpbmdaaXAodHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgYXdhaXQgZG93bmxvYWRQcm9qZWN0QXNaaXAoKTtcbiAgICAgICAgICAgICAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRJc0Rvd25sb2FkaW5nWmlwKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0zIHB4LTQgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS03MDAgdGV4dC13aGl0ZSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtY2VudGVyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHNoYWRvdy1zbSB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IHtpc0Rvd25sb2FkaW5nWmlwID8gJ1ppcHBpbmcuLi4nIDogJ0NsaWVudCBCcm93c2VyIFpJUCd9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBJbmNsdWRlZCBpbiB0aGUgWmlwICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMCBibG9ja1wiPlxuICAgICAgICAgICAgICAgIOCknOCkvOCkv+CkqiDgpKvgpL7gpIfgpLIg4KSu4KWH4KSCIOCkleCljeCkr+Ckvi3gpJXgpY3gpK/gpL4g4KS24KS+4KSu4KS/4KSyIOCkueCliCAoSW5jbHVkZWQgaW4gWklQKTpcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwibGlzdC1kaXNjIGxpc3QtaW5zaWRlIHNwYWNlLXktMSB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtNDAwIHRleHQtWzExcHhdIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgIDxsaT48c3Ryb25nPlJlYWN0IDE5ICsgVHlwZVNjcmlwdCArIFZpdGU6PC9zdHJvbmc+IENvbXBsZXRlIHBhcmVudCAmIGNoaWxkIGRhc2hib2FyZCB3aXRoIHJlc3BvbnNpdmUgZGVzaWduICYgZGFyayBtb2RlLjwvbGk+XG4gICAgICAgICAgICAgICAgPGxpPjxzdHJvbmc+RXhwcmVzcyBGdWxsLVN0YWNrIFNlcnZlcjo8L3N0cm9uZz4gUGFpcmluZyBjb2RlIGdlbmVyYXRvciwgbGl2ZSBzeW5jLCBnZW9mZW5jaW5nICYgYWxlcnRzLjwvbGk+XG4gICAgICAgICAgICAgICAgPGxpPjxzdHJvbmc+T3BlblN0cmVldE1hcCAoTGVhZmxldCk6PC9zdHJvbmc+IFJlYWwgR1BTIHRyYWNraW5nIHdpdGggc2FmZSB6b25lcyBnZW9mZW5jaW5nLjwvbGk+XG4gICAgICAgICAgICAgICAgPGxpPjxzdHJvbmc+TmF0aXZlIEFuZHJvaWQgS290bGluIFNvdXJjZXM6PC9zdHJvbmc+IEFjY2Vzc2liaWxpdHkgU2VydmljZSwgRGV2aWNlIEFkbWluLCBMb2NhdGlvbiBGb3JlZ3JvdW5kIFNlcnZpY2UsIE1lZGlhUHJvamVjdGlvbiBzY3JlZW4gc2hhcmluZy48L2xpPlxuICAgICAgICAgICAgICAgIDxsaT48c3Ryb25nPkdvb2dsZSBQbGF5IFN0b3JlIEtpdDo8L3N0cm9uZz4gQW5kcm9pZE1hbmlmZXN0LnhtbCwgYnVpbGQuZ3JhZGxlLmt0cywgRGF0YSBTYWZldHkgYW5zd2VycywgQ09QUEEgUHJpdmFjeSBQb2xpY3kuPC9saT5cbiAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUnVuIGluc3RydWN0aW9ucyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIHRleHQtc2xhdGUtMjAwIHJvdW5kZWQteGwgcC0zLjUgc3BhY2UteS0yIHRleHQteHMgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC00MDAgZm9udC1ib2xkIGJsb2NrIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAg4KSF4KSq4KSo4KWHIOCkleCkguCkquCljeCkr+ClguCkn+CksCDgpKrgpLAg4KSa4KSy4KS+4KSo4KWHIOCkleCkviDgpKTgpLDgpYDgpJXgpL4gKEhvdyB0byBydW4gbG9jYWxseSk6XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibGFjay82MCBwLTIuNSByb3VuZGVkLWxnIHRleHQtWzExcHhdIHNwYWNlLXktMSB0ZXh0LXNsYXRlLTMwMCBvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICA8cD4jIDEuIFVuemlwIHRoZSBkb3dubG9hZGVkIGZpbGU8L3A+XG4gICAgICAgICAgICAgICAgPHA+IyAyLiBPcGVuIHRlcm1pbmFsIGluc2lkZSB0aGUgZm9sZGVyIGFuZCBydW46PC9wPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteWVsbG93LTMwMCBmb250LWJvbGRcIj5ucG0gaW5zdGFsbDwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXllbGxvdy0zMDAgZm9udC1ib2xkXCI+bnBtIHJ1biBkZXY8L3A+XG4gICAgICAgICAgICAgICAgPHA+IyAzLiBPcGVuIGh0dHA6Ly9sb2NhbGhvc3Q6MzAwMCBpbiB5b3VyIGJyb3dzZXI8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMVwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0Rvd25sb2FkTW9kYWwoZmFsc2UpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yLjUgYmctc2xhdGUtMTAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTgwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENsb3NlXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIEFib3V0ICYgRGV2ZWxvcGVyIEF0dHJpYnV0aW9uIE1vZGFsICovfVxuICAgICAgPEFib3V0TW9kYWxcbiAgICAgICAgaXNPcGVuPXtzaG93QWJvdXRNb2RhbH1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd0Fib3V0TW9kYWwoZmFsc2UpfVxuICAgICAgICBwYXJlbnRQaW49e3N0YXRlLnBhcmVudFBpbn1cbiAgICAgIC8+XG5cbiAgICAgIHsvKiBEZXZlbG9wZXIgQnJhbmRpbmcgRm9vdGVyICovfVxuICAgICAgPGZvb3RlciBjbGFzc05hbWU9XCJtdC1hdXRvIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtODAwLzgwIGJnLXdoaXRlLzgwIGRhcms6Ymctc2xhdGUtOTAwLzgwIGJhY2tkcm9wLWJsdXItbWQgcHktNCBweC02XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgIFNhZmVLaWRzIEZyZWUgUGFyZW50YWwgQ29udHJvbFxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4+4oCiPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICBPcGVuLVNvdXJjZSAmIDEwMCUgRnJlZVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgPHNwYW4+RGV2ZWxvcGVkIGJ5PC9zcGFuPlxuICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9udC1ib2xkIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCBweC0yLjUgcHktMSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICBSYWphbiBWaXNod2FrYXJtYVxuICAgICAgICAgICAgPC9zdHJvbmc+XG4gICAgICAgICAgICA8c3Bhbj7igKI8L3NwYW4+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dBYm91dE1vZGFsKHRydWUpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIGRhcms6dGV4dC1ibHVlLTQwMCBob3Zlcjp1bmRlcmxpbmUgZm9udC1zZW1pYm9sZFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIEFib3V0ICYgU3BlY3NcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZm9vdGVyPlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==