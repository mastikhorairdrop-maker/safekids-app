const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=d3d47fa4";
import { Lock, AlertCircle } from "/node_modules/.vite/deps/lucide-react.js?v=d3d47fa4";
import { verifyParentPin } from "/src/services/api.ts";
var _jsxFileName = "/app/applet/src/components/PinProtectionModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d3d47fa4";
export const PinProtectionModal = ({ isOpen, title = "Parent Master PIN Required", subtitle = "Enter your 4-digit security PIN to proceed (Default: 1234)", onSuccess, onCancel }) => {
	const [pin, setPin] = useState("");
	const [error, setError] = useState(null);
	const [isVerifying, setIsVerifying] = useState(false);
	if (!isOpen) return null;
	const handleKeyPress = (num) => {
		if (pin.length < 6) {
			const nextPin = pin + num;
			setPin(nextPin);
			setError(null);
		}
	};
	const handleBackspace = () => {
		setPin(pin.slice(0, -1));
		setError(null);
	};
	const handleClear = () => {
		setPin("");
		setError(null);
	};
	const handleVerify = async () => {
		if (pin.length < 4) {
			setError("Please enter at least 4 digits");
			return;
		}
		setIsVerifying(true);
		const valid = await verifyParentPin(pin);
		setIsVerifying(false);
		if (valid) {
			setPin("");
			setError(null);
			onSuccess();
		} else {
			setError("Incorrect PIN. Default is 1234.");
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-xs w-full p-6 text-center space-y-5 shadow-2xl animate-in zoom-in-95",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-between items-center",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 mx-auto flex items-center justify-center",
						children: /* @__PURE__ */ _jsxDEV(Lock, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "font-bold text-base text-slate-900 dark:text-slate-100",
					children: title
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
					children: subtitle
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-center items-center gap-3 py-2",
					children: [
						0,
						1,
						2,
						3
					].map((idx) => /* @__PURE__ */ _jsxDEV("div", { className: `w-4 h-4 rounded-full border-2 transition-all ${pin.length > idx ? "bg-blue-600 border-blue-600 scale-110" : "border-slate-300 dark:border-slate-700 bg-transparent"}` }, idx, false, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 9
				}, this),
				error && /* @__PURE__ */ _jsxDEV("div", {
					className: "text-xs text-rose-500 font-semibold flex items-center justify-center gap-1",
					children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: error }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 96,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 94,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						[
							"1",
							"2",
							"3",
							"4",
							"5",
							"6",
							"7",
							"8",
							"9"
						].map((digit) => /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => handleKeyPress(digit),
							className: "py-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 font-bold text-base rounded-2xl active:scale-95 transition-all",
							children: digit
						}, digit, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 13
						}, this)),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleClear,
							className: "py-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 font-medium text-xs rounded-2xl active:scale-95 transition-all",
							children: "Clear"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => handleKeyPress("0"),
							className: "py-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 font-bold text-base rounded-2xl active:scale-95 transition-all",
							children: "0"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleBackspace,
							className: "py-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 font-medium text-xs rounded-2xl active:scale-95 transition-all",
							children: "⌫"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-2 gap-2 pt-1",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: onCancel,
						className: "py-2.5 px-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold",
						children: "Cancel"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 136,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleVerify,
						disabled: isVerifying || pin.length < 4,
						className: "py-2.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold disabled:opacity-50 transition-colors shadow-sm",
						children: "Verify PIN"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 142,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 135,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 62,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLE1BQXdCLG1CQUFtQztBQUNwRSxTQUFTLHVCQUF1Qjs7O0FBVWhDLE9BQU8sTUFBTSxzQkFBeUQsRUFDcEUsUUFDQSxRQUFRLDhCQUNSLFdBQVcsOERBQ1gsV0FDQSxlQUNJO0NBQ0osTUFBTSxDQUFDLEtBQUssVUFBVSxTQUFTLEVBQUU7Q0FDakMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUF3QixJQUFJO0NBQ3RELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEtBQUs7Q0FFcEQsSUFBSSxDQUFDLFFBQVEsT0FBTztDQUVwQixNQUFNLGtCQUFrQixRQUFnQjtFQUN0QyxJQUFJLElBQUksU0FBUyxHQUFHO0dBQ2xCLE1BQU0sVUFBVSxNQUFNO0dBQ3RCLE9BQU8sT0FBTztHQUNkLFNBQVMsSUFBSTtFQUNmO0NBQ0Y7Q0FFQSxNQUFNLHdCQUF3QjtFQUM1QixPQUFPLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO0VBQ3ZCLFNBQVMsSUFBSTtDQUNmO0NBRUEsTUFBTSxvQkFBb0I7RUFDeEIsT0FBTyxFQUFFO0VBQ1QsU0FBUyxJQUFJO0NBQ2Y7Q0FFQSxNQUFNLGVBQWUsWUFBWTtFQUMvQixJQUFJLElBQUksU0FBUyxHQUFHO0dBQ2xCLFNBQVMsZ0NBQWdDO0dBQ3pDO0VBQ0Y7RUFDQSxlQUFlLElBQUk7RUFDbkIsTUFBTSxRQUFRLE1BQU0sZ0JBQWdCLEdBQUc7RUFDdkMsZUFBZSxLQUFLO0VBQ3BCLElBQUksT0FBTztHQUNULE9BQU8sRUFBRTtHQUNULFNBQVMsSUFBSTtHQUNiLFVBQVU7RUFDWixPQUFPO0dBQ0wsU0FBUyxpQ0FBaUM7RUFDNUM7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztLQUN4Qjs7Ozs7SUFDRjs7Ozs7SUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFDWDtJQUNDOzs7O2NBQ0osd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDVjtJQUNBOzs7O1lBQ0E7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWjtNQUFDO01BQUc7TUFBRztNQUFHO0tBQUMsQ0FBQyxDQUFDLEtBQUssUUFDakIsd0JBQUMsT0FBRCxFQUVFLFdBQVcsZ0RBQ1QsSUFBSSxTQUFTLE1BQ1QsMENBQ0EsMERBRVAsR0FOTTs7OztZQU1OLENBQ0Y7SUFDRTs7Ozs7SUFFSixTQUNDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSxjQUFlOzs7O2VBQ3RDLHdCQUFDLFFBQUQsWUFBTyxNQUFZOzs7O2FBQ2hCOzs7Ozs7SUFJUCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0c7T0FBQztPQUFLO09BQUs7T0FBSztPQUFLO09BQUs7T0FBSztPQUFLO09BQUs7TUFBRyxDQUFDLENBQUMsS0FBSyxVQUNsRCx3QkFBQyxVQUFEO09BRUUsTUFBSztPQUNMLGVBQWUsZUFBZSxLQUFLO09BQ25DLFdBQVU7aUJBRVQ7TUFDSyxHQU5EOzs7O2FBTUMsQ0FDVDtNQUNELHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsU0FBUztPQUNULFdBQVU7aUJBQ1g7TUFFTzs7Ozs7TUFDUix3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLGVBQWUsZUFBZSxHQUFHO09BQ2pDLFdBQVU7aUJBQ1g7TUFFTzs7Ozs7TUFDUix3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLFNBQVM7T0FDVCxXQUFVO2lCQUNYO01BRU87Ozs7O0tBQ0w7Ozs7OztJQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBQ1g7S0FFTzs7OztlQUNSLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsVUFBVSxlQUFlLElBQUksU0FBUztNQUN0QyxXQUFVO2dCQUNYO0tBRU87Ozs7YUFDTDs7Ozs7O0dBQ0Y7Ozs7OztDQUNGOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBpblByb3RlY3Rpb25Nb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTG9jaywgVW5sb2NrLCBLZXlSb3VuZCwgQWxlcnRDaXJjbGUsIFgsIFNoaWVsZENoZWNrIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IHZlcmlmeVBhcmVudFBpbiB9IGZyb20gJy4uL3NlcnZpY2VzL2FwaSc7XG5cbmludGVyZmFjZSBQaW5Qcm90ZWN0aW9uTW9kYWxQcm9wcyB7XG4gIGlzT3BlbjogYm9vbGVhbjtcbiAgdGl0bGU/OiBzdHJpbmc7XG4gIHN1YnRpdGxlPzogc3RyaW5nO1xuICBvblN1Y2Nlc3M6ICgpID0+IHZvaWQ7XG4gIG9uQ2FuY2VsOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgUGluUHJvdGVjdGlvbk1vZGFsOiBSZWFjdC5GQzxQaW5Qcm90ZWN0aW9uTW9kYWxQcm9wcz4gPSAoe1xuICBpc09wZW4sXG4gIHRpdGxlID0gJ1BhcmVudCBNYXN0ZXIgUElOIFJlcXVpcmVkJyxcbiAgc3VidGl0bGUgPSAnRW50ZXIgeW91ciA0LWRpZ2l0IHNlY3VyaXR5IFBJTiB0byBwcm9jZWVkIChEZWZhdWx0OiAxMjM0KScsXG4gIG9uU3VjY2VzcyxcbiAgb25DYW5jZWwsXG59KSA9PiB7XG4gIGNvbnN0IFtwaW4sIHNldFBpbl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtpc1ZlcmlmeWluZywgc2V0SXNWZXJpZnlpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGlmICghaXNPcGVuKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBoYW5kbGVLZXlQcmVzcyA9IChudW06IHN0cmluZykgPT4ge1xuICAgIGlmIChwaW4ubGVuZ3RoIDwgNikge1xuICAgICAgY29uc3QgbmV4dFBpbiA9IHBpbiArIG51bTtcbiAgICAgIHNldFBpbihuZXh0UGluKTtcbiAgICAgIHNldEVycm9yKG51bGwpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVCYWNrc3BhY2UgPSAoKSA9PiB7XG4gICAgc2V0UGluKHBpbi5zbGljZSgwLCAtMSkpO1xuICAgIHNldEVycm9yKG51bGwpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNsZWFyID0gKCkgPT4ge1xuICAgIHNldFBpbignJyk7XG4gICAgc2V0RXJyb3IobnVsbCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlVmVyaWZ5ID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmIChwaW4ubGVuZ3RoIDwgNCkge1xuICAgICAgc2V0RXJyb3IoJ1BsZWFzZSBlbnRlciBhdCBsZWFzdCA0IGRpZ2l0cycpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzZXRJc1ZlcmlmeWluZyh0cnVlKTtcbiAgICBjb25zdCB2YWxpZCA9IGF3YWl0IHZlcmlmeVBhcmVudFBpbihwaW4pO1xuICAgIHNldElzVmVyaWZ5aW5nKGZhbHNlKTtcbiAgICBpZiAodmFsaWQpIHtcbiAgICAgIHNldFBpbignJyk7XG4gICAgICBzZXRFcnJvcihudWxsKTtcbiAgICAgIG9uU3VjY2VzcygpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRFcnJvcignSW5jb3JyZWN0IFBJTi4gRGVmYXVsdCBpcyAxMjM0LicpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay84MCBiYWNrZHJvcC1ibHVyLXNtIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBtYXgtdy14cyB3LWZ1bGwgcC02IHRleHQtY2VudGVyIHNwYWNlLXktNSBzaGFkb3ctMnhsIGFuaW1hdGUtaW4gem9vbS1pbi05NVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctYmx1ZS0xMDAgZGFyazpiZy1ibHVlLTkwMC80MCB0ZXh0LWJsdWUtNjAwIGRhcms6dGV4dC1ibHVlLTQwMCBteC1hdXRvIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtYmFzZSB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICB7dGl0bGV9XG4gICAgICAgICAgPC9oMz5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbXQtMVwiPlxuICAgICAgICAgICAge3N1YnRpdGxlfVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFBJTiBEb3RzIERpc3BsYXkgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgZ2FwLTMgcHktMlwiPlxuICAgICAgICAgIHtbMCwgMSwgMiwgM10ubWFwKChpZHgpID0+IChcbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAga2V5PXtpZHh9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctNCBoLTQgcm91bmRlZC1mdWxsIGJvcmRlci0yIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgcGluLmxlbmd0aCA+IGlkeFxuICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgYm9yZGVyLWJsdWUtNjAwIHNjYWxlLTExMCdcbiAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS0zMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGJnLXRyYW5zcGFyZW50J1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtlcnJvciAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtcm9zZS01MDAgZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgIDxzcGFuPntlcnJvcn08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIE51bWVyaWMgS2V5cGFkICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTJcIj5cbiAgICAgICAgICB7WycxJywgJzInLCAnMycsICc0JywgJzUnLCAnNicsICc3JywgJzgnLCAnOSddLm1hcCgoZGlnaXQpID0+IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXtkaWdpdH1cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUtleVByZXNzKGRpZ2l0KX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMyBiZy1zbGF0ZS0xMDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6Ymctc2xhdGUtODAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgZm9udC1ib2xkIHRleHQtYmFzZSByb3VuZGVkLTJ4bCBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7ZGlnaXR9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsZWFyfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMyBiZy1zbGF0ZS0xMDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6Ymctc2xhdGUtODAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtNTAwIGZvbnQtbWVkaXVtIHRleHQteHMgcm91bmRlZC0yeGwgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBDbGVhclxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlS2V5UHJlc3MoJzAnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB5LTMgYmctc2xhdGUtMTAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTgwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwIGZvbnQtYm9sZCB0ZXh0LWJhc2Ugcm91bmRlZC0yeGwgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICAwXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVCYWNrc3BhY2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweS0zIGJnLXNsYXRlLTEwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS04MDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW0gdGV4dC14cyByb3VuZGVkLTJ4bCBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIOKMq1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTIgcHQtMVwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2FuY2VsfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgYmctc2xhdGUtMTAwIGhvdmVyOmJnLXNsYXRlLTIwMCBkYXJrOmJnLXNsYXRlLTgwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVWZXJpZnl9XG4gICAgICAgICAgICBkaXNhYmxlZD17aXNWZXJpZnlpbmcgfHwgcGluLmxlbmd0aCA8IDR9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgZGlzYWJsZWQ6b3BhY2l0eS01MCB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3ctc21cIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIFZlcmlmeSBQSU5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=