const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=d3d47fa4";
import { Camera, Monitor, ShieldCheck, Video, VideoOff, X, AlertTriangle, Lock } from "/node_modules/.vite/deps/lucide-react.js?v=d3d47fa4";
import { requestCameraLookIn, requestScreenShare, respondCameraRequest, respondScreenRequest } from "/src/services/api.ts";
var _jsxFileName = "/app/applet/src/components/CameraScreenSession.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d3d47fa4";
export const CameraScreenSession = ({ child, isParentView, onRefresh }) => {
	const [selectedFacingMode, setSelectedFacingMode] = useState("user");
	const [requestReason, setRequestReason] = useState("Safety & Location Check");
	const [isLoading, setIsLoading] = useState(false);
	const [sessionError, setSessionError] = useState(null);
	// Real Local Media Stream (when running camera/screen)
	const [localStream, setLocalStream] = useState(null);
	const [isStreaming, setIsStreaming] = useState(false);
	const [streamType, setStreamType] = useState(null);
	const videoRef = useRef(null);
	// Stop all active tracks
	const stopLocalStream = () => {
		if (localStream) {
			localStream.getTracks().forEach((track) => track.stop());
			setLocalStream(null);
		}
		setIsStreaming(false);
		setStreamType(null);
	};
	useEffect(() => {
		if (videoRef.current && localStream) {
			videoRef.current.srcObject = localStream;
		}
	}, [localStream]);
	// Cleanup on unmount
	useEffect(() => {
		return () => {
			stopLocalStream();
		};
	}, []);
	const handleStartParentCameraRequest = async () => {
		setIsLoading(true);
		setSessionError(null);
		try {
			const res = await requestCameraLookIn(child.id, selectedFacingMode, requestReason);
			if (!res.success) {
				setSessionError("Could not send camera look-in request. Verify child device is online.");
			} else {
				// Also provide a local camera test view if child device is on this machine
				tryLocalCamera();
			}
			if (onRefresh) onRefresh();
		} catch (e) {
			setSessionError(e?.message || "Error initiating camera session");
		} finally {
			setIsLoading(false);
		}
	};
	const handleStartParentScreenRequest = async () => {
		setIsLoading(true);
		setSessionError(null);
		try {
			const res = await requestScreenShare(child.id, requestReason);
			if (!res.success) {
				setSessionError("Could not send screen share request. Verify child device is online.");
			} else {
				tryLocalScreenShare();
			}
			if (onRefresh) onRefresh();
		} catch (e) {
			setSessionError(e?.message || "Error initiating screen share session");
		} finally {
			setIsLoading(false);
		}
	};
	// Real Web Media Capture for Child / Test Device
	const tryLocalCamera = async () => {
		try {
			stopLocalStream();
			const constraints = {
				video: {
					facingMode: selectedFacingMode,
					width: { ideal: 1280 },
					height: { ideal: 720 }
				},
				audio: false
			};
			const stream = await navigator.mediaDevices.getUserMedia(constraints);
			setLocalStream(stream);
			setIsStreaming(true);
			setStreamType("camera");
			if (videoRef.current) {
				videoRef.current.srcObject = stream;
			}
		} catch (err) {
			console.warn("Camera access prompt declined or unsupported:", err);
			setSessionError(`Camera access status: ${err?.message || "Device camera permission required"}`);
		}
	};
	const tryLocalScreenShare = async () => {
		try {
			stopLocalStream();
			if (!navigator.mediaDevices.getDisplayMedia) {
				throw new Error("Screen sharing API is not supported on this browser or environment.");
			}
			const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
			// Handle when child clicks standard browser "Stop Sharing" bar
			stream.getVideoTracks()[0].onended = () => {
				stopLocalStream();
				respondScreenRequest(child.id, "ended");
			};
			setLocalStream(stream);
			setIsStreaming(true);
			setStreamType("screen");
			if (videoRef.current) {
				videoRef.current.srcObject = stream;
			}
		} catch (err) {
			console.warn("Screen share prompt cancelled:", err);
			setSessionError(`Screen share status: ${err?.message || "Screen capture permission required"}`);
		}
	};
	const handleEndSession = async () => {
		stopLocalStream();
		if (streamType === "camera" || child.activeSessions?.cameraRequest) {
			await respondCameraRequest(child.id, "ended");
		}
		if (streamType === "screen" || child.activeSessions?.screenRequest) {
			await respondScreenRequest(child.id, "ended");
		}
		if (onRefresh) onRefresh();
	};
	const takeSnapshot = () => {
		if (!videoRef.current) return;
		const canvas = document.createElement("canvas");
		canvas.width = videoRef.current.videoWidth || 640;
		canvas.height = videoRef.current.videoHeight || 480;
		const ctx = canvas.getContext("2d");
		if (ctx) {
			ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
			const dataUrl = canvas.toDataURL("image/png");
			const a = document.createElement("a");
			a.href = dataUrl;
			a.download = `SafeKids-LookIn-${child.name}-${new Date().toISOString().replace(/[:.]/g, "-")}.png`;
			a.click();
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm space-y-5",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "font-bold text-lg text-slate-800 dark:text-slate-100",
						children: "Live Camera & Screen Check-In"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 text-xs px-2.5 py-0.5 rounded-full font-semibold border border-emerald-300 dark:border-emerald-800 flex items-center gap-1",
						children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 15
						}, this), " Google Play Compliant"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 175,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 171,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500 dark:text-slate-400 mt-1",
					children: "Privacy-first look-in. Never stealth or spyware: requires child consent prompt and visible indicator."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 179,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 170,
					columnNumber: 9
				}, this), isStreaming && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "relative flex h-3 w-3",
							children: [/* @__PURE__ */ _jsxDEV("span", { className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { className: "relative inline-flex rounded-full h-3 w-3 bg-emerald-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 188,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider",
							children: "Live Feed Active"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleEndSession,
							className: "ml-2 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-medium transition-colors flex items-center gap-1",
							children: [/* @__PURE__ */ _jsxDEV(X, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 15
							}, this), " End Session"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 193,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 185,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 169,
				columnNumber: 7
			}, this),
			sessionError && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 rounded-xl p-3 text-xs text-amber-800 dark:text-amber-300 flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { className: "w-4 h-4 shrink-0 text-amber-600" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 205,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: sessionError }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 206,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 204,
				columnNumber: 9
			}, this),
			isStreaming ? /* @__PURE__ */ _jsxDEV("div", {
				className: "relative rounded-xl overflow-hidden bg-black aspect-video max-h-[460px] flex items-center justify-center border border-slate-700 shadow-inner group",
				children: [
					/* @__PURE__ */ _jsxDEV("video", {
						ref: videoRef,
						autoPlay: true,
						playsInline: true,
						muted: true,
						className: "w-full h-full object-contain"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 213,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute top-3 left-3 bg-black/70 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/20 text-white text-xs flex items-center gap-2",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 223,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: streamType === "camera" ? `Camera (${selectedFacingMode === "user" ? "Front" : "Rear"})` : "Live Screen" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 224,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400",
								children: "|"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 227,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-300",
								children: [child.name, "'s Device"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 228,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 222,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "absolute bottom-3 right-3 flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: takeSnapshot,
							className: "bg-white/90 hover:bg-white text-slate-800 text-xs px-3 py-1.5 rounded-lg font-medium shadow-md transition-all flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-3.5 h-3.5 text-blue-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 236,
								columnNumber: 15
							}, this), " Save Snapshot"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 232,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: handleEndSession,
							className: "bg-rose-600 hover:bg-rose-700 text-white text-xs px-3 py-1.5 rounded-lg font-medium shadow-md transition-all flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV(VideoOff, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 242,
								columnNumber: 15
							}, this), " Stop"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 238,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 231,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 212,
				columnNumber: 9
			}, this) : 
			/* Action Launcher for Parent */
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col justify-between space-y-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center",
								children: /* @__PURE__ */ _jsxDEV(Camera, { className: "w-5 h-5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 254,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 253,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
								className: "font-semibold text-slate-900 dark:text-slate-100 text-sm",
								children: "Live Camera Look-In"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 257,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 dark:text-slate-400",
								children: "Parent-initiated video check-in with child approval."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 260,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 256,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 252,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-xs font-medium text-slate-600 dark:text-slate-400 block mb-1.5",
							children: "Camera Lens"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 268,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setSelectedFacingMode("user"),
								className: `px-3 py-2 text-xs rounded-lg font-medium border text-center transition-all ${selectedFacingMode === "user" ? "bg-blue-600 text-white border-blue-600 shadow-sm" : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700"}`,
								children: "🤳 Front (Selfie)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 272,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setSelectedFacingMode("environment"),
								className: `px-3 py-2 text-xs rounded-lg font-medium border text-center transition-all ${selectedFacingMode === "environment" ? "bg-blue-600 text-white border-blue-600 shadow-sm" : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700"}`,
								children: "📷 Rear (Environment)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 283,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 271,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 267,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 251,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleStartParentCameraRequest,
						disabled: isLoading,
						className: "w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-50",
						children: [/* @__PURE__ */ _jsxDEV(Video, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 303,
							columnNumber: 15
						}, this), " Request Camera Feed"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 298,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 250,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-slate-50/50 dark:bg-slate-800/40 flex flex-col justify-between space-y-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400 flex items-center justify-center",
								children: /* @__PURE__ */ _jsxDEV(Monitor, { className: "w-5 h-5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 312,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 311,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
								className: "font-semibold text-slate-900 dark:text-slate-100 text-sm",
								children: "Live Screen Sharing"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 315,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 dark:text-slate-400",
								children: "Official Android MediaProjection screen capture."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 318,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 314,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 310,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "text-xs font-medium text-slate-600 dark:text-slate-400 block mb-1.5",
							children: "Request Reason (shown to child)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 326,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							value: requestReason,
							onChange: (e) => setRequestReason(e.target.value),
							placeholder: "e.g. Checking homework progress",
							className: "w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 329,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 325,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 309,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleStartParentScreenRequest,
						disabled: isLoading,
						className: "w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl shadow-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-50",
						children: [/* @__PURE__ */ _jsxDEV(Monitor, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 344,
							columnNumber: 15
						}, this), " Request Screen Share"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 339,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 308,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 248,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-100/70 dark:bg-slate-800/60 rounded-xl p-3.5 text-xs text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 space-y-1.5",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-1.5 font-semibold text-slate-800 dark:text-slate-200",
					children: [/* @__PURE__ */ _jsxDEV(Lock, { className: "w-3.5 h-3.5 text-emerald-600" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 353,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Security & Google Play Policy Assurance:" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 354,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 352,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("ul", {
					className: "list-disc list-inside space-y-1 pl-1 text-[11px] text-slate-500 dark:text-slate-400",
					children: [
						/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "No Covert Surveillance:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 357,
							columnNumber: 15
						}, this), " SafeKids explicitly complies with Google Play's Stalkerware & Spyware policy."] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 357,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Explicit Child Prompt:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 358,
							columnNumber: 15
						}, this), " The paired child Android device rings an audible chime and displays a full-screen consent dialog before video or screen sharing begins."] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 358,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Persistent Notification:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 359,
							columnNumber: 15
						}, this), " Android requires a continuous Foreground Service notification whenever camera or MediaProjection is active."] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 359,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Zero Recording Storage:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 360,
							columnNumber: 15
						}, this), " Feeds are encrypted point-to-point and never uploaded to public third-party storage."] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 360,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 356,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 351,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 167,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsUUFBUSxpQkFBaUI7QUFDbkQsU0FBUyxRQUFRLFNBQVMsYUFBYSxPQUFPLFVBQXFCLEdBQUcsZUFBb0IsWUFBWTtBQUV0RyxTQUFTLHFCQUFxQixvQkFBb0Isc0JBQXNCLDRCQUE0Qjs7O0FBUXBHLE9BQU8sTUFBTSx1QkFBMkQsRUFDdEUsT0FDQSxjQUNBLGdCQUNJO0NBQ0osTUFBTSxDQUFDLG9CQUFvQix5QkFBeUIsU0FBaUMsTUFBTTtDQUMzRixNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyx5QkFBeUI7Q0FDNUUsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBd0IsSUFBSTs7Q0FHcEUsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQTZCLElBQUk7Q0FDdkUsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSztDQUNwRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBcUMsSUFBSTtDQUM3RSxNQUFNLFdBQVcsT0FBeUIsSUFBSTs7Q0FHOUMsTUFBTSx3QkFBd0I7RUFDNUIsSUFBSSxhQUFhO0dBQ2YsWUFBWSxVQUFVLENBQUMsQ0FBQyxTQUFTLFVBQVUsTUFBTSxLQUFLLENBQUM7R0FDdkQsZUFBZSxJQUFJO0VBQ3JCO0VBQ0EsZUFBZSxLQUFLO0VBQ3BCLGNBQWMsSUFBSTtDQUNwQjtDQUVBLGdCQUFnQjtFQUNkLElBQUksU0FBUyxXQUFXLGFBQWE7R0FDbkMsU0FBUyxRQUFRLFlBQVk7RUFDL0I7Q0FDRixHQUFHLENBQUMsV0FBVyxDQUFDOztDQUdoQixnQkFBZ0I7RUFDZCxhQUFhO0dBQ1gsZ0JBQWdCO0VBQ2xCO0NBQ0YsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLGlDQUFpQyxZQUFZO0VBQ2pELGFBQWEsSUFBSTtFQUNqQixnQkFBZ0IsSUFBSTtFQUNwQixJQUFJO0dBQ0YsTUFBTSxNQUFNLE1BQU0sb0JBQW9CLE1BQU0sSUFBSSxvQkFBb0IsYUFBYTtHQUNqRixJQUFJLENBQUMsSUFBSSxTQUFTO0lBQ2hCLGdCQUFnQix1RUFBdUU7R0FDekYsT0FBTzs7SUFFTCxlQUFlO0dBQ2pCO0dBQ0EsSUFBSSxXQUFXLFVBQVU7RUFDM0IsU0FBUyxHQUFRO0dBQ2YsZ0JBQWdCLEdBQUcsV0FBVyxpQ0FBaUM7RUFDakUsVUFBVTtHQUNSLGFBQWEsS0FBSztFQUNwQjtDQUNGO0NBRUEsTUFBTSxpQ0FBaUMsWUFBWTtFQUNqRCxhQUFhLElBQUk7RUFDakIsZ0JBQWdCLElBQUk7RUFDcEIsSUFBSTtHQUNGLE1BQU0sTUFBTSxNQUFNLG1CQUFtQixNQUFNLElBQUksYUFBYTtHQUM1RCxJQUFJLENBQUMsSUFBSSxTQUFTO0lBQ2hCLGdCQUFnQixxRUFBcUU7R0FDdkYsT0FBTztJQUNMLG9CQUFvQjtHQUN0QjtHQUNBLElBQUksV0FBVyxVQUFVO0VBQzNCLFNBQVMsR0FBUTtHQUNmLGdCQUFnQixHQUFHLFdBQVcsdUNBQXVDO0VBQ3ZFLFVBQVU7R0FDUixhQUFhLEtBQUs7RUFDcEI7Q0FDRjs7Q0FHQSxNQUFNLGlCQUFpQixZQUFZO0VBQ2pDLElBQUk7R0FDRixnQkFBZ0I7R0FDaEIsTUFBTSxjQUFzQztJQUMxQyxPQUFPO0tBQ0wsWUFBWTtLQUNaLE9BQU8sRUFBRSxPQUFPLEtBQUs7S0FDckIsUUFBUSxFQUFFLE9BQU8sSUFBSTtJQUN2QjtJQUNBLE9BQU87R0FDVDtHQUNBLE1BQU0sU0FBUyxNQUFNLFVBQVUsYUFBYSxhQUFhLFdBQVc7R0FDcEUsZUFBZSxNQUFNO0dBQ3JCLGVBQWUsSUFBSTtHQUNuQixjQUFjLFFBQVE7R0FDdEIsSUFBSSxTQUFTLFNBQVM7SUFDcEIsU0FBUyxRQUFRLFlBQVk7R0FDL0I7RUFDRixTQUFTLEtBQVU7R0FDakIsUUFBUSxLQUFLLGlEQUFpRCxHQUFHO0dBQ2pFLGdCQUFnQix5QkFBeUIsS0FBSyxXQUFXLHFDQUFxQztFQUNoRztDQUNGO0NBRUEsTUFBTSxzQkFBc0IsWUFBWTtFQUN0QyxJQUFJO0dBQ0YsZ0JBQWdCO0dBQ2hCLElBQUksQ0FBQyxVQUFVLGFBQWEsaUJBQWlCO0lBQzNDLE1BQU0sSUFBSSxNQUFNLHFFQUFxRTtHQUN2RjtHQUNBLE1BQU0sU0FBUyxNQUFNLFVBQVUsYUFBYSxnQkFBZ0IsRUFDMUQsT0FBTyxLQUNULENBQUM7O0dBRUQsT0FBTyxlQUFlLENBQUMsQ0FBQyxFQUFFLENBQUMsZ0JBQWdCO0lBQ3pDLGdCQUFnQjtJQUNoQixxQkFBcUIsTUFBTSxJQUFJLE9BQU87R0FDeEM7R0FDQSxlQUFlLE1BQU07R0FDckIsZUFBZSxJQUFJO0dBQ25CLGNBQWMsUUFBUTtHQUN0QixJQUFJLFNBQVMsU0FBUztJQUNwQixTQUFTLFFBQVEsWUFBWTtHQUMvQjtFQUNGLFNBQVMsS0FBVTtHQUNqQixRQUFRLEtBQUssa0NBQWtDLEdBQUc7R0FDbEQsZ0JBQWdCLHdCQUF3QixLQUFLLFdBQVcsc0NBQXNDO0VBQ2hHO0NBQ0Y7Q0FFQSxNQUFNLG1CQUFtQixZQUFZO0VBQ25DLGdCQUFnQjtFQUNoQixJQUFJLGVBQWUsWUFBWSxNQUFNLGdCQUFnQixlQUFlO0dBQ2xFLE1BQU0scUJBQXFCLE1BQU0sSUFBSSxPQUFPO0VBQzlDO0VBQ0EsSUFBSSxlQUFlLFlBQVksTUFBTSxnQkFBZ0IsZUFBZTtHQUNsRSxNQUFNLHFCQUFxQixNQUFNLElBQUksT0FBTztFQUM5QztFQUNBLElBQUksV0FBVyxVQUFVO0NBQzNCO0NBRUEsTUFBTSxxQkFBcUI7RUFDekIsSUFBSSxDQUFDLFNBQVMsU0FBUztFQUN2QixNQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7RUFDOUMsT0FBTyxRQUFRLFNBQVMsUUFBUSxjQUFjO0VBQzlDLE9BQU8sU0FBUyxTQUFTLFFBQVEsZUFBZTtFQUNoRCxNQUFNLE1BQU0sT0FBTyxXQUFXLElBQUk7RUFDbEMsSUFBSSxLQUFLO0dBQ1AsSUFBSSxVQUFVLFNBQVMsU0FBUyxHQUFHLEdBQUcsT0FBTyxPQUFPLE9BQU8sTUFBTTtHQUNqRSxNQUFNLFVBQVUsT0FBTyxVQUFVLFdBQVc7R0FDNUMsTUFBTSxJQUFJLFNBQVMsY0FBYyxHQUFHO0dBQ3BDLEVBQUUsT0FBTztHQUNULEVBQUUsV0FBVyxtQkFBbUIsTUFBTSxLQUFLLEdBQUcsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxRQUFRLFNBQVMsR0FBRyxFQUFFO0dBQzdGLEVBQUUsTUFBTTtFQUNWO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBdUQ7S0FFakU7Ozs7ZUFDSix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEIsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSxjQUFlOzs7O2dCQUFDLHdCQUNuQzs7Ozs7YUFDSDs7Ozs7Y0FDTCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFrRDtJQUU1RDs7OztZQUNBOzs7O2NBRUosZUFDQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUseUZBQStGOzs7O2lCQUMvRyx3QkFBQyxRQUFELEVBQU0sV0FBVSwyREFBaUU7Ozs7ZUFDN0U7Ozs7OztNQUNOLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF3RjtNQUVsRzs7Ozs7TUFDTix3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7aUJBRlosQ0FJRSx3QkFBQyxHQUFELEVBQUcsV0FBVSxjQUFlOzs7O2lCQUFDLGNBQ3ZCOzs7Ozs7S0FDTDs7Ozs7WUFFSjs7Ozs7O0dBRUosZ0JBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLGtDQUFtQzs7OztjQUM1RCx3QkFBQyxRQUFELFlBQU8sYUFBbUI7Ozs7WUFDdkI7Ozs7OztHQUlOLGNBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFNBQUQ7TUFDRSxLQUFLO01BQ0w7TUFDQTtNQUNBO01BQ0EsV0FBVTtLQUNYOzs7OztLQUdELHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsd0RBQThEOzs7OztPQUM5RSx3QkFBQyxRQUFELFlBQ0csZUFBZSxXQUFXLFdBQVcsdUJBQXVCLFNBQVMsVUFBVSxPQUFPLEtBQUssY0FDeEY7Ozs7O09BQ04sd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWlCO09BQU87Ozs7O09BQ3hDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUFrQyxNQUFNLE1BQUssV0FBb0I7Ozs7OztNQUM5RDs7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7aUJBRlosQ0FJRSx3QkFBQyxRQUFELEVBQVEsV0FBVSw0QkFBNkI7Ozs7aUJBQUMsZ0JBQzFDOzs7OztnQkFDUix3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7aUJBRlosQ0FJRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O2lCQUFDLE9BQzlCOzs7OztjQUNMOzs7Ozs7SUFDRjs7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7O09BQzFCOzs7O2lCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBMkQ7T0FFckU7Ozs7aUJBQ0osd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQTZDO09BRXZEOzs7O2VBQ0E7Ozs7ZUFDRjs7Ozs7Z0JBR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFzRTtNQUVoRjs7OztnQkFDUCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsZUFBZSxzQkFBc0IsTUFBTTtRQUMzQyxXQUFXLDhFQUNULHVCQUF1QixTQUNuQixxREFDQTtrQkFFUDtPQUVPOzs7O2lCQUNSLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsZUFBZSxzQkFBc0IsYUFBYTtRQUNsRCxXQUFXLDhFQUNULHVCQUF1QixnQkFDbkIscURBQ0E7a0JBRVA7T0FFTzs7OztlQUNMOzs7OztjQUNGOzs7O2NBQ0Y7Ozs7O2VBRUwsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxVQUFVO01BQ1YsV0FBVTtnQkFIWixDQUtFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLFVBQVc7Ozs7Z0JBQUMsc0JBQ3ZCOzs7OzthQUNMOzs7OztjQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsU0FBRCxFQUFTLFdBQVUsVUFBVzs7Ozs7T0FDM0I7Ozs7aUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUEyRDtPQUVyRTs7OztpQkFDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBNkM7T0FFdkQ7Ozs7ZUFDQTs7OztlQUNGOzs7OztnQkFHTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQXNFO01BRWhGOzs7O2dCQUNQLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsT0FBTztPQUNQLFdBQVcsTUFBTSxpQkFBaUIsRUFBRSxPQUFPLEtBQUs7T0FDaEQsYUFBWTtPQUNaLFdBQVU7TUFDWDs7OztjQUNFOzs7O2NBQ0Y7Ozs7O2VBRUwsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxVQUFVO01BQ1YsV0FBVTtnQkFIWixDQUtFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7Z0JBQUMsdUJBQ3pCOzs7OzthQUNMOzs7OztZQUNGOzs7Ozs7R0FJUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLCtCQUFnQzs7OztlQUNoRCx3QkFBQyxRQUFELFlBQU0sMkNBQThDOzs7O2FBQ2pEOzs7OztjQUNMLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQ7TUFDRSx3QkFBQyxNQUFELGFBQUksd0JBQUMsVUFBRCxZQUFRLDBCQUErQjs7OztnQkFBQyxnRkFBdUY7Ozs7O01BQ25JLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxVQUFELFlBQVEseUJBQThCOzs7O2dCQUFDLDBJQUE0STs7Ozs7TUFDdkwsd0JBQUMsTUFBRCxhQUFJLHdCQUFDLFVBQUQsWUFBUSwyQkFBZ0M7Ozs7Z0JBQUMsOEdBQWdIOzs7OztNQUM3Six3QkFBQyxNQUFELGFBQUksd0JBQUMsVUFBRCxZQUFRLDBCQUErQjs7OztnQkFBQyx1RkFBeUY7Ozs7O0tBQ25JOzs7OztZQUNEOzs7Ozs7RUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2FtZXJhU2NyZWVuU2Vzc2lvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VSZWYsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IENhbWVyYSwgTW9uaXRvciwgU2hpZWxkQ2hlY2ssIFZpZGVvLCBWaWRlb09mZiwgUmVmcmVzaEN3LCBYLCBBbGVydFRyaWFuZ2xlLCBFeWUsIExvY2sgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgQ2hpbGREZXZpY2UgfSBmcm9tICcuLi90eXBlcy9zYWZla2lkcyc7XG5pbXBvcnQgeyByZXF1ZXN0Q2FtZXJhTG9va0luLCByZXF1ZXN0U2NyZWVuU2hhcmUsIHJlc3BvbmRDYW1lcmFSZXF1ZXN0LCByZXNwb25kU2NyZWVuUmVxdWVzdCB9IGZyb20gJy4uL3NlcnZpY2VzL2FwaSc7XG5cbmludGVyZmFjZSBDYW1lcmFTY3JlZW5TZXNzaW9uUHJvcHMge1xuICBjaGlsZDogQ2hpbGREZXZpY2U7XG4gIGlzUGFyZW50VmlldzogYm9vbGVhbjtcbiAgb25SZWZyZXNoPzogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IENhbWVyYVNjcmVlblNlc3Npb246IFJlYWN0LkZDPENhbWVyYVNjcmVlblNlc3Npb25Qcm9wcz4gPSAoe1xuICBjaGlsZCxcbiAgaXNQYXJlbnRWaWV3LFxuICBvblJlZnJlc2gsXG59KSA9PiB7XG4gIGNvbnN0IFtzZWxlY3RlZEZhY2luZ01vZGUsIHNldFNlbGVjdGVkRmFjaW5nTW9kZV0gPSB1c2VTdGF0ZTwndXNlcicgfCAnZW52aXJvbm1lbnQnPigndXNlcicpO1xuICBjb25zdCBbcmVxdWVzdFJlYXNvbiwgc2V0UmVxdWVzdFJlYXNvbl0gPSB1c2VTdGF0ZSgnU2FmZXR5ICYgTG9jYXRpb24gQ2hlY2snKTtcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3Nlc3Npb25FcnJvciwgc2V0U2Vzc2lvbkVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBcbiAgLy8gUmVhbCBMb2NhbCBNZWRpYSBTdHJlYW0gKHdoZW4gcnVubmluZyBjYW1lcmEvc2NyZWVuKVxuICBjb25zdCBbbG9jYWxTdHJlYW0sIHNldExvY2FsU3RyZWFtXSA9IHVzZVN0YXRlPE1lZGlhU3RyZWFtIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtpc1N0cmVhbWluZywgc2V0SXNTdHJlYW1pbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbc3RyZWFtVHlwZSwgc2V0U3RyZWFtVHlwZV0gPSB1c2VTdGF0ZTwnY2FtZXJhJyB8ICdzY3JlZW4nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHZpZGVvUmVmID0gdXNlUmVmPEhUTUxWaWRlb0VsZW1lbnQ+KG51bGwpO1xuXG4gIC8vIFN0b3AgYWxsIGFjdGl2ZSB0cmFja3NcbiAgY29uc3Qgc3RvcExvY2FsU3RyZWFtID0gKCkgPT4ge1xuICAgIGlmIChsb2NhbFN0cmVhbSkge1xuICAgICAgbG9jYWxTdHJlYW0uZ2V0VHJhY2tzKCkuZm9yRWFjaCgodHJhY2spID0+IHRyYWNrLnN0b3AoKSk7XG4gICAgICBzZXRMb2NhbFN0cmVhbShudWxsKTtcbiAgICB9XG4gICAgc2V0SXNTdHJlYW1pbmcoZmFsc2UpO1xuICAgIHNldFN0cmVhbVR5cGUobnVsbCk7XG4gIH07XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAodmlkZW9SZWYuY3VycmVudCAmJiBsb2NhbFN0cmVhbSkge1xuICAgICAgdmlkZW9SZWYuY3VycmVudC5zcmNPYmplY3QgPSBsb2NhbFN0cmVhbTtcbiAgICB9XG4gIH0sIFtsb2NhbFN0cmVhbV0pO1xuXG4gIC8vIENsZWFudXAgb24gdW5tb3VudFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBzdG9wTG9jYWxTdHJlYW0oKTtcbiAgICB9O1xuICB9LCBbXSk7XG5cbiAgY29uc3QgaGFuZGxlU3RhcnRQYXJlbnRDYW1lcmFSZXF1ZXN0ID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldElzTG9hZGluZyh0cnVlKTtcbiAgICBzZXRTZXNzaW9uRXJyb3IobnVsbCk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHJlcXVlc3RDYW1lcmFMb29rSW4oY2hpbGQuaWQsIHNlbGVjdGVkRmFjaW5nTW9kZSwgcmVxdWVzdFJlYXNvbik7XG4gICAgICBpZiAoIXJlcy5zdWNjZXNzKSB7XG4gICAgICAgIHNldFNlc3Npb25FcnJvcignQ291bGQgbm90IHNlbmQgY2FtZXJhIGxvb2staW4gcmVxdWVzdC4gVmVyaWZ5IGNoaWxkIGRldmljZSBpcyBvbmxpbmUuJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBBbHNvIHByb3ZpZGUgYSBsb2NhbCBjYW1lcmEgdGVzdCB2aWV3IGlmIGNoaWxkIGRldmljZSBpcyBvbiB0aGlzIG1hY2hpbmVcbiAgICAgICAgdHJ5TG9jYWxDYW1lcmEoKTtcbiAgICAgIH1cbiAgICAgIGlmIChvblJlZnJlc2gpIG9uUmVmcmVzaCgpO1xuICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgc2V0U2Vzc2lvbkVycm9yKGU/Lm1lc3NhZ2UgfHwgJ0Vycm9yIGluaXRpYXRpbmcgY2FtZXJhIHNlc3Npb24nKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU3RhcnRQYXJlbnRTY3JlZW5SZXF1ZXN0ID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldElzTG9hZGluZyh0cnVlKTtcbiAgICBzZXRTZXNzaW9uRXJyb3IobnVsbCk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHJlcXVlc3RTY3JlZW5TaGFyZShjaGlsZC5pZCwgcmVxdWVzdFJlYXNvbik7XG4gICAgICBpZiAoIXJlcy5zdWNjZXNzKSB7XG4gICAgICAgIHNldFNlc3Npb25FcnJvcignQ291bGQgbm90IHNlbmQgc2NyZWVuIHNoYXJlIHJlcXVlc3QuIFZlcmlmeSBjaGlsZCBkZXZpY2UgaXMgb25saW5lLicpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdHJ5TG9jYWxTY3JlZW5TaGFyZSgpO1xuICAgICAgfVxuICAgICAgaWYgKG9uUmVmcmVzaCkgb25SZWZyZXNoKCk7XG4gICAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgICBzZXRTZXNzaW9uRXJyb3IoZT8ubWVzc2FnZSB8fCAnRXJyb3IgaW5pdGlhdGluZyBzY3JlZW4gc2hhcmUgc2Vzc2lvbicpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICAvLyBSZWFsIFdlYiBNZWRpYSBDYXB0dXJlIGZvciBDaGlsZCAvIFRlc3QgRGV2aWNlXG4gIGNvbnN0IHRyeUxvY2FsQ2FtZXJhID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBzdG9wTG9jYWxTdHJlYW0oKTtcbiAgICAgIGNvbnN0IGNvbnN0cmFpbnRzOiBNZWRpYVN0cmVhbUNvbnN0cmFpbnRzID0ge1xuICAgICAgICB2aWRlbzoge1xuICAgICAgICAgIGZhY2luZ01vZGU6IHNlbGVjdGVkRmFjaW5nTW9kZSxcbiAgICAgICAgICB3aWR0aDogeyBpZGVhbDogMTI4MCB9LFxuICAgICAgICAgIGhlaWdodDogeyBpZGVhbDogNzIwIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGF1ZGlvOiBmYWxzZSxcbiAgICAgIH07XG4gICAgICBjb25zdCBzdHJlYW0gPSBhd2FpdCBuYXZpZ2F0b3IubWVkaWFEZXZpY2VzLmdldFVzZXJNZWRpYShjb25zdHJhaW50cyk7XG4gICAgICBzZXRMb2NhbFN0cmVhbShzdHJlYW0pO1xuICAgICAgc2V0SXNTdHJlYW1pbmcodHJ1ZSk7XG4gICAgICBzZXRTdHJlYW1UeXBlKCdjYW1lcmEnKTtcbiAgICAgIGlmICh2aWRlb1JlZi5jdXJyZW50KSB7XG4gICAgICAgIHZpZGVvUmVmLmN1cnJlbnQuc3JjT2JqZWN0ID0gc3RyZWFtO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICBjb25zb2xlLndhcm4oJ0NhbWVyYSBhY2Nlc3MgcHJvbXB0IGRlY2xpbmVkIG9yIHVuc3VwcG9ydGVkOicsIGVycik7XG4gICAgICBzZXRTZXNzaW9uRXJyb3IoYENhbWVyYSBhY2Nlc3Mgc3RhdHVzOiAke2Vycj8ubWVzc2FnZSB8fCAnRGV2aWNlIGNhbWVyYSBwZXJtaXNzaW9uIHJlcXVpcmVkJ31gKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgdHJ5TG9jYWxTY3JlZW5TaGFyZSA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgc3RvcExvY2FsU3RyZWFtKCk7XG4gICAgICBpZiAoIW5hdmlnYXRvci5tZWRpYURldmljZXMuZ2V0RGlzcGxheU1lZGlhKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignU2NyZWVuIHNoYXJpbmcgQVBJIGlzIG5vdCBzdXBwb3J0ZWQgb24gdGhpcyBicm93c2VyIG9yIGVudmlyb25tZW50LicpO1xuICAgICAgfVxuICAgICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgbmF2aWdhdG9yLm1lZGlhRGV2aWNlcy5nZXREaXNwbGF5TWVkaWEoe1xuICAgICAgICB2aWRlbzogdHJ1ZSxcbiAgICAgIH0pO1xuICAgICAgLy8gSGFuZGxlIHdoZW4gY2hpbGQgY2xpY2tzIHN0YW5kYXJkIGJyb3dzZXIgXCJTdG9wIFNoYXJpbmdcIiBiYXJcbiAgICAgIHN0cmVhbS5nZXRWaWRlb1RyYWNrcygpWzBdLm9uZW5kZWQgPSAoKSA9PiB7XG4gICAgICAgIHN0b3BMb2NhbFN0cmVhbSgpO1xuICAgICAgICByZXNwb25kU2NyZWVuUmVxdWVzdChjaGlsZC5pZCwgJ2VuZGVkJyk7XG4gICAgICB9O1xuICAgICAgc2V0TG9jYWxTdHJlYW0oc3RyZWFtKTtcbiAgICAgIHNldElzU3RyZWFtaW5nKHRydWUpO1xuICAgICAgc2V0U3RyZWFtVHlwZSgnc2NyZWVuJyk7XG4gICAgICBpZiAodmlkZW9SZWYuY3VycmVudCkge1xuICAgICAgICB2aWRlb1JlZi5jdXJyZW50LnNyY09iamVjdCA9IHN0cmVhbTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgY29uc29sZS53YXJuKCdTY3JlZW4gc2hhcmUgcHJvbXB0IGNhbmNlbGxlZDonLCBlcnIpO1xuICAgICAgc2V0U2Vzc2lvbkVycm9yKGBTY3JlZW4gc2hhcmUgc3RhdHVzOiAke2Vycj8ubWVzc2FnZSB8fCAnU2NyZWVuIGNhcHR1cmUgcGVybWlzc2lvbiByZXF1aXJlZCd9YCk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUVuZFNlc3Npb24gPSBhc3luYyAoKSA9PiB7XG4gICAgc3RvcExvY2FsU3RyZWFtKCk7XG4gICAgaWYgKHN0cmVhbVR5cGUgPT09ICdjYW1lcmEnIHx8IGNoaWxkLmFjdGl2ZVNlc3Npb25zPy5jYW1lcmFSZXF1ZXN0KSB7XG4gICAgICBhd2FpdCByZXNwb25kQ2FtZXJhUmVxdWVzdChjaGlsZC5pZCwgJ2VuZGVkJyk7XG4gICAgfVxuICAgIGlmIChzdHJlYW1UeXBlID09PSAnc2NyZWVuJyB8fCBjaGlsZC5hY3RpdmVTZXNzaW9ucz8uc2NyZWVuUmVxdWVzdCkge1xuICAgICAgYXdhaXQgcmVzcG9uZFNjcmVlblJlcXVlc3QoY2hpbGQuaWQsICdlbmRlZCcpO1xuICAgIH1cbiAgICBpZiAob25SZWZyZXNoKSBvblJlZnJlc2goKTtcbiAgfTtcblxuICBjb25zdCB0YWtlU25hcHNob3QgPSAoKSA9PiB7XG4gICAgaWYgKCF2aWRlb1JlZi5jdXJyZW50KSByZXR1cm47XG4gICAgY29uc3QgY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgY2FudmFzLndpZHRoID0gdmlkZW9SZWYuY3VycmVudC52aWRlb1dpZHRoIHx8IDY0MDtcbiAgICBjYW52YXMuaGVpZ2h0ID0gdmlkZW9SZWYuY3VycmVudC52aWRlb0hlaWdodCB8fCA0ODA7XG4gICAgY29uc3QgY3R4ID0gY2FudmFzLmdldENvbnRleHQoJzJkJyk7XG4gICAgaWYgKGN0eCkge1xuICAgICAgY3R4LmRyYXdJbWFnZSh2aWRlb1JlZi5jdXJyZW50LCAwLCAwLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xuICAgICAgY29uc3QgZGF0YVVybCA9IGNhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL3BuZycpO1xuICAgICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICAgIGEuaHJlZiA9IGRhdGFVcmw7XG4gICAgICBhLmRvd25sb2FkID0gYFNhZmVLaWRzLUxvb2tJbi0ke2NoaWxkLm5hbWV9LSR7bmV3IERhdGUoKS50b0lTT1N0cmluZygpLnJlcGxhY2UoL1s6Ll0vZywgJy0nKX0ucG5nYDtcbiAgICAgIGEuY2xpY2soKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBwLTUgc2hhZG93LXNtIHNwYWNlLXktNVwiPlxuICAgICAgey8qIEhlYWRlciBhbmQgQ29tcGxpYW5jZSBEaXNjbG9zdXJlICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcGItNFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1sZyB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgIExpdmUgQ2FtZXJhICYgU2NyZWVuIENoZWNrLUluXG4gICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctZW1lcmFsZC0xMDAgZGFyazpiZy1lbWVyYWxkLTk1MC82MCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCB0ZXh0LXhzIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtc2VtaWJvbGQgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTMwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBHb29nbGUgUGxheSBDb21wbGlhbnRcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgbXQtMVwiPlxuICAgICAgICAgICAgUHJpdmFjeS1maXJzdCBsb29rLWluLiBOZXZlciBzdGVhbHRoIG9yIHNweXdhcmU6IHJlcXVpcmVzIGNoaWxkIGNvbnNlbnQgcHJvbXB0IGFuZCB2aXNpYmxlIGluZGljYXRvci5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtpc1N0cmVhbWluZyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBoLTMgdy0zXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFuaW1hdGUtcGluZyBhYnNvbHV0ZSBpbmxpbmUtZmxleCBoLWZ1bGwgdy1mdWxsIHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTQwMCBvcGFjaXR5LTc1XCI+PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBpbmxpbmUtZmxleCByb3VuZGVkLWZ1bGwgaC0zIHctMyBiZy1lbWVyYWxkLTUwMFwiPjwvc3Bhbj5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgTGl2ZSBGZWVkIEFjdGl2ZVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVFbmRTZXNzaW9ufVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC0yIHB4LTMgcHktMS41IGJnLXJvc2UtNjAwIGhvdmVyOmJnLXJvc2UtNzAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBFbmQgU2Vzc2lvblxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAge3Nlc3Npb25FcnJvciAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYW1iZXItNTAgZGFyazpiZy1hbWJlci05NTAvNDAgYm9yZGVyIGJvcmRlci1hbWJlci0yMDAgZGFyazpib3JkZXItYW1iZXItOTAwIHJvdW5kZWQteGwgcC0zIHRleHQteHMgdGV4dC1hbWJlci04MDAgZGFyazp0ZXh0LWFtYmVyLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNCBoLTQgc2hyaW5rLTAgdGV4dC1hbWJlci02MDBcIiAvPlxuICAgICAgICAgIDxzcGFuPntzZXNzaW9uRXJyb3J9PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBNYWluIFN0cmVhbSBQbGF5ZXIgKi99XG4gICAgICB7aXNTdHJlYW1pbmcgPyAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gYmctYmxhY2sgYXNwZWN0LXZpZGVvIG1heC1oLVs0NjBweF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgc2hhZG93LWlubmVyIGdyb3VwXCI+XG4gICAgICAgICAgPHZpZGVvXG4gICAgICAgICAgICByZWY9e3ZpZGVvUmVmfVxuICAgICAgICAgICAgYXV0b1BsYXlcbiAgICAgICAgICAgIHBsYXlzSW5saW5lXG4gICAgICAgICAgICBtdXRlZFxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY29udGFpblwiXG4gICAgICAgICAgLz5cblxuICAgICAgICAgIHsvKiBQZXJzaXN0ZW50IFByaXZhY3kgV2F0ZXJtYXJrICYgQ29udHJvbHMgT3ZlcmxheSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIGxlZnQtMyBiZy1ibGFjay83MCBiYWNrZHJvcC1ibHVyLW1kIHB4LTMgcHktMS41IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci13aGl0ZS8yMCB0ZXh0LXdoaXRlIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMi41IGgtMi41IHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTUwMCBhbmltYXRlLXB1bHNlXCI+PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgIHtzdHJlYW1UeXBlID09PSAnY2FtZXJhJyA/IGBDYW1lcmEgKCR7c2VsZWN0ZWRGYWNpbmdNb2RlID09PSAndXNlcicgPyAnRnJvbnQnIDogJ1JlYXInfSlgIDogJ0xpdmUgU2NyZWVuJ31cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCI+fDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwXCI+e2NoaWxkLm5hbWV9JmFwb3M7cyBEZXZpY2U8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0zIHJpZ2h0LTMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17dGFrZVNuYXBzaG90fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZS85MCBob3ZlcjpiZy13aGl0ZSB0ZXh0LXNsYXRlLTgwMCB0ZXh0LXhzIHB4LTMgcHktMS41IHJvdW5kZWQtbGcgZm9udC1tZWRpdW0gc2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8Q2FtZXJhIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYmx1ZS02MDBcIiAvPiBTYXZlIFNuYXBzaG90XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRW5kU2Vzc2lvbn1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctcm9zZS02MDAgaG92ZXI6Ymctcm9zZS03MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIHB4LTMgcHktMS41IHJvdW5kZWQtbGcgZm9udC1tZWRpdW0gc2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8VmlkZW9PZmYgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBTdG9wXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICAvKiBBY3Rpb24gTGF1bmNoZXIgZm9yIFBhcmVudCAqL1xuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICB7LyogTGl2ZSBDYW1lcmEgQ2FyZCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtNCBiZy1zbGF0ZS01MC81MCBkYXJrOmJnLXNsYXRlLTgwMC80MCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLWJsdWUtMTAwIGRhcms6YmctYmx1ZS05MDAvNDAgdGV4dC1ibHVlLTYwMCBkYXJrOnRleHQtYmx1ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0xMDAgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAgICBMaXZlIENhbWVyYSBMb29rLUluXG4gICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIFBhcmVudC1pbml0aWF0ZWQgdmlkZW8gY2hlY2staW4gd2l0aCBjaGlsZCBhcHByb3ZhbC5cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIENhbWVyYSBGYWNpbmcgU2VsZWN0b3IgKi99XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIENhbWVyYSBMZW5zXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkRmFjaW5nTW9kZSgndXNlcicpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTIgdGV4dC14cyByb3VuZGVkLWxnIGZvbnQtbWVkaXVtIGJvcmRlciB0ZXh0LWNlbnRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRmFjaW5nTW9kZSA9PT0gJ3VzZXInXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1ibHVlLTYwMCBzaGFkb3ctc20nXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAg8J+ksyBGcm9udCAoU2VsZmllKVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZEZhY2luZ01vZGUoJ2Vudmlyb25tZW50Jyl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMiB0ZXh0LXhzIHJvdW5kZWQtbGcgZm9udC1tZWRpdW0gYm9yZGVyIHRleHQtY2VudGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRGYWNpbmdNb2RlID09PSAnZW52aXJvbm1lbnQnXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1ibHVlLTYwMCBzaGFkb3ctc20nXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAg8J+TtyBSZWFyIChFbnZpcm9ubWVudClcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVN0YXJ0UGFyZW50Q2FtZXJhUmVxdWVzdH1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ31cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIuNSBweC00IGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNzAwIHRleHQtd2hpdGUgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQteGwgc2hhZG93LXNtIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8VmlkZW8gY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IFJlcXVlc3QgQ2FtZXJhIEZlZWRcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIExpdmUgU2NyZWVuIFNoYXJlIENhcmQgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCBwLTQgYmctc2xhdGUtNTAvNTAgZGFyazpiZy1zbGF0ZS04MDAvNDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteS00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC14bCBiZy1pbmRpZ28tMTAwIGRhcms6YmctaW5kaWdvLTkwMC80MCB0ZXh0LWluZGlnby02MDAgZGFyazp0ZXh0LWluZGlnby00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxNb25pdG9yIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgTGl2ZSBTY3JlZW4gU2hhcmluZ1xuICAgICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICBPZmZpY2lhbCBBbmRyb2lkIE1lZGlhUHJvamVjdGlvbiBzY3JlZW4gY2FwdHVyZS5cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFJlYXNvbiBub3RlICovfVxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMS41XCI+XG4gICAgICAgICAgICAgICAgICBSZXF1ZXN0IFJlYXNvbiAoc2hvd24gdG8gY2hpbGQpXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtyZXF1ZXN0UmVhc29ufVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZXF1ZXN0UmVhc29uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBDaGVja2luZyBob21ld29yayBwcm9ncmVzc1wiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTdGFydFBhcmVudFNjcmVlblJlcXVlc3R9XG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yLjUgcHgtNCBiZy1pbmRpZ28tNjAwIGhvdmVyOmJnLWluZGlnby03MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC14bCBzaGFkb3ctc20gdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxNb25pdG9yIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiBSZXF1ZXN0IFNjcmVlbiBTaGFyZVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIEFuZHJvaWQgUGxheSBTdG9yZSBDb21wbGlhbmNlIERldGFpbHMgQm94ICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS0xMDAvNzAgZGFyazpiZy1zbGF0ZS04MDAvNjAgcm91bmRlZC14bCBwLTMuNSB0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS00MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHNwYWNlLXktMS41XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cbiAgICAgICAgICA8c3Bhbj5TZWN1cml0eSAmIEdvb2dsZSBQbGF5IFBvbGljeSBBc3N1cmFuY2U6PC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPHVsIGNsYXNzTmFtZT1cImxpc3QtZGlzYyBsaXN0LWluc2lkZSBzcGFjZS15LTEgcGwtMSB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgPGxpPjxzdHJvbmc+Tm8gQ292ZXJ0IFN1cnZlaWxsYW5jZTo8L3N0cm9uZz4gU2FmZUtpZHMgZXhwbGljaXRseSBjb21wbGllcyB3aXRoIEdvb2dsZSBQbGF5JmFwb3M7cyBTdGFsa2Vyd2FyZSAmIFNweXdhcmUgcG9saWN5LjwvbGk+XG4gICAgICAgICAgPGxpPjxzdHJvbmc+RXhwbGljaXQgQ2hpbGQgUHJvbXB0Ojwvc3Ryb25nPiBUaGUgcGFpcmVkIGNoaWxkIEFuZHJvaWQgZGV2aWNlIHJpbmdzIGFuIGF1ZGlibGUgY2hpbWUgYW5kIGRpc3BsYXlzIGEgZnVsbC1zY3JlZW4gY29uc2VudCBkaWFsb2cgYmVmb3JlIHZpZGVvIG9yIHNjcmVlbiBzaGFyaW5nIGJlZ2lucy48L2xpPlxuICAgICAgICAgIDxsaT48c3Ryb25nPlBlcnNpc3RlbnQgTm90aWZpY2F0aW9uOjwvc3Ryb25nPiBBbmRyb2lkIHJlcXVpcmVzIGEgY29udGludW91cyBGb3JlZ3JvdW5kIFNlcnZpY2Ugbm90aWZpY2F0aW9uIHdoZW5ldmVyIGNhbWVyYSBvciBNZWRpYVByb2plY3Rpb24gaXMgYWN0aXZlLjwvbGk+XG4gICAgICAgICAgPGxpPjxzdHJvbmc+WmVybyBSZWNvcmRpbmcgU3RvcmFnZTo8L3N0cm9uZz4gRmVlZHMgYXJlIGVuY3J5cHRlZCBwb2ludC10by1wb2ludCBhbmQgbmV2ZXIgdXBsb2FkZWQgdG8gcHVibGljIHRoaXJkLXBhcnR5IHN0b3JhZ2UuPC9saT5cbiAgICAgICAgPC91bD5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==