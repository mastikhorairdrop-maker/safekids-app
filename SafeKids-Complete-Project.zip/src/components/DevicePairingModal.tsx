const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=d3d47fa4";
import { Smartphone, Check, Copy, X, Clock } from "/node_modules/.vite/deps/lucide-react.js?v=d3d47fa4";
import { generatePairingCode } from "/src/services/api.ts";
var _jsxFileName = "/app/applet/src/components/DevicePairingModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=d3d47fa4";
export const DevicePairingModal = ({ isOpen, onClose, onDevicePaired }) => {
	const [childName, setChildName] = useState("Noah");
	const [childAge, setChildAge] = useState(9);
	const [deviceModel, setDeviceModel] = useState("Samsung Galaxy A15");
	const [pairingData, setPairingData] = useState(null);
	const [timeLeftSeconds, setTimeLeftSeconds] = useState(0);
	const [copied, setCopied] = useState(false);
	const [isGenerating, setIsGenerating] = useState(false);
	useEffect(() => {
		if (isOpen) {
			handleGenerate();
		}
	}, [isOpen]);
	useEffect(() => {
		if (!pairingData) return;
		const interval = setInterval(() => {
			const remaining = Math.max(0, Math.floor((pairingData.expiresAt - Date.now()) / 1e3));
			setTimeLeftSeconds(remaining);
			if (remaining <= 0) {
				clearInterval(interval);
			}
		}, 1e3);
		return () => clearInterval(interval);
	}, [pairingData]);
	const handleGenerate = async () => {
		setIsGenerating(true);
		const data = await generatePairingCode(childName, childAge, deviceModel);
		if (data) {
			setPairingData({
				code: data.code,
				expiresAt: data.expiresAt
			});
			setTimeLeftSeconds(Math.max(0, Math.floor((data.expiresAt - Date.now()) / 1e3)));
		}
		setIsGenerating(false);
	};
	const handleCopyCode = () => {
		if (pairingData) {
			navigator.clipboard.writeText(pairingData.code);
			setCopied(true);
			setTimeout(() => setCopied(false), 2e3);
		}
	};
	if (!isOpen) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl animate-in zoom-in-95",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center",
							children: /* @__PURE__ */ _jsxDEV(Smartphone, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-bold text-base text-slate-900 dark:text-slate-100",
							children: "Pair Child Android Device"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 dark:text-slate-400",
							children: "Secure, expiring 6-digit handshake code"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded-lg",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-2 gap-3 text-xs",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "font-semibold text-slate-700 dark:text-slate-300 block mb-1",
						children: "Child Name"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						value: childName,
						onChange: (e) => setChildName(e.target.value),
						className: "w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 93,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "font-semibold text-slate-700 dark:text-slate-300 block mb-1",
						children: "Child Age"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "number",
						value: childAge,
						onChange: (e) => setChildAge(parseInt(e.target.value) || 8),
						className: "w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 88,
					columnNumber: 9
				}, this),
				pairingData && /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-slate-800/80 dark:to-indigo-950/40 border-2 border-blue-200 dark:border-blue-900 rounded-2xl p-5 text-center space-y-3",
					children: [
						/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest",
							children: "Enter on Child Device"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono text-4xl font-black tracking-widest text-slate-900 dark:text-white selection:bg-blue-300",
								children: pairingData.code
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleCopyCode,
								className: "p-2 bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-blue-600",
								title: "Copy Code",
								children: copied ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 text-emerald-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 129,
									columnNumber: 27
								}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 129,
									columnNumber: 76
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 124,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-center gap-1.5 text-xs text-slate-500 dark:text-slate-400",
							children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Code expires in: ", /* @__PURE__ */ _jsxDEV("strong", { children: [
								Math.floor(timeLeftSeconds / 60),
								":",
								(timeLeftSeconds % 60).toString().padStart(2, "0")
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 34
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 115,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-2 text-xs text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/40 rounded-xl p-3.5 border border-slate-200 dark:border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "font-bold text-slate-800 dark:text-slate-200 block",
						children: "Instructions on Child Phone / Tablet:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("ol", {
						className: "list-decimal list-inside space-y-1 text-[11px] leading-relaxed",
						children: [
							/* @__PURE__ */ _jsxDEV("li", { children: "Open SafeKids on the child's phone (or select Child Mode)." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 148,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", { children: [
								"Tap ",
								/* @__PURE__ */ _jsxDEV("strong", { children: "\"Link with Parent Code\"" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 21
								}, this),
								"."
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", { children: "Type in the 6-digit code shown above." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("li", { children: "Permissions (GPS Location & Accessibility) will be registered immediately." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 151,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 147,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 143,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: handleGenerate,
						disabled: isGenerating,
						className: "flex-1 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold transition-colors",
						children: "Generate New Code"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 156,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "flex-1 py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors",
						children: "Done"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 163,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 155,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 63,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQWlCLFlBQXNCLE9BQU8sTUFBTSxHQUFHLGFBQTBCO0FBQ2pGLFNBQVMsMkJBQTJCOzs7QUFRcEMsT0FBTyxNQUFNLHNCQUF5RCxFQUNwRSxRQUNBLFNBQ0EscUJBQ0k7Q0FDSixNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxNQUFNO0NBQ2pELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxDQUFDO0NBQzFDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLG9CQUFvQjtDQUNuRSxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBcUQsSUFBSTtDQUMvRixNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLENBQUM7Q0FDeEQsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEtBQUs7Q0FDMUMsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUV0RCxnQkFBZ0I7RUFDZCxJQUFJLFFBQVE7R0FDVixlQUFlO0VBQ2pCO0NBQ0YsR0FBRyxDQUFDLE1BQU0sQ0FBQztDQUVYLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxhQUFhO0VBQ2xCLE1BQU0sV0FBVyxrQkFBa0I7R0FDakMsTUFBTSxZQUFZLEtBQUssSUFBSSxHQUFHLEtBQUssT0FBTyxZQUFZLFlBQVksS0FBSyxJQUFJLEtBQUssR0FBSSxDQUFDO0dBQ3JGLG1CQUFtQixTQUFTO0dBQzVCLElBQUksYUFBYSxHQUFHO0lBQ2xCLGNBQWMsUUFBUTtHQUN4QjtFQUNGLEdBQUcsR0FBSTtFQUNQLGFBQWEsY0FBYyxRQUFRO0NBQ3JDLEdBQUcsQ0FBQyxXQUFXLENBQUM7Q0FFaEIsTUFBTSxpQkFBaUIsWUFBWTtFQUNqQyxnQkFBZ0IsSUFBSTtFQUNwQixNQUFNLE9BQU8sTUFBTSxvQkFBb0IsV0FBVyxVQUFVLFdBQVc7RUFDdkUsSUFBSSxNQUFNO0dBQ1IsZUFBZTtJQUFFLE1BQU0sS0FBSztJQUFNLFdBQVcsS0FBSztHQUFVLENBQUM7R0FDN0QsbUJBQW1CLEtBQUssSUFBSSxHQUFHLEtBQUssT0FBTyxLQUFLLFlBQVksS0FBSyxJQUFJLEtBQUssR0FBSSxDQUFDLENBQUM7RUFDbEY7RUFDQSxnQkFBZ0IsS0FBSztDQUN2QjtDQUVBLE1BQU0sdUJBQXVCO0VBQzNCLElBQUksYUFBYTtHQUNmLFVBQVUsVUFBVSxVQUFVLFlBQVksSUFBSTtHQUM5QyxVQUFVLElBQUk7R0FDZCxpQkFBaUIsVUFBVSxLQUFLLEdBQUcsR0FBSTtFQUN6QztDQUNGO0NBRUEsSUFBSSxDQUFDLFFBQVEsT0FBTztDQUVwQixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFlBQUQsRUFBWSxXQUFVLFVBQVc7Ozs7O01BQzlCOzs7O2dCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBeUQ7TUFFbkU7Ozs7Z0JBQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTZDO01BRXZEOzs7O2NBQ0E7Ozs7Y0FDRjs7Ozs7ZUFDTCx3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7S0FDbEI7Ozs7YUFDTDs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBOEQ7S0FFeEU7Ozs7ZUFDUCx3QkFBQyxTQUFEO01BQ0UsTUFBSztNQUNMLE9BQU87TUFDUCxXQUFXLE1BQU0sYUFBYSxFQUFFLE9BQU8sS0FBSztNQUM1QyxXQUFVO0tBQ1g7Ozs7YUFDRTs7OztlQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBOEQ7S0FFeEU7Ozs7ZUFDUCx3QkFBQyxTQUFEO01BQ0UsTUFBSztNQUNMLE9BQU87TUFDUCxXQUFXLE1BQU0sWUFBWSxTQUFTLEVBQUUsT0FBTyxLQUFLLEtBQUssQ0FBQztNQUMxRCxXQUFVO0tBQ1g7Ozs7YUFDRTs7OzthQUNGOzs7Ozs7SUFHSixlQUNDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBK0U7TUFFekY7Ozs7O01BRU4sd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixZQUFZO09BQ1Q7Ozs7aUJBQ04sd0JBQUMsVUFBRDtRQUNFLFNBQVM7UUFDVCxXQUFVO1FBQ1YsT0FBTTtrQkFFTCxTQUFTLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDJCQUE0Qjs7OzttQkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztPQUNoRjs7OztlQUNMOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDZCQUE4Qjs7OztpQkFDL0Msd0JBQUMsUUFBRCxhQUFNLHFCQUNhLHdCQUFDLFVBQUQ7UUFBUyxLQUFLLE1BQU0sa0JBQWtCLEVBQUU7UUFBRTtTQUFHLGtCQUFrQixHQUFFLENBQUUsU0FBUyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7T0FBVTs7OztlQUNwSDs7OztlQUNIOzs7Ozs7S0FDRjs7Ozs7O0lBSVAsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFxRDtLQUUvRDs7OztlQUNOLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkO09BQ0Usd0JBQUMsTUFBRCxZQUFJLDZEQUFtRTs7Ozs7T0FDdkUsd0JBQUMsTUFBRDtRQUFJO1FBQUksd0JBQUMsVUFBRCxZQUFRLDRCQUF5Qzs7Ozs7UUFBQztPQUFLOzs7OztPQUMvRCx3QkFBQyxNQUFELFlBQUksd0NBQXlDOzs7OztPQUM3Qyx3QkFBQyxNQUFELFlBQUksNkVBQThFOzs7OztNQUNoRjs7Ozs7YUFDRDs7Ozs7O0lBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsVUFBVTtNQUNWLFdBQVU7Z0JBQ1g7S0FFTzs7OztlQUNSLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFDWDtLQUVPOzs7O2FBQ0w7Ozs7OztHQUNGOzs7Ozs7Q0FDRjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJEZXZpY2VQYWlyaW5nTW9kYWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgUXJDb2RlLCBTbWFydHBob25lLCBTcGFya2xlcywgQ2hlY2ssIENvcHksIFgsIENsb2NrLCBBbGVydENpcmNsZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBnZW5lcmF0ZVBhaXJpbmdDb2RlIH0gZnJvbSAnLi4vc2VydmljZXMvYXBpJztcblxuaW50ZXJmYWNlIERldmljZVBhaXJpbmdNb2RhbFByb3BzIHtcbiAgaXNPcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBvbkRldmljZVBhaXJlZD86ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBEZXZpY2VQYWlyaW5nTW9kYWw6IFJlYWN0LkZDPERldmljZVBhaXJpbmdNb2RhbFByb3BzPiA9ICh7XG4gIGlzT3BlbixcbiAgb25DbG9zZSxcbiAgb25EZXZpY2VQYWlyZWQsXG59KSA9PiB7XG4gIGNvbnN0IFtjaGlsZE5hbWUsIHNldENoaWxkTmFtZV0gPSB1c2VTdGF0ZSgnTm9haCcpO1xuICBjb25zdCBbY2hpbGRBZ2UsIHNldENoaWxkQWdlXSA9IHVzZVN0YXRlKDkpO1xuICBjb25zdCBbZGV2aWNlTW9kZWwsIHNldERldmljZU1vZGVsXSA9IHVzZVN0YXRlKCdTYW1zdW5nIEdhbGF4eSBBMTUnKTtcbiAgY29uc3QgW3BhaXJpbmdEYXRhLCBzZXRQYWlyaW5nRGF0YV0gPSB1c2VTdGF0ZTx7IGNvZGU6IHN0cmluZzsgZXhwaXJlc0F0OiBudW1iZXIgfSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbdGltZUxlZnRTZWNvbmRzLCBzZXRUaW1lTGVmdFNlY29uZHNdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtjb3BpZWQsIHNldENvcGllZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpc0dlbmVyYXRpbmcsIHNldElzR2VuZXJhdGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoaXNPcGVuKSB7XG4gICAgICBoYW5kbGVHZW5lcmF0ZSgpO1xuICAgIH1cbiAgfSwgW2lzT3Blbl0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFwYWlyaW5nRGF0YSkgcmV0dXJuO1xuICAgIGNvbnN0IGludGVydmFsID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgY29uc3QgcmVtYWluaW5nID0gTWF0aC5tYXgoMCwgTWF0aC5mbG9vcigocGFpcmluZ0RhdGEuZXhwaXJlc0F0IC0gRGF0ZS5ub3coKSkgLyAxMDAwKSk7XG4gICAgICBzZXRUaW1lTGVmdFNlY29uZHMocmVtYWluaW5nKTtcbiAgICAgIGlmIChyZW1haW5pbmcgPD0gMCkge1xuICAgICAgICBjbGVhckludGVydmFsKGludGVydmFsKTtcbiAgICAgIH1cbiAgICB9LCAxMDAwKTtcbiAgICByZXR1cm4gKCkgPT4gY2xlYXJJbnRlcnZhbChpbnRlcnZhbCk7XG4gIH0sIFtwYWlyaW5nRGF0YV0pO1xuXG4gIGNvbnN0IGhhbmRsZUdlbmVyYXRlID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldElzR2VuZXJhdGluZyh0cnVlKTtcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgZ2VuZXJhdGVQYWlyaW5nQ29kZShjaGlsZE5hbWUsIGNoaWxkQWdlLCBkZXZpY2VNb2RlbCk7XG4gICAgaWYgKGRhdGEpIHtcbiAgICAgIHNldFBhaXJpbmdEYXRhKHsgY29kZTogZGF0YS5jb2RlLCBleHBpcmVzQXQ6IGRhdGEuZXhwaXJlc0F0IH0pO1xuICAgICAgc2V0VGltZUxlZnRTZWNvbmRzKE1hdGgubWF4KDAsIE1hdGguZmxvb3IoKGRhdGEuZXhwaXJlc0F0IC0gRGF0ZS5ub3coKSkgLyAxMDAwKSkpO1xuICAgIH1cbiAgICBzZXRJc0dlbmVyYXRpbmcoZmFsc2UpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNvcHlDb2RlID0gKCkgPT4ge1xuICAgIGlmIChwYWlyaW5nRGF0YSkge1xuICAgICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQocGFpcmluZ0RhdGEuY29kZSk7XG4gICAgICBzZXRDb3BpZWQodHJ1ZSk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldENvcGllZChmYWxzZSksIDIwMDApO1xuICAgIH1cbiAgfTtcblxuICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svNzAgYmFja2Ryb3AtYmx1ci1zbSB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgbWF4LXctbWQgdy1mdWxsIHAtNiBzcGFjZS15LTUgc2hhZG93LTJ4bCBhbmltYXRlLWluIHpvb20taW4tOTVcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcGItM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLXhsIGJnLWJsdWUtMTAwIGRhcms6YmctYmx1ZS05MDAvNDAgdGV4dC1ibHVlLTYwMCBkYXJrOnRleHQtYmx1ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgPFNtYXJ0cGhvbmUgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1iYXNlIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICBQYWlyIENoaWxkIEFuZHJvaWQgRGV2aWNlXG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgIFNlY3VyZSwgZXhwaXJpbmcgNi1kaWdpdCBoYW5kc2hha2UgY29kZVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS02MDAgZGFyazpob3Zlcjp0ZXh0LXNsYXRlLTIwMCBwLTEgcm91bmRlZC1sZ1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBDaGlsZCBEZXRhaWxzIElucHV0ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgdGV4dC14c1wiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGJsb2NrIG1iLTFcIj5cbiAgICAgICAgICAgICAgQ2hpbGQgTmFtZVxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtjaGlsZE5hbWV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2hpbGROYW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtc2xhdGUtMTAwXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgYmxvY2sgbWItMVwiPlxuICAgICAgICAgICAgICBDaGlsZCBBZ2VcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgIHZhbHVlPXtjaGlsZEFnZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDaGlsZEFnZShwYXJzZUludChlLnRhcmdldC52YWx1ZSkgfHwgOCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXNsYXRlLTEwMFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogUGFpcmluZyBDb2RlIEJveCAqL31cbiAgICAgICAge3BhaXJpbmdEYXRhICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MCB0by1pbmRpZ28tNTAgZGFyazpmcm9tLXNsYXRlLTgwMC84MCBkYXJrOnRvLWluZGlnby05NTAvNDAgYm9yZGVyLTIgYm9yZGVyLWJsdWUtMjAwIGRhcms6Ym9yZGVyLWJsdWUtOTAwIHJvdW5kZWQtMnhsIHAtNSB0ZXh0LWNlbnRlciBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtYmx1ZS02MDAgZGFyazp0ZXh0LWJsdWUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3RcIj5cbiAgICAgICAgICAgICAgRW50ZXIgb24gQ2hpbGQgRGV2aWNlXG4gICAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtNHhsIGZvbnQtYmxhY2sgdHJhY2tpbmctd2lkZXN0IHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBzZWxlY3Rpb246YmctYmx1ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICB7cGFpcmluZ0RhdGEuY29kZX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ29weUNvZGV9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHJvdW5kZWQteGwgc2hhZG93LXNtIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtYmx1ZS02MDBcIlxuICAgICAgICAgICAgICAgIHRpdGxlPVwiQ29weSBDb2RlXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtjb3BpZWQgPyA8Q2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNTAwXCIgLz4gOiA8Q29weSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz59XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNTAwXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgQ29kZSBleHBpcmVzIGluOiA8c3Ryb25nPntNYXRoLmZsb29yKHRpbWVMZWZ0U2Vjb25kcyAvIDYwKX06eyh0aW1lTGVmdFNlY29uZHMgJSA2MCkudG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpfTwvc3Ryb25nPlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogU3RlcHMgR3VpZGUgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIHRleHQteHMgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC80MCByb3VuZGVkLXhsIHAtMy41IGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGJsb2NrXCI+XG4gICAgICAgICAgICBJbnN0cnVjdGlvbnMgb24gQ2hpbGQgUGhvbmUgLyBUYWJsZXQ6XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxvbCBjbGFzc05hbWU9XCJsaXN0LWRlY2ltYWwgbGlzdC1pbnNpZGUgc3BhY2UteS0xIHRleHQtWzExcHhdIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgPGxpPk9wZW4gU2FmZUtpZHMgb24gdGhlIGNoaWxkJmFwb3M7cyBwaG9uZSAob3Igc2VsZWN0IENoaWxkIE1vZGUpLjwvbGk+XG4gICAgICAgICAgICA8bGk+VGFwIDxzdHJvbmc+JnF1b3Q7TGluayB3aXRoIFBhcmVudCBDb2RlJnF1b3Q7PC9zdHJvbmc+LjwvbGk+XG4gICAgICAgICAgICA8bGk+VHlwZSBpbiB0aGUgNi1kaWdpdCBjb2RlIHNob3duIGFib3ZlLjwvbGk+XG4gICAgICAgICAgICA8bGk+UGVybWlzc2lvbnMgKEdQUyBMb2NhdGlvbiAmIEFjY2Vzc2liaWxpdHkpIHdpbGwgYmUgcmVnaXN0ZXJlZCBpbW1lZGlhdGVseS48L2xpPlxuICAgICAgICAgIDwvb2w+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUdlbmVyYXRlfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzR2VuZXJhdGluZ31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0yLjUgcHgtNCBiZy1zbGF0ZS0xMDAgaG92ZXI6Ymctc2xhdGUtMjAwIGRhcms6Ymctc2xhdGUtODAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIEdlbmVyYXRlIE5ldyBDb2RlXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0yLjUgcHgtNCBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkIHNoYWRvdy1zbSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgRG9uZVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==